# [모듈 2] pose_estimation_node 실행
#   ros2 launch pkg_pose_estimation pose_estimation.launch.py                 # 단독 (autostart)
#   ros2 launch pkg_pose_estimation pose_estimation.launch.py sim:=true       # 합성 검출 발행기 동시 실행
#   ros2 launch pkg_pose_estimation pose_estimation.launch.py composed:=true  # [모듈 1]+[모듈 2] 한 컨테이너 (intra-process)
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import ComposableNodeContainer, Node
from launch_ros.descriptions import ComposableNode


def _setup(context):
    share = get_package_share_directory('pkg_pose_estimation')
    params = LaunchConfiguration('params').perform(context) or os.path.join(share, 'config', 'pose_estimation.yaml')
    sim = LaunchConfiguration('sim').perform(context).lower() == 'true'
    composed = LaunchConfiguration('composed').perform(context).lower() == 'true'
    sim_params = {
        'corner_sigma_px': float(LaunchConfiguration('sim_noise').perform(context)),
        'occlusion_ratio': float(LaunchConfiguration('sim_occlusion').perform(context)),
        'dead_camera_mask': int(LaunchConfiguration('sim_dead_mask').perform(context)),
        'blackout_start_s': float(LaunchConfiguration('sim_blackout_start').perform(context)),
        'blackout_duration_s': 1.0,
    }
    actions = []
    if composed:
        nodes = [ComposableNode(package='pkg_pose_estimation', plugin='ppe::PoseEstimationNode',
                                name='pose_estimation_node', parameters=[params, {'autostart': False}],
                                extra_arguments=[{'use_intra_process_comms': True}])]
        if sim:
            nodes.append(ComposableNode(package='pkg_pose_estimation', plugin='ppe::SyntheticTagPublisher',
                                        name='synthetic_tag_publisher', parameters=[sim_params],
                                        extra_arguments=[{'use_intra_process_comms': True}]))
        else:
            try:
                acq_share = get_package_share_directory('pkg_vision_acquisition')
                nodes.insert(0, ComposableNode(
                    package='pkg_vision_acquisition', plugin='pva::VisionAcquisitionNode',
                    name='vision_acquisition_node',
                    parameters=[os.path.join(acq_share, 'config', 'vision_acquisition.yaml')],
                    extra_arguments=[{'use_intra_process_comms': True}]))
            except Exception:  # noqa: BLE001  (모듈 1 미설치 환경)
                pass
        actions.append(ComposableNodeContainer(
            name='inhaul_vision_container', namespace='', package='rclcpp_components',
            executable='component_container_mt', composable_node_descriptions=nodes, output='screen'))
        # composed 모드: lifecycle 전이는 외부(ros2 lifecycle set / 운용 매니저)에서 수행
    else:
        actions.append(Node(package='pkg_pose_estimation', executable='pose_estimation_node',
                            name='pose_estimation_node', parameters=[params], output='screen'))
        if sim:
            actions.append(Node(package='pkg_pose_estimation', executable='synthetic_tag_publisher',
                                name='synthetic_tag_publisher', parameters=[sim_params], output='screen'))
    return actions


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('params', default_value=''),
        DeclareLaunchArgument('sim', default_value='false'),
        DeclareLaunchArgument('composed', default_value='false'),
        DeclareLaunchArgument('sim_noise', default_value='0.05'),
        DeclareLaunchArgument('sim_occlusion', default_value='0.0'),
        DeclareLaunchArgument('sim_dead_mask', default_value='0'),
        DeclareLaunchArgument('sim_blackout_start', default_value='-1.0'),
        OpaqueFunction(function=_setup),
    ])
