// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_pose_estimation/sim_scene.hpp"

namespace ppe {

SimScene::SimScene(const TagBundleModel& bundle, const MultiCamExtrinsicManager& cams, uint32_t seed)
    : bundle_(bundle), cams_(cams), rng_(seed) {}

bool SimScene::projectTag(const CameraModel& c, const TagModel& t, const SE3& T_wb, std::array<Vec2, 4>& uv) const {
  const Vec3 center_c = c.T_cam_world * (T_wb * t.center_body);
  if (center_c.z() <= 0.05) return false;
  // 태그 앞면 법선과 시선(태그→카메라) 각도
  const Vec3 n_w = T_wb.R * t.normal_body;
  const Vec3 to_cam = (c.center_world() - T_wb * t.center_body).normalized();
  if (n_w.dot(to_cam) < std::cos(noise_.max_view_angle_deg * kDeg2Rad)) return false;
  for (int m = 0; m < 4; ++m) {
    const Vec3 pc = c.T_cam_world * (T_wb * t.corners_body[m]);
    if (pc.z() <= 0.05) return false;
    uv[m] = c.project(pc);
    if (!c.inImage(uv[m], noise_.border_px)) return false;
  }
  for (int m = 0; m < 4; ++m)
    if ((uv[m] - uv[(m + 1) % 4]).norm() < noise_.min_side_px) return false;
  return true;
}

std::vector<int> SimScene::visibleTags(const SE3& T_wb, int camera_id) const {
  std::vector<int> v;
  const CameraModel* c = cams_.camera(camera_id);
  if (!c) return v;
  std::array<Vec2, 4> uv;
  for (const auto& t : bundle_.tags())
    if (projectTag(*c, t, T_wb, uv)) v.push_back(t.id);
  return v;
}

DetectionFrame SimScene::observe(const SE3& T_wb, int64_t stamp_ns, const std::set<int>& occluded, uint8_t dead) {
  DetectionFrame f;
  f.stamp_ns = stamp_ns;
  std::normal_distribution<double> N(0.0, noise_.corner_sigma_px);
  std::uniform_real_distribution<double> U(0.0, 1.0);
  const uint8_t cfgmask = cams_.configuredMask();
  f.active_camera_mask = cfgmask & static_cast<uint8_t>(~dead);
  for (int c = 1; c <= kMaxCameras; ++c) {
    if (!(f.active_camera_mask & (1u << (c - 1)))) continue;
    const CameraModel& cam = *cams_.camera(c);
    std::array<Vec2, 4> uv;
    for (const auto& t : bundle_.tags()) {
      if (occluded.count(t.id)) continue;
      if (!projectTag(cam, t, T_wb, uv)) continue;
      Detection d;
      d.camera_id = static_cast<uint8_t>(c);
      d.tag_id = t.id;
      d.decision_margin = 80.f;
      d.hamming = 0;
      for (int m = 0; m < 4; ++m) d.corners[m] = uv[m] + Vec2(N(rng_), N(rng_));
      if (noise_.blur_outlier_prob > 0 && U(rng_) < noise_.blur_outlier_prob) {
        const int m = static_cast<int>(U(rng_) * 4) % 4;
        const double a = U(rng_) * 2 * M_PI;
        d.corners[m] += noise_.blur_outlier_px * Vec2(std::cos(a), std::sin(a));
      }
      f.detections.push_back(d);
    }
  }
  // 수면 반사상: 실제 태그의 수면(z=0) 거울상 위치에 동일 ID 가 상하반전되어 검출된 상황 모사
  if (noise_.reflection_prob > 0 && U(rng_) < noise_.reflection_prob && !f.detections.empty()) {
    const size_t k = static_cast<size_t>(U(rng_) * f.detections.size()) % f.detections.size();
    Detection r = f.detections[k];
    const CameraModel& cam = *cams_.camera(r.camera_id);
    const TagModel& t = *bundle_.find(r.tag_id);
    bool ok = true;
    for (int m = 0; m < 4; ++m) {
      Vec3 pw = T_wb * t.corners_body[m];
      pw.z() = -pw.z();  // 수면 기준 거울상
      const Vec3 pc = cam.T_cam_world * pw;
      if (pc.z() <= 0.05) {
        ok = false;
        break;
      }
      r.corners[m] = cam.project(pc);
    }
    std::swap(r.corners[0], r.corners[3]);  // 거울상은 코너 와인딩 반전
    std::swap(r.corners[1], r.corners[2]);
    if (ok) {
      r.decision_margin = 40.f;
      f.detections.push_back(r);
    }
  }
  return f;
}

SE3 RailTrajectory::at(double t) const {
  const double L = x_max - x_min;
  const double s = std::fmod(speed_mps * t, 2.0 * L);
  const double x = s <= L ? x_min + s : x_max - (s - L);  // 왕복
  const double w = 2.0 * M_PI;
  const Vec3 pos(x, y0, z0 + heave_amp_m * std::sin(w * heave_hz * t));
  const Mat3 R = rotationFromRpy(roll_amp_deg * kDeg2Rad * std::sin(w * roll_hz * t),
                                 pitch_amp_deg * kDeg2Rad * std::sin(w * pitch_hz * t + 0.7),
                                 yaw_amp_deg * kDeg2Rad * std::sin(w * yaw_hz * t + 1.3));
  return SE3(R, pos);
}

}  // namespace ppe
