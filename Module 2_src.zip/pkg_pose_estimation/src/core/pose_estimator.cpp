// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_pose_estimation/pose_estimator.hpp"

#include <chrono>

#include <Eigen/Cholesky>

namespace ppe {

namespace {
inline int64_t monoNs() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
}  // namespace

bool PoseEstimator::configure(const TagBundleModel& bundle, const MultiCamExtrinsicManager& cams,
                              const EstimatorConfig& cfg, std::string& err) {
  if (bundle.size() == 0) {
    err = "Tag Bundle 이 비어 있습니다";
    return false;
  }
  if (cams.configuredMask() == 0) {
    err = "내부·외부 파라미터가 모두 설정된 카메라가 없습니다";
    return false;
  }
  bundle_ = bundle;
  cams_ = cams;
  setConfig(cfg);
  filtered_.reserve(64);
  reset();
  configured_ = true;
  return true;
}

void PoseEstimator::setConfig(const EstimatorConfig& cfg) {
  cfg_ = cfg;
  solver_.setConfig(cfg.solver);
  solver_.setAmbiguitySigma(cfg.covariance.prior_sigma_px);
  cov_.setConfig(cfg.covariance);
}

void PoseEstimator::reset() {
  last_.reset();
  prev_.reset();
  prior_ = PosePrior{};
  counters_ = EstimatorCounters{};
}

std::optional<SE3> PoseEstimator::predictedPrior(int64_t stamp_ns) const {
  if (prior_.valid) {
    const double age = std::abs(static_cast<double>(stamp_ns - prior_.stamp_ns)) * 1e-9;
    if (age <= cfg_.gate.prior_timeout_s) return prior_.predict(stamp_ns);
  }
  if (last_) {
    const double age = static_cast<double>(stamp_ns - last_->stamp_ns) * 1e-9;
    if (age < 0.0 || age > cfg_.gate.vision_prior_timeout_s) return std::nullopt;
    if (prev_) {
      const double dt = static_cast<double>(last_->stamp_ns - prev_->stamp_ns) * 1e-9;
      if (dt > 1e-4 && dt <= cfg_.gate.vision_prior_timeout_s) {
        // 등속 외삽 (월드 좌측 섭동): T(t) = Exp(ξ·age/dt) ⊞ T_last,  ξ = T_prev ⊟ T_last
        const Vec6 xi = prev_->T.boxminus(last_->T);
        return last_->T.boxplus(xi * (age / dt));
      }
    }
    return last_->T;
  }
  return std::nullopt;
}

bool PoseEstimator::kinematicOk(const PoseEstimate& e) const {
  if (!last_) return true;
  const GateConfig& g = cfg_.gate;
  const double dt = static_cast<double>(e.stamp_ns - last_->stamp_ns) * 1e-9;
  if (dt < 0.0) return false;  // 타임스탬프 역행 프레임은 기각
  const double dpos = (e.T_world_body.t - last_->T.t).norm();
  const double drot = rotationAngle(e.T_world_body.R, last_->T.R);
  const double sp = std::sqrt(e.covariance.block<3, 3>(0, 0).trace() + last_->cov.block<3, 3>(0, 0).trace());
  const double sr = std::sqrt(e.covariance.block<3, 3>(3, 3).trace() + last_->cov.block<3, 3>(3, 3).trace());
  const double pos_allow = g.max_speed_mps * dt + g.pos_tolerance_m + g.sigma_multiplier * sp;
  const double rot_allow = g.max_rate_dps * kDeg2Rad * dt + g.rot_tolerance_deg * kDeg2Rad + g.sigma_multiplier * sr;
  return dpos <= pos_allow && drot <= rot_allow;
}

PoseEstimate PoseEstimator::process(const DetectionFrame& frame) {
  const int64_t t0 = monoNs();
  PoseEstimate e;
  e.stamp_ns = frame.stamp_ns;
  ++counters_.frames;
  if (!configured_) {
    e.status = PoseStatus::kSolverFailed;
    return e;
  }

  // ── 입력 필터 (2D-3D 매칭 전)
  filtered_.clear();
  const uint8_t cam_mask = cams_.configuredMask();
  int rejected = 0;
  for (const Detection& d : frame.detections) {
    const bool cam_ok = d.camera_id >= 1 && d.camera_id <= kMaxCameras &&
                        (cam_mask & (1u << (d.camera_id - 1))) &&
                        (!cfg_.input.respect_active_mask || frame.active_camera_mask == 0 ||
                         (frame.active_camera_mask & (1u << (d.camera_id - 1))));
    bool ok = cam_ok && bundle_.find(d.tag_id) != nullptr && d.hamming <= cfg_.input.max_hamming &&
              d.decision_margin >= cfg_.input.min_decision_margin;
    if (ok) {
      for (const auto& c : d.corners) ok &= c.allFinite();
    }
    if (ok) {  // 같은 카메라·같은 ID 중복 → 신뢰도 높은 쪽 유지
      for (auto& f : filtered_) {
        if (f.camera_id == d.camera_id && f.tag_id == d.tag_id) {
          if (d.decision_margin > f.decision_margin) f = d;
          ok = false;
          ++rejected;
          break;
        }
      }
    } else {
      ++rejected;
    }
    if (ok) filtered_.push_back(d);
  }

  if (filtered_.empty()) {
    e.status = PoseStatus::kDropout;  // 6장 3) 완전 차폐 → 발행 중단
    e.stats.num_rejected_detections = rejected;
    ++counters_.dropouts;
    e.solve_time_ms = (monoNs() - t0) * 1e-6;
    return e;
  }

  // ── 결합 PnP + 다중 시점 LM
  const std::optional<SE3> amb_prior = predictedPrior(frame.stamp_ns);
  SolveResult r = solver_.solve(filtered_, bundle_, cams_, amb_prior);
  e.stats = r.stats;
  e.stats.num_rejected_detections = rejected;
  if (!r.ok) {
    e.status = PoseStatus::kSolverFailed;
    ++counters_.solver_failed;
    e.solve_time_ms = (monoNs() - t0) * 1e-6;
    return e;
  }
  e.T_world_body = r.T_world_body;
  e.has_pose = true;
  if (e.stats.single_tag_ambiguity) ++counters_.ambiguity_frames;

  // ── 동적 공분산
  CovarianceInputs ci;
  ci.information = r.information;
  ci.information_valid = r.information_valid;
  ci.reproj_rms_px = r.stats.reproj_rms_px;
  ci.num_residuals = r.stats.num_corners;
  ci.num_tags = r.stats.num_tags;
  ci.mean_distance_m = r.stats.mean_distance_m;
  ci.baseline_m = r.stats.baseline_m;
  ci.single_tag = r.stats.single_tag_ambiguity;
  if (!filtered_.empty()) {
    const TagModel* tm = bundle_.find(filtered_.front().tag_id);
    if (tm) ci.tag_size_m = tm->size;
  }
  e.covariance = cov_.compute(ci);
  // 1카메라·1태그: 두 IPPE 해의 2-성분 혼합 공분산  Σ ← Σ + w(1−w)·ΔΔᵀ
  //  (정면 시점에서 두 해가 수 도 이내로 근접 → 선형화 공분산만으로는 과소평가. 벤치 S6 NEES 참조)
  if (r.has_alternative && cfg_.covariance.ambiguity_mixture) {
    const Vec6 d = e.T_world_body.boxminus(r.alternative);
    const double w = std::max(r.alternative_weight, cfg_.covariance.ambiguity_min_weight);
    e.covariance += w * (1.0 - w) * d * d.transpose();
  }

  // ── 품질 게이트
  const GateConfig& g = cfg_.gate;
  const int all_corners = r.stats.num_corners + r.stats.num_outlier_corners;
  const double inlier_ratio = all_corners ? static_cast<double>(r.stats.num_corners) / all_corners : 0.0;
  if (r.stats.reproj_rms_px > g.max_reproj_rms_px || inlier_ratio < g.min_inlier_ratio) {
    e.status = PoseStatus::kRejectedReprojection;
    ++counters_.rejected_reproj;
  } else if (r.stats.single_tag_ambiguity && !r.stats.ambiguity_resolved_by_prior &&
             r.stats.ippe_error_ratio < g.ambiguity_min_error_ratio) {
    e.status = PoseStatus::kRejectedAmbiguous;  // 뒤집힌 법선 해를 EKF 에 넘기지 않음
    ++counters_.rejected_ambiguous;
  } else {
    bool reacquire = false;
    if (last_) {
      const double since = static_cast<double>(frame.stamp_ns - last_->stamp_ns) * 1e-9;
      reacquire = since > g.reacquire_after_s && r.stats.num_tags >= g.reacquire_min_tags;
    }
    if (g.kinematic_gate && !reacquire && !kinematicOk(e)) {
      e.status = PoseStatus::kRejectedKinematic;
      ++counters_.rejected_kinematic;
    } else {
      if (reacquire) ++counters_.reacquisitions;
      e.status = PoseStatus::kOk;
      if (g.mahalanobis_gate && prior_.valid && prior_.has_cov &&
          std::abs(static_cast<double>(frame.stamp_ns - prior_.stamp_ns)) * 1e-9 <= g.prior_timeout_s) {
        const SE3 pred = prior_.predict(frame.stamp_ns);
        const Vec6 d = pred.boxminus(e.T_world_body);
        const Mat6 S = prior_.cov + e.covariance;
        const double m2 = d.dot(S.ldlt().solve(d));
        if (m2 > g.mahalanobis_chi2) {
          e.status = PoseStatus::kRejectedMahalanobis;
          ++counters_.rejected_mahalanobis;
        }
      }
    }
  }
  if (e.status == PoseStatus::kOk) {
    prev_ = last_;
    last_ = Accepted{frame.stamp_ns, e.T_world_body, e.covariance};
    ++counters_.published;
  }
  e.solve_time_ms = (monoNs() - t0) * 1e-6;
  return e;
}

}  // namespace ppe
