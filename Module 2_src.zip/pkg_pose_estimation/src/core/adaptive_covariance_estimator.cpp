// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_pose_estimation/adaptive_covariance_estimator.hpp"

#include <Eigen/Cholesky>
#include <Eigen/Eigenvalues>

namespace ppe {

CovarianceConfig::Mode parseCovarianceMode(const std::string& s) {
  return s == "formula" ? CovarianceConfig::Mode::kFormula : CovarianceConfig::Mode::kJacobian;
}

Mat6 AdaptiveCovarianceEstimator::formula(const CovarianceInputs& in) const {
  const double e = std::max(in.reproj_rms_px, cfg_.sigma_floor_px);
  const double n = std::max(1, in.num_tags);
  const double d2 = in.mean_distance_m * in.mean_distance_m;
  // 단일 태그면 기저선 = 태그 한 변 (회전 레버암)
  const double L = std::max(in.baseline_m, in.tag_size_m);
  const double var_pos = cfg_.alpha * d2 * e * e / n;
  const double var_rot = cfg_.beta * d2 * e * e / (n * L * L);
  Mat6 S = Mat6::Zero();
  S.diagonal() << var_pos, var_pos, var_pos, var_rot, var_rot, var_rot;
  return S;
}

Mat6 AdaptiveCovarianceEstimator::compute(const CovarianceInputs& in) const {
  Mat6 S;
  bool ok = false;
  if (cfg_.mode == CovarianceConfig::Mode::kJacobian && in.information_valid && in.num_residuals >= 4) {
    // e_rms 는 코너(2D) 단위 RMS → 성분당 분산 = Σ|r|² / (2N − 6)
    const int m = 2 * in.num_residuals;
    const double ssq = in.reproj_rms_px * in.reproj_rms_px * in.num_residuals;  // Σ‖r‖²
    const double nu = std::max(0, m - 6);
    const double s2 = (ssq + cfg_.prior_dof * cfg_.prior_sigma_px * cfg_.prior_sigma_px) / (nu + cfg_.prior_dof);
    const double s = std::max(std::sqrt(s2), cfg_.sigma_floor_px);
    Eigen::LDLT<Mat6> ldlt(in.information);
    if (ldlt.info() == Eigen::Success && ldlt.isPositive()) {
      S = ldlt.solve(Mat6::Identity()) * (s * s);
      S = 0.5 * (S + S.transpose());
      ok = S.allFinite() && (S.diagonal().array() > 0).all();
    }
  }
  if (!ok) S = formula(in);
  S *= cfg_.scale;

  if (in.single_tag) {
    S.block<3, 3>(3, 3) *= cfg_.single_tag_rot_inflation;
    S.block<3, 3>(0, 0) *= cfg_.single_tag_pos_inflation;
    const double k = std::sqrt(cfg_.single_tag_rot_inflation * cfg_.single_tag_pos_inflation);
    S.block<3, 3>(0, 3) *= k;
    S.block<3, 3>(3, 0) *= k;
    const double lmax = Eigen::SelfAdjointEigenSolver<Mat3>(S.block<3, 3>(3, 3)).eigenvalues().maxCoeff();
    const double floor2 = std::pow(cfg_.single_tag_min_rot_std_deg * kDeg2Rad, 2);
    if (lmax > 0 && lmax < floor2) S *= floor2 / lmax;
  }
  const double vp = cfg_.min_pos_std_m * cfg_.min_pos_std_m;
  const double vr = std::pow(cfg_.min_rot_std_deg * kDeg2Rad, 2);
  for (int i = 0; i < 3; ++i) {
    S(i, i) = std::max(S(i, i), vp);
    S(i + 3, i + 3) = std::max(S(i + 3, i + 3), vr);
  }
  return S;
}

}  // namespace ppe
