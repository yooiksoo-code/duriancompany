// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// TagBundleModelLoader / MultiCamExtrinsicManager 구현 (YAML 입출력)
#include <set>

#include <yaml-cpp/yaml.h>

#include "pkg_pose_estimation/multi_cam_extrinsic_manager.hpp"
#include "pkg_pose_estimation/tag_bundle_model.hpp"

namespace ppe {

namespace {

std::vector<double> readVec(const YAML::Node& n) {
  std::vector<double> v;
  if (!n) return v;
  const YAML::Node data = (n.IsMap() && n["data"]) ? n["data"] : n;
  if (!data.IsSequence()) return v;
  for (const auto& e : data) v.push_back(e.as<double>());
  return v;
}

/// {position|x,y,z} + {rpy_deg | quaternion[qw,qx,qy,qz] | quaternion_xyzw | qw.. | rotation[9] | matrix[16]}
bool readPose(const YAML::Node& n, SE3& p, std::string& err) {
  p = SE3();
  if (!n) {
    err = "pose 항목 없음";
    return false;
  }
  if (n["matrix"]) {
    const auto m = readVec(n["matrix"]);
    if (m.size() != 16) {
      err = "matrix 는 16개 원소(row-major 4x4)가 필요합니다";
      return false;
    }
    for (int r = 0; r < 3; ++r) {
      for (int c = 0; c < 3; ++c) p.R(r, c) = m[r * 4 + c];
      p.t[r] = m[r * 4 + 3];
    }
  } else {
    if (n["position"]) {
      const auto t = readVec(n["position"]);
      if (t.size() != 3) {
        err = "position 은 3개 원소가 필요합니다";
        return false;
      }
      p.t = Vec3(t[0], t[1], t[2]);
    } else if (n["x"]) {
      p.t = Vec3(n["x"].as<double>(), n["y"].as<double>(), n["z"].as<double>());
    }
    if (n["rpy_deg"]) {
      const auto r = readVec(n["rpy_deg"]);
      if (r.size() != 3) {
        err = "rpy_deg 는 3개 원소가 필요합니다";
        return false;
      }
      p.R = rotationFromRpy(r[0] * kDeg2Rad, r[1] * kDeg2Rad, r[2] * kDeg2Rad);
    } else if (n["quaternion"]) {  // [qw, qx, qy, qz]  ([모듈 1] 규약)
      const auto q = readVec(n["quaternion"]);
      if (q.size() != 4) {
        err = "quaternion 은 [qw,qx,qy,qz] 4개 원소가 필요합니다";
        return false;
      }
      p.R = Eigen::Quaterniond(q[0], q[1], q[2], q[3]).normalized().toRotationMatrix();
    } else if (n["quaternion_xyzw"]) {  // ROS geometry_msgs 순서
      const auto q = readVec(n["quaternion_xyzw"]);
      if (q.size() != 4) {
        err = "quaternion_xyzw 는 4개 원소가 필요합니다";
        return false;
      }
      p.R = Eigen::Quaterniond(q[3], q[0], q[1], q[2]).normalized().toRotationMatrix();
    } else if (n["qw"]) {
      p.R = Eigen::Quaterniond(n["qw"].as<double>(), n["qx"].as<double>(), n["qy"].as<double>(),
                               n["qz"].as<double>())
                .normalized()
                .toRotationMatrix();
    } else if (n["rotation"]) {
      const auto r = readVec(n["rotation"]);
      if (r.size() != 9) {
        err = "rotation 은 9개 원소(row-major)가 필요합니다";
        return false;
      }
      for (int i = 0; i < 9; ++i) p.R(i / 3, i % 3) = r[i];
    }
  }
  // 직교성 검사 (수기 입력 오류 방지)
  const double ortho = (p.R.transpose() * p.R - Mat3::Identity()).norm();
  if (ortho > 1e-4 || p.R.determinant() < 0.0) {
    err = "회전 행렬이 직교 행렬이 아닙니다 (|RᵀR-I|=" + std::to_string(ortho) + ")";
    return false;
  }
  return true;
}

}  // namespace

// ───────────────────────────── Tag Bundle ─────────────────────────────
std::array<Vec3, 4> tagCornersInTagFrame(double size) {
  const double s = size * 0.5;
  return {Vec3(-s, s, 0), Vec3(s, s, 0), Vec3(s, -s, 0), Vec3(-s, -s, 0)};
}

void TagBundleModel::clear() {
  tags_.clear();
  index_.fill(-1);
}

bool TagBundleModel::addTag(int id, double size, const SE3& T_body_tag, std::string& err) {
  if (id < 0 || id >= kMaxTagId) {
    err = "tag id 범위 초과: " + std::to_string(id);
    return false;
  }
  if (index_[id] >= 0) {
    err = "중복 tag id: " + std::to_string(id);
    return false;
  }
  if (!(size > 0.0 && size < 5.0)) {
    err = "tag " + std::to_string(id) + " size 가 유효하지 않습니다";
    return false;
  }
  TagModel t;
  t.id = id;
  t.size = size;
  t.T_body_tag = T_body_tag;
  t.corners_tag = tagCornersInTagFrame(size);
  for (int m = 0; m < 4; ++m) t.corners_body[m] = T_body_tag * t.corners_tag[m];
  t.center_body = T_body_tag.t;
  t.normal_body = -T_body_tag.R.col(2);
  index_[id] = static_cast<int16_t>(tags_.size());
  tags_.push_back(t);
  return true;
}

bool loadTagBundle(const std::string& path, TagBundleModel& out, std::string& err) {
  try {
    const YAML::Node y = YAML::LoadFile(path);
    out.clear();
    if (y["name"]) out.setName(y["name"].as<std::string>());
    const double default_size = y["default_size"] ? y["default_size"].as<double>() : 0.08;
    const YAML::Node list = y["tags"] ? y["tags"] : y["layout"];
    if (!list || !list.IsSequence() || list.size() == 0) {
      err = path + ": 'tags'(또는 'layout') 목록이 비어 있습니다";
      return false;
    }
    for (const auto& n : list) {
      if (!n["id"]) {
        err = path + ": id 없는 태그 항목";
        return false;
      }
      const int id = n["id"].as<int>();
      const double size = n["size"] ? n["size"].as<double>() : default_size;
      SE3 T;
      std::string e;
      const YAML::Node pose = n["pose"] ? n["pose"] : n;
      if (!readPose(pose, T, e)) {
        err = path + ": tag " + std::to_string(id) + ": " + e;
        return false;
      }
      if (!out.addTag(id, size, T, e)) {
        err = path + ": " + e;
        return false;
      }
    }
    return true;
  } catch (const std::exception& ex) {
    err = path + ": " + ex.what();
    return false;
  }
}

// ───────────────────────────── Cameras ─────────────────────────────
bool loadIntrinsics(const std::string& path, Intrinsics& out, std::string& err) {
  try {
    const YAML::Node y = YAML::LoadFile(path);
    out = Intrinsics{};
    if (y["image_width"]) {
      out.width = y["image_width"].as<int>();
      out.height = y["image_height"].as<int>();
    } else if (y["width"]) {
      out.width = y["width"].as<int>();
      out.height = y["height"].as<int>();
    }
    const auto K = readVec(y["camera_matrix"] ? y["camera_matrix"] : y["K"]);
    if (K.size() != 9) {
      err = path + ": camera_matrix/K 는 9개 원소가 필요합니다";
      return false;
    }
    out.fx = K[0];
    out.fy = K[4];
    out.cx = K[2];
    out.cy = K[5];
    const auto D = readVec(y["distortion_coefficients"] ? y["distortion_coefficients"] : y["D"]);
    for (double d : D) out.distortion_nonzero |= std::abs(d) > 0.0;
    if (!(out.fx > 1.0 && out.fy > 1.0 && out.width > 0 && out.height > 0)) {
      err = path + ": 유효하지 않은 내부 파라미터 (fx/fy/width/height)";
      return false;
    }
    return true;
  } catch (const std::exception& ex) {
    err = path + ": " + ex.what();
    return false;
  }
}

void MultiCamExtrinsicManager::clear() {
  for (auto& c : cams_) c.reset();
  has_K_.fill(false);
  has_T_.fill(false);
}

bool MultiCamExtrinsicManager::setCamera(int id, const Intrinsics& K, const SE3& T, std::string& err) {
  if (id < 1 || id > kMaxCameras) {
    err = "camera_id 범위 초과: " + std::to_string(id);
    return false;
  }
  if (!setIntrinsics(id, K, err)) return false;
  auto& c = *cams_[id - 1];
  c.T_world_cam = T;
  c.T_cam_world = T.inverse();
  has_T_[id - 1] = true;
  return true;
}

bool MultiCamExtrinsicManager::setIntrinsics(int id, const Intrinsics& K, std::string& err) {
  if (id < 1 || id > kMaxCameras) {
    err = "camera_id 범위 초과: " + std::to_string(id);
    return false;
  }
  if (!cams_[id - 1]) cams_[id - 1] = CameraModel{};
  auto& c = *cams_[id - 1];
  c.camera_id = id;
  c.width = K.width;
  c.height = K.height;
  c.fx = K.fx;
  c.fy = K.fy;
  c.cx = K.cx;
  c.cy = K.cy;
  has_K_[id - 1] = true;
  return true;
}

bool MultiCamExtrinsicManager::loadExtrinsics(const std::string& path, std::string& err) {
  try {
    const YAML::Node y = YAML::LoadFile(path);
    if (y["world_frame"]) world_frame_ = y["world_frame"].as<std::string>();
    const YAML::Node list = y["cameras"];
    if (!list || !list.IsSequence()) {
      err = path + ": 'cameras' 목록이 없습니다";
      return false;
    }
    for (const auto& n : list) {
      const int id = n["camera_id"].as<int>();
      if (id < 1 || id > kMaxCameras) {
        err = path + ": camera_id 범위 초과 " + std::to_string(id);
        return false;
      }
      SE3 T;
      std::string e;
      if (!readPose(n["T_world_cam"], T, e)) {
        err = path + ": camera " + std::to_string(id) + ": " + e;
        return false;
      }
      if (!cams_[id - 1]) cams_[id - 1] = CameraModel{};
      auto& c = *cams_[id - 1];
      c.camera_id = id;
      c.T_world_cam = T;
      c.T_cam_world = T.inverse();
      has_T_[id - 1] = true;
    }
    return true;
  } catch (const std::exception& ex) {
    err = path + ": " + ex.what();
    return false;
  }
}

uint8_t MultiCamExtrinsicManager::configuredMask() const {
  uint8_t m = 0;
  for (int i = 0; i < kMaxCameras; ++i)
    if (cams_[i] && has_K_[i] && has_T_[i]) m |= static_cast<uint8_t>(1u << i);
  return m;
}

double MultiCamExtrinsicManager::meanFocal() const {
  double s = 0;
  int n = 0;
  for (int i = 0; i < kMaxCameras; ++i)
    if (cams_[i] && has_K_[i]) {
      s += 0.5 * (cams_[i]->fx + cams_[i]->fy);
      ++n;
    }
  return n ? s / n : 0.0;
}

}  // namespace ppe
