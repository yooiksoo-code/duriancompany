// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_pose_estimation/multi_view_bundle_pnp_solver.hpp"

#include <algorithm>
#include <limits>

#include <Eigen/Cholesky>
#include <opencv2/calib3d.hpp>
#include <opencv2/core/eigen.hpp>

namespace ppe {

namespace {

SE3 fromRvecTvec(const cv::Mat& rvec, const cv::Mat& tvec) {
  cv::Mat Rcv;
  cv::Rodrigues(rvec, Rcv);
  Mat3 R;
  cv::cv2eigen(Rcv, R);
  Vec3 t(tvec.at<double>(0), tvec.at<double>(1), tvec.at<double>(2));
  return SE3(R, t);
}

cv::Matx33d cameraMatrix(const CameraModel& c) { return cv::Matx33d(c.fx, 0, c.cx, 0, c.fy, c.cy, 0, 0, 1); }

/// 재투영 잔차 r = u − π(K, T_cw · T_wb · P). 깊이가 비정상이면 false
inline bool residual(const CameraModel& c, const SE3& T_wb, const Correspondence& k, double min_z, Vec2& r) {
  const Vec3 pc = c.T_cam_world * (T_wb * k.Pb);
  if (pc.z() < min_z) return false;
  r = k.uv - c.project(pc);
  return true;
}

}  // namespace

MultiViewBundlePnPSolver::MultiViewBundlePnPSolver() {
  corr_.reserve(4 * 64);
  candidates_.reserve(2 * kMaxCameras + 1);
}

void MultiViewBundlePnPSolver::buildCorrespondences(const std::vector<Detection>& dets,
                                                     const TagBundleModel& bundle) {
  corr_.clear();
  cam_begin_.fill(0);
  cam_end_.fill(0);
  for (int c = 1; c <= kMaxCameras; ++c) {
    cam_begin_[c] = static_cast<int>(corr_.size());
    for (size_t di = 0; di < dets.size(); ++di) {
      const Detection& d = dets[di];
      if (d.camera_id != c) continue;
      const int ti = bundle.indexOf(d.tag_id);
      if (ti < 0) continue;
      const TagModel& tm = bundle.tags()[ti];
      for (int m = 0; m < 4; ++m) {
        Correspondence k;
        k.cam = static_cast<int8_t>(c);
        k.tag_index = static_cast<int16_t>(ti);
        k.det_index = static_cast<int16_t>(di);
        k.corner = static_cast<int8_t>(m);
        k.uv = d.corners[m];
        k.Pb = tm.corners_body[m];
        corr_.push_back(k);
      }
    }
    cam_end_[c] = static_cast<int>(corr_.size());
  }
}

void MultiViewBundlePnPSolver::initPerCamera(const std::vector<Detection>& dets, const TagBundleModel& bundle,
                                             const MultiCamExtrinsicManager& cams, SolveStats& st) {
  (void)dets;
  candidates_.clear();
  ippe_cand_idx_ = {-1, -1};
  std::vector<cv::Point3d> obj;
  std::vector<cv::Point2d> img;
  for (int c = 1; c <= kMaxCameras; ++c) {
    const int n = cam_end_[c] - cam_begin_[c];
    if (n < 4) continue;
    const CameraModel* cam = cams.camera(c);
    if (!cam) continue;
    const cv::Matx33d K = cameraMatrix(*cam);
    const int ntags = n / 4;

    if (ntags >= 2) {
      obj.clear();
      img.clear();
      for (int i = cam_begin_[c]; i < cam_end_[c]; ++i) {
        obj.emplace_back(corr_[i].Pb.x(), corr_[i].Pb.y(), corr_[i].Pb.z());
        img.emplace_back(corr_[i].uv.x(), corr_[i].uv.y());
      }
      cv::Mat rvec, tvec;
      bool ok = false;
      try {
        if (cfg_.use_ransac) {
          std::vector<int> inl;
          ok = cv::solvePnPRansac(obj, img, K, cv::noArray(), rvec, tvec, false, cfg_.ransac_iterations,
                                  static_cast<float>(cfg_.ransac_reproj_px), cfg_.ransac_confidence, inl,
                                  cv::SOLVEPNP_SQPNP);
          ok = ok && static_cast<int>(inl.size()) >= 4;
        } else {
          ok = cv::solvePnP(obj, img, K, cv::noArray(), rvec, tvec, false, cv::SOLVEPNP_SQPNP);
        }
      } catch (const cv::Exception&) {
        ok = false;
      }
      if (ok) candidates_.push_back({cam->T_world_cam * fromRvecTvec(rvec, tvec), c, false});
    } else {
      // 단일 태그 → IPPE (평면 정사각 마커 두 해)
      const int b = cam_begin_[c];
      const TagModel& tm = bundle.tags()[corr_[b].tag_index];
      obj.clear();
      img.clear();
      for (int m = 0; m < 4; ++m) {
        obj.emplace_back(tm.corners_tag[m].x(), tm.corners_tag[m].y(), 0.0);
        img.emplace_back(corr_[b + m].uv.x(), corr_[b + m].uv.y());
      }
      std::vector<cv::Mat> rvecs, tvecs;
      cv::Mat errs;
      int nsol = 0;
      try {
        nsol = cv::solvePnPGeneric(obj, img, K, cv::noArray(), rvecs, tvecs, false, cv::SOLVEPNP_IPPE_SQUARE,
                                   cv::noArray(), cv::noArray(), errs);
      } catch (const cv::Exception&) {
        nsol = 0;
      }
      const SE3 T_tag_body = tm.T_body_tag.inverse();
      for (int s = 0; s < nsol && s < 2; ++s) {
        const SE3 T_cam_tag = fromRvecTvec(rvecs[s], tvecs[s]);
        candidates_.push_back({cam->T_world_cam * T_cam_tag * T_tag_body, c, true});
        last_ippe_err_[s] = errs.empty() ? 0.0 : errs.at<double>(s);
        ippe_cand_idx_[s] = static_cast<int>(candidates_.size()) - 1;
      }
      if (nsol == 2 && corr_.size() == 4) {
        const double lo = std::max(1e-9, std::min(last_ippe_err_[0], last_ippe_err_[1]));
        st.ippe_error_ratio = std::max(last_ippe_err_[0], last_ippe_err_[1]) / lo;
      }
    }
  }
}

double MultiViewBundlePnPSolver::truncatedCost(const SE3& T, const MultiCamExtrinsicManager& cams) const {
  const double tau2 = cfg_.candidate_truncation_px * cfg_.candidate_truncation_px;
  double cost = 0.0;
  Vec2 r;
  for (const auto& k : corr_) {
    const CameraModel* c = cams.camera(k.cam);
    if (!c || !residual(*c, T, k, cfg_.min_depth_m, r)) {
      cost += tau2;
      continue;
    }
    cost += std::min(r.squaredNorm(), tau2);
  }
  return cost;
}

void MultiViewBundlePnPSolver::classifyOutliers(const SE3& T, const MultiCamExtrinsicManager& cams) {
  const double tc2 = cfg_.outlier_corner_px * cfg_.outlier_corner_px;
  Vec2 r;
  // corr_ 는 (카메라, 검출) 순으로 4개씩 연속 저장됨
  for (size_t g = 0; g + 3 < corr_.size(); g += 4) {
    double sum = 0.0;
    bool bad_depth = false;
    std::array<double, 4> e2{};
    for (int m = 0; m < 4; ++m) {
      const auto& k = corr_[g + m];
      const CameraModel* c = cams.camera(k.cam);
      if (!c || !residual(*c, T, k, cfg_.min_depth_m, r)) {
        bad_depth = true;
        break;
      }
      e2[m] = r.squaredNorm();
      sum += std::sqrt(e2[m]);
    }
    const bool tag_bad = bad_depth || (sum * 0.25 > cfg_.outlier_tag_px);
    for (int m = 0; m < 4; ++m) corr_[g + m].inlier = !tag_bad && e2[m] <= tc2;
  }
}

bool MultiViewBundlePnPSolver::optimize(SE3& T, const MultiCamExtrinsicManager& cams, SolveResult& out) {
  const double hd = cfg_.huber_delta_px;
  auto accumulate = [&](const SE3& X, Mat6* H, Vec6* g, int* used) -> double {
    double cost = 0.0;
    int n = 0;
    if (H) H->setZero();
    if (g) g->setZero();
    for (const auto& k : corr_) {
      if (!k.inlier) continue;
      const CameraModel& c = *cams.camera(k.cam);
      const Vec3 RP = X.R * k.Pb;
      const Vec3 pw = RP + X.t;
      const Vec3 pc = c.T_cam_world.R * pw + c.T_cam_world.t;
      if (pc.z() < cfg_.min_depth_m) {
        cost += 2.0 * hd * 1e3;  // 비정상 깊이 페널티
        continue;
      }
      const double iz = 1.0 / pc.z();
      const Vec2 r = k.uv - Vec2(c.fx * pc.x() * iz + c.cx, c.fy * pc.y() * iz + c.cy);
      const double s = r.norm();
      double w = 1.0;
      if (s <= hd) {
        cost += s * s;
      } else {
        cost += 2.0 * hd * s - hd * hd;
        w = hd / s;
      }
      ++n;
      if (H) {
        Eigen::Matrix<double, 2, 3> Jp;
        Jp << c.fx * iz, 0, -c.fx * pc.x() * iz * iz, 0, c.fy * iz, -c.fy * pc.y() * iz * iz;
        const Eigen::Matrix<double, 2, 3> A = Jp * c.T_cam_world.R;
        Eigen::Matrix<double, 2, 6> J;
        J.leftCols<3>() = -A;
        J.rightCols<3>() = A * skew(RP);  // ∂pw/∂δθ = −[RP]× ,  r = u − π → 부호 반전
        H->noalias() += w * J.transpose() * J;
        g->noalias() += w * J.transpose() * r;
      }
    }
    if (used) *used = n;
    return cost;
  };

  Mat6 H;
  Vec6 g;
  int used = 0;
  double cost = accumulate(T, &H, &g, &used);
  if (used < cfg_.min_corners) return false;
  double lambda = cfg_.initial_lambda;
  bool converged = false;
  int it = 0;
  for (; it < cfg_.max_iterations; ++it) {
    Mat6 A = H;
    A.diagonal() += lambda * H.diagonal().cwiseMax(1e-9);
    const Vec6 delta = A.ldlt().solve(-g);
    if (!delta.allFinite()) break;
    const SE3 Tn = T.boxplus(delta);
    const double cn = accumulate(Tn, nullptr, nullptr, nullptr);
    if (cn < cost) {
      const double rel = (cost - cn) / std::max(cost, 1e-30);
      T = Tn;
      cost = accumulate(T, &H, &g, &used);
      lambda = std::max(lambda * 0.2, 1e-12);
      if (delta.norm() < cfg_.step_tolerance || rel < cfg_.cost_rel_tolerance) {
        converged = true;
        ++it;
        break;
      }
    } else {
      lambda *= 10.0;
      if (lambda > 1e8) {
        converged = delta.norm() < 1e-6;  // 이미 최소점 근방
        ++it;
        break;
      }
    }
  }
  if (!converged && g.norm() < 1e-6) converged = true;  // 기울기 0 (정확해)
  out.stats.iterations += it;
  out.stats.converged = converged;
  out.final_cost = cost;
  return true;
}

void MultiViewBundlePnPSolver::finalizeStats(const SE3& T, const TagBundleModel& bundle,
                                             const MultiCamExtrinsicManager& cams, SolveResult& out) {
  SolveStats& st = out.stats;
  Mat6 I = Mat6::Zero();
  double sum2 = 0.0, emax = 0.0, dsum = 0.0;
  int n = 0, nout = 0, nobs = 0;
  uint8_t mask = 0;
  std::array<bool, kMaxTagId> seen{};
  std::vector<int>& tag_list = tag_scratch_;
  tag_list.clear();
  for (size_t g = 0; g + 3 < corr_.size(); g += 4) {
    bool any = false;
    for (int m = 0; m < 4; ++m) {
      const auto& k = corr_[g + m];
      if (!k.inlier) {
        ++nout;
        continue;
      }
      any = true;
      const CameraModel& c = *cams.camera(k.cam);
      const Vec3 RP = T.R * k.Pb;
      const Vec3 pc = c.T_cam_world * (RP + T.t);
      const double iz = 1.0 / pc.z();
      const Vec2 r = k.uv - c.project(pc);
      sum2 += r.squaredNorm();
      emax = std::max(emax, r.norm());
      ++n;
      Eigen::Matrix<double, 2, 3> Jp;
      Jp << c.fx * iz, 0, -c.fx * pc.x() * iz * iz, 0, c.fy * iz, -c.fy * pc.y() * iz * iz;
      const Eigen::Matrix<double, 2, 3> A = Jp * c.T_cam_world.R;
      Eigen::Matrix<double, 2, 6> J;
      J.leftCols<3>() = -A;
      J.rightCols<3>() = A * skew(RP);
      I.noalias() += J.transpose() * J;
    }
    if (!any) continue;
    const auto& k0 = corr_[g];
    const TagModel& tm = bundle.tags()[k0.tag_index];
    const CameraModel& c = *cams.camera(k0.cam);
    dsum += (T * tm.center_body - c.center_world()).norm();
    ++nobs;
    mask |= static_cast<uint8_t>(1u << (k0.cam - 1));
    if (!seen[tm.id]) {
      seen[tm.id] = true;
      tag_list.push_back(k0.tag_index);
    }
  }
  st.num_corners = n;
  st.num_outlier_corners = nout;
  st.num_tag_observations = nobs;
  st.num_tags = static_cast<int>(tag_list.size());
  st.observed_camera_mask = mask;
  st.num_cameras = __builtin_popcount(mask);
  st.reproj_rms_px = n ? std::sqrt(sum2 / n) : 0.0;
  st.reproj_max_px = emax;
  st.mean_distance_m = nobs ? dsum / nobs : 0.0;
  double L = 0.0;
  for (size_t a = 0; a < tag_list.size(); ++a)
    for (size_t b = a + 1; b < tag_list.size(); ++b)
      L = std::max(L, (bundle.tags()[tag_list[a]].center_body - bundle.tags()[tag_list[b]].center_body).norm());
  st.baseline_m = L;
  st.single_tag_ambiguity = (nobs == 1);
  out.information = I;
  out.information_valid = n >= 4;
}

SolveResult MultiViewBundlePnPSolver::solve(const std::vector<Detection>& detections, const TagBundleModel& bundle,
                                            const MultiCamExtrinsicManager& cams, const std::optional<SE3>& prior) {
  SolveResult out;
  buildCorrespondences(detections, bundle);
  if (static_cast<int>(corr_.size()) < cfg_.min_corners) return out;

  const bool single_obs = corr_.size() == 4;
  bool fast = false;
  if (cfg_.tracking_fast_path && prior && !single_obs) {
    const double tau2 = cfg_.candidate_truncation_px * cfg_.candidate_truncation_px;
    Vec2 r;
    int nin = 0;
    for (const auto& k : corr_) {
      const CameraModel* c = cams.camera(k.cam);
      nin += c && residual(*c, *prior, k, cfg_.min_depth_m, r) && r.squaredNorm() <= tau2;
    }
    fast = nin >= cfg_.fast_path_min_inlier_ratio * static_cast<double>(corr_.size());
  }
  out.stats.fast_path = fast;
  candidates_.clear();
  ippe_cand_idx_ = {-1, -1};
  if (!fast) initPerCamera(detections, bundle, cams, out.stats);
  if (prior) candidates_.push_back({*prior, 0, false});
  if (candidates_.empty()) return out;

  // ── 초기해 선택
  size_t best = 0;
  if (fast) {
    best = candidates_.size() - 1;
  } else if (single_obs && prior && candidates_.size() >= 2) {
    // 설계서 6장 1): 두 IPPE 해 중 직전 자세(EKF)와 회전 차이가 작은 해 선택
    double best_ang = std::numeric_limits<double>::max();
    for (size_t i = 0; i < candidates_.size(); ++i) {
      if (!candidates_[i].from_ippe) continue;
      const double a = rotationAngle(candidates_[i].T.R, prior->R);
      if (a < best_ang) {
        best_ang = a;
        best = i;
      }
    }
    out.stats.ambiguity_resolved_by_prior = true;
  } else {
    double best_cost = std::numeric_limits<double>::max();
    for (size_t i = 0; i < candidates_.size(); ++i) {
      const double cst = truncatedCost(candidates_[i].T, cams);
      if (cst < best_cost) {
        best_cost = cst;
        best = i;
      }
    }
  }
  SE3 T = candidates_[best].T;

  // ── 1단계: 절단 임계 내 대응으로 강건 LM (초기해가 다른 카메라에 대해 부정확할 수 있음)
  {
    const double tau2 = cfg_.candidate_truncation_px * cfg_.candidate_truncation_px;
    Vec2 r;
    int nin = 0;
    for (auto& k : corr_) {
      const CameraModel* c = cams.camera(k.cam);
      k.inlier = c && residual(*c, T, k, cfg_.min_depth_m, r) && r.squaredNorm() <= tau2;
      nin += k.inlier;
    }
    if (nin < cfg_.min_corners) {
      for (auto& k : corr_) k.inlier = true;
    }
    if (!optimize(T, cams, out)) return out;
  }
  // ── 2단계: 코너/태그 단위 이상치 재분류 후 최종 LM
  classifyOutliers(T, cams);
  int nin = 0;
  for (const auto& k : corr_) nin += k.inlier;
  if (nin < cfg_.min_corners) {
    finalizeStats(T, bundle, cams, out);
    return out;  // ok=false
  }
  if (!optimize(T, cams, out)) return out;

  finalizeStats(T, bundle, cams, out);
  out.T_world_body = T;
  out.ok = true;

  // 모호 상황: 다른 IPPE 해의 사후확률 w (재투영 우도 기반, σ0 = huber_delta 가 아닌 0.05 px 기준)
  if (single_obs && ippe_cand_idx_[0] >= 0 && ippe_cand_idx_[1] >= 0) {
    const int chosen = static_cast<size_t>(ippe_cand_idx_[0]) == best ? 0 : 1;
    const int other = 1 - chosen;
    out.has_alternative = true;
    out.alternative = candidates_[ippe_cand_idx_[other]].T;
    // SSE_i = 8·e_i² (IPPE 오차는 RMS), p_i ∝ exp(−SSE_i / 2σ²)
    const double s2 = 2.0 * ambiguity_sigma_px_ * ambiguity_sigma_px_;
    const double dl = 8.0 * (last_ippe_err_[other] * last_ippe_err_[other] -
                             last_ippe_err_[chosen] * last_ippe_err_[chosen]) / s2;
    out.alternative_weight = 1.0 / (1.0 + std::exp(std::clamp(dl, -50.0, 50.0)));
  }
  return out;
}

double MultiViewBundlePnPSolver::reprojectionRms(const SE3& T, const MultiCamExtrinsicManager& cams) const {
  double s = 0;
  int n = 0;
  Vec2 r;
  for (const auto& k : corr_) {
    if (!k.inlier) continue;
    const CameraModel* c = cams.camera(k.cam);
    if (!c || !residual(*c, T, k, cfg_.min_depth_m, r)) continue;
    s += r.squaredNorm();
    ++n;
  }
  return n ? std::sqrt(s / n) : 0.0;
}

}  // namespace ppe
