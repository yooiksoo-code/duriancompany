// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// pose_estimation_node 단독 실행 (systemd 서비스용)
//  - autostart: configure → activate 자동 전이, 성공 시 sd_notify READY=1
//  - systemd watchdog: 실행기 하트비트가 살아 있을 때만 WATCHDOG=1 (멈추면 WatchdogSec 후 재기동)
//  - configure/activate 실패 또는 on_error → 종료코드 4 → systemd Restart=always
#include <lifecycle_msgs/msg/state.hpp>
#include <rclcpp/rclcpp.hpp>

#include "pkg_pose_estimation/pose_estimation_node.hpp"
#include "pkg_pose_estimation/sd_notify.hpp"

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions opts;
  auto node = std::make_shared<ppe::PoseEstimationNode>(opts);
  rclcpp::executors::SingleThreadedExecutor exec;
  exec.add_node(node->get_node_base_interface());

  int rc = 0;
  if (node->autostart()) {
    using lifecycle_msgs::msg::State;
    if (node->configure().id() != State::PRIMARY_STATE_INACTIVE ||
        node->activate().id() != State::PRIMARY_STATE_ACTIVE) {
      RCLCPP_FATAL(node->get_logger(), "autostart 실패 → 종료 (systemd 재기동)");
      rclcpp::shutdown();
      return 4;
    }
  }
  ppe::sdNotify("READY=1\nSTATUS=pose_estimation_node active");
  rclcpp::TimerBase::SharedPtr wd;
  const int wd_ms = ppe::sdWatchdogIntervalMs();
  if (wd_ms > 0) {
    wd = node->create_wall_timer(std::chrono::milliseconds(wd_ms), [node] {
      if (node->healthy()) ppe::sdNotify("WATCHDOG=1");
    });
  }
  // on_error → FINALIZED 시 프로세스 종료 (systemd 가 재기동)
  bool finalized = false;
  auto guard = node->create_wall_timer(std::chrono::milliseconds(200), [&] {
    if (node->get_current_state().id() == lifecycle_msgs::msg::State::PRIMARY_STATE_FINALIZED) {
      finalized = true;
      exec.cancel();
    }
  });
  exec.spin();
  if (finalized) rc = 4;
  rclcpp::shutdown();
  return rc;
}
