// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_pose_estimation/pose_estimation_node.hpp"

#include <chrono>

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <rclcpp_components/register_node_macro.hpp>

namespace ppe {

namespace {
inline int64_t monoNs() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
inline int64_t stampNs(const builtin_interfaces::msg::Time& t) {
  return static_cast<int64_t>(t.sec) * 1'000'000'000LL + t.nanosec;
}
}  // namespace

PoseEstimationNode::PoseEstimationNode(const rclcpp::NodeOptions& options)
    : rclcpp_lifecycle::LifecycleNode("pose_estimation_node", options) {
  declareParameters();
  autostart_ = get_parameter("autostart").as_bool();
  frame_.detections.reserve(64);
}

void PoseEstimationNode::declareParameters() {
  const EstimatorConfig d;  // 단일 기본값 원천 = 코어 구조체
  declare_parameter("autostart", true);
  declare_parameter("input_topic", "/vision/tag_detections");
  declare_parameter("output_topic", "/sub_pose_vision");
  declare_parameter("diagnostics_topic", "/vision/pose_diagnostics");
  declare_parameter("alert_topic", "/hmi/vision_alerts");
  declare_parameter("prior_topic", "/sub_pose_filtered");
  declare_parameter("use_prior", true);
  declare_parameter("publish_diagnostics", true);
  declare_parameter("world_frame", "");  // 빈 값 → 외부파라미터 YAML 의 world_frame (기본 dock_world_frame)
  declare_parameter("child_frame", "submarine_base_link");
  declare_parameter("publish_tf", false);
  declare_parameter("tf_child_frame", "submarine_base_link_vision");
  declare_parameter("stats_period_s", 10.0);
  declare_parameter("dropout_alert_frames", 3);

  declare_parameter("tag_bundle_file", "package://pkg_pose_estimation/config/Tag_Bundle_Rigid_Map.yaml");
  declare_parameter("extrinsics_file", "package://pkg_pose_estimation/config/camera_extrinsics_world.yaml");
  declare_parameter("camera_ids", std::vector<int64_t>{1, 2, 3, 4});
  declare_parameter("intrinsics_files",
                    std::vector<std::string>{"package://pkg_pose_estimation/config/cam_intrinsics_ch1.yaml",
                                             "package://pkg_pose_estimation/config/cam_intrinsics_ch2.yaml",
                                             "package://pkg_pose_estimation/config/cam_intrinsics_ch3.yaml",
                                             "package://pkg_pose_estimation/config/cam_intrinsics_ch4.yaml"});

  declare_parameter("input.min_decision_margin", static_cast<double>(d.input.min_decision_margin));
  declare_parameter("input.max_hamming", d.input.max_hamming);
  declare_parameter("input.respect_active_mask", d.input.respect_active_mask);

  declare_parameter("solver.use_ransac", d.solver.use_ransac);
  declare_parameter("solver.ransac_reproj_px", d.solver.ransac_reproj_px);
  declare_parameter("solver.ransac_iterations", d.solver.ransac_iterations);
  declare_parameter("solver.ransac_confidence", d.solver.ransac_confidence);
  declare_parameter("solver.outlier_corner_px", d.solver.outlier_corner_px);
  declare_parameter("solver.outlier_tag_px", d.solver.outlier_tag_px);
  declare_parameter("solver.candidate_truncation_px", d.solver.candidate_truncation_px);
  declare_parameter("solver.huber_delta_px", d.solver.huber_delta_px);
  declare_parameter("solver.max_iterations", d.solver.max_iterations);

  declare_parameter("gate.max_reproj_rms_px", d.gate.max_reproj_rms_px);
  declare_parameter("gate.min_inlier_ratio", d.gate.min_inlier_ratio);
  declare_parameter("gate.kinematic_gate", d.gate.kinematic_gate);
  declare_parameter("gate.max_speed_mps", d.gate.max_speed_mps);
  declare_parameter("gate.max_rate_dps", d.gate.max_rate_dps);
  declare_parameter("gate.pos_tolerance_m", d.gate.pos_tolerance_m);
  declare_parameter("gate.rot_tolerance_deg", d.gate.rot_tolerance_deg);
  declare_parameter("gate.sigma_multiplier", d.gate.sigma_multiplier);
  declare_parameter("gate.reacquire_after_s", d.gate.reacquire_after_s);
  declare_parameter("gate.reacquire_min_tags", d.gate.reacquire_min_tags);
  declare_parameter("gate.mahalanobis_gate", d.gate.mahalanobis_gate);
  declare_parameter("gate.mahalanobis_chi2", d.gate.mahalanobis_chi2);
  declare_parameter("gate.prior_timeout_s", d.gate.prior_timeout_s);
  declare_parameter("gate.vision_prior_timeout_s", d.gate.vision_prior_timeout_s);
  declare_parameter("gate.ambiguity_min_error_ratio", d.gate.ambiguity_min_error_ratio);

  declare_parameter("covariance.mode", std::string("jacobian"));
  declare_parameter("covariance.alpha", d.covariance.alpha);
  declare_parameter("covariance.beta", d.covariance.beta);
  declare_parameter("covariance.scale", d.covariance.scale);
  declare_parameter("covariance.sigma_floor_px", d.covariance.sigma_floor_px);
  declare_parameter("covariance.prior_sigma_px", d.covariance.prior_sigma_px);
  declare_parameter("covariance.prior_dof", d.covariance.prior_dof);
  declare_parameter("covariance.single_tag_rot_inflation", d.covariance.single_tag_rot_inflation);
  declare_parameter("covariance.single_tag_pos_inflation", d.covariance.single_tag_pos_inflation);
  declare_parameter("covariance.single_tag_min_rot_std_deg", d.covariance.single_tag_min_rot_std_deg);
  declare_parameter("covariance.ambiguity_mixture", d.covariance.ambiguity_mixture);
  declare_parameter("covariance.ambiguity_min_weight", d.covariance.ambiguity_min_weight);
  declare_parameter("covariance.min_pos_std_m", d.covariance.min_pos_std_m);
  declare_parameter("covariance.min_rot_std_deg", d.covariance.min_rot_std_deg);
}

std::string PoseEstimationNode::resolvePath(const std::string& p) const {
  const std::string pre = "package://";
  if (p.rfind(pre, 0) != 0) return p;
  const std::string rest = p.substr(pre.size());
  const auto slash = rest.find('/');
  if (slash == std::string::npos) return p;
  return ament_index_cpp::get_package_share_directory(rest.substr(0, slash)) + rest.substr(slash);
}

bool PoseEstimationNode::buildConfig(EstimatorConfig& c, std::string& err) {
  auto D = [&](const char* n) { return get_parameter(n).as_double(); };
  auto I = [&](const char* n) { return static_cast<int>(get_parameter(n).as_int()); };
  auto B = [&](const char* n) { return get_parameter(n).as_bool(); };
  c.input.min_decision_margin = static_cast<float>(D("input.min_decision_margin"));
  c.input.max_hamming = I("input.max_hamming");
  c.input.respect_active_mask = B("input.respect_active_mask");
  c.solver.use_ransac = B("solver.use_ransac");
  c.solver.ransac_reproj_px = D("solver.ransac_reproj_px");
  c.solver.ransac_iterations = I("solver.ransac_iterations");
  c.solver.ransac_confidence = D("solver.ransac_confidence");
  c.solver.outlier_corner_px = D("solver.outlier_corner_px");
  c.solver.outlier_tag_px = D("solver.outlier_tag_px");
  c.solver.candidate_truncation_px = D("solver.candidate_truncation_px");
  c.solver.huber_delta_px = D("solver.huber_delta_px");
  c.solver.max_iterations = I("solver.max_iterations");
  c.gate.max_reproj_rms_px = D("gate.max_reproj_rms_px");
  c.gate.min_inlier_ratio = D("gate.min_inlier_ratio");
  c.gate.kinematic_gate = B("gate.kinematic_gate");
  c.gate.max_speed_mps = D("gate.max_speed_mps");
  c.gate.max_rate_dps = D("gate.max_rate_dps");
  c.gate.pos_tolerance_m = D("gate.pos_tolerance_m");
  c.gate.rot_tolerance_deg = D("gate.rot_tolerance_deg");
  c.gate.sigma_multiplier = D("gate.sigma_multiplier");
  c.gate.reacquire_after_s = D("gate.reacquire_after_s");
  c.gate.reacquire_min_tags = I("gate.reacquire_min_tags");
  c.gate.mahalanobis_gate = B("gate.mahalanobis_gate");
  c.gate.mahalanobis_chi2 = D("gate.mahalanobis_chi2");
  c.gate.prior_timeout_s = D("gate.prior_timeout_s");
  c.gate.vision_prior_timeout_s = D("gate.vision_prior_timeout_s");
  c.gate.ambiguity_min_error_ratio = D("gate.ambiguity_min_error_ratio");
  const std::string mode = get_parameter("covariance.mode").as_string();
  if (mode != "jacobian" && mode != "formula") {
    err = "covariance.mode 는 jacobian | formula 이어야 합니다: " + mode;
    return false;
  }
  c.covariance.mode = parseCovarianceMode(mode);
  c.covariance.alpha = D("covariance.alpha");
  c.covariance.beta = D("covariance.beta");
  c.covariance.scale = D("covariance.scale");
  c.covariance.sigma_floor_px = D("covariance.sigma_floor_px");
  c.covariance.prior_sigma_px = D("covariance.prior_sigma_px");
  c.covariance.prior_dof = D("covariance.prior_dof");
  c.covariance.single_tag_rot_inflation = D("covariance.single_tag_rot_inflation");
  c.covariance.single_tag_pos_inflation = D("covariance.single_tag_pos_inflation");
  c.covariance.single_tag_min_rot_std_deg = D("covariance.single_tag_min_rot_std_deg");
  c.covariance.ambiguity_mixture = B("covariance.ambiguity_mixture");
  c.covariance.ambiguity_min_weight = D("covariance.ambiguity_min_weight");
  c.covariance.min_pos_std_m = D("covariance.min_pos_std_m");
  c.covariance.min_rot_std_deg = D("covariance.min_rot_std_deg");
  if (c.gate.max_reproj_rms_px <= 0 || c.gate.max_speed_mps <= 0 || c.gate.max_rate_dps <= 0) {
    err = "gate 임계값은 양수여야 합니다";
    return false;
  }
  return true;
}

bool PoseEstimationNode::loadGeometry(TagBundleModel& bundle, MultiCamExtrinsicManager& cams, std::string& err) {
  const std::string bpath = resolvePath(get_parameter("tag_bundle_file").as_string());
  if (!loadTagBundle(bpath, bundle, err)) return false;
  const std::string epath = resolvePath(get_parameter("extrinsics_file").as_string());
  if (!cams.loadExtrinsics(epath, err)) return false;
  const auto ids = get_parameter("camera_ids").as_integer_array();
  const auto files = get_parameter("intrinsics_files").as_string_array();
  if (ids.size() != files.size()) {
    err = "camera_ids 와 intrinsics_files 개수가 다릅니다";
    return false;
  }
  for (size_t i = 0; i < ids.size(); ++i) {
    Intrinsics K;
    if (!loadIntrinsics(resolvePath(files[i]), K, err)) return false;
    if (!cams.setIntrinsics(static_cast<int>(ids[i]), K, err)) return false;
    if (!cams.camera(static_cast<int>(ids[i])) ||
        !(cams.configuredMask() & (1u << (ids[i] - 1)))) {
      err = "camera " + std::to_string(ids[i]) + " 외부파라미터가 " + epath + " 에 없습니다";
      return false;
    }
  }
  RCLCPP_INFO(get_logger(), "Tag Bundle '%s' %zu개 태그 (%s), 카메라 마스크 0x%02X, world_frame '%s'",
              bundle.name().c_str(), bundle.size(), bpath.c_str(), cams.configuredMask(), cams.worldFrame().c_str());
  return true;
}

PoseEstimationNode::CallbackReturn PoseEstimationNode::on_configure(const rclcpp_lifecycle::State&) {
  std::string err;
  EstimatorConfig cfg;
  TagBundleModel bundle;
  MultiCamExtrinsicManager cams;
  try {
    if (!buildConfig(cfg, err) || !loadGeometry(bundle, cams, err) || !estimator_.configure(bundle, cams, cfg, err)) {
      RCLCPP_ERROR(get_logger(), "configure 실패: %s", err.c_str());
      return CallbackReturn::FAILURE;
    }
  } catch (const std::exception& e) {
    RCLCPP_ERROR(get_logger(), "configure 예외: %s", e.what());
    return CallbackReturn::FAILURE;
  }
  world_frame_ = get_parameter("world_frame").as_string();
  if (world_frame_.empty()) world_frame_ = cams.worldFrame();
  child_frame_ = get_parameter("child_frame").as_string();
  publish_tf_ = get_parameter("publish_tf").as_bool();
  tf_child_frame_ = get_parameter("tf_child_frame").as_string();
  publish_diag_ = get_parameter("publish_diagnostics").as_bool();
  dropout_alert_frames_ = static_cast<int>(get_parameter("dropout_alert_frames").as_int());

  pose_pub_ = create_publisher<PoseMsg>(get_parameter("output_topic").as_string(), rclcpp::QoS(10).reliable());
  diag_pub_ = create_publisher<DiagMsg>(get_parameter("diagnostics_topic").as_string(), rclcpp::QoS(10).reliable());
  alert_pub_ = create_publisher<std_msgs::msg::String>(get_parameter("alert_topic").as_string(),
                                                       rclcpp::QoS(20).reliable());
  if (publish_tf_) tf_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);

  // [모듈 1] 발행 QoS (reliable, keep_last 5) 와 일치
  det_sub_ = create_subscription<TagArray>(get_parameter("input_topic").as_string(), rclcpp::QoS(5).reliable(),
                                           [this](TagArray::UniquePtr m) { onDetections(std::move(m)); });
  if (get_parameter("use_prior").as_bool()) {
    prior_sub_ = create_subscription<nav_msgs::msg::Odometry>(
        get_parameter("prior_topic").as_string(), rclcpp::QoS(10),
        [this](const nav_msgs::msg::Odometry::ConstSharedPtr& m) { onPrior(m); });
  }
  heartbeat_ns_ = monoNs();
  heartbeat_timer_ = create_wall_timer(std::chrono::milliseconds(100), [this] { heartbeat_ns_ = monoNs(); });
  const double sp = get_parameter("stats_period_s").as_double();
  if (sp > 0)
    stats_timer_ = create_wall_timer(std::chrono::milliseconds(static_cast<int>(sp * 1000)), [this] { logStats(); });
  RCLCPP_INFO(get_logger(), "configured: %s → %s (frame '%s'), 진단 %s",
              get_parameter("input_topic").as_string().c_str(), get_parameter("output_topic").as_string().c_str(),
              world_frame_.c_str(), get_parameter("diagnostics_topic").as_string().c_str());
  return CallbackReturn::SUCCESS;
}

PoseEstimationNode::CallbackReturn PoseEstimationNode::on_activate(const rclcpp_lifecycle::State&) {
  pose_pub_->on_activate();
  diag_pub_->on_activate();
  alert_pub_->on_activate();
  estimator_.reset();
  have_status_ = false;
  consecutive_non_ok_ = 0;
  active_ = true;
  RCLCPP_INFO(get_logger(), "activated");
  return CallbackReturn::SUCCESS;
}

PoseEstimationNode::CallbackReturn PoseEstimationNode::on_deactivate(const rclcpp_lifecycle::State&) {
  active_ = false;
  pose_pub_->on_deactivate();
  diag_pub_->on_deactivate();
  alert_pub_->on_deactivate();
  RCLCPP_INFO(get_logger(), "deactivated");
  return CallbackReturn::SUCCESS;
}

PoseEstimationNode::CallbackReturn PoseEstimationNode::on_cleanup(const rclcpp_lifecycle::State&) {
  active_ = false;
  det_sub_.reset();
  prior_sub_.reset();
  pose_pub_.reset();
  diag_pub_.reset();
  alert_pub_.reset();
  tf_.reset();
  heartbeat_timer_.reset();
  stats_timer_.reset();
  return CallbackReturn::SUCCESS;
}

PoseEstimationNode::CallbackReturn PoseEstimationNode::on_shutdown(const rclcpp_lifecycle::State& s) {
  return on_cleanup(s);
}

PoseEstimationNode::CallbackReturn PoseEstimationNode::on_error(const rclcpp_lifecycle::State&) {
  RCLCPP_FATAL(get_logger(), "라이프사이클 오류 → FAILURE (프로세스 재기동 필요)");
  active_ = false;
  return CallbackReturn::FAILURE;
}

bool PoseEstimationNode::healthy() const {
  return monoNs() - heartbeat_ns_.load() < 1'000'000'000LL;  // 실행기가 1 s 이상 멈추면 비정상
}

void PoseEstimationNode::onPrior(const nav_msgs::msg::Odometry::ConstSharedPtr& m) {
  if (!world_frame_.empty() && m->header.frame_id != world_frame_) {
    RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 5000, "prior frame '%s' ≠ world_frame '%s' → 무시",
                         m->header.frame_id.c_str(), world_frame_.c_str());
    return;
  }
  PosePrior p;
  p.valid = true;
  p.stamp_ns = stampNs(m->header.stamp);
  const auto& q = m->pose.pose.orientation;
  const auto& t = m->pose.pose.position;
  p.T_world_body = SE3::fromQuaternion(q.w, q.x, q.y, q.z, Vec3(t.x, t.y, t.z));
  p.v_body = Vec3(m->twist.twist.linear.x, m->twist.twist.linear.y, m->twist.twist.linear.z);
  p.w_body = Vec3(m->twist.twist.angular.x, m->twist.twist.angular.y, m->twist.twist.angular.z);
  for (int i = 0; i < 36; ++i) p.cov(i / 6, i % 6) = m->pose.covariance[i];
  p.has_cov = p.cov.diagonal().minCoeff() > 0.0;
  std::lock_guard<std::mutex> lk(prior_mtx_);
  prior_ = p;
  prior_dirty_ = true;
}

void PoseEstimationNode::onDetections(TagArray::UniquePtr msg) {
  const int64_t t0 = monoNs();
  if (!active_.load(std::memory_order_relaxed)) return;
  const double input_age_ms = (now().nanoseconds() - stampNs(msg->header.stamp)) * 1e-6;

  {
    std::lock_guard<std::mutex> lk(prior_mtx_);
    if (prior_dirty_) {
      estimator_.setPrior(prior_);
      prior_dirty_ = false;
    }
  }
  frame_.stamp_ns = stampNs(msg->header.stamp);
  frame_.active_camera_mask = msg->active_camera_mask;
  frame_.detections.resize(msg->detections.size());
  for (size_t i = 0; i < msg->detections.size(); ++i) {
    const auto& s = msg->detections[i];
    Detection& d = frame_.detections[i];
    d.camera_id = s.camera_id;
    d.tag_id = s.tag_id;
    d.decision_margin = s.decision_margin;
    d.hamming = s.hamming_error;
    for (int k = 0; k < 4; ++k) d.corners[k] = Vec2(s.corners[k].x, s.corners[k].y);
  }

  const PoseEstimate e = estimator_.process(frame_);
  const bool ok = e.status == PoseStatus::kOk;
  if (ok) {
    auto out = std::make_unique<PoseMsg>();
    out->header.stamp = msg->header.stamp;  // PTP 촬영 시각 그대로 (EKF 지연 보상)
    out->header.frame_id = world_frame_;
    const Eigen::Quaterniond q = e.T_world_body.quaternion();
    out->pose.pose.position.x = e.T_world_body.t.x();
    out->pose.pose.position.y = e.T_world_body.t.y();
    out->pose.pose.position.z = e.T_world_body.t.z();
    out->pose.pose.orientation.x = q.x();
    out->pose.pose.orientation.y = q.y();
    out->pose.pose.orientation.z = q.z();
    out->pose.pose.orientation.w = q.w();
    for (int i = 0; i < 36; ++i) out->pose.covariance[i] = e.covariance(i / 6, i % 6);
    if (tf_) {
      geometry_msgs::msg::TransformStamped tf;
      tf.header = out->header;
      tf.child_frame_id = tf_child_frame_;
      tf.transform.translation.x = out->pose.pose.position.x;
      tf.transform.translation.y = out->pose.pose.position.y;
      tf.transform.translation.z = out->pose.pose.position.z;
      tf.transform.rotation = out->pose.pose.orientation;
      tf_->sendTransform(tf);
    }
    pose_pub_->publish(std::move(out));
  }
  // 설계서 8장 정의: TagDetectionArray 수신 ~ /sub_pose_vision 발행까지
  const double proc_ms = (monoNs() - t0) * 1e-6;
  lat_sum_ += proc_ms;
  lat_max_ = std::max(lat_max_, proc_ms);
  ++lat_n_;

  // HMI 경보: 비정상 상태가 연속 dropout_alert_frames 프레임 지속 시 1회, 정상 복귀 시 1회 (깜빡임 억제)
  consecutive_non_ok_ = ok ? 0 : consecutive_non_ok_ + 1;
  if (!ok && consecutive_non_ok_ == dropout_alert_frames_) {
    publishAlert(PoseStatus::kOk, e.status, e);
    have_status_ = true;  // 경보 발령 상태
  } else if (ok && have_status_) {
    publishAlert(last_status_, PoseStatus::kOk, e);
    have_status_ = false;
  }
  last_status_ = e.status;

  if (publish_diag_) {
    auto dg = std::make_unique<DiagMsg>();
    dg->header.stamp = msg->header.stamp;
    dg->header.frame_id = world_frame_;
    dg->status = static_cast<uint8_t>(e.status);
    dg->status_text = poseStatusName(e.status);
    dg->pose_published = ok;
    dg->active_camera_mask = msg->active_camera_mask;
    dg->observed_camera_mask = e.stats.observed_camera_mask;
    dg->num_cameras = static_cast<uint8_t>(e.stats.num_cameras);
    dg->num_tags = static_cast<uint16_t>(e.stats.num_tags);
    dg->num_tag_observations = static_cast<uint16_t>(e.stats.num_tag_observations);
    dg->num_corners = static_cast<uint16_t>(e.stats.num_corners);
    dg->num_outlier_corners = static_cast<uint16_t>(e.stats.num_outlier_corners);
    dg->num_rejected_detections = static_cast<uint16_t>(e.stats.num_rejected_detections);
    dg->reprojection_error_px = static_cast<float>(e.stats.reproj_rms_px);
    dg->max_reprojection_error_px = static_cast<float>(e.stats.reproj_max_px);
    dg->mean_distance_m = static_cast<float>(e.stats.mean_distance_m);
    dg->baseline_m = static_cast<float>(e.stats.baseline_m);
    dg->converged = e.stats.converged;
    dg->iterations = static_cast<uint16_t>(e.stats.iterations);
    dg->single_tag_ambiguity = e.stats.single_tag_ambiguity;
    dg->ambiguity_resolved_by_prior = e.stats.ambiguity_resolved_by_prior;
    if (e.has_pose) {
      dg->position_std_m = static_cast<float>(std::sqrt(e.covariance.block<3, 3>(0, 0).trace()));
      dg->rotation_std_deg = static_cast<float>(std::sqrt(e.covariance.block<3, 3>(3, 3).trace()) * kRad2Deg);
    }
    dg->processing_time_ms = static_cast<float>(proc_ms);
    dg->input_age_ms = static_cast<float>(input_age_ms);
    diag_pub_->publish(std::move(dg));
  }
}

void PoseEstimationNode::publishAlert(PoseStatus prev, PoseStatus now_s, const PoseEstimate& e) {
  if (!alert_pub_ || !alert_pub_->is_activated()) return;
  std::string text;
  if (now_s == PoseStatus::kOk) {
    (void)prev;
    text = std::string("INFO_VISION_RECOVERED|tags=") + std::to_string(e.stats.num_tags) +
           "|cams=" + std::to_string(e.stats.num_cameras);
    RCLCPP_INFO(get_logger(), "%s", text.c_str());
  } else {
    text = std::string("WARN_") + poseStatusName(now_s) +
           "|tags=" + std::to_string(e.stats.num_tags) + "|reproj=" + std::to_string(e.stats.reproj_rms_px);
    RCLCPP_WARN(get_logger(), "%s", text.c_str());
  }
  std_msgs::msg::String m;
  m.data = text;
  alert_pub_->publish(m);
}

void PoseEstimationNode::logStats() {
  const auto& c = estimator_.counters();
  RCLCPP_INFO(get_logger(),
              "frames %lu | 발행 %lu | DROPOUT %lu | 기각 reproj %lu kin %lu maha %lu amb %lu | 실패 %lu | "
              "모호 %lu | 재획득 %lu | 지연 avg %.3f max %.3f ms",
              c.frames, c.published, c.dropouts, c.rejected_reproj, c.rejected_kinematic, c.rejected_mahalanobis,
              c.rejected_ambiguous, c.solver_failed, c.ambiguity_frames, c.reacquisitions,
              lat_n_ ? lat_sum_ / lat_n_ : 0.0, lat_max_);
  lat_sum_ = lat_max_ = 0;
  lat_n_ = 0;
}

}  // namespace ppe

RCLCPP_COMPONENTS_REGISTER_NODE(ppe::PoseEstimationNode)
