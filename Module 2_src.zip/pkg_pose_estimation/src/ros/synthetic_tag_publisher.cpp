// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// synthetic_tag_publisher : [모듈 1] 없이 pose_estimation_node / EKF 연동을 시험하기 위한 합성 검출 발행기
//  - /vision/tag_detections (inhaul_msgs/TagDetectionArray) : 레일 주행 참값 + 코너 잡음, 차폐/단절 주입
//  - /sim/ground_truth_pose (geometry_msgs/PoseStamped)     : 동일 stamp 의 참값 (KPI 모니터용)
#include <memory>
#include <numeric>

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <inhaul_msgs/msg/tag_detection_array.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_components/register_node_macro.hpp>

#include "pkg_pose_estimation/sim_scene.hpp"

namespace ppe {

class SyntheticTagPublisher : public rclcpp::Node {
 public:
  explicit SyntheticTagPublisher(const rclcpp::NodeOptions& o) : rclcpp::Node("synthetic_tag_publisher", o) {
    const std::string share = ament_index_cpp::get_package_share_directory("pkg_pose_estimation") + "/config/";
    const auto bundle_file = declare_parameter("tag_bundle_file", share + "Tag_Bundle_Rigid_Map.yaml");
    const auto ext_file = declare_parameter("extrinsics_file", share + "camera_extrinsics_world.yaml");
    const auto fps = declare_parameter("fps", 60.0);
    noise_.corner_sigma_px = declare_parameter("corner_sigma_px", 0.05);
    noise_.reflection_prob = declare_parameter("reflection_prob", 0.0);
    occlusion_ratio_ = declare_parameter("occlusion_ratio", 0.0);
    dead_mask_ = static_cast<uint8_t>(declare_parameter("dead_camera_mask", 0));
    blackout_start_s_ = declare_parameter("blackout_start_s", -1.0);
    blackout_duration_s_ = declare_parameter("blackout_duration_s", 0.0);
    traj_.speed_mps = declare_parameter("speed_mps", 0.3);
    frame_id_ = declare_parameter("frame_id", std::string("dock_vision"));

    std::string err;
    if (!loadTagBundle(bundle_file, bundle_, err) || !cams_.loadExtrinsics(ext_file, err)) {
      throw std::runtime_error(err);
    }
    for (int c = 1; c <= 4; ++c) {
      Intrinsics K;
      if (!loadIntrinsics(share + "cam_intrinsics_ch" + std::to_string(c) + ".yaml", K, err) ||
          !cams_.setIntrinsics(c, K, err))
        throw std::runtime_error(err);
    }
    sim_ = std::make_unique<SimScene>(bundle_, cams_, 1234);
    sim_->setNoise(noise_);
    pub_ = create_publisher<inhaul_msgs::msg::TagDetectionArray>("/vision/tag_detections", rclcpp::QoS(5).reliable());
    gt_pub_ = create_publisher<geometry_msgs::msg::PoseStamped>("/sim/ground_truth_pose", rclcpp::QoS(10));
    t0_ = now();
    timer_ = create_wall_timer(std::chrono::nanoseconds(static_cast<int64_t>(1e9 / fps)), [this] { tick(); });
    RCLCPP_INFO(get_logger(), "합성 검출 발행 %.0f Hz, σ=%.3f px, 차폐 %.0f%%, 단절 마스크 0x%X", fps,
                noise_.corner_sigma_px, occlusion_ratio_ * 100, dead_mask_);
  }

 private:
  void tick() {
    const rclcpp::Time stamp = now();
    const double t = (stamp - t0_).seconds();
    const SE3 gt = traj_.at(t);
    if (occlusion_ratio_ > 0 && (frame_count_ % 30 == 0)) {
      std::vector<int> ids;
      for (const auto& tg : bundle_.tags()) ids.push_back(tg.id);
      std::shuffle(ids.begin(), ids.end(), sim_->rng());
      occ_ = std::set<int>(ids.begin(), ids.begin() + static_cast<long>(std::lround(ids.size() * occlusion_ratio_)));
    }
    ++frame_count_;
    const bool blackout = blackout_start_s_ >= 0 && t >= blackout_start_s_ && t < blackout_start_s_ + blackout_duration_s_;
    DetectionFrame f = sim_->observe(gt, stamp.nanoseconds(), occ_, dead_mask_);
    if (blackout) f.detections.clear();

    auto m = std::make_unique<inhaul_msgs::msg::TagDetectionArray>();
    m->header.stamp = stamp;
    m->header.frame_id = frame_id_;
    m->active_camera_mask = f.active_camera_mask;
    m->detections.resize(f.detections.size());
    for (size_t i = 0; i < f.detections.size(); ++i) {
      const auto& d = f.detections[i];
      auto& o = m->detections[i];
      o.camera_id = d.camera_id;
      o.tag_id = d.tag_id;
      o.decision_margin = d.decision_margin;
      o.hamming_error = d.hamming;
      Vec2 c = Vec2::Zero();
      for (int k = 0; k < 4; ++k) {
        o.corners[k].x = static_cast<float>(d.corners[k].x());
        o.corners[k].y = static_cast<float>(d.corners[k].y());
        c += d.corners[k] * 0.25;
      }
      o.center.x = static_cast<float>(c.x());
      o.center.y = static_cast<float>(c.y());
    }
    m->processing_time_ms = 2.0f;
    pub_->publish(std::move(m));

    geometry_msgs::msg::PoseStamped g;
    g.header.stamp = stamp;
    g.header.frame_id = cams_.worldFrame();
    const auto q = gt.quaternion();
    g.pose.position.x = gt.t.x();
    g.pose.position.y = gt.t.y();
    g.pose.position.z = gt.t.z();
    g.pose.orientation.x = q.x();
    g.pose.orientation.y = q.y();
    g.pose.orientation.z = q.z();
    g.pose.orientation.w = q.w();
    gt_pub_->publish(g);
  }

  TagBundleModel bundle_;
  MultiCamExtrinsicManager cams_;
  std::unique_ptr<SimScene> sim_;
  SimNoiseConfig noise_;
  RailTrajectory traj_;
  double occlusion_ratio_ = 0;
  uint8_t dead_mask_ = 0;
  double blackout_start_s_ = -1, blackout_duration_s_ = 0;
  std::set<int> occ_;
  uint64_t frame_count_ = 0;
  std::string frame_id_;
  rclcpp::Time t0_;
  rclcpp::Publisher<inhaul_msgs::msg::TagDetectionArray>::SharedPtr pub_;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr gt_pub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

}  // namespace ppe

RCLCPP_COMPONENTS_REGISTER_NODE(ppe::SyntheticTagPublisher)
