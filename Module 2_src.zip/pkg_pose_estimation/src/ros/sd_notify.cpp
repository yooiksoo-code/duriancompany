// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_pose_estimation/sd_notify.hpp"

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <cstdlib>
#include <cstring>

namespace ppe {

bool sdNotify(const std::string& state) {
  const char* path = std::getenv("NOTIFY_SOCKET");
  if (!path || !*path) return false;
  const int fd = ::socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (fd < 0) return false;
  sockaddr_un addr{};
  addr.sun_family = AF_UNIX;
  const size_t len = std::min(std::strlen(path), sizeof(addr.sun_path) - 1);
  std::memcpy(addr.sun_path, path, len);
  if (addr.sun_path[0] == '@') addr.sun_path[0] = '\0';  // abstract namespace
  const socklen_t alen = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + len);
  const ssize_t n = ::sendto(fd, state.data(), state.size(), MSG_NOSIGNAL, reinterpret_cast<sockaddr*>(&addr), alen);
  ::close(fd);
  return n == static_cast<ssize_t>(state.size());
}

int sdWatchdogIntervalMs() {
  const char* us = std::getenv("WATCHDOG_USEC");
  if (!us) return 0;
  const long v = std::strtol(us, nullptr, 10);
  return v > 0 ? static_cast<int>(v / 2000) : 0;
}

}  // namespace ppe
