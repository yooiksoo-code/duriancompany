// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// PoseEstimator : pose_estimation_node 의 ROS 비의존 처리 엔진 (설계서 4장 파이프라인 + 6장 예외처리)
//
//   TagDetectionArray
//     │ 입력 필터: active_camera_mask, 미등록 카메라/태그 ID, hamming, decision_margin, 중복
//     │ 유효 검출 0개 → VISION_DROPOUT (발행 중단, 진단만 송출)               ← 6장 3)
//     ▼
//   MultiViewBundlePnPSolver (RANSAC/IPPE 초기화 → 다중 시점 Huber-LM)
//     │ 1카메라·1태그 → prior(EKF 예측 → 없으면 직전 비전 해)로 IPPE 해 선택   ← 6장 1)
//     ▼
//   품질 게이트: 재투영 RMS > 2.5 px 기각                                    ← 6장 2)
//               키네마틱 게이트 (0.5 m/s, 15 °/s + 잡음 허용)                 ← 6장 2)
//               [선택] EKF 예측 대비 Mahalanobis 게이트
//     ▼
//   AdaptiveCovarianceEstimator → 6×6 Σ (단일 태그 시 회전 분산 ×5)        ← 4장 4)
//
//  키네마틱 게이트 재획득: 마지막 승인 후 reacquire_after_s 경과 시 기준을 해제하고
//  다중 태그(N_tags ≥ reacquire_min_tags) 해를 새 기준으로 채택 → 영구 락아웃 방지.
#pragma once

#include <optional>
#include <string>

#include "pkg_pose_estimation/adaptive_covariance_estimator.hpp"
#include "pkg_pose_estimation/multi_cam_extrinsic_manager.hpp"
#include "pkg_pose_estimation/multi_view_bundle_pnp_solver.hpp"
#include "pkg_pose_estimation/tag_bundle_model.hpp"

namespace ppe {

struct InputFilterConfig {
  float min_decision_margin = 0.f;  ///< [모듈 1]에서 이미 필터링 (기본 비활성)
  int max_hamming = 1;
  bool respect_active_mask = true;
};

struct GateConfig {
  double max_reproj_rms_px = 2.5;
  double min_inlier_ratio = 0.5;     ///< 이상치 제거 후 잔존 코너 비율 하한 (전면 흐림/오정합 프레임 기각)
  bool kinematic_gate = true;
  double max_speed_mps = 0.5;
  double max_rate_dps = 15.0;
  double pos_tolerance_m = 0.004;    ///< 측정 잡음 허용 (dt→0 일 때도 통과 여유)
  double rot_tolerance_deg = 0.3;
  double sigma_multiplier = 4.0;     ///< + k·σ (현재 해 공분산)
  double reacquire_after_s = 0.5;
  int reacquire_min_tags = 2;
  bool mahalanobis_gate = false;     ///< 기본 비활성 (EKF 혁신 게이트와 중복 → 상호 락아웃 위험)
  double mahalanobis_chi2 = 22.46;   ///< χ²(6, 0.999)
  double prior_timeout_s = 0.2;      ///< EKF prior 유효 시간
  double vision_prior_timeout_s = 0.3;  ///< 직전 비전 해를 모호성 prior 로 쓸 수 있는 시간
  /// prior 없이 1카메라·1태그만 보일 때: 두 IPPE 해의 재투영오차 비가 이 값 이상이면 확정, 미만이면 기각
  double ambiguity_min_error_ratio = 4.0;
};

struct EstimatorConfig {
  InputFilterConfig input;
  SolverConfig solver;
  GateConfig gate;
  CovarianceConfig covariance;
};

struct EstimatorCounters {
  uint64_t frames = 0, published = 0, dropouts = 0, rejected_reproj = 0, rejected_kinematic = 0,
           rejected_mahalanobis = 0, rejected_ambiguous = 0, solver_failed = 0, ambiguity_frames = 0, reacquisitions = 0;
};

class PoseEstimator {
 public:
  PoseEstimator() = default;
  bool configure(const TagBundleModel& bundle, const MultiCamExtrinsicManager& cams, const EstimatorConfig& cfg,
                 std::string& err);
  void setConfig(const EstimatorConfig& cfg);
  const EstimatorConfig& config() const { return cfg_; }

  /// EKF(모듈 3) 상태 갱신 (/sub_pose_filtered)
  void setPrior(const PosePrior& p) { prior_ = p; }
  /// 한 동기 주기 처리. status == kOk 일 때만 /sub_pose_vision 발행
  PoseEstimate process(const DetectionFrame& frame);
  void reset();

  const EstimatorCounters& counters() const { return counters_; }
  const TagBundleModel& bundle() const { return bundle_; }
  const MultiCamExtrinsicManager& cameras() const { return cams_; }
  bool hasReference() const { return last_.has_value(); }

 private:
  bool kinematicOk(const PoseEstimate& e) const;
  /// 예측 자세: EKF(유효 시) → 직전 두 비전 해 등속 외삽 → 직전 비전 해
  std::optional<SE3> predictedPrior(int64_t stamp_ns) const;

  TagBundleModel bundle_;
  MultiCamExtrinsicManager cams_;
  EstimatorConfig cfg_;
  MultiViewBundlePnPSolver solver_;
  AdaptiveCovarianceEstimator cov_;
  PosePrior prior_;
  struct Accepted {
    int64_t stamp_ns;
    SE3 T;
    Mat6 cov;
  };
  std::optional<Accepted> last_, prev_;
  std::vector<Detection> filtered_;
  EstimatorCounters counters_;
  bool configured_ = false;
};

}  // namespace ppe
