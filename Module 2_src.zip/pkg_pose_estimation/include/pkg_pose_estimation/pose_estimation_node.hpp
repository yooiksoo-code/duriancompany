// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// pose_estimation_node : [모듈 2] 6DoF 추정 ROS2 Humble LifecycleNode (rclcpp_components 등록)
//
//  상태 전이
//   configure  : 파라미터 → EstimatorConfig, Tag Bundle / 내부·외부 파라미터 로드, pub/sub 생성
//   activate   : 처리·발행 개시      deactivate : 처리 중단 (구독 유지, 입력 무시)
//   cleanup    : 자원 해제           error      : FAILURE → 프로세스 종료 → systemd 재기동
//
//  입력 : /vision/tag_detections   (inhaul_msgs/TagDetectionArray, [모듈 1], reliable keep_last 5)
//         /sub_pose_filtered       (nav_msgs/Odometry, [모듈 3] EKF — 모호성 해소/선택적 Mahalanobis)
//  출력 : /sub_pose_vision         (geometry_msgs/PoseWithCovarianceStamped, frame_id = dock_world_frame,
//                                   header.stamp = 입력 PTP 촬영 시각 그대로)
//         /vision/pose_diagnostics (inhaul_msgs/VisionPoseDiagnostics, 매 입력 프레임)
//         /hmi/vision_alerts       (std_msgs/String, 상태 전이 시 "코드|메시지")
//         [선택] TF dock_world_frame → submarine_base_link_vision
//
//  처리는 구독 콜백에서 동기 수행 (태그 ≤ 40개 규모에서 < 1 ms) → 큐잉 지연 없음.
//  [모듈 1]과 같은 컴포넌트 컨테이너에 적재 시 intra-process 로 무복사 전달 (launch composed:=true).
#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <inhaul_msgs/msg/tag_detection_array.hpp>
#include <inhaul_msgs/msg/vision_pose_diagnostics.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <rclcpp_lifecycle/lifecycle_publisher.hpp>
#include <std_msgs/msg/string.hpp>
#include <tf2_ros/transform_broadcaster.h>

#include "pkg_pose_estimation/pose_estimator.hpp"

namespace ppe {

class PoseEstimationNode : public rclcpp_lifecycle::LifecycleNode {
 public:
  using CallbackReturn = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn;
  using TagArray = inhaul_msgs::msg::TagDetectionArray;
  using PoseMsg = geometry_msgs::msg::PoseWithCovarianceStamped;
  using DiagMsg = inhaul_msgs::msg::VisionPoseDiagnostics;

  explicit PoseEstimationNode(const rclcpp::NodeOptions& options = rclcpp::NodeOptions());
  ~PoseEstimationNode() override = default;

  CallbackReturn on_configure(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_activate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_deactivate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_cleanup(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_shutdown(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_error(const rclcpp_lifecycle::State&) override;

  bool autostart() const { return autostart_; }
  /// systemd watchdog: 실행기(executor)가 살아 있는지 (타이머 하트비트)
  bool healthy() const;

 private:
  void declareParameters();
  bool buildConfig(EstimatorConfig& cfg, std::string& err);
  bool loadGeometry(TagBundleModel& bundle, MultiCamExtrinsicManager& cams, std::string& err);
  std::string resolvePath(const std::string& p) const;
  void onDetections(TagArray::UniquePtr msg);
  void onPrior(const nav_msgs::msg::Odometry::ConstSharedPtr& msg);
  void publishAlert(PoseStatus prev, PoseStatus now, const PoseEstimate& e);
  void logStats();

  PoseEstimator estimator_;
  DetectionFrame frame_;  // 재사용 버퍼
  std::mutex prior_mtx_;
  PosePrior prior_;
  bool prior_dirty_ = false;

  rclcpp::Subscription<TagArray>::SharedPtr det_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr prior_sub_;
  rclcpp_lifecycle::LifecyclePublisher<PoseMsg>::SharedPtr pose_pub_;
  rclcpp_lifecycle::LifecyclePublisher<DiagMsg>::SharedPtr diag_pub_;
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::String>::SharedPtr alert_pub_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_;
  rclcpp::TimerBase::SharedPtr heartbeat_timer_, stats_timer_;

  std::atomic<bool> active_{false};
  std::atomic<int64_t> heartbeat_ns_{0};
  bool autostart_ = true;
  bool publish_tf_ = false;
  bool publish_diag_ = true;
  std::string world_frame_, child_frame_, tf_child_frame_;
  PoseStatus last_status_ = PoseStatus::kOk;
  bool have_status_ = false;  ///< HMI 경보 발령 중 (정상 복귀 시 INFO 송출)
  int dropout_alert_frames_ = 3;
  int consecutive_non_ok_ = 0;
  // 지연 통계 (stats_period 단위 로그)
  double lat_sum_ = 0, lat_max_ = 0;
  uint64_t lat_n_ = 0;
};

}  // namespace ppe
