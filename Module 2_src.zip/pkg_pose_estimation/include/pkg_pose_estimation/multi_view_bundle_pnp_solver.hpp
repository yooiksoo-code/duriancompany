// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [세부 3] 결합 PnP 및 비선형 번들 조정 솔버 (MultiViewBundlePnPSolver)
//
//  ① 2D-3D 점 대응 매칭   : (camera_id, tag_id, m) → (u_{c,i,m}, P^body_{i,m})
//  ② 카메라별 초기 자세    : 태그 ≥ 2 → cv::solvePnPRansac (수면반사·번짐 코너 1차 제거)
//                            태그 = 1 → cv::solvePnPGeneric(IPPE_SQUARE) 두 해 모두 후보
//                            T_{W→body} = T_{W→Cc} · T_{Cc→tag_i} · (T_{body→tag_i})⁻¹
//     후보 선택            : 전 카메라 관측에 대한 절단(truncated) 재투영 비용 최소 후보
//                            단, 1카메라·1태그(모호) 시 prior(EKF) 회전과 가장 가까운 해 (설계서 6장 1)
//  ③ 다중 시점 LM 정합     : T* = argmin Σ_c Σ_{i∈V_c} Σ_m ρ_Huber(‖u − π(K_c, T_{W→Cc}⁻¹·T·P)‖²)
//                            해석적 야코비안 + Levenberg-Marquardt, 6변수, 동적할당 없음
//  산출                    : T*, JᵀJ(정보행렬), 재투영 RMS, d, L_baseline, N_tags …
//
//  Ceres/g2o 대신 직접 구현한 이유: 변수 6개·잔차 ≤ 320개 규모라 고정크기 Eigen 6×6 정규방정식이
//  범용 솔버 대비 오버헤드가 없고 결정적(deterministic) 실행시간을 가짐 (2.0 ms KPI).
#pragma once

#include <optional>
#include <vector>

#include "pkg_pose_estimation/multi_cam_extrinsic_manager.hpp"
#include "pkg_pose_estimation/tag_bundle_model.hpp"
#include "pkg_pose_estimation/types.hpp"

namespace ppe {

struct SolverConfig {
  // 추적 고속경로: 신뢰 가능한 예측 자세(EKF 또는 등속 외삽)가 대응점의 fast_path_min_inlier_ratio 이상을
  // candidate_truncation_px 이내로 설명하면 카메라별 RANSAC/IPPE 초기화를 생략하고 예측 자세에서 바로 LM.
  // 이상치는 동일하게 잔차 기반 2단계 분류로 제거됨. 재획득·단일태그 모호 상황은 항상 전체 초기화.
  bool tracking_fast_path = true;
  double fast_path_min_inlier_ratio = 0.8;
  // RANSAC (카메라별)
  bool use_ransac = true;
  double ransac_reproj_px = 3.0;
  int ransac_iterations = 60;
  double ransac_confidence = 0.995;
  // 이상치 판정 (초기해 및 LM 이후)
  double outlier_corner_px = 3.0;  ///< 코너 단위
  double outlier_tag_px = 2.5;     ///< 태그 단위 평균 (반사상/오매칭 태그 전체 제거)
  double candidate_truncation_px = 6.0;
  // LM
  double huber_delta_px = 1.0;
  int max_iterations = 12;
  double step_tolerance = 1e-9;     ///< |δ| 수렴 기준 ([m], [rad])
  double cost_rel_tolerance = 1e-10;
  double initial_lambda = 1e-4;
  int min_corners = 4;
  double min_depth_m = 0.05;
};

/// 매 프레임 재사용되는 2D-3D 대응 (사전할당 버퍼)
struct Correspondence {
  int8_t cam = 0;         ///< camera_id (1..)
  int16_t tag_index = 0;  ///< TagBundleModel 인덱스
  int16_t det_index = 0;  ///< 입력 검출 인덱스
  int8_t corner = 0;
  bool inlier = true;
  Vec2 uv;
  Vec3 Pb;  ///< P^body
};

struct SolveResult {
  bool ok = false;
  SE3 T_world_body;
  Mat6 information = Mat6::Zero();
  bool information_valid = false;
  SolveStats stats;
  double final_cost = 0.0;
  /// 1카메라·1태그 모호 상황: 선택되지 않은 IPPE 해와 그 사후확률 (혼합 공분산 계산용)
  bool has_alternative = false;
  SE3 alternative;
  double alternative_weight = 0.0;
};

class MultiViewBundlePnPSolver {
 public:
  MultiViewBundlePnPSolver();
  void setConfig(const SolverConfig& c) { cfg_ = c; }
  void setAmbiguitySigma(double px) { ambiguity_sigma_px_ = px; }
  const SolverConfig& config() const { return cfg_; }

  /// detections: 입력 필터를 통과한 검출 (camera, tag 모두 등록된 것)
  /// prior: 모호성 해소에 사용할 자세 (EKF 예측 또는 직전 비전 해), 없으면 nullopt
  SolveResult solve(const std::vector<Detection>& detections, const TagBundleModel& bundle,
                    const MultiCamExtrinsicManager& cams, const std::optional<SE3>& prior);

  /// 진단·시험용: 주어진 자세의 코너별 재투영 오차
  double reprojectionRms(const SE3& T_world_body, const MultiCamExtrinsicManager& cams) const;
  const std::vector<Correspondence>& correspondences() const { return corr_; }

 private:
  struct Candidate {
    SE3 T;
    int cam = 0;
    bool from_ippe = false;
  };
  void buildCorrespondences(const std::vector<Detection>& dets, const TagBundleModel& bundle);
  void initPerCamera(const std::vector<Detection>& dets, const TagBundleModel& bundle,
                     const MultiCamExtrinsicManager& cams, SolveStats& st);
  double truncatedCost(const SE3& T, const MultiCamExtrinsicManager& cams) const;
  void classifyOutliers(const SE3& T, const MultiCamExtrinsicManager& cams);
  bool optimize(SE3& T, const MultiCamExtrinsicManager& cams, SolveResult& out);
  void finalizeStats(const SE3& T, const TagBundleModel& bundle, const MultiCamExtrinsicManager& cams,
                     SolveResult& out);

  SolverConfig cfg_;
  std::vector<Correspondence> corr_;
  std::vector<Candidate> candidates_;
  // 카메라별 대응 인덱스 범위 (corr_ 는 카메라 순으로 정렬되어 저장)
  std::array<int, kMaxCameras + 1> cam_begin_{};
  std::array<int, kMaxCameras + 1> cam_end_{};
  std::array<double, 2> last_ippe_err_{};
  std::array<int, 2> ippe_cand_idx_{{-1, -1}};
  std::vector<int> tag_scratch_;
  double ambiguity_sigma_px_ = 0.05;
};

}  // namespace ppe
