// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [모듈 2] 6DoF 추정 SW 모듈 (pkg_pose_estimation) - 공통 타입 / SE(3) 연산
//
//  표기 규약 (설계서 T_{A→B} 와 동일 의미)
//    SE3 T_a_b : 좌표계 b 의 점을 a 로 옮기는 변환, p_a = R * p_b + t  (= 설계서 T_{a→b})
//    예) T_world_cam = T_{W→Cc}, T_world_body = T_{W→body}, T_body_tag = T_{body→tag_i}
//
//  자세 섭동/공분산 규약 (ROS geometry_msgs/PoseWithCovariance 와 일치)
//    위치: t' = t + δp           (월드 좌표계 [m])
//    회전: R' = Exp(δθ) · R      (월드 고정축 x,y,z 기준 소회전 [rad])
//    공분산 순서: [x, y, z, rot_x, rot_y, rot_z]
#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

#include <Eigen/Core>
#include <Eigen/Geometry>

namespace ppe {

using Vec2 = Eigen::Vector2d;
using Vec3 = Eigen::Vector3d;
using Mat3 = Eigen::Matrix3d;
using Vec6 = Eigen::Matrix<double, 6, 1>;
using Mat6 = Eigen::Matrix<double, 6, 6>;

constexpr int kMaxCameras = 8;     ///< camera_id 1..8 (설계 4대)
constexpr int kMaxTagId = 1024;    ///< tag36h11 ID 범위(0~586) 포함
constexpr double kDeg2Rad = M_PI / 180.0;
constexpr double kRad2Deg = 180.0 / M_PI;

inline Mat3 skew(const Vec3& v) {
  Mat3 m;
  m << 0, -v.z(), v.y(), v.z(), 0, -v.x(), -v.y(), v.x(), 0;
  return m;
}

/// SO(3) 지수사상 (Rodrigues)
inline Mat3 expSO3(const Vec3& w) {
  const double th = w.norm();
  if (th < 1e-12) return Mat3::Identity() + skew(w);
  return Eigen::AngleAxisd(th, w / th).toRotationMatrix();
}

/// SO(3) 로그사상
inline Vec3 logSO3(const Mat3& R) {
  const Eigen::AngleAxisd aa(R);
  return aa.angle() * aa.axis();
}

/// 두 회전 간 각도 [rad]
inline double rotationAngle(const Mat3& Ra, const Mat3& Rb) {
  return Eigen::AngleAxisd(Ra.transpose() * Rb).angle();  // 쿼터니언 경유 (acos 대비 소각 정밀)
}

/// ROS 규약 RPY → R = Rz(yaw)·Ry(pitch)·Rx(roll)  ([모듈 1] rotationFromRpyDeg 와 동일)
inline Mat3 rotationFromRpy(double roll, double pitch, double yaw) {
  return (Eigen::AngleAxisd(yaw, Vec3::UnitZ()) * Eigen::AngleAxisd(pitch, Vec3::UnitY()) *
          Eigen::AngleAxisd(roll, Vec3::UnitX()))
      .toRotationMatrix();
}

/// R → (roll, pitch, yaw) [rad], R = Rz·Ry·Rx
inline Vec3 rpyFromRotation(const Mat3& R) {
  const double pitch = std::asin(std::clamp(-R(2, 0), -1.0, 1.0));
  const double roll = std::atan2(R(2, 1), R(2, 2));
  const double yaw = std::atan2(R(1, 0), R(0, 0));
  return Vec3(roll, pitch, yaw);
}

struct SE3 {
  Mat3 R = Mat3::Identity();
  Vec3 t = Vec3::Zero();

  SE3() = default;
  SE3(const Mat3& R_, const Vec3& t_) : R(R_), t(t_) {}

  Vec3 operator*(const Vec3& p) const { return R * p + t; }
  SE3 operator*(const SE3& o) const { return SE3(R * o.R, R * o.t + t); }
  SE3 inverse() const {
    const Mat3 Rt = R.transpose();
    return SE3(Rt, -(Rt * t));
  }
  Eigen::Quaterniond quaternion() const { return Eigen::Quaterniond(R).normalized(); }
  static SE3 fromQuaternion(double qw, double qx, double qy, double qz, const Vec3& t) {
    return SE3(Eigen::Quaterniond(qw, qx, qy, qz).normalized().toRotationMatrix(), t);
  }
  /// 월드 기준 좌측 섭동 적용: δ = [δp; δθ]
  SE3 boxplus(const Vec6& d) const { return SE3(expSO3(d.tail<3>()) * R, t + d.head<3>()); }
  /// 이 자세 기준 o 의 차이 δ (boxplus 의 역): o = this ⊞ δ
  Vec6 boxminus(const SE3& o) const {
    Vec6 d;
    d.head<3>() = o.t - t;
    d.tail<3>() = logSO3(o.R * R.transpose());
    return d;
  }
};

/// [모듈 1] inhaul_msgs/TagDetection 대응 (ROS 비의존)
/// corners: 왜곡 보정된 이상적 핀홀 좌표 (K 동일, D=0), OpenCV 픽셀중심 규약, AprilTag 3 코너 순서
struct Detection {
  uint8_t camera_id = 0;
  int32_t tag_id = -1;
  float decision_margin = 0.f;
  uint8_t hamming = 0;
  std::array<Vec2, 4> corners{};
};

/// 단일 동기 주기 입력 (inhaul_msgs/TagDetectionArray 대응)
struct DetectionFrame {
  int64_t stamp_ns = 0;            ///< PTP 노출 시각 (출력 header.stamp 로 그대로 전달)
  uint8_t active_camera_mask = 0;  ///< bit0 = CH1
  std::vector<Detection> detections;
};

/// EKF(모듈 3) 직전 상태 (모호성 해소·Mahalanobis 게이트용)
struct PosePrior {
  bool valid = false;
  int64_t stamp_ns = 0;
  SE3 T_world_body;
  Vec3 v_body = Vec3::Zero();  ///< nav_msgs/Odometry twist (child frame = body)
  Vec3 w_body = Vec3::Zero();
  Mat6 cov = Mat6::Zero();
  bool has_cov = false;

  /// 등속 모델로 stamp_ns 시점까지 전파
  SE3 predict(int64_t to_ns) const {
    const double dt = static_cast<double>(to_ns - stamp_ns) * 1e-9;
    SE3 T = T_world_body;
    T.t += T.R * v_body * dt;
    T.R = T.R * expSO3(w_body * dt);
    return T;
  }
};

enum class PoseStatus : uint8_t {
  kOk = 0,
  kDropout = 1,                ///< VISION_DROPOUT : 유효 태그 0개 → 발행 중단
  kRejectedReprojection = 2,   ///< 재투영 오차 > 임계 (2.5 px)
  kRejectedKinematic = 3,      ///< 물리 속도 한계 초과 점프
  kRejectedMahalanobis = 4,    ///< EKF 예측 대비 Mahalanobis 거리 초과 (선택)
  kSolverFailed = 5,           ///< 초기해 실패 / 비수렴
  kRejectedAmbiguous = 6,      ///< 1카메라·1태그, prior 없음, 두 IPPE 해 구분 불가
};

inline const char* poseStatusName(PoseStatus s) {
  switch (s) {
    case PoseStatus::kOk: return "OK";
    case PoseStatus::kDropout: return "VISION_DROPOUT";
    case PoseStatus::kRejectedReprojection: return "REJECT_REPROJECTION";
    case PoseStatus::kRejectedKinematic: return "REJECT_KINEMATIC_GATE";
    case PoseStatus::kRejectedMahalanobis: return "REJECT_MAHALANOBIS";
    case PoseStatus::kSolverFailed: return "SOLVER_FAILED";
    case PoseStatus::kRejectedAmbiguous: return "REJECT_UNRESOLVED_AMBIGUITY";
  }
  return "UNKNOWN";
}

/// 솔버 품질 통계 (/vision/pose_diagnostics)
struct SolveStats {
  uint8_t observed_camera_mask = 0;
  int num_cameras = 0;
  int num_tags = 0;              ///< 서로 다른 태그 ID 수 (N_tags)
  int num_tag_observations = 0;  ///< (카메라, 태그) 관측 쌍 수
  int num_corners = 0;           ///< 최적화에 사용된 인라이어 코너 수
  int num_outlier_corners = 0;
  int num_rejected_detections = 0;  ///< 입력 필터(미등록 ID/카메라, hamming 등)에서 제외
  double reproj_rms_px = 0.0;    ///< e_reproj
  double reproj_max_px = 0.0;
  double mean_distance_m = 0.0;  ///< 카메라-관측태그 평균 거리 d
  double baseline_m = 0.0;       ///< 관측 태그 중심 간 최대 거리 L_baseline
  int iterations = 0;
  bool converged = false;
  bool single_tag_ambiguity = false;  ///< 1카메라·1태그 IPPE 모호성 상황
  bool ambiguity_resolved_by_prior = false;
  double ippe_error_ratio = 0.0;      ///< 모호 상황 시 두 IPPE 해의 재투영오차 비 (≥1)
  bool fast_path = false;             ///< 추적 고속경로(초기화 생략) 사용 여부
};

struct PoseEstimate {
  PoseStatus status = PoseStatus::kSolverFailed;
  int64_t stamp_ns = 0;
  SE3 T_world_body;
  Mat6 covariance = Mat6::Zero();
  SolveStats stats;
  double solve_time_ms = 0.0;
  bool has_pose = false;  ///< 해는 구했으나 게이트 기각된 경우에도 true (진단용)
};

}  // namespace ppe
