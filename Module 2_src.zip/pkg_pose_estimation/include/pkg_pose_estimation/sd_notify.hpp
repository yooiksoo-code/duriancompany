// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
// 최소 sd_notify 구현 (libsystemd 비의존). $NOTIFY_SOCKET 미설정 시 no-op.
#pragma once
#include <string>

namespace ppe {
bool sdNotify(const std::string& state);
/// $WATCHDOG_USEC 의 절반 [ms] (미설정 시 0)
int sdWatchdogIntervalMs();
}  // namespace ppe
