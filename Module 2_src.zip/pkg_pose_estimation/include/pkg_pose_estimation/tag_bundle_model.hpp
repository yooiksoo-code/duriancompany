// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [세부 1] 선체 Tag Bundle 3D 기하 매퍼 (TagBundleModelLoader)
//  - submarine_base_link 원점 기준 각 태그 ID_i 의 4개 코너 P^body_{i,m} 를 CAD 설계치로부터 로드
//  - 복수 태그를 하나의 가상 강체로 취급 → 일부 차폐 시에도 잔여 코너만으로 6DoF 추정 지속
//
//  지원 YAML 포맷
//   (A) 설계서 5장 Tag_Bundle_Rigid_Map.yaml
//       tags:
//         - {id: 0, size: 0.08, position: [x,y,z], quaternion: [qw,qx,qy,qz]}   # 또는 rpy_deg: [r,p,y]
//   (B) [모듈 1] tag_bundle.yaml (layout: [{id, x, y, z, rpy_deg}], default_size)
//  태그 좌표계는 AprilTag 3 규약: x 오른쪽, y 아래, z 태그 안쪽 (상향 부착 → rpy [180,0,0])
//  코너 순서: (-s/2,+s/2), (+s/2,+s/2), (+s/2,-s/2), (-s/2,-s/2)  = cv::SOLVEPNP_IPPE_SQUARE 순서
#pragma once

#include <string>
#include <vector>

#include "pkg_pose_estimation/types.hpp"

namespace ppe {

struct TagModel {
  int id = -1;
  double size = 0.08;  ///< 검정 외곽 테두리 한 변 [m]
  SE3 T_body_tag;
  std::array<Vec3, 4> corners_tag{};   ///< 태그 좌표계 코너 (z=0)
  std::array<Vec3, 4> corners_body{};  ///< P^body_{i,m}
  Vec3 center_body = Vec3::Zero();
  Vec3 normal_body = Vec3::UnitZ();    ///< 태그 앞면 방향 (= -z_tag)
};

std::array<Vec3, 4> tagCornersInTagFrame(double size);

class TagBundleModel {
 public:
  void clear();
  bool addTag(int id, double size, const SE3& T_body_tag, std::string& err);
  const TagModel* find(int id) const {
    return (id >= 0 && id < kMaxTagId && index_[id] >= 0) ? &tags_[index_[id]] : nullptr;
  }
  int indexOf(int id) const { return (id >= 0 && id < kMaxTagId) ? index_[id] : -1; }
  const std::vector<TagModel>& tags() const { return tags_; }
  size_t size() const { return tags_.size(); }
  const std::string& name() const { return name_; }
  void setName(const std::string& n) { name_ = n; }

 private:
  std::string name_ = "submarine_hull_bundle";
  std::vector<TagModel> tags_;
  std::array<int16_t, kMaxTagId> index_ = makeIndex();
  static std::array<int16_t, kMaxTagId> makeIndex() {
    std::array<int16_t, kMaxTagId> a{};
    a.fill(-1);
    return a;
  }
};

/// TagBundleModelLoader
bool loadTagBundle(const std::string& path, TagBundleModel& out, std::string& err);

}  // namespace ppe
