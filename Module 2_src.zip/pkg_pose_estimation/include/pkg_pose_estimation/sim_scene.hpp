// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 합성 관측 생성기 (단위시험 / KPI 벤치 / synthetic_tag_publisher 공용)
//  - 참값 T_{W→body} 와 카메라·번들 기하로 [모듈 1] 출력과 동일 규약의 코너를 생성
//    (왜곡 보정 좌표, K 동일, D=0, AprilTag 코너 순서)
//  - 가시성: 영상 내부(border), 카메라 앞, 태그 앞면-시선 각 ≤ max_view_angle_deg, 최소 변 길이
//  - 잡음: 코너별 가우시안 σ [px] (모듈 1 실측 정지지터 0.0085~0.05 px)
//  - 장애 주입: 태그 차폐 목록, 카메라 단절, 반사상(거울) 오검출, 코너 1개 번짐(outlier)
//  - 레일 주행 참값 궤적 (Physical Twin 2~3 m 구간 왕복, 롤/피치/요 소진동)
#pragma once

#include <random>
#include <set>

#include "pkg_pose_estimation/multi_cam_extrinsic_manager.hpp"
#include "pkg_pose_estimation/tag_bundle_model.hpp"
#include "pkg_pose_estimation/types.hpp"

namespace ppe {

struct SimNoiseConfig {
  double corner_sigma_px = 0.05;
  double max_view_angle_deg = 75.0;
  double min_side_px = 10.0;
  double border_px = 3.0;
  double reflection_prob = 0.0;     ///< 프레임당 반사상(오검출) 1개 주입 확률
  double blur_outlier_prob = 0.0;   ///< 검출당 코너 1개 번짐(수 px 오차) 확률
  double blur_outlier_px = 6.0;
};

class SimScene {
 public:
  SimScene(const TagBundleModel& bundle, const MultiCamExtrinsicManager& cams, uint32_t seed = 1);
  void setNoise(const SimNoiseConfig& n) { noise_ = n; }

  /// T_world_body 에서 관측 생성. occluded: 가려진 tag id, dead_mask: 단절 카메라 비트
  DetectionFrame observe(const SE3& T_world_body, int64_t stamp_ns, const std::set<int>& occluded = {},
                         uint8_t dead_mask = 0);
  /// 노이즈 없이 특정 카메라에 보이는 태그 id 목록
  std::vector<int> visibleTags(const SE3& T_world_body, int camera_id) const;

  std::mt19937& rng() { return rng_; }

 private:
  bool projectTag(const CameraModel& c, const TagModel& t, const SE3& T_wb, std::array<Vec2, 4>& uv) const;
  const TagBundleModel& bundle_;
  const MultiCamExtrinsicManager& cams_;
  SimNoiseConfig noise_;
  std::mt19937 rng_;
};

/// 레일 주행 참값 궤적
struct RailTrajectory {
  double x_min = -1.25, x_max = 1.25;  ///< 주행 구간 [m] (2.5 m)
  double speed_mps = 0.30;
  double y0 = 0.0, z0 = 0.35;          ///< body 원점(갑판 상면) 높이 → 카메라까지 ≈ 1.85 m
  double heave_amp_m = 0.003, heave_hz = 0.4;
  double roll_amp_deg = 1.5, roll_hz = 0.25;
  double pitch_amp_deg = 0.8, pitch_hz = 0.18;
  double yaw_amp_deg = 1.0, yaw_hz = 0.1;
  SE3 at(double t_s) const;
};

}  // namespace ppe
