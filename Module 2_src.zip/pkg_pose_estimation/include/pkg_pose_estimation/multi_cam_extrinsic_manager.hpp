// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [세부 2] 다중 카메라 월드 좌표계 통합 (MultiCamExtrinsicManager)
//  - 레일 프레임 상부 고정 카메라 c ∈ {1..4} 의 내부(K_c) / 외부(T_{W→Cc}) 파라미터 관리
//  - 입력 코너는 [모듈 1]에서 이미 왜곡 보정됨 → 투영 모델은 D=0 이상적 핀홀 (K 그대로)
//
//  외부 파라미터 YAML ([모듈 1] cam_extrinsics.yaml 과 동일 포맷, 설계서 camera_extrinsics_world.yaml)
//    world_frame: dock_world_frame
//    cameras:
//      - camera_id: 1
//        T_world_cam: {position: [x,y,z], rpy_deg: [r,p,y]}      # 또는 quaternion: [qw,qx,qy,qz]
//                                                                # 또는 matrix: [16개, row-major 4x4]
//  내부 파라미터 YAML: ROS camera_info 포맷 ([모듈 1] intrinsic_calibrator 출력 그대로)
#pragma once

#include <array>
#include <optional>
#include <string>

#include "pkg_pose_estimation/types.hpp"

namespace ppe {

struct CameraModel {
  int camera_id = 0;
  int width = 0;
  int height = 0;
  double fx = 0, fy = 0, cx = 0, cy = 0;
  SE3 T_world_cam;  ///< T_{W→Cc}
  SE3 T_cam_world;  ///< 역변환 캐시

  Vec3 center_world() const { return T_world_cam.t; }
  /// 카메라 좌표 → 픽셀 (z > 0 가정)
  Vec2 project(const Vec3& pc) const {
    const double iz = 1.0 / pc.z();
    return Vec2(fx * pc.x() * iz + cx, fy * pc.y() * iz + cy);
  }
  bool inImage(const Vec2& u, double border = 0.0) const {
    return u.x() >= border && u.y() >= border && u.x() <= width - 1 - border && u.y() <= height - 1 - border;
  }
};

struct Intrinsics {
  int width = 0, height = 0;
  double fx = 0, fy = 0, cx = 0, cy = 0;
  bool distortion_nonzero = false;  ///< 참고용 (입력은 이미 보정 좌표이므로 사용하지 않음)
};

bool loadIntrinsics(const std::string& path, Intrinsics& out, std::string& err);

class MultiCamExtrinsicManager {
 public:
  void clear();
  bool setCamera(int camera_id, const Intrinsics& K, const SE3& T_world_cam, std::string& err);
  /// 외부 파라미터 YAML 로드 → 로드된 카메라들의 T_world_cam 갱신 (내부 파라미터는 setIntrinsics 로)
  bool loadExtrinsics(const std::string& path, std::string& err);
  bool setIntrinsics(int camera_id, const Intrinsics& K, std::string& err);

  const CameraModel* camera(int camera_id) const {
    return (camera_id >= 1 && camera_id <= kMaxCameras && cams_[camera_id - 1]) ? &*cams_[camera_id - 1]
                                                                                 : nullptr;
  }
  /// 내부·외부 파라미터가 모두 설정된 카메라 비트마스크
  uint8_t configuredMask() const;
  double meanFocal() const;
  const std::string& worldFrame() const { return world_frame_; }
  void setWorldFrame(const std::string& f) { world_frame_ = f; }

 private:
  std::array<std::optional<CameraModel>, kMaxCameras> cams_{};
  std::array<bool, kMaxCameras> has_K_{};
  std::array<bool, kMaxCameras> has_T_{};
  std::string world_frame_ = "dock_world_frame";
};

}  // namespace ppe
