// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [세부 4] 적응형 오차 공분산 산출기 (AdaptiveCovarianceEstimator)
//
//  mode = "formula"  : 설계서 4장 4) 수식 (대각 공분산)
//        σ²_pos = α · d² · e² / N_tags
//        σ²_rot = β · d² · e² / (N_tags · L²_baseline)
//      ※ 설계서 원문은 σ²_rot 분자가 d²·e_reproj (e 1제곱) 로 표기되어 있으나 차원상 e² 가 맞아
//        (σ_rot ≈ d·e /(f·L)) e² 로 구현함. α, β 는 1/f² [rad²/px²] 스케일을 흡수하는 상수이며
//        pose_estimation_bench 가 몬테카를로 보정값(S1)을 출력함.
//  mode = "jacobian" : Σ = scale · s² · (JᵀJ)⁻¹,  s² = (Σ‖r‖² + ν0σ0²)/(2N−6+ν0) (성분당 잔차분산, 베이즈 결합)
//      LM 최종 야코비안 기반 — 축별 비등방성(카메라 광축 방향 Z 오차가 큼)과 위치-회전 상관을
//      반영하므로 EKF 입력으로 더 정확함 (기본값). 몬테카를로 NEES 로 일관성 검증.
//  공통 : 단일 태그(IPPE 모호) 시 회전 분산 × single_tag_rot_inflation (설계서 6장 1), 기본 5배)
//         분산 하한(min_pos_std_m / min_rot_std_deg) 적용
#pragma once

#include <string>

#include "pkg_pose_estimation/types.hpp"

namespace ppe {

struct CovarianceConfig {
  enum class Mode { kJacobian, kFormula };
  Mode mode = Mode::kJacobian;
  double alpha = 2.2e-7;   ///< [formula] 합성 몬테카를로 보정값 (벤치 S1). 테스트베드 재보정 필요
  double beta = 1.1e-5;    ///< [formula] 〃
  double sigma_floor_px = 0.02;  ///< 성분당 잔차 σ 하한 [px]
  /// 잔차 자유도가 작을 때(단일 태그: 2N−6 = 2) 경험 σ 가 매우 불안정 → 사전 σ0 와 베이즈 결합
  ///   s² = (ν·s_emp² + ν0·σ0²) / (ν + ν0),  ν = 2N − 6
  double prior_sigma_px = 0.05;  ///< σ0 : [모듈 1] 코너 잡음 수준 (실측 지터 0.0085~0.05 px)
  double prior_dof = 6.0;        ///< ν0
  double scale = 1.0;            ///< 전체 배율 (외부파라미터·모델 오차 등 미모델 오차 반영용, 실험 보정)
  double single_tag_rot_inflation = 5.0;
  double single_tag_pos_inflation = 1.0;
  /// 단일 태그 시 회전 표준편차 하한 [deg]: 정면 시점 소형 태그는 비용함수가 비선형(두 극소 근접)이라
  /// 국소 헤시안 공분산이 실제 오차를 크게 과소평가 → 회전 최대 고유값이 하한 미만이면 Σ 전체를 같은
  /// 비율로 확대 (레버암에 의한 위치-회전 상관 구조 유지). 벤치 S6 근거.
  double single_tag_min_rot_std_deg = 2.0;
  bool ambiguity_mixture = true;        ///< 단일 태그 시 두 IPPE 해 혼합 공분산 가산
  double ambiguity_min_weight = 0.05;   ///< 반대 해 사후확률 하한 (prior 선택 오류 가능성)
  double min_pos_std_m = 2e-5;
  double min_rot_std_deg = 0.001;
};

CovarianceConfig::Mode parseCovarianceMode(const std::string& s);

struct CovarianceInputs {
  Mat6 information = Mat6::Zero();  ///< JᵀJ (단위 픽셀 분산 기준)
  bool information_valid = false;
  double reproj_rms_px = 0.0;
  int num_residuals = 0;            ///< 코너 수 (잔차 2N)
  int num_tags = 0;
  double mean_distance_m = 0.0;
  double baseline_m = 0.0;
  double tag_size_m = 0.08;
  bool single_tag = false;
};

class AdaptiveCovarianceEstimator {
 public:
  explicit AdaptiveCovarianceEstimator(const CovarianceConfig& c = {}) : cfg_(c) {}
  void setConfig(const CovarianceConfig& c) { cfg_ = c; }
  const CovarianceConfig& config() const { return cfg_; }
  Mat6 compute(const CovarianceInputs& in) const;

 private:
  Mat6 formula(const CovarianceInputs& in) const;
  CovarianceConfig cfg_;
};

}  // namespace ppe
