// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// pkg_pose_estimation 단위시험 (설계서 4장 세부모듈 1~4, 6장 예외처리, 8장 KPI 축소판)
#include <gtest/gtest.h>

#include <chrono>
#include <numeric>

#include "pkg_pose_estimation/pose_estimator.hpp"
#include "pkg_pose_estimation/sim_scene.hpp"

#include <opencv2/calib3d.hpp>

using namespace ppe;

namespace {

const std::string kCfg = PPE_CONFIG_DIR;

struct World {
  TagBundleModel bundle;
  MultiCamExtrinsicManager cams;
  World() {
    std::string err;
    EXPECT_TRUE(loadTagBundle(kCfg + "/Tag_Bundle_Rigid_Map.yaml", bundle, err)) << err;
    EXPECT_TRUE(cams.loadExtrinsics(kCfg + "/camera_extrinsics_world.yaml", err)) << err;
    for (int c = 1; c <= 4; ++c) {
      Intrinsics K;
      EXPECT_TRUE(loadIntrinsics(kCfg + "/cam_intrinsics_ch" + std::to_string(c) + ".yaml", K, err)) << err;
      EXPECT_TRUE(cams.setIntrinsics(c, K, err)) << err;
    }
  }
};

SE3 nominalPose(double x = 0.1) {
  return SE3(rotationFromRpy(1.0 * kDeg2Rad, -0.5 * kDeg2Rad, 2.0 * kDeg2Rad), Vec3(x, 0.01, 0.35));
}

double posErr(const SE3& a, const SE3& b) { return (a.t - b.t).norm(); }
double rotErrDeg(const SE3& a, const SE3& b) { return rotationAngle(a.R, b.R) * kRad2Deg; }

PoseEstimator makeEstimator(const World& w, EstimatorConfig cfg = {}) {
  PoseEstimator pe;
  std::string err;
  EXPECT_TRUE(pe.configure(w.bundle, w.cams, cfg, err)) << err;
  return pe;
}

int64_t ns(double s) { return static_cast<int64_t>(s * 1e9); }

}  // namespace

// ───────────────────────── 세부 1/2: 설정 로드 ─────────────────────────
TEST(Config, BundleAndCamerasLoad) {
  World w;
  ASSERT_EQ(w.bundle.size(), 10u);
  EXPECT_EQ(w.cams.configuredMask(), 0x0F);
  EXPECT_EQ(w.cams.worldFrame(), "dock_world_frame");
  // 상향 태그: 법선 = +z_body, 코너 순서(AprilTag) → 상방에서 보면 영상 좌표 와인딩 일정
  const TagModel* t0 = w.bundle.find(0);
  ASSERT_NE(t0, nullptr);
  EXPECT_NEAR(t0->normal_body.z(), 1.0, 1e-12);
  EXPECT_NEAR((t0->corners_body[0] - t0->corners_body[1]).norm(), 0.08, 1e-12);
  // quaternion [0,1,0,0] 표기(세일 태그)와 rpy [180,0,0] 표기(갑판 태그)가 같은 회전
  EXPECT_LT((w.bundle.find(8)->T_body_tag.R - t0->T_body_tag.R).norm(), 1e-9);
  EXPECT_EQ(w.bundle.find(42), nullptr);
}

TEST(Config, Module1LayoutFormatCompatible) {
  const std::string p = "/tmp/ppe_m1_bundle.yaml";
  FILE* f = std::fopen(p.c_str(), "w");
  std::fputs("name: m1\ndefault_size: 0.08\nlayout:\n  - {id: 3, x: -0.15, y: -0.08, z: 0.0, rpy_deg: [180, 0, 0]}\n", f);
  std::fclose(f);
  TagBundleModel b;
  std::string err;
  ASSERT_TRUE(loadTagBundle(p, b, err)) << err;
  ASSERT_NE(b.find(3), nullptr);
  EXPECT_NEAR(b.find(3)->center_body.x(), -0.15, 1e-12);
}

TEST(Config, RejectsNonOrthogonalRotation) {
  const std::string p = "/tmp/ppe_bad_bundle.yaml";
  FILE* f = std::fopen(p.c_str(), "w");
  std::fputs("tags:\n  - {id: 1, position: [0,0,0], rotation: [1,0,0, 0,2,0, 0,0,1]}\n", f);
  std::fclose(f);
  TagBundleModel b;
  std::string err;
  EXPECT_FALSE(loadTagBundle(p, b, err));
  EXPECT_NE(err.find("직교"), std::string::npos);
}

// ───────────────────────── SE(3) / 야코비안 ─────────────────────────
TEST(Math, BoxplusBoxminusRoundTrip) {
  const SE3 a = nominalPose();
  Vec6 d;
  d << 0.01, -0.02, 0.005, 0.01, -0.003, 0.02;
  const SE3 b = a.boxplus(d);
  EXPECT_LT((a.boxminus(b) - d).norm(), 1e-12);
}

// ───────────────────────── 세부 3: 솔버 정밀도 ─────────────────────────
TEST(Solver, NoiselessMultiCameraExact) {
  World w;
  SimScene sim(w.bundle, w.cams, 7);
  SimNoiseConfig nz;
  nz.corner_sigma_px = 0.0;
  sim.setNoise(nz);
  const SE3 gt = nominalPose();
  const DetectionFrame f = sim.observe(gt, ns(1.0));
  ASSERT_GE(f.detections.size(), 10u);
  MultiViewBundlePnPSolver s;
  const SolveResult r = s.solve(f.detections, w.bundle, w.cams, std::nullopt);
  ASSERT_TRUE(r.ok);
  EXPECT_LT(posErr(r.T_world_body, gt), 1e-7);
  EXPECT_LT(rotErrDeg(r.T_world_body, gt), 1e-6);
  EXPECT_LT(r.stats.reproj_rms_px, 1e-5);
  EXPECT_EQ(r.stats.num_cameras, 4);
  EXPECT_EQ(r.stats.num_tags, 10);
  EXPECT_TRUE(r.stats.converged);
}

TEST(Solver, NoisyAccuracyWithinKpi) {
  World w;
  SimScene sim(w.bundle, w.cams, 11);  // σ = 0.05 px
  MultiViewBundlePnPSolver s;
  double se = 0, re = 0;
  const int N = 200;
  for (int i = 0; i < N; ++i) {
    const SE3 gt = nominalPose(-0.6 + 1.2 * i / N);
    const SolveResult r = s.solve(sim.observe(gt, ns(i / 60.0)).detections, w.bundle, w.cams, std::nullopt);
    ASSERT_TRUE(r.ok);
    se += std::pow(posErr(r.T_world_body, gt), 2);
    re += std::pow(rotErrDeg(r.T_world_body, gt), 2);
  }
  EXPECT_LT(std::sqrt(se / N), 0.5e-3);  // KPI ±2.0 mm 대비 여유
  EXPECT_LT(std::sqrt(re / N), 0.05);    // KPI ±0.25° 대비 여유
}

TEST(Solver, RejectsMirrorReflectionAndBlurredCorner) {
  World w;
  SimScene sim(w.bundle, w.cams, 3);
  SimNoiseConfig nz;
  nz.reflection_prob = 1.0;     // 매 프레임 반사상 1개
  nz.blur_outlier_prob = 0.15;  // 검출 15% 에서 코너 1개 6px 번짐
  sim.setNoise(nz);
  MultiViewBundlePnPSolver s;
  int with_outliers = 0;
  for (int i = 0; i < 100; ++i) {
    const SE3 gt = nominalPose(-0.5 + 0.01 * i);
    const SolveResult r = s.solve(sim.observe(gt, ns(i / 60.0)).detections, w.bundle, w.cams, std::nullopt);
    ASSERT_TRUE(r.ok);
    with_outliers += r.stats.num_outlier_corners > 0;
    EXPECT_LT(posErr(r.T_world_body, gt), 1.0e-3) << "frame " << i;
    EXPECT_LT(rotErrDeg(r.T_world_body, gt), 0.05) << "frame " << i;
    EXPECT_LT(r.stats.reproj_rms_px, 0.2);
  }
  EXPECT_GT(with_outliers, 90);
}

// ───────────────────────── 6장 1): 단일 태그 모호성 ─────────────────────────
TEST(Ambiguity, PriorSelectsCorrectIppeSolution) {
  World w;
  SimScene sim(w.bundle, w.cams, 5);
  const SE3 gt = nominalPose(0.0);
  DetectionFrame f = sim.observe(gt, ns(2.0));
  // CH2 의 태그 1개만 남김 (1카메라·1태그)
  DetectionFrame one;
  one.stamp_ns = f.stamp_ns;
  one.active_camera_mask = f.active_camera_mask;
  for (const auto& d : f.detections)
    if (d.camera_id == 2) {
      one.detections.push_back(d);
      break;
    }
  ASSERT_EQ(one.detections.size(), 1u);

  MultiViewBundlePnPSolver s;
  // prior = 참값 근처 (EKF 예측 오차 2°, 1 cm)
  const SE3 prior = gt.boxplus((Vec6() << 0.01, 0, 0, 0.02, -0.02, 0.01).finished());
  const SolveResult r = s.solve(one.detections, w.bundle, w.cams, prior);
  ASSERT_TRUE(r.ok);
  EXPECT_TRUE(r.stats.single_tag_ambiguity);
  EXPECT_TRUE(r.stats.ambiguity_resolved_by_prior);
  EXPECT_LT(rotErrDeg(r.T_world_body, gt), 3.0);  // 단일 80mm 태그 @1.85m: 회전 정밀도 낮음, 플립(수십°) 아님

  // 두 IPPE 해를 직접 구해 각각을 prior 로 주면, 솔버가 그 prior 쪽 해를 고르는지 확인
  const Detection& d = one.detections[0];
  const TagModel& tm = *w.bundle.find(d.tag_id);
  const CameraModel& cam = *w.cams.camera(2);
  std::vector<cv::Point3d> obj;
  std::vector<cv::Point2d> img;
  for (int m = 0; m < 4; ++m) {
    obj.emplace_back(tm.corners_tag[m].x(), tm.corners_tag[m].y(), 0);
    img.emplace_back(d.corners[m].x(), d.corners[m].y());
  }
  std::vector<cv::Mat> rv, tv;
  const cv::Matx33d K(cam.fx, 0, cam.cx, 0, cam.fy, cam.cy, 0, 0, 1);
  ASSERT_EQ(cv::solvePnPGeneric(obj, img, K, cv::noArray(), rv, tv, false, cv::SOLVEPNP_IPPE_SQUARE), 2);
  std::array<SE3, 2> sol;
  for (int k = 0; k < 2; ++k) {
    cv::Mat Rm;
    cv::Rodrigues(rv[k], Rm);
    SE3 Tct;
    for (int i = 0; i < 3; ++i) {
      for (int j = 0; j < 3; ++j) Tct.R(i, j) = Rm.at<double>(i, j);
      Tct.t[i] = tv[k].at<double>(i);
    }
    sol[k] = cam.T_world_cam * Tct * tm.T_body_tag.inverse();
  }
  const double sep = rotErrDeg(sol[0], sol[1]);
  std::printf("    IPPE 두 해 회전 차 = %.2f°\n", sep);
  EXPECT_GT(sep, 1.0);
  for (int k = 0; k < 2; ++k) {
    const SolveResult rk = s.solve(one.detections, w.bundle, w.cams, sol[k]);
    ASSERT_TRUE(rk.ok);
    EXPECT_LT(rotErrDeg(rk.T_world_body, sol[k]), rotErrDeg(rk.T_world_body, sol[1 - k]));
  }
}

TEST(Ambiguity, EstimatorInflatesRotationCovarianceFiveTimes) {
  World w;
  EstimatorConfig cfg;
  cfg.covariance.ambiguity_mixture = false;  // 설계서 6장 1) ×5 규칙만 분리 검증
  cfg.covariance.single_tag_min_rot_std_deg = 0.0;
  PoseEstimator pe = makeEstimator(w, cfg);
  SimScene sim(w.bundle, w.cams, 9);
  const SE3 gt = nominalPose(0.0);
  // 1) 다중 태그 프레임으로 기준 확보
  ASSERT_EQ(pe.process(sim.observe(gt, ns(0.0))).status, PoseStatus::kOk);
  // 2) 1카메라·1태그 프레임 (직전 비전 해가 prior)
  DetectionFrame f = sim.observe(gt, ns(1.0 / 60));
  DetectionFrame one = f;
  one.detections.assign(1, f.detections[0]);
  const PoseEstimate e = pe.process(one);
  ASSERT_EQ(e.status, PoseStatus::kOk) << poseStatusName(e.status);
  EXPECT_TRUE(e.stats.single_tag_ambiguity);
  // 같은 관측을 inflation=1 로 계산한 공분산과 비교 → 회전 블록 5배
  EstimatorConfig c1 = cfg;
  c1.covariance.single_tag_rot_inflation = 1.0;
  PoseEstimator pe1 = makeEstimator(w, c1);
  pe1.process(sim.observe(gt, ns(0.0)));
  const PoseEstimate e1 = pe1.process(one);
  ASSERT_EQ(e1.status, PoseStatus::kOk);
  for (int i = 3; i < 6; ++i) EXPECT_NEAR(e.covariance(i, i) / e1.covariance(i, i), 5.0, 1e-6);
}

TEST(Ambiguity, NoPriorIndistinguishableIsRejected) {
  World w;
  PoseEstimator pe = makeEstimator(w);
  SimScene sim(w.bundle, w.cams, 13);
  int rejected = 0, ok_flip = 0, total = 0;
  for (int i = 0; i < 60; ++i) {
    pe.reset();  // prior 없음
    const SE3 gt = nominalPose(-0.4 + 0.013 * i);
    DetectionFrame f = sim.observe(gt, ns(i));
    DetectionFrame one = f;
    one.detections.assign(1, f.detections[i % f.detections.size()]);
    const PoseEstimate e = pe.process(one);
    ++total;
    if (e.status == PoseStatus::kRejectedAmbiguous) ++rejected;
    if (e.status == PoseStatus::kOk && rotErrDeg(e.T_world_body, gt) > 5.0) ++ok_flip;
  }
  EXPECT_EQ(ok_flip, 0) << "prior 없는 모호 상황에서 뒤집힌 해가 발행됨";
  EXPECT_GT(rejected, 0);
}

// ───────────────────────── 6장 2): 게이트 ─────────────────────────
TEST(Gate, KinematicJumpRejectedThenReacquired) {
  World w;
  PoseEstimator pe = makeEstimator(w);
  SimScene sim(w.bundle, w.cams, 21);
  const SE3 gt = nominalPose(0.0);
  ASSERT_EQ(pe.process(sim.observe(gt, ns(0.0))).status, PoseStatus::kOk);
  // 1/60 s 후 5 cm 점프 (3 m/s 상당) → 기각
  const SE3 jump(gt.R, gt.t + Vec3(0.05, 0, 0));
  EXPECT_EQ(pe.process(sim.observe(jump, ns(1.0 / 60))).status, PoseStatus::kRejectedKinematic);
  // 회전 점프 3° (180 °/s 상당) → 기각
  const SE3 rjump(expSO3(Vec3(0, 0, 3.0 * kDeg2Rad)) * gt.R, gt.t);
  EXPECT_EQ(pe.process(sim.observe(rjump, ns(2.0 / 60))).status, PoseStatus::kRejectedKinematic);
  // 정상 이동(0.3 m/s)은 통과
  const SE3 move(gt.R, gt.t + Vec3(0.3 / 60 * 3, 0, 0));
  EXPECT_EQ(pe.process(sim.observe(move, ns(3.0 / 60))).status, PoseStatus::kOk);
  // 지속적 점프 상태가 reacquire_after_s(0.5 s) 넘게 이어지면 새 기준 채택 (영구 락아웃 방지)
  const SE3 far(gt.R, gt.t + Vec3(0.4, 0, 0));
  PoseStatus st = PoseStatus::kOk;
  int k = 4;
  for (; k < 60; ++k) {
    st = pe.process(sim.observe(far, ns(k / 60.0))).status;
    if (st == PoseStatus::kOk) break;
  }
  EXPECT_EQ(st, PoseStatus::kOk);
  EXPECT_GE(k / 60.0 - 3.0 / 60, 0.5 - 1e-9);
  EXPECT_EQ(pe.counters().reacquisitions, 1u);
}

TEST(Gate, ReprojectionErrorAboveThresholdRejected) {
  World w;
  SimScene sim(w.bundle, w.cams, 4);
  // (1) RMS 게이트 로직: 임계값을 잡음 수준 이하로 낮추면 기각
  {
    EstimatorConfig cfg;
    cfg.gate.max_reproj_rms_px = 0.02;  // σ=0.05 px 잡음 RMS(≈0.07) 미만
    PoseEstimator pe = makeEstimator(w, cfg);
    const PoseEstimate e = pe.process(sim.observe(nominalPose(), ns(0)));
    EXPECT_EQ(e.status, PoseStatus::kRejectedReprojection);
    EXPECT_TRUE(e.has_pose);
  }
  // (2) 전면 흐림(σ=3.5 px): 이상치 제거 후 잔존 비율 < 50% 또는 RMS 초과 → 한 프레임도 발행 안 됨
  PoseEstimator pe = makeEstimator(w);
  SimNoiseConfig nz;
  nz.corner_sigma_px = 3.5;
  sim.setNoise(nz);
  int rej = 0, published = 0;
  for (int i = 0; i < 20; ++i) {
    pe.reset();
    const PoseStatus st = pe.process(sim.observe(nominalPose(), ns(i))).status;
    rej += st == PoseStatus::kRejectedReprojection;
    published += st == PoseStatus::kOk;
  }
  EXPECT_EQ(published, 0);
  std::printf("    σ=3.5px: REJECT_REPROJECTION %d / SOLVER_FAILED %d / 20\n", rej, 20 - rej - published);
}

TEST(Gate, MahalanobisOptionalAgainstPrior) {
  World w;
  EstimatorConfig cfg;
  cfg.gate.mahalanobis_gate = true;
  cfg.gate.kinematic_gate = false;
  PoseEstimator pe = makeEstimator(w, cfg);
  SimScene sim(w.bundle, w.cams, 8);
  const SE3 gt = nominalPose();
  PosePrior p;
  p.valid = true;
  p.stamp_ns = ns(1.0);
  p.T_world_body = gt.boxplus((Vec6() << 0.03, 0, 0, 0, 0, 0).finished());  // EKF 가 3 cm 어긋남
  p.has_cov = true;
  p.cov = Mat6::Identity() * 1e-6;  // σ = 1 mm 로 과신
  pe.setPrior(p);
  EXPECT_EQ(pe.process(sim.observe(gt, ns(1.0))).status, PoseStatus::kRejectedMahalanobis);
  p.cov = Mat6::Identity() * 1e-3;  // σ ≈ 3 cm
  pe.setPrior(p);
  EXPECT_EQ(pe.process(sim.observe(gt, ns(1.0 + 1.0 / 60))).status, PoseStatus::kOk);
}

// ───────────────────────── 6장 3): 완전 차폐 / 카메라 단절 ─────────────────────────
TEST(Dropout, ZeroDetectionStopsPublishing) {
  World w;
  PoseEstimator pe = makeEstimator(w);
  DetectionFrame f;
  f.stamp_ns = ns(1.0);
  f.active_camera_mask = 0x0F;
  EXPECT_EQ(pe.process(f).status, PoseStatus::kDropout);
  // 미등록 ID / 비활성 카메라 / hamming 초과만 있는 경우도 DROPOUT
  Detection d;
  d.camera_id = 1;
  d.tag_id = 300;
  f.detections.push_back(d);
  d.tag_id = 2;
  d.hamming = 3;
  f.detections.push_back(d);
  d.hamming = 0;
  d.camera_id = 3;
  f.active_camera_mask = 0x0B;  // CH3 비활성
  f.detections.push_back(d);
  const PoseEstimate e = pe.process(f);
  EXPECT_EQ(e.status, PoseStatus::kDropout);
  EXPECT_EQ(e.stats.num_rejected_detections, 3);
  EXPECT_EQ(pe.counters().dropouts, 2u);
}

TEST(Dropout, TwoCamerasLostStillAccurate) {
  World w;
  PoseEstimator pe = makeEstimator(w);
  SimScene sim(w.bundle, w.cams, 17);
  const SE3 gt = nominalPose(0.2);
  const PoseEstimate e = pe.process(sim.observe(gt, ns(0.0), {}, 0b0101));  // CH1, CH3 단절
  ASSERT_EQ(e.status, PoseStatus::kOk);
  EXPECT_EQ(e.stats.observed_camera_mask, 0b1010);
  EXPECT_LT(posErr(e.T_world_body, gt), 1e-3);
}

// ───────────────────────── 8장: 70% 마커 차폐 ─────────────────────────
TEST(Occlusion, SevenOfTenTagsHiddenContinuous) {
  World w;
  PoseEstimator pe = makeEstimator(w);
  SimScene sim(w.bundle, w.cams, 31);
  RailTrajectory traj;
  std::mt19937 rng(99);
  double max_pos = 0, max_rot = 0;
  int ok = 0, frames = 0;
  std::set<int> occ;
  for (int i = 0; i < 600; ++i) {
    const double t = i / 60.0;
    if (i % 30 == 0) {  // 0.5 초마다 무작위 7개 차폐
      std::vector<int> ids(10);
      std::iota(ids.begin(), ids.end(), 0);
      std::shuffle(ids.begin(), ids.end(), rng);
      occ = std::set<int>(ids.begin(), ids.begin() + 7);
    }
    const SE3 gt = traj.at(t);
    const DetectionFrame f = sim.observe(gt, ns(t), occ);
    if (f.detections.empty()) continue;  // 남은 3개가 모두 시야 밖 → 정상 DROPOUT
    ++frames;
    const PoseEstimate e = pe.process(f);
    if (e.status != PoseStatus::kOk) continue;
    ++ok;
    max_pos = std::max(max_pos, posErr(e.T_world_body, gt));
    max_rot = std::max(max_rot, rotErrDeg(e.T_world_body, gt));
  }
  EXPECT_GE(ok, frames * 0.97) << ok << "/" << frames;
  EXPECT_LT(max_pos, 5e-3);  // 발산 없음 (최악 프레임: 원거리 단일 태그)
  EXPECT_LT(max_rot, 1.0);
}

// ───────────────────────── 세부 4: 공분산 ─────────────────────────
TEST(Covariance, JacobianModeConsistentNees) {
  World w;
  EstimatorConfig cfg;
  // 하한값은 운영 안전장치(합성 잡음에서는 실제 오차가 µm 수준이라 하한이 지배) → 일관성 검증 시 해제
  cfg.covariance.min_pos_std_m = 1e-9;
  cfg.covariance.min_rot_std_deg = 1e-9;
  cfg.covariance.sigma_floor_px = 1e-6;
  PoseEstimator pe = makeEstimator(w, cfg);
  SimScene sim(w.bundle, w.cams, 41);
  double nees = 0;
  int n = 0;
  for (int i = 0; i < 400; ++i) {
    pe.reset();
    const SE3 gt = nominalPose(-0.8 + 0.004 * i);
    const PoseEstimate e = pe.process(sim.observe(gt, ns(i)));
    ASSERT_EQ(e.status, PoseStatus::kOk);
    const Vec6 d = gt.boxminus(e.T_world_body);
    nees += d.dot(e.covariance.ldlt().solve(d));
    ++n;
  }
  nees /= n;
  std::printf("    NEES(jacobian) = %.2f (기대값 6)\n", nees);
  // 일관된 6자유도 추정기의 NEES 기대값 = 6 (하한 바닥값 적용으로 다소 보수적 허용)
  EXPECT_GT(nees, 6.0 * 0.8);
  EXPECT_LT(nees, 6.0 * 1.2);
}

TEST(Covariance, FormulaModeScalesWithDistanceAndTags) {
  CovarianceConfig c;
  c.mode = CovarianceConfig::Mode::kFormula;
  c.alpha = c.beta = 1e-4;  // 하한값(min_*_std)에 걸리지 않는 스케일로 비례관계만 검증
  AdaptiveCovarianceEstimator est(c);
  CovarianceInputs in;
  in.reproj_rms_px = 0.2;
  in.num_tags = 4;
  in.mean_distance_m = 2.0;
  in.baseline_m = 1.0;
  const Mat6 a = est.compute(in);
  in.mean_distance_m = 4.0;
  const Mat6 b = est.compute(in);
  EXPECT_NEAR(b(0, 0) / a(0, 0), 4.0, 1e-9);  // ∝ d²
  in.mean_distance_m = 2.0;
  in.num_tags = 8;
  const Mat6 c2 = est.compute(in);
  EXPECT_NEAR(a(0, 0) / c2(0, 0), 2.0, 1e-9);  // ∝ 1/N
  in.num_tags = 4;
  in.baseline_m = 2.0;
  const Mat6 d = est.compute(in);
  EXPECT_NEAR(a(3, 3) / d(3, 3), 4.0, 1e-9);  // σ²_rot ∝ 1/L²
}

// ───────────────────────── 8장: 연산 지연 ─────────────────────────
TEST(Latency, FullViewUnderBudget) {
  World w;
  PoseEstimator pe = makeEstimator(w);
  SimScene sim(w.bundle, w.cams, 2);
  RailTrajectory traj;
  std::vector<double> ms;
  int fast = 0;
  for (int i = 0; i < 600; ++i) {
    const DetectionFrame f = sim.observe(traj.at(i / 60.0), ns(i / 60.0));
    const PoseEstimate e = pe.process(f);
    ms.push_back(e.solve_time_ms);
    fast += e.stats.fast_path;
    if (i == 0) {
      EXPECT_FALSE(e.stats.fast_path);  // 최초 프레임은 RANSAC/IPPE 전체 초기화
    }
  }
  EXPECT_GT(fast, 590);  // 추적 중에는 등속 외삽 예측으로 고속경로
  std::sort(ms.begin(), ms.end());
  const double p50 = ms[ms.size() / 2];
  // KPI ≤ 2.0 ms (목표 HW). 공유 CI 머신 변동을 고려해 중앙값으로 판정
  EXPECT_LT(p50, 2.0) << "p50=" << p50;
}
