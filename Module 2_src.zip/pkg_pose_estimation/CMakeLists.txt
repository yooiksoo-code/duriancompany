cmake_minimum_required(VERSION 3.16)
project(pkg_pose_estimation LANGUAGES CXX)

# ─────────────────────────────────────────────────────────────────────────────
#  [모듈 2] 6DoF 추정 SW 모듈 - 손원일급 잠수함 자동 INHAUL / 주식회사 두리안컴퍼니
#   PPE_CORE_ONLY=ON : ROS 없이 코어 라이브러리 + 시험 + 벤치만 빌드 (알고리즘 개발·CI)
# ─────────────────────────────────────────────────────────────────────────────
option(PPE_CORE_ONLY "Build ROS-independent core, tests and bench only" OFF)
option(PPE_NATIVE_ARCH "Compile with -march=native (target edge PC only)" OFF)

if(NOT CMAKE_CXX_STANDARD)
  set(CMAKE_CXX_STANDARD 17)
endif()
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
add_compile_options(-Wall -Wextra -Wpedantic -Wno-unused-parameter)
if(PPE_NATIVE_ARCH)
  add_compile_options(-march=native)
endif()

find_package(Eigen3 REQUIRED)
find_package(OpenCV 4 REQUIRED COMPONENTS core calib3d)
find_package(yaml-cpp REQUIRED)
if(TARGET yaml-cpp::yaml-cpp)
  set(PPE_YAML yaml-cpp::yaml-cpp)
else()
  set(PPE_YAML yaml-cpp)
endif()

# ───────────── 코어 라이브러리 (ROS 비의존) ─────────────
add_library(ppe_core SHARED
  src/core/config_io.cpp
  src/core/multi_view_bundle_pnp_solver.cpp
  src/core/adaptive_covariance_estimator.cpp
  src/core/pose_estimator.cpp
  src/core/sim_scene.cpp)
target_include_directories(ppe_core PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>
  ${OpenCV_INCLUDE_DIRS})
target_link_libraries(ppe_core PUBLIC Eigen3::Eigen ${OpenCV_LIBS} PRIVATE ${PPE_YAML})

add_executable(pose_estimation_bench tools/pose_estimation_bench.cpp)
target_link_libraries(pose_estimation_bench ppe_core)
target_compile_definitions(pose_estimation_bench PRIVATE PPE_CONFIG_DIR="${CMAKE_CURRENT_SOURCE_DIR}/config")

if(PPE_CORE_ONLY)
  enable_testing()
  find_package(GTest REQUIRED)
  add_executable(test_pose_estimation test/test_pose_estimation.cpp)
  target_link_libraries(test_pose_estimation ppe_core GTest::gtest_main)
  target_compile_definitions(test_pose_estimation PRIVATE PPE_CONFIG_DIR="${CMAKE_CURRENT_SOURCE_DIR}/config")
  add_test(NAME test_pose_estimation COMMAND test_pose_estimation)
  return()
endif()

# ───────────── ROS2 (ament) 빌드 ─────────────
find_package(ament_cmake REQUIRED)
find_package(ament_index_cpp REQUIRED)
find_package(rclcpp REQUIRED)
find_package(rclcpp_lifecycle REQUIRED)
find_package(rclcpp_components REQUIRED)
find_package(lifecycle_msgs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(tf2_ros REQUIRED)
find_package(inhaul_msgs REQUIRED)

add_library(pose_estimation_component SHARED
  src/ros/pose_estimation_node.cpp
  src/ros/sd_notify.cpp)
target_include_directories(pose_estimation_component PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)
target_link_libraries(pose_estimation_component ppe_core ${PPE_YAML})
ament_target_dependencies(pose_estimation_component
  rclcpp rclcpp_lifecycle rclcpp_components lifecycle_msgs ament_index_cpp
  std_msgs geometry_msgs nav_msgs tf2_ros inhaul_msgs)
rclcpp_components_register_node(pose_estimation_component
  PLUGIN "ppe::PoseEstimationNode"
  EXECUTABLE pose_estimation_component_node)

# 합성 검출 발행기 ([모듈 1] 없이 노드·EKF 연동 시험)
add_library(synthetic_tag_publisher_component SHARED src/ros/synthetic_tag_publisher.cpp)
target_include_directories(synthetic_tag_publisher_component PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>)
target_link_libraries(synthetic_tag_publisher_component ppe_core)
ament_target_dependencies(synthetic_tag_publisher_component
  rclcpp rclcpp_components ament_index_cpp geometry_msgs inhaul_msgs)
rclcpp_components_register_node(synthetic_tag_publisher_component
  PLUGIN "ppe::SyntheticTagPublisher"
  EXECUTABLE synthetic_tag_publisher)

# 단독 실행 파일 (systemd 서비스용: 자동 configure/activate + watchdog)
add_executable(pose_estimation_node src/ros/main.cpp)
target_link_libraries(pose_estimation_node pose_estimation_component)
ament_target_dependencies(pose_estimation_node rclcpp rclcpp_lifecycle lifecycle_msgs)

install(TARGETS ppe_core pose_estimation_component synthetic_tag_publisher_component
  ARCHIVE DESTINATION lib LIBRARY DESTINATION lib RUNTIME DESTINATION bin)
install(TARGETS pose_estimation_node pose_estimation_bench DESTINATION lib/${PROJECT_NAME})
install(DIRECTORY include/ DESTINATION include)
install(DIRECTORY config launch systemd DESTINATION share/${PROJECT_NAME})
install(PROGRAMS tools/pose_kpi_monitor.py DESTINATION lib/${PROJECT_NAME})

if(BUILD_TESTING)
  find_package(ament_cmake_gtest REQUIRED)
  ament_add_gtest(test_pose_estimation test/test_pose_estimation.cpp TIMEOUT 300)
  target_link_libraries(test_pose_estimation ppe_core)
  target_compile_definitions(test_pose_estimation PRIVATE PPE_CONFIG_DIR="${CMAKE_CURRENT_SOURCE_DIR}/config")
endif()

ament_export_include_directories(include)
ament_export_libraries(ppe_core)
ament_export_dependencies(Eigen3 OpenCV rclcpp rclcpp_lifecycle geometry_msgs nav_msgs inhaul_msgs)
ament_package()
