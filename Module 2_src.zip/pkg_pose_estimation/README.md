# pkg_pose_estimation — [모듈 2] 6DoF 추정 SW 모듈

손원일급 잠수함 자동 INHAUL 시스템 구축을 위한 3D 위치 데이터 수집 및 분석 SW 개발
주식회사 두리안컴퍼니 · 연구책임자 박완선 · SW총괄 유익수
설계 근거: 연구노트 「SW 개발 설계계획서 — 6DoF 추정 SW 모듈 (pkg_pose_estimation)」(2026.10.21)

[모듈 1] `vision_acquisition_node` 의 4채널 AprilTag 서브픽셀 코너(`/vision/tag_detections`)와 선체 Tag Bundle 강체 맵을
결합해 도크 월드 좌표계(`dock_world_frame`) 기준 잠수함 6DoF 와 6×6 공분산을 산출하고
`/sub_pose_vision` (`geometry_msgs/PoseWithCovarianceStamped`) 으로 [모듈 3] `sensor_fusion_node` 에 전달합니다.

---

## 1. 구성

```
inhaul_ws/src/
├── inhaul_msgs/                          # 공용 메시지 (모듈 1 정의 그대로 + 모듈 2 진단 메시지 추가)
│   └── msg/TagDetection.msg, TagDetectionArray.msg, VisionPoseDiagnostics.msg (신규)
└── pkg_pose_estimation/
    ├── include/pkg_pose_estimation/
    │   ├── types.hpp                         # SE(3), 섭동/공분산 규약, 상태 코드
    │   ├── tag_bundle_model.hpp              # [세부 1] TagBundleModelLoader
    │   ├── multi_cam_extrinsic_manager.hpp   # [세부 2] MultiCamExtrinsicManager
    │   ├── multi_view_bundle_pnp_solver.hpp  # [세부 3] MultiViewBundlePnPSolver (RANSAC/IPPE + Huber-LM)
    │   ├── adaptive_covariance_estimator.hpp # [세부 4] AdaptiveCovarianceEstimator
    │   ├── pose_estimator.hpp                # 입력필터 + 솔버 + 게이트 + 공분산 (ROS 비의존 엔진)
    │   ├── sim_scene.hpp                     # 합성 관측 생성기 (시험·벤치·합성 발행기 공용)
    │   └── pose_estimation_node.hpp          # ROS2 LifecycleNode (component)
    ├── src/core, src/ros
    ├── config/  Tag_Bundle_Rigid_Map.yaml, camera_extrinsics_world.yaml, cam_intrinsics_ch1~4.yaml, pose_estimation.yaml
    ├── launch/pose_estimation.launch.py      # 단독 / sim:=true / composed:=true (모듈 1+2 intra-process)
    ├── systemd/pose-estimation.service       # Type=notify, Restart=always, WatchdogSec=1s
    ├── tools/pose_estimation_bench.cpp       # 설계서 8장 KPI 계측 (S1~S7 시나리오)
    ├── tools/pose_kpi_monitor.py             # ROS 그래프 수준 KPI 계측 (참값 토픽 대비 오차·지연)
    ├── src/ros/synthetic_tag_publisher.cpp   # 모듈 1 없이 노드/EKF 연동 시험용 합성 검출 발행기
    ├── test/test_pose_estimation.cpp         # gtest 19건
    └── docs/test_reports/                    # 벤치 보고서 (60 s × 60 fps)
```

## 2. 설계계획서 검토 결과

설계서를 [모듈 1] 산출물(메시지·설정 파일·좌표 규약)과 대조하고 구현·시험하면서 확인한 사항입니다.
**[반영]** 은 이번 구현에 반영한 것, **[결정 필요]** 는 연구책임자/모듈 3 담당 확인이 필요한 것입니다.

### 2.1 수식·알고리즘

| # | 설계서 항목 | 검토 내용 | 조치 |
|---|---|---|---|
| R1 | 4장 4) σ²_rot = β·d²·e_reproj /(N·L²) | 분자의 e 가 1제곱으로 표기됨. σ_rot ≈ d·e /(f·L) 이므로 분산은 e² 이어야 차원이 맞음. α·β 는 1/f² 스케일을 흡수하는 상수로 정의해야 함 | **[반영]** e² 로 구현. α=2.2e-7, β=1.1e-5 (합성 몬테카를로 보정값, 테스트베드 재보정 필요) |
| R2 | 4장 4) L_baseline | "카메라 기저선"인지 "관측 태그 간 거리"인지 불명. 회전 정밀도를 좌우하는 것은 관측된 태그들의 퍼짐(레버암) | **[반영]** 관측 태그 중심 간 최대 거리, 단일 태그면 태그 한 변 길이로 정의 |
| R3 | 4장 4) 공분산 모델 (등방 대각) | 실제 오차는 **비등방**: 하향 카메라 광축 방향(Z) 오차가 X/Y 의 약 4배 (S1 RMSE 0.032 vs 0.007~0.008 mm). 또 선체 원점과 태그 간 레버암 때문에 위치-회전 **상관**이 큼. 대각 등방 모델은 EKF 에 잘못된 가중을 줌 | **[반영]** 기본값을 LM 야코비안 기반 6×6 (`covariance.mode: jacobian`, 상관 포함)으로 하고, 설계서 수식은 `formula` 모드로 유지. 몬테카를로 NEES 6.32 (기대값 6)로 일관성 검증 |
| R4 | 6장 1) 단일 태그 회전 공분산 ×5 | 정면 시점의 소형 태그는 두 IPPE 해가 **수 도 이내로 근접**하고 비용함수가 비선형이라, 국소 공분산 ×5 로도 실제 오차를 크게 과소평가함 (NEES 중앙값 수백~수천) | **[반영]** ×5 유지 + ① 두 해의 2-성분 혼합 공분산 Σ+w(1−w)ΔΔᵀ ② 회전 σ 하한 2° → NEES 중앙값 5.1. 그래도 χ² 95% 이내는 64% 로 꼬리가 낙관적 → **모듈 3 EKF 의 혁신(innovation) 게이트 필수** |
| R5 | 6장 1) prior 가 없는 단일 태그 | EKF 기동 전이거나 끊긴 상태에서 1카메라·1태그만 보이는 경우 처리 규정 없음. 뒤집힌 법선 해를 내보내면 EKF 가 오염됨 | **[반영]** 두 해의 재투영오차 비 ≥ 4 일 때만 확정, 아니면 `REJECT_AMBIGUOUS` 로 기각 |
| R6 | 6장 2) 재투영 오차 > 2.5 px 기각 | 이상치 제거 후의 RMS 는 거의 항상 임계 미만이 되어 게이트가 사실상 동작하지 않음 (전면 흐림 σ=3.5 px 에서도 잔존 코너 RMS < 2.5) | **[반영]** 인라이어 비율 ≥ 50% 조건 추가 (`gate.min_inlier_ratio`) |
| R7 | 6장 2) 키네마틱 게이트 | 기준 자세가 한 번 틀리면 이후 정상 해가 모두 기각되는 **영구 락아웃** 위험. 또 dt 가 0 에 가까울 때 잡음만으로 기각될 수 있음 | **[반영]** 허용치 = v_max·dt + 잡음여유 + 4σ, 마지막 승인 후 0.5 s 경과 시 다중 태그 해로 기준 재설정 |
| R8 | 6장 2) Mahalanobis 필터 | EKF 사전값 대비 게이트를 모듈 2 에서 하면 모듈 3 의 혁신 게이트와 중복되고, EKF 가 발산하면 비전이 영구 기각되는 **상호 락아웃** 루프가 생김 | **[반영]** 구현은 했으나 기본 off (`gate.mahalanobis_gate`). **[결정 필요]** 게이트 책임을 모듈 3 으로 일원화할지 |
| R9 | 3장 Ceres / g2o | 변수 6개·잔차 ≤ 320개 규모라 범용 그래프 최적화기는 오버헤드만 큼 | **[반영]** 해석적 야코비안 + 고정크기 Eigen LM 직접 구현 (의존성 없음, 결정적 실행시간) |

### 2.2 인터페이스·모듈 간 정합

| # | 항목 | 검토 내용 | 조치 |
|---|---|---|---|
| I1 | 5장 ① 입력 | 6장 1)이 "직전 프레임 EKF 자세(T_{t−1})"를 쓰는데 입력 목록에 EKF 토픽이 없음 | **[반영]** `/sub_pose_filtered` (nav_msgs/Odometry) 구독 추가 (모듈 1 동적 ROI 와 같은 토픽) |
| I2 | 5장 ② 진단 토픽 | `/vision/pose_diagnostics` 의 메시지 타입 미정 | **[반영]** `inhaul_msgs/VisionPoseDiagnostics` 신설 (상태코드, 카메라/태그/코너 수, 재투영 오차, 수렴 여부, σ, 처리시간) |
| I3 | world frame 이름 | 설계서는 `dock_world_frame`, 모듈 1 `cam_extrinsics.yaml` 은 `world_frame: dock`. 모듈 1 동적 ROI 는 EKF 자세의 frame 이 다르면 경고를 냄 | **[결정 필요]** 모듈 1 설정을 `dock_world_frame` 으로 바꿔 통일할 것을 권장. 모듈 2 는 외부파라미터 YAML 의 값을 따름 |
| I4 | 외부파라미터 파일 | 설계서 `camera_extrinsics_world.yaml` ↔ 모듈 1 `cam_extrinsics.yaml` (같은 내용, 다른 이름) | **[반영]** 포맷을 같게 하여 한 파일을 공유할 수 있게 함. **[결정 필요]** 단일 파일로 일원화 |
| I5 | 태그 수 | 8장 KPI 는 "태그 10개 중 7개 차폐"인데 모듈 1 Tag Bundle 은 8개 | **[반영]** 10개 번들 작성 (갑판 ID 0~7 = 모듈 1 과 동일 + 세일 상면 ID 8·9). **모듈 1 화이트리스트(tag_bundle.yaml)에 ID 8·9 추가 필요**. 세일 태그는 번들을 비평면으로 만들어 롤/피치 관측성을 높임 |
| I6 | 쿼터니언 표기 | 모듈 1 YAML 은 [qw,qx,qy,qz], ROS 메시지는 (x,y,z,w) | **[반영]** `quaternion` = [qw,qx,qy,qz], `quaternion_xyzw` 키를 분리하여 둘 다 지원 |
| I7 | 공분산 회전 성분 | 회전 섭동의 기준 좌표계 미정 (EKF 구현과 반드시 일치해야 함) | **[반영]** 월드 고정축 소회전 R' = Exp(δθ)·R, 순서 [x,y,z,rx,ry,rz] (ROS REP 규약). **[결정 필요]** 모듈 3 과 확인 |

### 2.3 KPI 달성 조건

- **위치 ±2.0 mm 는 외부 보정 정밀도가 지배합니다.** 비전 잡음만으로는 S1 최대 0.13 mm 로 여유가 크지만,
  카메라 외부파라미터에 위치 σ 0.5 mm·회전 σ 0.02° 오차를 넣으면 최대 3.2 mm 로 **KPI 를 넘습니다** (S7).
  σ 0.2 mm·0.005° 에서는 최대 0.50 mm 입니다. 회전 0.02° 는 2.2 m 레버암에서 0.77 mm 에 해당합니다.
  → **1단계 외부 보정 툴의 목표 정밀도(권장: 위치 ≤ 0.2 mm, 회전 ≤ 0.005°)를 설계서에 명시할 것을 제안합니다.**
- **단일 태그만 보이는 상황은 KPI 를 만족할 수 없습니다** (S6: 위치 Z RMSE 5.6 mm, 자세 RMSE 0.6°).
  80 mm 태그 하나는 1.85 m 거리에서 기울기 관측성이 낮고, 선체 원점까지의 레버암(최대 1 m)이 회전 오차를 위치 오차로 키웁니다.
  설계 의도대로 공분산을 키워 EKF 가 IMU 를 우선 신뢰하게 하는 것이 맞으며, KPI 판정은 다중 태그 조건으로 한정해야 합니다.
- 70% 차폐(S3)는 연속 추정을 유지하지만(발행률 100%, 발산 0) 남은 3개가 한쪽 끝에 몰린 프레임에서는 최대 2.5 mm 가 나옵니다.

## 3. 처리 구조 (설계서 4장 구현)

```
/vision/tag_detections (TagDetectionArray, PTP stamp)          /sub_pose_filtered (EKF, 선택)
   │                                                                  │ prior (등속 전파)
   ▼ 입력 필터: active_camera_mask, 미등록 카메라/ID, hamming, 비정상 값, (카메라,ID) 중복
   │  유효 0개 → VISION_DROPOUT: 발행 중단, 진단·HMI 경보만 송출 (6장 3)
   ▼ ① 2D-3D 대응: (cam, tag, m) → (u_{c,i,m}, P^body_{i,m})
   ▼ ② 초기해
   │   추적 중: 예측 자세(EKF → 직전 두 비전 해 등속 외삽)가 대응점 80% 이상을 6 px 이내로 설명하면 바로 ③ (고속경로)
   │   그 외 : 카메라별 태그≥2 → solvePnPRansac(SQPnP) / 태그=1 → IPPE_SQUARE 두 해
   │           T_{W→body} = T_{W→Cc}·T_{Cc→tag}·T_{body→tag}⁻¹ 후보 중 전 카메라 절단 재투영비용 최소 선택
   │           1카메라·1태그 → prior 회전과 가까운 IPPE 해 (6장 1)
   ▼ ③ 다중 시점 LM: Σ_c Σ_i Σ_m ρ_Huber(‖u − π(K_c, T_{W→Cc}⁻¹·T·P)‖) 최소화
   │   1단계(절단 6 px 내) → 코너 3 px / 태그평균 2.5 px 이상치 재분류 → 2단계
   ▼ ④ 공분산: s²·(JᵀJ)⁻¹ (+ 단일 태그 ×5, 혼합, 하한)
   ▼ 게이트: 재투영 RMS ≤ 2.5 px & 인라이어 ≥ 50%, 키네마틱(0.5 m/s, 15 °/s), [선택] Mahalanobis
   ▼
/sub_pose_vision (PoseWithCovarianceStamped, frame dock_world_frame, stamp = 입력 PTP stamp 그대로)
/vision/pose_diagnostics (매 프레임), /hmi/vision_alerts (상태 전이 시)
```

### 좌표·데이터 계약
- 입력 코너: 모듈 1 계약 그대로 — **왜곡 보정된 이상적 핀홀 좌표, K 동일, D = 0**, OpenCV 픽셀중심 규약, AprilTag 3 코너 순서.
  따라서 모듈 2 는 내부 파라미터 파일에서 K 만 읽고 D 는 무시합니다 (모듈 1 과 같은 파일 사용).
- `SE3 T_a_b` 는 설계서 `T_{a→b}` 와 같은 의미(p_a = R·p_b + t). 출력 pose = T_{W→body}.
- 공분산: 위치 [m], 회전 = 월드 고정축 소회전 [rad], 순서 [x, y, z, rot_x, rot_y, rot_z].

## 4. 빌드

```bash
# 의존성 (Ubuntu 22.04 + ROS2 Humble)
sudo apt install ros-humble-rclcpp-components ros-humble-tf2-ros ros-humble-rmw-cyclonedds-cpp libeigen3-dev libopencv-dev libyaml-cpp-dev
cd inhaul_ws && colcon build --merge-install --packages-up-to pkg_pose_estimation --cmake-args -DCMAKE_BUILD_TYPE=Release
colcon test --packages-select pkg_pose_estimation && colcon test-result --verbose

# ROS 없이 코어/시험/벤치만 (알고리즘 개발·CI)
cmake -S src/pkg_pose_estimation -B build_core -DPPE_CORE_ONLY=ON && cmake --build build_core -j && ctest --test-dir build_core
./build_core/pose_estimation_bench --duration 60 --report bench.md
```

`inhaul_msgs` 는 모듈 1 의 정의를 그대로 두고 `VisionPoseDiagnostics.msg` 만 추가했습니다(버전 0.2.0).
모듈 1 워크스페이스의 `inhaul_msgs` 를 이 버전으로 교체하면 됩니다 (기존 메시지 변경 없음 → 모듈 1 재빌드만 필요).

## 5. 실행

```bash
# 합성 검출 발행기와 함께 (모듈 1·카메라 없이 노드 전체 검증)
ros2 launch pkg_pose_estimation pose_estimation.launch.py sim:=true [sim_occlusion:=0.7] [sim_dead_mask:=5] [sim_blackout_start:=8.0]
ros2 run pkg_pose_estimation pose_kpi_monitor.py --duration 20      # 참값 대비 오차·발행률·처리지연

# 실운용 (모듈 1 이 /vision/tag_detections 발행 중)
ros2 launch pkg_pose_estimation pose_estimation.launch.py
# 모듈 1 + 모듈 2 한 컨테이너 (intra-process 무복사). 라이프사이클은 외부에서 전이
ros2 launch pkg_pose_estimation pose_estimation.launch.py composed:=true
ros2 lifecycle set /pose_estimation_node configure && ros2 lifecycle set /pose_estimation_node activate

ros2 topic echo /vision/pose_diagnostics      # 상태, 태그 수, 재투영 오차, processing_time_ms
ros2 topic echo /hmi/vision_alerts            # WARN_VISION_DROPOUT / INFO_VISION_RECOVERED 등
```

운영 배포: `systemd/pose-estimation.service` (Type=notify, `Restart=always`, `RestartSec=100ms`, `WatchdogSec=1s`,
SCHED_FIFO 70, 모듈 1 워커와 다른 코어 고정).

## 6. 인터페이스

| 구분 | 토픽 / 파일 | 타입 | 비고 |
|---|---|---|---|
| 입력 | `/vision/tag_detections` | `inhaul_msgs/TagDetectionArray` | reliable, keep_last 5 (모듈 1 QoS 일치) |
| 입력(선택) | `/sub_pose_filtered` | `nav_msgs/Odometry` | EKF 자세. frame_id ≠ world_frame 이면 무시 |
| 출력 | `/sub_pose_vision` | `geometry_msgs/PoseWithCovarianceStamped` | frame `dock_world_frame`, stamp = PTP 촬영시각, covariance 6×6 |
| 출력 | `/vision/pose_diagnostics` | `inhaul_msgs/VisionPoseDiagnostics` | 매 입력 프레임 (DROPOUT 포함) |
| 출력 | `/hmi/vision_alerts` | `std_msgs/String` | `코드\|정보`, 비정상 3프레임 연속 시 1회, 복귀 시 1회 |
| 출력(선택) | TF | `dock_world_frame → submarine_base_link_vision` | `publish_tf: true` |
| 설정 | `config/Tag_Bundle_Rigid_Map.yaml` | 태그 ID, size, position, rpy_deg / quaternion | 모듈 1 `layout` 포맷도 읽음 |
| 설정 | `config/camera_extrinsics_world.yaml` | T_{W→Cc} | 모듈 1 `cam_extrinsics.yaml` 과 같은 포맷 |
| 설정 | `config/cam_intrinsics_ch1~4.yaml` | ROS camera_info | 모듈 1 `intrinsic_calibrator` 출력 그대로 |

진단 상태코드: `OK`, `VISION_DROPOUT`, `REJECT_REPROJECTION`, `REJECT_KINEMATIC_GATE`, `REJECT_MAHALANOBIS`, `SOLVER_FAILED`, `REJECT_UNRESOLVED_AMBIGUITY`.

## 7. 예외 처리 (설계서 6장)

| 요구 | 구현 | 검증 |
|---|---|---|
| 1) 단일 태그 Flip Ambiguity | IPPE 두 해 중 prior(EKF → 등속 외삽 비전해)와 회전차 작은 해 선택, 회전 분산 ×5 + 혼합 공분산 + 회전 σ 하한. prior 없고 오차비 < 4 → 기각 | `Ambiguity.*` 3건 (두 해 38° 차이에서 prior 쪽 선택 확인), 벤치 S6 |
| 2) 키네마틱 게이트 / 재투영 임계 | 0.5 m/s·15 °/s (dt 비례 + 잡음 허용), RMS > 2.5 px 또는 인라이어 < 50% 기각, 0.5 s 후 재획득 | `Gate.*` 3건 (5 cm·3° 점프 기각, 0.5 s 후 재획득 1회) |
| 3) 완전 차폐 | 유효 태그 0 → 발행 중단, 진단 `VISION_DROPOUT`, HMI `WARN_VISION_DROPOUT` → 복귀 시 `INFO_VISION_RECOVERED` | `Dropout.*` 2건, ROS 실행 시 1 s 블랙아웃 주입으로 경보·복귀 확인 |
| 자가 복구 | 프로세스 종료/실행기 정지 → systemd 재기동 (watchdog 은 실행기 하트비트 기준), on_error → 종료코드 4 | — (모듈 1 과 같은 구조) |

## 8. 시험 결과 (2026-11-19, 개발 컨테이너: Xeon **2 vCPU**, 실시간 커널 아님, 합성 관측)

### 8.1 KPI 벤치 (`docs/test_reports/bench_60s_sigma0.05.md`, 60 s × 60 fps, 코너 잡음 σ 0.05 px)

| 시나리오 | 발행률 | 위치 RMSE x/y/z [mm] | 위치 max [mm] | 자세 RMSE r/p/y [deg] | 자세 max [deg] | 지연 avg / p99 / max [ms] |
|---|---|---|---|---|---|---|
| S1 정상 주행 (레일 2.5 m 왕복 0.3 m/s) | 100% | 0.007 / 0.008 / 0.032 | **0.13** | 0.0063 / 0.0027 / 0.0007 | **0.028** | **0.045** / 0.089 / 3.49 |
| S1' 고속경로 off (매 프레임 RANSAC/IPPE) | 100% | 동일 | 0.13 | 동일 | 0.025 | 0.325 / 0.605 / 1.79 |
| S2 고잡음 σ 0.15 px | 100% | 0.021 / 0.023 / 0.098 | 0.46 | 0.018 / 0.008 / 0.002 | 0.075 | 0.043 / 0.084 / 0.43 |
| S3 **70% 마커 차폐** (10개 중 7개, 0.5 s 마다 재추첨) | 100% | 0.019 / 0.038 / 0.230 | 2.51 | 0.074 / 0.022 / 0.004 | 1.30 | 0.014 / 0.030 / 0.29 |
| S4 카메라 2대 단절 | 100% | 0.010 / 0.014 / 0.057 | 0.38 | 0.012 / 0.004 / 0.001 | 0.10 | 0.024 / 0.086 / 0.51 |
| S5 반사상 1개/프레임 + 코너 번짐 10% | 100% | 0.007 / 0.008 / 0.032 | 0.13 | 0.0062 / 0.0027 / 0.0007 | 0.033 | 0.046 / 0.073 / 0.42 |
| S6 단일 태그만 (prior = EKF 모사) | 100% | 1.00 / 0.95 / 5.58 | 47.6 | 0.57 / 0.58 / 0.04 | 5.9 | 0.019 / 0.035 / 0.13 |
| S7 외부파라미터 오차 σ 0.5 mm / 0.02° | 100% | 0.76 / 0.49 / 1.33 | **3.20** | 0.13 / 0.13 / 0.016 | 0.58 | 0.072 / 0.162 / 2.07 |
| S7 외부파라미터 오차 σ 0.2 mm / 0.005° | 100% | 0.13 / 0.13 / 0.19 | 0.50 | 0.013 / 0.012 / 0.004 | 0.051 | 0.038 / 0.055 / 0.33 |

KPI 대비: 위치 ±2.0 mm, 자세 ±0.25°, 지연 ≤ 2.0 ms, 70% 차폐 연속추정 → 다중 태그 조건에서 모두 충족 (S7 0.5 mm/0.02° 는 미충족, 2.3절).
지연 max 는 2 vCPU 공유 환경의 스케줄링 지터가 섞인 값이며 p99 는 0.1 ms 수준입니다.

### 8.2 공분산 일관성 (NEES, 6자유도 기대값 6)
| 조건 | 결과 |
|---|---|
| 야코비안 공분산, 하한 해제, 다중 태그 400 프레임 (`Covariance.JacobianModeConsistentNees`) | NEES 평균 **6.32** |
| 운용 설정(하한 적용) S1 / S2 | 중앙값 3.2 / 5.5, χ² 95% 이내 99% / 94% (하한 때문에 보수적) |
| 단일 태그 S6 | 중앙값 5.1~5.8, χ² 95% 이내 63~64% (꼬리 낙관적, R4 참조) |
| 외부파라미터 오차 S7 | 중앙값 147 → 외부 보정 오차는 공분산 모델 밖의 계통오차. 테스트베드에서 `covariance.scale` 보정 필요 |

### 8.3 ROS 노드 실행 (RoboStack ROS2 Humble, CycloneDDS, synthetic_tag_publisher 60 Hz)
| 항목 | 결과 |
|---|---|
| colcon build (inhaul_msgs, pkg_pose_estimation) | 경고 0 |
| colcon test | 20건 통과 / 0 실패 |
| `pose_kpi_monitor` 15 s (1 s 블랙아웃 주입 포함) | 840/900 발행(블랙아웃 60프레임 DROPOUT), 위치 RMS 0.033 mm, 자세 RMS 0.0067°, processing_time avg 0.109 / p99 0.216 ms |
| HMI 경보 | 블랙아웃 시 `WARN_VISION_DROPOUT`, 복귀 시 `INFO_VISION_RECOVERED`, 재획득 1회 |
| 라이프사이클 | active 60.5 Hz → deactivate 0 Hz → activate 60.5 Hz, SIGINT 종료코드 0 |
| `composed:=true` (컨테이너 + intra-process) | 60.2 Hz, 301/301 발행, 처리 p50 0.056 / p99 0.104 ms, 입력 지연(전송) p50 0.059 ms |

### 8.4 개발 중 발견·반영한 사항
1. **단일 태그 공분산 과소평가** — 설계서의 ×5 만으로는 NEES 중앙값 ~1000. 혼합 공분산과 회전 σ 하한을 추가해 중앙값 5.1 (R4).
2. **성분당 잔차분산 계산 오류를 시험으로 발견** — 코너 단위 RMS(2D)를 성분 분산으로 바로 쓰면 공분산이 2배 커짐. Σ‖r‖²/(2N−6) 로 수정 후 NEES 6.32.
3. **잔차 자유도가 2 인 단일 태그** — 경험적 σ 가 매우 불안정해서 모듈 1 실측 잡음 0.05 px 를 사전값으로 베이즈 결합 (ν0 = 6).
4. **추적 고속경로** — 매 프레임 4대 RANSAC 은 OpenCV 호출이 지연의 대부분(0.33 ms)을 차지. 등속 외삽 예측이 대응점 80% 이상을 설명하면 초기화를 건너뛰어 평균 **0.045 ms (7배)**, 정확도 동일.
5. **OpenCV 버전에 따른 PnP 성능 차이** — 같은 코드에서 conda OpenCV 4.13 은 시스템 4.6 보다 solvePnP/IPPE 가 약 10~20배 느림 (IPPE 0.26 vs 0.011 ms, BLAS 교체로도 개선 없음). 목표 플랫폼(Ubuntu 22.04 apt, OpenCV 4.5.4) 에서 재확인 필요하며, 고속경로 덕분에 어느 쪽이든 KPI 여유가 큼.
6. **키네마틱 게이트 락아웃** 시험으로 재현 → 0.5 s 재획득 규칙 (R7).

## 9. 한계 및 실장비 검증 필요 사항 (정직 고지)

- **모든 정밀도 수치는 합성 관측 기준입니다.** 코너 잡음은 가우시안이고 모델 오차가 없는 조건이라 낙관적입니다.
  실제 정밀도는 외부 보정 정밀도(2.3절), 태그 인쇄·부착 오차(CAD 대비), 선체 변형, 모션블러가 지배합니다. 5단계 테스트베드 엔코더 비교로 확정해야 합니다.
- `Tag_Bundle_Rigid_Map.yaml`, `camera_extrinsics_world.yaml`, `cam_intrinsics_ch*.yaml` 은 **설계 초기값**입니다. CAD·보정 결과로 교체해야 합니다.
- **1단계 산출물인 Extrinsic Calibration 자동 산출 노드는 이번 범위에 넣지 않았습니다.** 같은 LM 코어(카메라 자세를 변수로)로 구현할 수 있으며 다음 작업으로 제안합니다.
- 지연 KPI 는 2 vCPU 컨테이너 결과입니다. 목표 엣지PC(Preempt-RT, 전용 코어)에서 `pose_kpi_monitor` 또는 진단 토픽 `processing_time_ms` 로 재측정하십시오.
- 단일 태그 모드의 공분산은 꼬리가 여전히 낙관적입니다(χ² 95% 이내 64%). 모듈 3 EKF 에 Mahalanobis 혁신 게이트가 반드시 있어야 합니다.
- conda(RoboStack) 빌드 환경 한정 우회 옵션(`-include cstdint`, `--allow-shlib-undefined`, libpython preload)을 개발 검증에만 썼습니다. 소스 코드와 apt 기반 목표 환경과는 무관합니다.

## 10. 설계서 일정 대비 진행

| 단계 | 산출물 | 상태 |
|---|---|---|
| 1단계 (M1~M2) | 좌표계 정의, camera_extrinsics_world.yaml, 외부 보정 툴 | 좌표계·섭동 규약 정의, 설정 포맷(모듈 1 공유) 완료. **외부 보정 툴 미착수** |
| 2단계 (M3~M4) | pose_estimation_node 기본형, Tag Bundle 설정 | 노드(Lifecycle/component/systemd), 10태그 번들, RANSAC+IPPE 구현 완료. **CAD 좌표 반영 필요** |
| 3단계 (M5~M6) | Multi-View PnP 최적화, 동적 공분산 | Huber-LM 결합 최적화, 야코비안/수식 공분산, NEES 검증 완료 |
| 4단계 (M7~M9) | 차폐 강건성 시험 보고서, 모듈 2-3 통합 | 합성 70% 차폐 시험 완료 (`docs/test_reports`). **EKF(모듈 3) 연동 미착수** |
| 5단계 (M10~M12) | 테스트베드 실증, 성적서 | 미착수 |
