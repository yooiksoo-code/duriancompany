// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// pose_estimation_bench : 설계서 8장 KPI 계측 도구 (ROS 비의존, 합성 관측)
//
//   시나리오
//    S1 정상 주행      : 레일 2.5 m 왕복 0.3 m/s, 롤/피치/요 소진동, 코너 잡음 σ (기본 0.05 px)
//    S2 고잡음         : σ × 3 (모션블러·초점 열화 가정)
//    S3 70% 차폐       : 태그 10개 중 7개 무작위 차폐 (0.5 s 마다 재추첨)
//    S4 카메라 2대 단절 : CH1, CH3 단절
//    S5 이상치 주입    : 매 프레임 수면 반사상 1개 + 검출 10% 코너 번짐 6 px
//    S6 단일 태그 전용  : 1카메라·1태그만 관측 (IPPE 모호성, 직전 비전 해 prior)
//    S7 외부파라미터 오차 민감도 : 카메라별 위치 σ_t, 회전 σ_r 오차를 추정기 쪽에만 주입
//   지표: 위치 RMSE/최대 [mm], 자세 RMSE/최대 [deg], 발행률, 연산지연 avg/p50/p99/max [ms],
//         NEES (공분산 일관성), formula 모드 α/β 보정값
//
//   사용: pose_estimation_bench [--config DIR] [--duration 60] [--noise 0.05] [--seed 1] [--report out.md]
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <numeric>
#include <sstream>
#include <string>

#include <Eigen/Cholesky>

#include "pkg_pose_estimation/pose_estimator.hpp"
#include "pkg_pose_estimation/sim_scene.hpp"

using namespace ppe;

namespace {

struct Args {
  std::string config = PPE_CONFIG_DIR;
  double duration = 60.0;
  double fps = 60.0;
  double noise = 0.05;
  uint32_t seed = 1;
  std::string report;
  double ext_sigma_t_mm = 0.5;
  double ext_sigma_r_deg = 0.02;
};

struct Stats {
  std::vector<double> ex, ey, ez, er, ep, eyaw, ms;
  std::vector<double> pos_norm, rot_norm, nees_all;
  int frames = 0, published = 0, dropouts = 0, rejected = 0, flips = 0, fast = 0;
  double nees_sum = 0;
  int nees_n = 0;
  // formula 보정용
  double a_num = 0, a_den = 0, b_num = 0, b_den = 0;

  static double rms(const std::vector<double>& v) {
    if (v.empty()) return 0;
    double s = 0;
    for (double x : v) s += x * x;
    return std::sqrt(s / v.size());
  }
  static double maxabs(const std::vector<double>& v) {
    double m = 0;
    for (double x : v) m = std::max(m, std::abs(x));
    return m;
  }
  static double pct(std::vector<double> v, double p) {
    if (v.empty()) return 0;
    std::sort(v.begin(), v.end());
    return v[std::min(v.size() - 1, static_cast<size_t>(p * (v.size() - 1) + 0.5))];
  }
};

bool loadWorld(const std::string& dir, TagBundleModel& b, MultiCamExtrinsicManager& c) {
  std::string err;
  if (!loadTagBundle(dir + "/Tag_Bundle_Rigid_Map.yaml", b, err) ||
      !c.loadExtrinsics(dir + "/camera_extrinsics_world.yaml", err)) {
    std::fprintf(stderr, "%s\n", err.c_str());
    return false;
  }
  for (int i = 1; i <= 4; ++i) {
    Intrinsics K;
    if (!loadIntrinsics(dir + "/cam_intrinsics_ch" + std::to_string(i) + ".yaml", K, err) ||
        !c.setIntrinsics(i, K, err)) {
      std::fprintf(stderr, "%s\n", err.c_str());
      return false;
    }
  }
  return true;
}

enum class Scenario { kNominal, kNominalFullInit, kHighNoise, kOcclusion70, kCamDropout, kOutliers, kSingleTag, kSingleTagEkf, kExtrinsicError };

Stats run(Scenario sc, const Args& a, const TagBundleModel& bundle, const MultiCamExtrinsicManager& cams_true) {
  // 추정기 쪽 카메라 모델 (S7 에서만 오차 주입)
  MultiCamExtrinsicManager cams_est = cams_true;
  std::mt19937 rng(a.seed * 7919u + static_cast<uint32_t>(sc));
  if (sc == Scenario::kExtrinsicError) {
    std::normal_distribution<double> Nt(0, a.ext_sigma_t_mm * 1e-3), Nr(0, a.ext_sigma_r_deg * kDeg2Rad);
    std::string err;
    for (int c = 1; c <= 4; ++c) {
      const CameraModel& cm = *cams_true.camera(c);
      SE3 T = cm.T_world_cam;
      T = T.boxplus((Vec6() << Nt(rng), Nt(rng), Nt(rng), Nr(rng), Nr(rng), Nr(rng)).finished());
      Intrinsics K{cm.width, cm.height, cm.fx, cm.fy, cm.cx, cm.cy, false};
      cams_est.setCamera(c, K, T, err);
    }
  }
  PoseEstimator pe;
  std::string err;
  EstimatorConfig cfg;
  if (sc == Scenario::kNominalFullInit) cfg.solver.tracking_fast_path = false;
  pe.configure(bundle, cams_est, cfg, err);

  SimScene sim(bundle, cams_true, a.seed + 100u * static_cast<uint32_t>(sc));
  SimNoiseConfig nz;
  nz.corner_sigma_px = sc == Scenario::kHighNoise ? 3.0 * a.noise : a.noise;
  if (sc == Scenario::kOutliers) {
    nz.reflection_prob = 1.0;
    nz.blur_outlier_prob = 0.10;
  }
  sim.setNoise(nz);
  RailTrajectory traj;

  Stats st;
  std::set<int> occ;
  const int N = static_cast<int>(a.duration * a.fps);
  std::uniform_int_distribution<int> pick(0, 1 << 20);
  for (int i = 0; i < N; ++i) {
    const double t = i / a.fps;
    const int64_t stamp = static_cast<int64_t>(t * 1e9);
    if (sc == Scenario::kOcclusion70 && i % static_cast<int>(a.fps * 0.5) == 0) {
      std::vector<int> ids;
      for (const auto& tg : bundle.tags()) ids.push_back(tg.id);
      std::shuffle(ids.begin(), ids.end(), rng);
      occ = std::set<int>(ids.begin(), ids.begin() + static_cast<long>(std::lround(ids.size() * 0.7)));
    }
    const SE3 gt = traj.at(t);
    DetectionFrame f = sim.observe(gt, stamp, occ, sc == Scenario::kCamDropout ? 0b0101 : 0);
    if (sc == Scenario::kSingleTagEkf) {  // 모듈 3 EKF 예측 모사: 10 ms 전 상태, 오차 σ 3 mm / 0.5°
      std::normal_distribution<double> Np(0, 3e-3), Nr(0, 0.5 * kDeg2Rad);
      PosePrior p;
      p.valid = true;
      p.stamp_ns = stamp - 10'000'000;
      p.T_world_body = traj.at(t - 0.01).boxplus((Vec6() << Np(rng), Np(rng), Np(rng), Nr(rng), Nr(rng), Nr(rng)).finished());
      pe.setPrior(p);
    }
    if ((sc == Scenario::kSingleTag || sc == Scenario::kSingleTagEkf) && !f.detections.empty()) {
      const Detection d = f.detections[pick(rng) % f.detections.size()];
      f.detections.assign(1, d);
    }
    ++st.frames;
    const PoseEstimate e = pe.process(f);
    st.ms.push_back(e.solve_time_ms);
    st.fast += e.stats.fast_path;
    if (e.status == PoseStatus::kDropout) {
      ++st.dropouts;
      continue;
    }
    if (e.status != PoseStatus::kOk) {
      ++st.rejected;
      continue;
    }
    ++st.published;
    const Vec3 dp = e.T_world_body.t - gt.t;
    const Vec3 rpy_e = rpyFromRotation(e.T_world_body.R), rpy_g = rpyFromRotation(gt.R);
    st.ex.push_back(dp.x() * 1e3);
    st.ey.push_back(dp.y() * 1e3);
    st.ez.push_back(dp.z() * 1e3);
    st.er.push_back((rpy_e.x() - rpy_g.x()) * kRad2Deg);
    st.ep.push_back((rpy_e.y() - rpy_g.y()) * kRad2Deg);
    st.eyaw.push_back((rpy_e.z() - rpy_g.z()) * kRad2Deg);
    st.pos_norm.push_back(dp.norm() * 1e3);
    const double rot = rotationAngle(e.T_world_body.R, gt.R) * kRad2Deg;
    st.rot_norm.push_back(rot);
    if (rot > 5.0) ++st.flips;
    if (std::getenv("PPE_BENCH_DEBUG") && rot > 3.0)
      std::fprintf(stderr, "[%s] t=%.3f tag=%d cam=%d rot=%.2f pos=%.1fmm ratio=%.2f byprior=%d rms=%.3f\n", "dbg", t,
                   f.detections[0].tag_id, f.detections[0].camera_id, rot, dp.norm() * 1e3, e.stats.ippe_error_ratio,
                   e.stats.ambiguity_resolved_by_prior, e.stats.reproj_rms_px);
    const Vec6 d = gt.boxminus(e.T_world_body);
    const double nees = d.dot(e.covariance.ldlt().solve(d));
    st.nees_sum += nees;
    st.nees_all.push_back(nees);
    if (std::getenv("PPE_BENCH_DEBUG") && nees > 200)
      std::fprintf(stderr, "[nees] t=%.3f tag=%d cam=%d nees=%.0f rot=%.2f pos=%.1fmm w=%.3f sig_rot=%.2fdeg sig_pos=%.1fmm\n", t,
                   f.detections[0].tag_id, f.detections[0].camera_id, nees, rot, dp.norm() * 1e3, 0.0,
                   std::sqrt(e.covariance.block<3,3>(3,3).trace()) * kRad2Deg, std::sqrt(e.covariance.block<3,3>(0,0).trace()) * 1e3);
    ++st.nees_n;
    // formula 모드 α, β 최소제곱 보정: E[δp²/3] = α·g_pos,  E[δθ²/3] = β·g_rot
    const double ee = std::max(e.stats.reproj_rms_px, 0.03);
    const double dd = e.stats.mean_distance_m;
    const double nn = std::max(1, e.stats.num_tags);
    const double L = std::max(e.stats.baseline_m, 0.06);
    const double gp = dd * dd * ee * ee / nn, gr = dd * dd * ee * ee / (nn * L * L);
    st.a_num += gp * dp.squaredNorm() / 3.0;
    st.a_den += gp * gp;
    const double th2 = std::pow(rot * kDeg2Rad, 2) / 3.0;
    st.b_num += gr * th2;
    st.b_den += gr * gr;
  }
  return st;
}

const char* name(Scenario s) {
  switch (s) {
    case Scenario::kNominal: return "S1 정상 주행";
    case Scenario::kNominalFullInit: return "S1' 정상 주행, 고속경로 off (매 프레임 RANSAC/IPPE)";
    case Scenario::kHighNoise: return "S2 고잡음 (σ×3)";
    case Scenario::kOcclusion70: return "S3 70% 마커 차폐";
    case Scenario::kCamDropout: return "S4 카메라 2대 단절";
    case Scenario::kOutliers: return "S5 반사상·번짐 주입";
    case Scenario::kSingleTag: return "S6a 단일 태그 전용 (prior=직전 비전해)";
    case Scenario::kSingleTagEkf: return "S6b 단일 태그 전용 (prior=EKF 모사)";
    case Scenario::kExtrinsicError: return "S7 외부파라미터 오차";
  }
  return "?";
}

}  // namespace

int main(int argc, char** argv) {
  Args a;
  for (int i = 1; i + 1 < argc; i += 2) {
    const std::string k = argv[i], v = argv[i + 1];
    if (k == "--config") a.config = v;
    else if (k == "--duration") a.duration = std::stod(v);
    else if (k == "--fps") a.fps = std::stod(v);
    else if (k == "--noise") a.noise = std::stod(v);
    else if (k == "--seed") a.seed = static_cast<uint32_t>(std::stoul(v));
    else if (k == "--report") a.report = v;
    else if (k == "--ext-sigma-t-mm") a.ext_sigma_t_mm = std::stod(v);
    else if (k == "--ext-sigma-r-deg") a.ext_sigma_r_deg = std::stod(v);
    else {
      std::fprintf(stderr,
                   "usage: pose_estimation_bench [--config DIR] [--duration s] [--fps 60] [--noise px] [--seed n]\n"
                   "                             [--ext-sigma-t-mm 0.5] [--ext-sigma-r-deg 0.02] [--report out.md]\n");
      return 2;
    }
  }
  TagBundleModel bundle;
  MultiCamExtrinsicManager cams;
  if (!loadWorld(a.config, bundle, cams)) return 1;

  std::ostringstream os;
  os << "# pose_estimation_bench 보고서\n\n";
  os << "- 조건: " << a.duration << " s × " << a.fps << " fps, 코너 잡음 σ = " << a.noise
     << " px, 태그 " << bundle.size() << "개, 카메라 4대, seed " << a.seed << "\n";
  os << "- 궤적: 레일 x ∈ [−1.25, +1.25] m 왕복 0.3 m/s, 롤 ±1.5°, 피치 ±0.8°, 요 ±1.0°, 히브 ±3 mm\n";
  os << "- S7 외부파라미터 오차: 카메라별 위치 σ " << a.ext_sigma_t_mm << " mm, 회전 σ " << a.ext_sigma_r_deg
     << "° (추정기 쪽에만 주입)\n\n";
  os << "| 시나리오 | 발행률 | 위치 RMSE x/y/z [mm] | 위치 오차 max [mm] | 자세 RMSE r/p/y [deg] | 자세 max [deg] | 자세>5° | NEES 중앙값 / χ²95% 내 | 지연 avg/p50/p99/max [ms] |\n";
  os << "|---|---|---|---|---|---|---|---|---|\n";

  double alpha = 0, beta = 0;
  const Scenario all[] = {Scenario::kNominal,    Scenario::kNominalFullInit, Scenario::kHighNoise, Scenario::kOcclusion70,
                          Scenario::kCamDropout, Scenario::kOutliers,  Scenario::kSingleTag,
                          Scenario::kSingleTagEkf, Scenario::kExtrinsicError};
  for (Scenario sc : all) {
    const Stats s = run(sc, a, bundle, cams);
    const int eligible = s.frames - s.dropouts;
    char line[1024];
    std::snprintf(line, sizeof(line),
                  "| %s | %.1f%% (%d/%d) | %.3f / %.3f / %.3f | %.3f | %.4f / %.4f / %.4f | %.4f | %d | %.2f / %.0f%% | "
                  "%.3f / %.3f / %.3f / %.3f |\n",
                  name(sc), eligible ? 100.0 * s.published / eligible : 0.0, s.published, eligible,
                  Stats::rms(s.ex), Stats::rms(s.ey), Stats::rms(s.ez), Stats::maxabs(s.pos_norm),
                  Stats::rms(s.er), Stats::rms(s.ep), Stats::rms(s.eyaw), Stats::maxabs(s.rot_norm), s.flips,
                  Stats::pct(s.nees_all, 0.5),
                  s.nees_all.empty() ? 0.0
                                     : 100.0 * std::count_if(s.nees_all.begin(), s.nees_all.end(),
                                                             [](double v) { return v <= 12.59; }) / s.nees_all.size(),
                  s.ms.empty() ? 0.0 : std::accumulate(s.ms.begin(), s.ms.end(), 0.0) / s.ms.size(),
                  Stats::pct(s.ms, 0.5), Stats::pct(s.ms, 0.99), Stats::pct(s.ms, 1.0));
    os << line;
    std::fputs(line, stdout);
    std::fflush(stdout);
    if (sc == Scenario::kNominal) {
      alpha = s.a_den > 0 ? s.a_num / s.a_den : 0;
      beta = s.b_den > 0 ? s.b_num / s.b_den : 0;
    }
  }
  os << "\n- 발행률 = OK / (전체 − VISION_DROPOUT). DROPOUT = 남은 태그가 모두 시야 밖이거나 검출 0개인 프레임\n";
  os << "- NEES = δᵀΣ⁻¹δ (δ: 참값 대비 6D 오차). 일관된 추정기면 중앙값 ≈ 5.35, χ²(6) 95% 한계(12.59) 내 비율 ≈ 95%.\n"
        "  정상 조건에서 중앙값이 작은 것은 분산 하한(min_pos_std 0.02 mm 등)에 의한 보수적 설정 때문이며,\n"
        "  S7 은 외부파라미터 오차가 공분산 모델 밖의 계통오차임을 보여줌 (covariance.scale 로 실험 보정 필요)\n";
  char buf[256];
  std::snprintf(buf, sizeof(buf), "- formula 모드 몬테카를로 보정값 (S1): alpha = %.3e, beta = %.3e\n", alpha, beta);
  os << buf;
  std::fputs(buf, stdout);
  if (!a.report.empty()) {
    std::ofstream f(a.report);
    f << os.str();
    std::printf("report → %s\n", a.report.c_str());
  }
  return 0;
}
