#!/usr/bin/env python3
# Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
"""pose_kpi_monitor : ROS 그래프 수준 KPI 계측 (설계서 8장)

  /sub_pose_vision  ↔  /sim/ground_truth_pose (synthetic_tag_publisher) 를 stamp 로 매칭하여
  위치/자세 오차, 발행률, /vision/pose_diagnostics 의 processing_time_ms 분포를 출력한다.
  실장비에서는 ground truth 대신 엔코더 참값 토픽을 --gt-topic 으로 지정.

  사용: ros2 run pkg_pose_estimation pose_kpi_monitor.py --duration 20
"""
import argparse
import math
import sys

import rclpy
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy

try:
    from inhaul_msgs.msg import VisionPoseDiagnostics
except ImportError:  # pragma: no cover
    VisionPoseDiagnostics = None


def quat_angle_deg(a, b):
    d = abs(a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w)
    return math.degrees(2.0 * math.acos(min(1.0, d)))


def key(stamp):
    return stamp.sec * 1_000_000_000 + stamp.nanosec


class Monitor(Node):
    def __init__(self, a):
        super().__init__('pose_kpi_monitor')
        q = QoSProfile(depth=50, reliability=ReliabilityPolicy.RELIABLE)
        self.gt = {}
        self.pos_err, self.rot_err, self.proc, self.status = [], [], [], {}
        self.n_pose = 0
        self.create_subscription(PoseStamped, a.gt_topic, self.on_gt, q)
        self.create_subscription(PoseWithCovarianceStamped, a.pose_topic, self.on_pose, q)
        if VisionPoseDiagnostics is not None:
            self.create_subscription(VisionPoseDiagnostics, a.diag_topic, self.on_diag, q)

    def on_gt(self, m):
        self.gt[key(m.header.stamp)] = m.pose
        if len(self.gt) > 2000:
            for k in sorted(self.gt)[:1000]:
                del self.gt[k]

    def on_pose(self, m):
        self.n_pose += 1
        g = self.gt.get(key(m.header.stamp))
        if g is None:
            return
        p = m.pose.pose.position
        self.pos_err.append(math.dist((p.x, p.y, p.z), (g.position.x, g.position.y, g.position.z)) * 1e3)
        self.rot_err.append(quat_angle_deg(m.pose.pose.orientation, g.orientation))

    def on_diag(self, m):
        self.proc.append(m.processing_time_ms)
        self.status[m.status_text] = self.status.get(m.status_text, 0) + 1


def pct(v, p):
    if not v:
        return float('nan')
    s = sorted(v)
    return s[min(len(s) - 1, int(p * (len(s) - 1) + 0.5))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--duration', type=float, default=20.0)
    ap.add_argument('--pose-topic', default='/sub_pose_vision')
    ap.add_argument('--gt-topic', default='/sim/ground_truth_pose')
    ap.add_argument('--diag-topic', default='/vision/pose_diagnostics')
    a, ros_args = ap.parse_known_args()
    rclpy.init(args=ros_args)
    n = Monitor(a)
    t_end = n.get_clock().now().nanoseconds + int(a.duration * 1e9)
    while rclpy.ok() and n.get_clock().now().nanoseconds < t_end:
        rclpy.spin_once(n, timeout_sec=0.1)
    rms = lambda v: math.sqrt(sum(x * x for x in v) / len(v)) if v else float('nan')  # noqa: E731
    print(f'pose msgs {n.n_pose} ({n.n_pose / a.duration:.1f} Hz), matched {len(n.pos_err)}')
    print(f'position err [mm]  RMS {rms(n.pos_err):.3f}  p99 {pct(n.pos_err, .99):.3f}  max {max(n.pos_err, default=float("nan")):.3f}')
    print(f'rotation err [deg] RMS {rms(n.rot_err):.4f}  p99 {pct(n.rot_err, .99):.4f}  max {max(n.rot_err, default=float("nan")):.4f}')
    if n.proc:
        print(f'processing_time_ms avg {sum(n.proc) / len(n.proc):.3f}  p50 {pct(n.proc, .5):.3f}  '
              f'p99 {pct(n.proc, .99):.3f}  max {max(n.proc):.3f}  (KPI ≤ 2.0 ms)')
    print('status counts:', dict(sorted(n.status.items())))
    n.destroy_node()
    rclpy.shutdown()
    return 0


if __name__ == '__main__':
    sys.exit(main())
