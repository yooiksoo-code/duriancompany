# inhaul_msgs/msg/TagDetectionArray.msg
# 단일 동기 주기(4채널 동시 노출) 내 전체 검출 결과

std_msgs/Header header             # PTP 동기화된 정밀 촬영 타임스탬프 및 frame_id
uint8 active_camera_mask           # 정상 수신된 카메라 비트마스크 (bit0=CH1 ... bit3=CH4, 정상 시 0b1111)
TagDetection[] detections          # 단일 동기 주기 내 4대 카메라 전체 검출 태그 배열 (차폐 시 빈 배열)
float32 processing_time_ms         # 해당 프레임 수집~검출 소요 시간 (모니터링용)
