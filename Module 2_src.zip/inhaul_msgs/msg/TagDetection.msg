# inhaul_msgs/msg/TagDetection.msg
# 단일 카메라에서 검출된 단일 AprilTag 3 (tag36h11) 정보

uint8 camera_id                    # 검출된 카메라 채널 ID (1 ~ 4)
int32 tag_id                       # AprilTag 고유 ID (tag36h11)
float32 decision_margin            # 디코딩 신뢰도 점수 (임계값 필터링 기준)
uint8 hamming_error                # 비트 에러 수 (0 또는 1)
geometry_msgs/Point32[4] corners   # 왜곡 보정된 2D 서브픽셀 코너 좌표 [x0,y0 ~ x3,y3] (z = 0)
                                   # 코너 순서는 AprilTag 표준(태그 좌표계 기준 (-1,1),(1,1),(1,-1),(-1,-1))
geometry_msgs/Point32 center       # 태그 중심 2D 픽셀 좌표
