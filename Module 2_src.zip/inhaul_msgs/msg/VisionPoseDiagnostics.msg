# inhaul_msgs/msg/VisionPoseDiagnostics.msg
# [모듈 2] pose_estimation_node 진단 및 품질 상태 (/vision/pose_diagnostics, 매 입력 프레임 발행)
# 설계서 5장 ②: 관측 카메라 수, 관측 태그 수, 재투영 오차 픽셀값, PnP 수렴 여부

uint8 STATUS_OK = 0
uint8 STATUS_VISION_DROPOUT = 1            # 유효 태그 0개 → /sub_pose_vision 발행 중단 (EKF Dead-Reckoning)
uint8 STATUS_REJECT_REPROJECTION = 2       # 재투영 오차 > 임계 (2.5 px) 또는 인라이어 비율 부족
uint8 STATUS_REJECT_KINEMATIC_GATE = 3     # 물리 속도 한계 초과 점프 (0.5 m/s, 15 deg/s)
uint8 STATUS_REJECT_MAHALANOBIS = 4        # EKF 예측 대비 Mahalanobis 거리 초과 (선택 기능)
uint8 STATUS_SOLVER_FAILED = 5             # 초기해 실패 / 코너 부족
uint8 STATUS_REJECT_AMBIGUOUS = 6          # 1카메라·1태그, prior 없음, IPPE 두 해 구분 불가

std_msgs/Header header                     # stamp = 입력 TagDetectionArray stamp (PTP 촬영 시각)
uint8 status
string status_text
bool pose_published                        # 이번 프레임 /sub_pose_vision 발행 여부

uint8 active_camera_mask                   # [모듈 1] 정상 수신 카메라
uint8 observed_camera_mask                 # 유효 태그를 관측해 최적화에 기여한 카메라
uint8 num_cameras
uint16 num_tags                            # 서로 다른 태그 ID 수 (N_tags)
uint16 num_tag_observations                # (카메라, 태그) 관측 쌍 수
uint16 num_corners                         # 최적화 인라이어 코너 수
uint16 num_outlier_corners                 # RANSAC/잔차 기반 제거 코너 수
uint16 num_rejected_detections             # 입력 필터 제외 (미등록 ID/카메라, hamming, 중복)

float32 reprojection_error_px              # 인라이어 재투영 RMS (e_reproj)
float32 max_reprojection_error_px
float32 mean_distance_m                    # 카메라-관측태그 평균 거리 d
float32 baseline_m                         # 관측 태그 간 최대 거리 L_baseline
bool converged                             # LM 수렴 여부
uint16 iterations
bool single_tag_ambiguity                  # IPPE 모호성 처리 프레임 (회전 공분산 확대 적용)
bool ambiguity_resolved_by_prior

float32 position_std_m                     # sqrt(trace(Σ_pos))
float32 rotation_std_deg                   # sqrt(trace(Σ_rot))
float32 processing_time_ms                 # TagDetectionArray 수신 ~ /sub_pose_vision 발행 (KPI ≤ 2.0 ms)
float32 input_age_ms                       # 수신 시점의 (now − header.stamp): 모듈 1 지연 + 전송 지연
