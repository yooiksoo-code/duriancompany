// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [세부모듈 4] 수면 반사 및 오검출 필터링 (OutlierRejectionFilter)
//
//  1) 신뢰도 필터  : decision_margin < min_decision_margin(35.0) 또는 hamming > max_hamming(1) 폐기
//  2) ID 화이트리스트: Tag Bundle 에 등록된 ID 외 번호 차단 (배경 노이즈)
//  3) 기하 이상치  : 최소 변 길이, 변 길이 비(원근 허용 범위), 볼록성/와인딩, 면적 → 수면 글린트/반사상 제거
//  4) 중복 ID      : 동일 프레임 내 동일 ID 가 복수 검출되면(수면 반사상) decision_margin 최대 1개만 유지
#pragma once

#include <array>
#include <cstdint>
#include <set>
#include <vector>

#include "pkg_vision_acquisition/types.hpp"

namespace pva {

struct FilterConfig {
  float min_decision_margin = 35.0f;
  int max_hamming = 1;
  bool enable_whitelist = true;
  std::set<int> whitelist;          ///< 비어있고 enable_whitelist=true 이면 전부 차단 (설정 오류 방지 위해 경고)
  float min_side_px = 8.0f;         ///< 이보다 작은 태그는 서브픽셀 정밀도 확보 불가 → 폐기
  float max_side_ratio = 4.0f;      ///< 최장변/최단변. 과도한 원근/반사 왜곡 사각형 폐기
  float min_area_px = 64.0f;
  bool reject_duplicates = true;
  bool check_winding = true;        ///< AprilTag 코너 와인딩 방향 (거울 반사상은 반대 방향)
};

struct FilterStats {
  uint64_t passed = 0;
  uint64_t low_margin = 0;
  uint64_t high_hamming = 0;
  uint64_t not_whitelisted = 0;
  uint64_t bad_geometry = 0;
  uint64_t duplicate = 0;
  uint64_t total_rejected() const {
    return low_margin + high_hamming + not_whitelisted + bad_geometry + duplicate;
  }
};

class OutlierRejectionFilter {
 public:
  enum class Reason : uint8_t { kPass, kLowMargin, kHighHamming, kNotWhitelisted, kBadGeometry, kDuplicate };

  explicit OutlierRejectionFilter(const FilterConfig& cfg);

  /// in-place 필터링. 폐기 개수 반환.
  uint32_t apply(std::vector<Detection>& dets);

  /// 단일 검출 판정 (중복 검사 제외)
  Reason check(const Detection& d) const;

  const FilterStats& stats() const { return stats_; }
  const FilterConfig& config() const { return cfg_; }

  /// 이미지 좌표계(y 아래)에서 AprilTag 3 코너 순서의 기대 와인딩 부호.
  /// 기본값은 단위시험(test_detector)에서 실측 검증된 값으로 설정.
  static int expectedWindingSign();

 private:
  FilterConfig cfg_;
  FilterStats stats_;
};

}  // namespace pva
