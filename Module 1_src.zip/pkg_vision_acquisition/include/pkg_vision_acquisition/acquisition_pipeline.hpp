// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 3D 위치 데이터 수집 파이프라인 (ROS 비의존 오케스트레이터)
//
//   [Cam1..4] ─(grab thread ×4)─▶ SPSC(frame idx) ─▶ (worker thread ×4)
//        MultiCamSyncGrabber          Lock-Free           ImagePreprocessor → AprilTagDetectorCore
//                                                         → OutlierRejectionFilter → DynamicRoi
//                                                                │
//                                         SPSC(ChannelResult) ×4 ▼
//                                     (aggregator thread) 타임스탬프 동기 집계 → on_result 콜백
//
//  - 채널별 독립 스레드: 한 채널의 지연/장애가 다른 채널에 전파되지 않음
//  - 데이터 경로는 전부 SPSC Lock-Free 링, 프레임 버퍼는 사전할당 풀
//  - 콜백(on_result / on_event)은 모두 aggregator 스레드 1곳에서만 호출 (호출측 동기화 불필요)
#pragma once

#include <array>
#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <vector>

#include "pkg_vision_acquisition/apriltag_detector_core.hpp"
#include "pkg_vision_acquisition/camera_driver.hpp"
#include "pkg_vision_acquisition/dynamic_roi.hpp"
#include "pkg_vision_acquisition/frame_pool.hpp"
#include "pkg_vision_acquisition/geometry.hpp"
#include "pkg_vision_acquisition/image_preprocessor.hpp"
#include "pkg_vision_acquisition/latency_stats.hpp"
#include "pkg_vision_acquisition/outlier_rejection_filter.hpp"
#include "pkg_vision_acquisition/spsc_ring_buffer.hpp"

namespace pva {

struct ChannelConfig {
  CameraConfig camera;
  CameraIntrinsics intrinsics;
  std::optional<Pose3> T_world_cam;  ///< 동적 ROI(EKF 투영) 사용 시 필요
};

struct ThreadConfig {
  int rt_priority_grab = 0;     ///< >0 이면 SCHED_FIFO (Preempt-RT 커널 + CAP_SYS_NICE 필요)
  int rt_priority_worker = 0;
  int rt_priority_aggregator = 0;
  std::vector<int> cpu_grab;    ///< 채널 순서별 CPU 고정 (빈 값 → 미지정)
  std::vector<int> cpu_worker;
  int cpu_aggregator = -1;
  int worker_spin_us = 50;      ///< 프레임 대기 busy-poll 시간 (wake-up 지연 감소)
};

struct SyncConfig {
  double window_us = 2000.0;     ///< 동일 동기 주기로 간주할 타임스탬프 차 (≪ 프레임 주기)
  double tolerance_us = 100.0;   ///< 설계 요구 노출 동기 허용치 ±us: max|t_i - mean| 초과 시 WARN_SYNC_VIOLATION
  double max_wait_ms = 8.0;      ///< 첫 채널 도착 후 나머지 채널 최대 대기 (초과 시 부분 발행)
};

struct HealthConfig {
  int dropout_timeout_ms = 250;   ///< 이 시간 동안 프레임 없으면 채널 단절 판정
  int reconnect_interval_ms = 1000;
  int occlusion_warn_cycles = 15; ///< 연속 N 주기 태그 0개 → WARN_TOTAL_OCCLUSION (1회)
  int event_throttle_ms = 1000;   ///< 동일 이벤트 반복 억제
};

struct PipelineConfig {
  std::vector<ChannelConfig> channels;
  PreprocessConfig preprocess;
  DetectorConfig detector;
  FilterConfig filter;
  RoiConfig roi;
  TagBundle bundle;
  SyncConfig sync;
  HealthConfig health;
  ThreadConfig threads;
  int pool_buffers = 6;
  int ring_capacity = 4;
};

struct ChannelStats {
  uint8_t camera_id = 0;
  bool connected = false;
  uint64_t frames_grabbed = 0;
  uint64_t frames_processed = 0;
  uint64_t frames_skipped_stale = 0;   ///< 워커 지연으로 최신 프레임만 처리하고 건너뛴 수
  uint64_t frames_dropped_nobuf = 0;   ///< 풀 고갈로 폐기
  uint64_t frames_incomplete = 0;      ///< 패킷 손실 프레임
  uint64_t seq_gaps = 0;               ///< 프레임 카운터 누락 수
  uint64_t lost_packets = 0;
  uint64_t timeouts = 0;
  uint64_t disconnects = 0;
  uint64_t reconnects = 0;
  uint64_t roi_frames = 0;
  uint64_t roi_fallbacks = 0;
  uint64_t detections = 0;
  FilterStats filter;
  CameraStats camera;
  double fps = 0.0;
  LatencySummary work_ms;              ///< 전처리+검출+필터
};

struct PipelineStats {
  uint64_t published = 0;
  uint64_t partial_published = 0;  ///< 일부 채널 누락 상태로 발행
  uint64_t empty_published = 0;    ///< 태그 0개 (차폐) 발행
  uint64_t late_results = 0;       ///< 발행 후 도착하여 폐기된 채널 결과
  uint64_t sync_violations = 0;
  double publish_fps = 0.0;
  LatencySummary processing_ms;    ///< processing_time_ms 통계
  LatencySummary stamp_dev_us;     ///< 노출 시점 기준 대비 최대 편차 [us] (±tolerance 판정)
  std::vector<ChannelStats> channels;
};

class AcquisitionPipeline {
 public:
  using ResultCallback = std::function<void(SyncedResult&)>;
  using EventCallback = std::function<void(const PipelineEvent&)>;

  explicit AcquisitionPipeline(PipelineConfig cfg);
  ~AcquisitionPipeline();
  AcquisitionPipeline(const AcquisitionPipeline&) = delete;
  AcquisitionPipeline& operator=(const AcquisitionPipeline&) = delete;

  void setResultCallback(ResultCallback cb) { on_result_ = std::move(cb); }
  void setEventCallback(EventCallback cb) { on_event_ = std::move(cb); }

  /// 드라이버 생성 및 카메라 연결 시도. require_all=true 이면 1대라도 실패 시 false.
  bool start(std::string& err, bool require_all = false);
  void stop();
  bool running() const { return running_.load(); }

  /// EKF 추정 자세 입력 (단일 작성자: ROS 구독 콜백). Lock-Free SeqLock.
  void setPoseFeedback(const PoseSnapshot& pose) { pose_.store(pose); }

  PipelineStats stats();
  /// aggregator 루프 최근 실행 시각 (systemd watchdog 판단용)
  int64_t heartbeatMonoNs() const { return heartbeat_mono_ns_.load(std::memory_order_relaxed); }
  uint8_t connectedMask() const;
  const PipelineConfig& config() const { return cfg_; }

 private:
  struct Channel;
  void grabLoop(Channel& ch);
  void workerLoop(Channel& ch);
  void aggregatorLoop();
  void processFrame(Channel& ch, FrameBuffer& frame, ChannelResult& res);
  void pushEvent(EventCode code, uint8_t cam, const std::string& msg);
  void drainEvents();

  PipelineConfig cfg_;
  std::vector<std::unique_ptr<Channel>> channels_;
  std::atomic<bool> running_{false};
  std::thread aggregator_;
  Doorbell agg_bell_;
  SeqLock<PoseSnapshot> pose_;
  std::atomic<int64_t> heartbeat_mono_ns_{0};

  ResultCallback on_result_;
  EventCallback on_event_;

  std::mutex event_mtx_;
  std::vector<PipelineEvent> events_;

  std::mutex stats_mtx_;
  PipelineStats agg_stats_;
  LatencyStats processing_lat_{4096};
  LatencyStats spread_lat_{4096};
  RateMeter publish_rate_;
};

/// 현재 스레드 실시간 설정 (SCHED_FIFO 우선순위, CPU 고정, 이름). 실패 사유를 err 에 기록.
bool configureCurrentThread(const char* name, int rt_priority, int cpu, std::string& err);

}  // namespace pva
