// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 동적 관심영역(Dynamic ROI) 산출기 - 채널별 1개 인스턴스
//
//  우선순위
//   1) EKF 피드백(/sub_pose_filtered): 직전 추정 6DoF 자세를 프레임 노출시각까지 외삽 →
//      Tag Bundle 전체 코너를 카메라에 투영 → bounding box + 마진
//   2) 자기 추적: 직전 프레임 같은 채널의 검출 코너 bounding box + 마진 (EKF 미연동 시)
//   3) Full Frame : 위 정보가 없거나, 주기적 전체 탐색 시점이거나, ROI 가 화면 대부분인 경우
//  * ROI 탐색 결과 태그 0개 → 워커가 동일 프레임에서 즉시 Full Frame 재탐색 (설계서 요구사항)
#pragma once

#include <cstdint>
#include <optional>
#include <vector>

#include <opencv2/core.hpp>

#include "pkg_vision_acquisition/geometry.hpp"
#include "pkg_vision_acquisition/types.hpp"

namespace pva {

/// EKF 추정 자세 스냅샷 (SeqLock 공유를 위해 trivially copyable)
struct PoseSnapshot {
  int64_t stamp_ns = 0;
  double R_world_body[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  double t_world_body[3] = {0, 0, 0};
  double v_body[3] = {0, 0, 0};  ///< 선속도 (child frame 기준, nav_msgs/Odometry 규약)
  double w_body[3] = {0, 0, 0};  ///< 각속도 (child frame 기준)
};

struct RoiConfig {
  bool enable = true;
  bool use_pose_feedback = true;
  bool use_detection_tracking = true;
  int margin_px = 40;               ///< 고정 마진
  double margin_ratio = 0.25;       ///< 투영 bbox 크기 대비 추가 마진 (자세 오차 흡수)
  double pose_timeout_ms = 150.0;   ///< 이보다 오래된 EKF 자세는 사용하지 않음
  int track_max_age_frames = 3;     ///< 자기추적 ROI 유효 프레임 수
  int full_frame_every_n = 15;      ///< N 프레임마다 강제 전체 탐색 (신규 진입 태그 포착)
  double max_area_ratio = 0.6;      ///< ROI 가 전체의 60% 초과 시 Full Frame (이득 없음)
  int min_size_px = 96;
  int align_px = 16;                ///< ROI x/width 정렬 (SIMD/캐시 친화)
  bool retry_full_frame_on_miss = true;
};

enum class RoiSource : uint8_t { kFull = 0, kPose, kTracking };

class DynamicRoi {
 public:
  DynamicRoi(const RoiConfig& cfg, const CameraIntrinsics& intr, std::optional<Pose3> T_world_cam,
             const TagBundle& bundle);

  /// 프레임 노출 시각 기준 ROI. empty Rect 이면 Full Frame.
  cv::Rect compute(int64_t frame_stamp_ns, const PoseSnapshot* pose, RoiSource* source = nullptr);

  /// 이번 프레임 최종 검출 결과로 자기추적 상태 갱신
  void update(const std::vector<Detection>& dets);

  /// EKF 자세를 이용해 번들 코너를 투영 (보정 좌표계). 테스트/디버그용
  std::vector<cv::Point2f> projectBundle(const PoseSnapshot& pose, int64_t frame_stamp_ns) const;

 private:
  cv::Rect finalize(const cv::Rect2f& box) const;

  RoiConfig cfg_;
  CameraIntrinsics intr_;
  std::optional<Pose3> T_cam_world_;
  std::vector<cv::Point3d> bundle_pts_;
  cv::Rect2f last_track_box_;
  int track_age_ = 1 << 20;
  uint64_t frame_counter_ = 0;
};

}  // namespace pva
