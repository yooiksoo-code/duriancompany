// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [세부모듈 2] 고속 왜곡 보정 및 동적 ROI 모듈 (ImagePreprocessor)
//
//  - 초기화 시 cv::initUndistortRectifyMap 으로 LUT 생성 → 고정소수점(CV_16SC2) 맵으로 변환
//  - 매 프레임 cv::remap 만 수행 (삼각함수 연산 없음)
//  - ROI 가 주어지면 "출력(보정) 좌표계 ROI" 영역의 LUT 부분만 remap → 연산량이 ROI 면적에 비례
//  - 보정 후 좌표계 = K 동일, D = 0 인 이상적 핀홀 (하류 PnP 는 D=0 으로 사용)
#pragma once

#include <memory>
#include <vector>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>

#include "pkg_vision_acquisition/types.hpp"

namespace pva {

enum class UndistortMode : uint8_t {
  kRemap = 0,    ///< 영상 전체(또는 ROI) LUT remap 후 검출 (설계서 기본안)
  kCornersOnly,  ///< 원본 영상에서 검출 후 코너 좌표만 undistortPoints (최저 지연)
  kNone,         ///< 보정 없음 (왜곡이 무시 가능한 렌즈/시험용)
};

UndistortMode parseUndistortMode(const std::string& s);

struct PreprocessConfig {
  UndistortMode undistort_mode = UndistortMode::kRemap;
  int interpolation = cv::INTER_LINEAR;
  bool clahe_enable = false;
  double clahe_clip_limit = 2.0;
  int clahe_tile_grid = 8;
};

/// 전처리 결과. image 는 ImagePreprocessor 내부 버퍼 또는 입력 프레임을 참조 (다음 호출까지 유효)
struct PreprocessOutput {
  cv::Mat image;              ///< 검출기 입력 (ROI 크기)
  cv::Point2f offset{0, 0};   ///< image(0,0) 의 전체 영상 좌표 (검출 좌표 + offset = 전체 좌표)
  bool rectified = false;     ///< image 가 이미 왜곡 보정된 좌표계인지
};

class ImagePreprocessor {
 public:
  ImagePreprocessor(const CameraIntrinsics& intr, const PreprocessConfig& cfg);

  /// raw: 원본 Mono8 프레임 (전체 해상도). roi: 보정 좌표계 기준 탐색 영역 (empty → 전체)
  PreprocessOutput process(const cv::Mat& raw, const cv::Rect& roi);

  /// kCornersOnly 모드에서 원본 좌표 → 보정 좌표 변환 (in-place). 다른 모드에서는 no-op.
  void rectifyPoints(std::vector<cv::Point2f>& pts) const;

  /// 원본(왜곡) 좌표 → 보정 좌표 (모드 무관, 테스트/ROI 계산용)
  void undistortPoints(std::vector<cv::Point2f>& pts) const;

  /// kCornersOnly 모드에서 보정 좌표계 ROI 를 원본 좌표계 ROI 로 변환 (보수적 bounding box)
  cv::Rect rectifiedRoiToRaw(const cv::Rect& roi) const;

  const CameraIntrinsics& intrinsics() const { return intr_; }
  const PreprocessConfig& config() const { return cfg_; }
  cv::Size imageSize() const { return {intr_.width, intr_.height}; }

 private:
  CameraIntrinsics intr_;
  PreprocessConfig cfg_;
  cv::Mat map1_, map2_;  // CV_16SC2 + CV_16UC1 고정소수점 LUT
  cv::Mat rect_buf_;     // remap 출력 버퍼 (전체 해상도 사전할당, ROI 는 부분 뷰 사용)
  cv::Mat clahe_buf_;
  cv::Ptr<cv::CLAHE> clahe_;
};

}  // namespace pva
