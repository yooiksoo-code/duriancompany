// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// [세부모듈 3] AprilTag 3 서브픽셀 검출 엔진 (AprilTagDetectorCore)
//
//  - tag36h11 전용, 채널 워커마다 독립 인스턴스 (apriltag_detector_t 는 스레드 안전하지 않음)
//  - 적응형 이진화: AprilTag 3 의 4x4 px 타일 단위 local min/max 임계값 (min_white_black_diff 등 노출)
//  - 서브픽셀 정밀화: refine_edges (에지 법선 방향 그래디언트 가중 직선 피팅 → 코너 교점)
//  - 좌표 규약 보정: AprilTag 은 픽셀 중심을 (i+0.5) 로, OpenCV/핀홀 모델은 (i) 로 정의하므로
//    pixel_center_offset(-0.5) 를 적용하여 OpenCV 규약(K, solvePnP)과 일치시킨다.
#pragma once

#include <memory>
#include <vector>

#include <opencv2/core.hpp>

#include "pkg_vision_acquisition/types.hpp"

struct apriltag_detector;
struct apriltag_family;

namespace pva {

struct DetectorConfig {
  float quad_decimate = 2.0f;       ///< 사각형 탐색용 데시메이션 (정밀도는 refine_edges 로 원해상도 복원)
  float quad_sigma = 0.0f;          ///< 가우시안 블러 (노이즈 많을 때 0.8 등)
  int nthreads = 2;                 ///< 검출기 내부 스레드 (채널당)
  bool refine_edges = true;         ///< 서브픽셀 코너 정밀화 (필수)
  double decode_sharpening = 0.25;
  int max_hamming = 1;              ///< 패밀리 등록 시 허용 비트 정정 수 (설계: ≤ 1)
  // 적응형 이진화 / 사각형 피팅 파라미터 (apriltag_quad_thresh_params)
  int min_white_black_diff = 20;    ///< 타일 내 명암 대비 최소치. 5(라이브러리 기본)는 센서 노이즈(±2DN)로
                                    ///< 가짜 클러스터가 폭증하여 1.5MP 기준 ~9배 느려짐 (실측). 저조도 시 10~15
  int min_cluster_pixels = 5;
  int max_nmaxima = 10;
  float critical_angle_deg = 10.0f;
  float max_line_fit_mse = 10.0f;
  bool deglitch = false;
  float pixel_center_offset = -0.5f; ///< AprilTag→OpenCV 픽셀 중심 규약 보정
};

class AprilTagDetectorCore {
 public:
  explicit AprilTagDetectorCore(const DetectorConfig& cfg);
  ~AprilTagDetectorCore();
  AprilTagDetectorCore(const AprilTagDetectorCore&) = delete;
  AprilTagDetectorCore& operator=(const AprilTagDetectorCore&) = delete;

  /// image: Mono8 (ROI 뷰 가능, zero-copy). offset: image 원점의 전체 영상 좌표.
  /// 결과를 out 에 append 한다 (camera_id 는 호출측에서 지정).
  void detect(const cv::Mat& image, const cv::Point2f& offset, uint8_t camera_id,
              std::vector<Detection>& out);

  const DetectorConfig& config() const { return cfg_; }

 private:
  DetectorConfig cfg_;
  apriltag_detector* td_ = nullptr;
  apriltag_family* tf_ = nullptr;
};

}  // namespace pva
