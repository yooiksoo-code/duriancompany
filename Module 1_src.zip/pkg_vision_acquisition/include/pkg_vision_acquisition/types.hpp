// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
// 손원일급 잠수함 자동 INHAUL 시스템 - [모듈 1] 3D 위치수집 SW Module (pkg_vision_acquisition)
//
// 공용 데이터 타입 정의 (ROS 비의존 코어)
#pragma once

#include <array>
#include <chrono>
#include <cstdint>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

namespace pva {

/// 지원 최대 카메라 채널 수 (active_camera_mask uint8 비트 수와 일치하도록 8 이하)
constexpr int kMaxCameras = 4;

using SteadyClock = std::chrono::steady_clock;

/// 단조 증가 시계 [ns] (지연시간 계측 전용)
inline int64_t monoNowNs() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
             SteadyClock::now().time_since_epoch())
      .count();
}

/// 벽시계 [ns since UNIX epoch] (PTP/phc2sys 로 동기화된 시스템 시계)
inline int64_t wallNowNs() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
             std::chrono::system_clock::now().time_since_epoch())
      .count();
}

/// 카메라 내부 파라미터 (config/cam_intrinsics_chN.yaml)
struct CameraIntrinsics {
  std::string camera_name;
  int width = 0;
  int height = 0;
  cv::Matx33d K = cv::Matx33d::eye();
  cv::Mat D;  ///< 1xN (plumb_bob: k1,k2,p1,p2[,k3])
  std::string distortion_model = "plumb_bob";

  bool valid() const { return width > 0 && height > 0 && K(0, 0) > 0.0 && K(1, 1) > 0.0; }
};

/// 프레임 메타데이터
struct FrameMeta {
  uint8_t camera_id = 0;      ///< 1 ~ 4
  uint64_t frame_seq = 0;     ///< 카메라 프레임 카운터 (BlockID / FrameNum)
  int64_t stamp_ns = 0;       ///< 노출 시점 타임스탬프 (PTP 동기 장치시계, UNIX epoch ns)
  int64_t recv_mono_ns = 0;   ///< 호스트 버퍼 수신 완료 시점 (steady clock) - 지연 계측 기준점
  uint32_t lost_packets = 0;  ///< 해당 프레임에서 손실된 GVSP 패킷 수 (SDK 제공 시)
};

/// 사전할당 프레임 버퍼 (Mono8). FramePool 이 소유하며 루프 내 동적할당 없음.
struct FrameBuffer {
  std::vector<uint8_t> data;
  int width = 0;
  int height = 0;
  int stride = 0;
  FrameMeta meta;

  void allocate(int w, int h) {
    if (w <= 0 || h <= 0) return;
    width = w;
    height = h;
    // 16B 배수 폭은 그대로(SDK 직접 수신 가능), 그 외는 64B 정렬 stride (SIMD/캐시라인 친화)
    stride = (w % 16 == 0) ? w : ((w + 63) & ~63);
    data.assign(static_cast<size_t>(stride) * static_cast<size_t>(h), 0);
  }
  size_t bytes() const { return data.size(); }
  cv::Mat view() { return cv::Mat(height, width, CV_8UC1, data.data(), static_cast<size_t>(stride)); }
  cv::Mat view() const {
    return cv::Mat(height, width, CV_8UC1, const_cast<uint8_t*>(data.data()),
                   static_cast<size_t>(stride));
  }
};

/// 단일 태그 검출 결과 (inhaul_msgs/TagDetection 대응)
struct Detection {
  uint8_t camera_id = 0;
  int32_t tag_id = -1;
  float decision_margin = 0.f;
  uint8_t hamming = 0;
  std::array<cv::Point2f, 4> corners{};  ///< 왜곡 보정(이상적 핀홀, K 동일, D=0) 좌표계
  cv::Point2f center{};
};

/// 채널 워커 처리 결과
struct ChannelResult {
  FrameMeta meta;
  std::vector<Detection> detections;
  cv::Rect roi;               ///< 실제 탐색에 사용된 영역 (Full Frame 이면 전체)
  bool roi_used = false;      ///< 동적 ROI 적용 여부
  bool roi_fallback = false;  ///< ROI 미검출 → 동일 프레임 Full Frame 재탐색 수행 여부
  uint32_t rejected = 0;      ///< 필터에 의해 폐기된 검출 수
  double preprocess_ms = 0.0;
  double detect_ms = 0.0;
  double filter_ms = 0.0;
  int64_t done_mono_ns = 0;
};

/// 동기 주기 단위 집계 결과 (inhaul_msgs/TagDetectionArray 대응)
struct SyncedResult {
  uint64_t sync_seq = 0;
  int64_t stamp_ns = 0;            ///< 기여 채널 노출 타임스탬프 평균
  int64_t stamp_spread_ns = 0;     ///< 채널 간 노출 시점 범위 (max - min)
  int64_t stamp_max_dev_ns = 0;    ///< 기준(평균) 대비 최대 편차 max|t_i - mean| (설계 ±100us 판정 기준)
  uint8_t active_camera_mask = 0;  ///< 이번 주기에 정상 수신된 카메라 비트마스크
  std::vector<Detection> detections;
  int64_t earliest_recv_mono_ns = 0;
  double processing_time_ms = 0.0;  ///< 버퍼 수신 ~ 발행 직전까지 소요시간
  std::array<double, kMaxCameras> channel_work_ms{};  ///< 채널별 전처리+검출+필터 소요시간
  std::array<bool, kMaxCameras> channel_roi_used{};
};

/// HMI 로 전달되는 이벤트 코드
enum class EventCode : uint8_t {
  kInfo = 0,
  kCamDropout,       ///< WARN_CAM_DROPOUT
  kCamRecovered,     ///< INFO_CAM_RECOVERED
  kTotalOcclusion,   ///< WARN_TOTAL_OCCLUSION (연속 N 주기 태그 0개)
  kSyncViolation,    ///< WARN_SYNC_VIOLATION (채널 간 노출 편차 > 허용치)
  kPacketLoss,       ///< WARN_PACKET_LOSS
  kPipelineStall,    ///< ERROR_PIPELINE_STALL
};

inline const char* eventCodeName(EventCode c) {
  switch (c) {
    case EventCode::kInfo: return "INFO";
    case EventCode::kCamDropout: return "WARN_CAM_DROPOUT";
    case EventCode::kCamRecovered: return "INFO_CAM_RECOVERED";
    case EventCode::kTotalOcclusion: return "WARN_TOTAL_OCCLUSION";
    case EventCode::kSyncViolation: return "WARN_SYNC_VIOLATION";
    case EventCode::kPacketLoss: return "WARN_PACKET_LOSS";
    case EventCode::kPipelineStall: return "ERROR_PIPELINE_STALL";
  }
  return "UNKNOWN";
}

struct PipelineEvent {
  EventCode code = EventCode::kInfo;
  uint8_t camera_id = 0;  ///< 0 = 전체
  std::string message;
};

}  // namespace pva
