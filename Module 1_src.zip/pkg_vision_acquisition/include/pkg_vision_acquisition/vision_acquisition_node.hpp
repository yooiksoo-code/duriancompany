// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// vision_acquisition_node : ROS2 Humble LifecycleNode 래퍼
//
//  상태 전이
//   configure  : 파라미터 → PipelineConfig, 퍼블리셔/구독 생성 (카메라 미구동)
//   activate   : 카메라 연결 및 수집 시작, 발행 개시
//   deactivate : 수집 정지 (카메라 연결 해제)
//   cleanup    : 자원 해제
//   error      : 파이프라인 정지 후 FAILURE → 프로세스 종료 → systemd 재기동 (Self-Healing)
//
//  출력: /vision/tag_detections (inhaul_msgs/TagDetectionArray), [/camera_n/detected_tags],
//        /hmi/vision_alerts (std_msgs/String), /diagnostics (diagnostic_msgs/DiagnosticArray)
//  입력: /sub_pose_filtered (nav_msgs/Odometry, 선택) → 동적 ROI
#pragma once

#include <array>
#include <atomic>
#include <memory>
#include <string>

#include <diagnostic_msgs/msg/diagnostic_array.hpp>
#include <inhaul_msgs/msg/tag_detection_array.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <rclcpp_lifecycle/lifecycle_publisher.hpp>
#include <std_msgs/msg/string.hpp>

#include "pkg_vision_acquisition/acquisition_pipeline.hpp"

namespace pva {

class VisionAcquisitionNode : public rclcpp_lifecycle::LifecycleNode {
 public:
  using CallbackReturn = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn;
  using TagArray = inhaul_msgs::msg::TagDetectionArray;

  explicit VisionAcquisitionNode(const rclcpp::NodeOptions& options = rclcpp::NodeOptions());
  ~VisionAcquisitionNode() override;

  CallbackReturn on_configure(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_activate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_deactivate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_cleanup(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_shutdown(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_error(const rclcpp_lifecycle::State&) override;

  /// systemd watchdog 판단: 활성 상태에서 파이프라인 집계 루프가 watchdog_stall_ms 내 동작 중인지
  bool healthy() const;
  bool autostart() const { return autostart_; }

 private:
  void onResult(SyncedResult& r);            // 집계 스레드에서 호출
  void onEvent(const PipelineEvent& e);      // 집계 스레드에서 호출
  void onPose(const nav_msgs::msg::Odometry::ConstSharedPtr& msg);
  void publishDiagnostics();
  std::string resolvePath(const std::string& p) const;
  void stopPipeline();

  PipelineConfig cfg_;
  std::unique_ptr<AcquisitionPipeline> pipeline_;
  std::string world_frame_;

  rclcpp_lifecycle::LifecyclePublisher<TagArray>::SharedPtr pub_;
  std::array<rclcpp_lifecycle::LifecyclePublisher<TagArray>::SharedPtr, kMaxCameras> cam_pubs_{};
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::String>::SharedPtr alert_pub_;
  rclcpp_lifecycle::LifecyclePublisher<diagnostic_msgs::msg::DiagnosticArray>::SharedPtr diag_pub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr pose_sub_;
  rclcpp::TimerBase::SharedPtr diag_timer_;

  std::string frame_id_;
  bool per_camera_topics_ = false;
  bool autostart_ = true;
  int64_t watchdog_stall_ns_ = 300'000'000;
  std::atomic<bool> active_{false};
  std::atomic<bool> pose_frame_warned_{false};
  std::atomic<uint64_t> publish_errors_{0};
};

}  // namespace pva
