// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// GigE Vision 카메라 드라이버 추상화 계층.
//   - "aravis" : GenICam 표준 오픈소스 드라이버 (HAVE_ARAVIS)
//   - "hikmvs" : Hikrobot MVS SDK (HAVE_HIK_MVS)
//   - "sim"    : 테스트베드 합성영상 시뮬레이터 (항상 사용 가능, 단위시험/벤치마크 용)
#pragma once

#include <cstdint>
#include <memory>
#include <string>

#include "pkg_vision_acquisition/types.hpp"

namespace pva {

struct SimSceneConfig;  // sim_camera.hpp

enum class TriggerMode : uint8_t {
  kFreeRun = 0,   ///< 내부 타이머 (AcquisitionFrameRate) - 동기 보장 안됨, 개발용
  kHardware,      ///< 외부 GPIO 트리거 (TriggerSource=Line0 등) - 4대 동시 노출
  kPtpScheduled,  ///< IEEE 1588 PTP 동기 + 카메라 내부 프레임레이트 (PTP 지원 모델)
};

enum class TimestampSource : uint8_t {
  kDevicePtp = 0,  ///< 카메라 장치 타임스탬프 (PTP 동기, ns). 권장.
  kHost,           ///< 호스트 수신 시각 - host_latency_compensation_us (PTP 미지원 시)
};

struct CameraConfig {
  uint8_t camera_id = 1;      ///< 1 ~ 4
  std::string driver = "sim";
  std::string device_id;      ///< 시리얼번호 / IP / Aravis device name (빈 문자열 = 첫 번째 장치)
  int width = 1440;
  int height = 1080;
  int offset_x = 0;
  int offset_y = 0;
  double fps = 60.0;
  double exposure_us = 2000.0;  ///< 모션블러 억제를 위해 짧은 노출 + 조명/게인 보상
  double gain_db = 6.0;
  TriggerMode trigger_mode = TriggerMode::kHardware;
  std::string trigger_source = "Line0";
  std::string trigger_activation = "RisingEdge";
  bool ptp_enable = true;
  TimestampSource timestamp_source = TimestampSource::kDevicePtp;
  double host_latency_compensation_us = 0.0;
  int64_t ptp_tai_utc_offset_ns = 0;  ///< 카메라가 TAI 기준일 경우 37s (=37e9) 보정

  // GigE 네트워크 튜닝
  int packet_size = 8192;      ///< GevSCPSPacketSize (Jumbo Frame MTU 9000 기준)
  int packet_delay = 0;        ///< GevSCPD (inter-packet delay, ticks). 스위치 경유 시 조정
  int num_sdk_buffers = 16;    ///< SDK 내부 스트림 버퍼 수
  bool packet_resend = true;
  int grab_timeout_ms = 100;

  std::shared_ptr<SimSceneConfig> sim;  ///< driver == "sim" 일 때만 사용
};

struct CameraStats {
  uint64_t frames_completed = 0;
  uint64_t frames_incomplete = 0;
  uint64_t packets_resent = 0;
  uint64_t packets_missing = 0;
};

class ICameraDriver {
 public:
  enum class GrabStatus { kOk, kTimeout, kIncomplete, kDisconnected };

  virtual ~ICameraDriver() = default;

  virtual bool open(std::string& err) = 0;
  virtual bool start(std::string& err) = 0;
  virtual void stop() = 0;
  virtual void close() = 0;

  /// out 버퍼(사전할당, width/height 일치)에 Mono8 프레임을 기록한다.
  /// out.meta.camera_id / frame_seq / stamp_ns / lost_packets 를 채운다 (recv_mono_ns 는 호출측).
  virtual GrabStatus grab(FrameBuffer& out, int timeout_ms) = 0;

  virtual CameraStats stats() const { return {}; }
  virtual std::string describe() const = 0;
};

/// 드라이버 팩토리. 빌드에 포함되지 않은 드라이버 요청 시 nullptr 와 err 반환.
std::unique_ptr<ICameraDriver> createCameraDriver(const CameraConfig& cfg, std::string& err);

TriggerMode parseTriggerMode(const std::string& s);
TimestampSource parseTimestampSource(const std::string& s);

}  // namespace pva
