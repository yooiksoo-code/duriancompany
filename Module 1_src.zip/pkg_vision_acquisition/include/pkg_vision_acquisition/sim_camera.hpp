// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 시뮬레이션 카메라 드라이버 ("sim")
//  - 축소형 Physical Twin 테스트베드(3.5m x 1.35m) 상부 카메라 시점의 합성 영상 생성
//  - 잠수함 선체 + tag36h11 Tag Bundle 을 실제 내부/외부 파라미터로 투영, 렌즈 왜곡 적용
//  - 4대가 공유하는 SimTriggerClock 으로 하드웨어 트리거 + PTP 타임스탬프를 모사
//  - 장애 주입: 채널 단절(dropout), 전면 차폐(glare/물보라), 수면 글린트, 센서 노이즈
//  - 실시간 렌더링 부하를 없애기 위해 prerender_frames 장을 사전 렌더링 후 순환 재생
#pragma once

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <optional>
#include <vector>

#include "pkg_vision_acquisition/camera_driver.hpp"
#include "pkg_vision_acquisition/geometry.hpp"

namespace pva {

/// 4채널 공유 트리거 클럭 (하드웨어 트리거 펄스 + PTP 시각 모사)
class SimTriggerClock {
 public:
  explicit SimTriggerClock(double fps);
  double fps() const { return fps_; }
  int64_t periodNs() const { return period_ns_; }
  int64_t startMonoNs() const { return start_mono_ns_; }
  int64_t startWallNs() const { return start_wall_ns_; }
  /// k 번째 트리거 시각 (steady clock ns)
  int64_t triggerMonoNs(uint64_t k) const { return start_mono_ns_ + static_cast<int64_t>(k) * period_ns_; }
  /// 현재 시각 이후 첫 트리거 인덱스
  uint64_t nextIndex() const;
  /// 시각 원점 재설정 (사전렌더 등 초기화 완료 후, 수집 스레드 시작 전에 호출)
  void restart();

 private:
  double fps_;
  int64_t period_ns_;
  int64_t start_mono_ns_;
  int64_t start_wall_ns_;
};

struct SimSceneConfig {
  CameraIntrinsics intrinsics;      ///< 영상 생성에 사용할 실제 렌즈 모델 (왜곡 포함)
  Pose3 T_world_cam;
  TagBundle bundle;
  Pose3 T_world_body0;              ///< 선체 기준 자세
  double hull_length_m = 2.4;       ///< 축소 모형 선체 (body x 축 방향)
  double hull_beam_m = 0.40;
  double motion_amp_m = 0.02;       ///< body x 방향 사인 왕복 진폭 (0 → 정지)
  double roll_amp_deg = 0.5;        ///< 롤 흔들림 진폭
  bool static_scene = false;        ///< true → 자세 고정 (지터 시험용), 노이즈만 프레임별 상이
  double noise_sigma = 2.0;         ///< 센서 가우시안 노이즈 [DN]
  int prerender_frames = 48;
  int supersample = 3;
  bool glints = true;               ///< 수면 글린트(포화 반점) 합성
  double timestamp_jitter_us = 20.0;  ///< 채널별 노출 시점 편차 (PTP ±100us 이내 모사)
  double arrival_jitter_us = 300.0;   ///< 채널별 버퍼 도착 편차 (전송 지연 모사)
  // 장애 주입 (클럭 시작 기준 초, < 0 이면 비활성)
  double dropout_start_s = -1.0;
  double dropout_duration_s = 0.0;
  double occlusion_start_s = -1.0;
  double occlusion_duration_s = 0.0;
  uint32_t seed = 1234;
  std::shared_ptr<SimTriggerClock> clock;
};

/// 프레임별 정답(보정 좌표계) - 벤치마크/시험용
struct SimGroundTruth {
  int tag_id;
  std::array<cv::Point2f, 4> corners;
};

class SimCamera : public ICameraDriver {
 public:
  explicit SimCamera(const CameraConfig& cfg);
  ~SimCamera() override;

  bool open(std::string& err) override;
  bool start(std::string& err) override;
  void stop() override;
  void close() override;
  GrabStatus grab(FrameBuffer& out, int timeout_ms) override;
  CameraStats stats() const override;
  std::string describe() const override;

  /// 사전렌더 프레임 index 의 보정 좌표계 정답 코너
  const std::vector<SimGroundTruth>& groundTruth(size_t frame_index) const;
  size_t numPrerendered() const { return frames_.size(); }

  /// 단일 프레임 렌더 (단위시험용 정적 유틸). 반환: 왜곡 적용된 Mono8 영상
  static cv::Mat renderFrame(const SimSceneConfig& scene, const Pose3& T_world_body, int width, int height,
                             cv::RNG& rng, std::vector<SimGroundTruth>* gt, bool add_glints);

 private:
  bool inWindow(double t_s, double start, double dur) const { return start >= 0 && t_s >= start && t_s < start + dur; }
  void prerender();

  CameraConfig cfg_;
  std::shared_ptr<SimSceneConfig> scene_;
  std::vector<cv::Mat> frames_;
  std::vector<std::vector<SimGroundTruth>> gt_;
  cv::Mat occluded_frame_;
  bool open_ = false;
  bool running_ = false;
  bool index_init_ = false;
  uint64_t next_index_ = 0;
  cv::RNG rng_;
  CameraStats stats_;
};

}  // namespace pva
