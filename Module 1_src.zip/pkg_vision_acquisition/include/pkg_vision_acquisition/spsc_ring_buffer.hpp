// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// Lock-Free 단일 생산자/단일 소비자(SPSC) 링 버퍼 + 대기용 Doorbell + SeqLock
//
//  - 데이터 경로(push/pop)는 원자적 인덱스만 사용 (mutex 없음, 할당 없음)
//  - Doorbell 은 소비자 스레드를 재우기 위한 용도로만 사용하며 데이터 보호에는 관여하지 않음
#pragma once

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <mutex>
#include <new>
#include <type_traits>
#include <utility>
#include <vector>

namespace pva {

// x86-64 캐시라인 고정값 (std::hardware_destructive_interference_size 는 컴파일러/플래그별로 달라 ABI 불안정)
constexpr size_t kCacheLine = 64;

/// SPSC 링 버퍼. capacity 는 2의 거듭제곱으로 올림 처리됨.
template <typename T>
class SpscRingBuffer {
 public:
  explicit SpscRingBuffer(size_t capacity) {
    size_t cap = 2;
    while (cap < capacity) cap <<= 1;
    mask_ = cap - 1;
    slots_.resize(cap);
  }

  SpscRingBuffer(const SpscRingBuffer&) = delete;
  SpscRingBuffer& operator=(const SpscRingBuffer&) = delete;

  size_t capacity() const { return mask_ + 1; }

  /// 생산자 전용. 가득 찬 경우 false.
  template <typename U>
  bool tryPush(U&& value) {
    const size_t head = head_.load(std::memory_order_relaxed);
    const size_t next = head + 1;
    if (next - tail_cache_ > capacity()) {
      tail_cache_ = tail_.load(std::memory_order_acquire);
      if (next - tail_cache_ > capacity()) return false;
    }
    slots_[head & mask_] = std::forward<U>(value);
    head_.store(next, std::memory_order_release);
    return true;
  }

  /// 소비자 전용. 비어있는 경우 false.
  bool tryPop(T& out) {
    const size_t tail = tail_.load(std::memory_order_relaxed);
    if (tail == head_cache_) {
      head_cache_ = head_.load(std::memory_order_acquire);
      if (tail == head_cache_) return false;
    }
    out = std::move(slots_[tail & mask_]);
    tail_.store(tail + 1, std::memory_order_release);
    return true;
  }

  /// 근사 크기 (모니터링 용도)
  size_t sizeApprox() const {
    const size_t h = head_.load(std::memory_order_acquire);
    const size_t t = tail_.load(std::memory_order_acquire);
    return h - t;
  }
  bool emptyApprox() const { return sizeApprox() == 0; }

 private:
  std::vector<T> slots_;
  size_t mask_ = 0;
  alignas(kCacheLine) std::atomic<size_t> head_{0};  // 생산자 쓰기
  alignas(kCacheLine) size_t tail_cache_ = 0;        // 생산자 로컬 캐시
  alignas(kCacheLine) std::atomic<size_t> tail_{0};  // 소비자 쓰기
  alignas(kCacheLine) size_t head_cache_ = 0;        // 소비자 로컬 캐시
};

/// 소비자 대기/기상 신호. notify() 는 lost-wakeup 없이 카운트를 누적한다.
/// spin_us > 0 이면 sleep 전 짧게 busy-poll 하여 wake-up 지연(수십 us)을 줄인다.
class Doorbell {
 public:
  void notify() {
    pending_.fetch_add(1, std::memory_order_release);
    if (waiters_.load(std::memory_order_acquire) > 0) {
      std::lock_guard<std::mutex> lk(m_);
      cv_.notify_all();
    }
  }

  /// 신호가 있으면 true (카운트 소모), 타임아웃이면 false
  template <typename Rep, typename Period>
  bool wait(std::chrono::duration<Rep, Period> timeout, int spin_us = 0) {
    if (consume()) return true;
    if (spin_us > 0) {
      const auto spin_end = std::chrono::steady_clock::now() + std::chrono::microseconds(spin_us);
      while (std::chrono::steady_clock::now() < spin_end) {
        if (consume()) return true;
#if defined(__x86_64__) || defined(__i386__)
        __builtin_ia32_pause();
#endif
      }
    }
    std::unique_lock<std::mutex> lk(m_);
    waiters_.fetch_add(1, std::memory_order_acq_rel);
    const bool ok = cv_.wait_for(lk, timeout, [this] { return consume(); });
    waiters_.fetch_sub(1, std::memory_order_acq_rel);
    return ok;
  }

 private:
  bool consume() {
    uint64_t p = pending_.load(std::memory_order_acquire);
    while (p > 0) {
      // 누적된 신호를 한 번에 모두 소모 (소비자는 깨어나면 큐를 전부 비운다)
      if (pending_.compare_exchange_weak(p, 0, std::memory_order_acq_rel)) return true;
    }
    return false;
  }

  std::atomic<uint64_t> pending_{0};
  std::atomic<int> waiters_{0};
  std::mutex m_;
  std::condition_variable cv_;
};

/// 단일 작성자 / 다중 독자용 SeqLock (작성자 대기 없음, 독자는 재시도).
/// T 는 trivially copyable 이어야 한다.
template <typename T>
class SeqLock {
  static_assert(std::is_trivially_copyable<T>::value, "SeqLock<T> requires trivially copyable T");

 public:
  void store(const T& v) {
    const uint64_t s = seq_.load(std::memory_order_relaxed);
    seq_.store(s + 1, std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_release);
    value_ = v;
    std::atomic_thread_fence(std::memory_order_release);
    seq_.store(s + 2, std::memory_order_release);
  }

  /// 한 번도 store 되지 않았으면 false
  bool load(T& out) const {
    for (;;) {
      const uint64_t s0 = seq_.load(std::memory_order_acquire);
      if (s0 & 1u) continue;
      std::atomic_thread_fence(std::memory_order_acquire);
      out = value_;
      std::atomic_thread_fence(std::memory_order_acquire);
      const uint64_t s1 = seq_.load(std::memory_order_acquire);
      if (s0 == s1) return s0 != 0;
    }
  }

 private:
  std::atomic<uint64_t> seq_{0};
  T value_{};
};

}  // namespace pva
