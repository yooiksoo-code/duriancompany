// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 파라미터 소스 추상화 → PipelineConfig 생성.
//  ROS2 노드(RosParamSource)와 단독 벤치마크 도구(YamlParamSource)가 동일한
//  config/vision_acquisition.yaml 과 동일한 기본값을 공유하도록 한다.
#pragma once

#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "pkg_vision_acquisition/acquisition_pipeline.hpp"

namespace YAML { class Node; }

namespace pva {

class ParamSource {
 public:
  virtual ~ParamSource() = default;
  virtual bool getBool(const std::string& name, bool def) = 0;
  virtual int64_t getInt(const std::string& name, int64_t def) = 0;
  virtual double getDouble(const std::string& name, double def) = 0;
  virtual std::string getString(const std::string& name, const std::string& def) = 0;
  virtual std::vector<int64_t> getIntArray(const std::string& name, const std::vector<int64_t>& def) = 0;
  virtual std::vector<double> getDoubleArray(const std::string& name, const std::vector<double>& def) = 0;
};

/// ROS2 파라미터 YAML 파일을 직접 읽는 소스 (node_name.ros__parameters 하위, 중첩 맵 = 점 표기)
class YamlParamSource : public ParamSource {
 public:
  YamlParamSource(const std::string& path, const std::string& node_name);
  ~YamlParamSource() override;
  bool getBool(const std::string& n, bool d) override;
  int64_t getInt(const std::string& n, int64_t d) override;
  double getDouble(const std::string& n, double d) override;
  std::string getString(const std::string& n, const std::string& d) override;
  std::vector<int64_t> getIntArray(const std::string& n, const std::vector<int64_t>& d) override;
  std::vector<double> getDoubleArray(const std::string& n, const std::vector<double>& d) override;
  /// 프로그램 인자 등으로 값 덮어쓰기 (점 표기 이름, 문자열 값)
  void set(const std::string& name, const std::string& value);
  /// 다른 파라미터 파일을 덮어씀 (ROS2 의 다중 params 파일 로드와 동일 의미)
  void overlay(const std::string& path, const std::string& node_name);

 private:
  std::unique_ptr<YAML::Node> lookup(const std::string& name) const;
  std::unique_ptr<YAML::Node> root_;
};

using PathResolver = std::function<std::string(const std::string&)>;

/// 파라미터 → PipelineConfig. 내부/외부 파라미터, Tag Bundle 파일도 로드한다.
bool buildPipelineConfig(ParamSource& p, const PathResolver& resolve, PipelineConfig& out, std::string& err);

}  // namespace pva
