// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 지연시간/주기 통계 (최근 N 샘플 슬라이딩 윈도우 + 누적 최대값). 외부 동기화 필요.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace pva {

struct LatencySummary {
  uint64_t count = 0;   ///< 누적 샘플 수
  double mean = 0.0;    ///< 윈도우 평균
  double stddev = 0.0;
  double p50 = 0.0;
  double p99 = 0.0;
  double max = 0.0;     ///< 윈도우 최대
  double max_all = 0.0; ///< 누적 최대
};

class LatencyStats {
 public:
  explicit LatencyStats(size_t window = 2048) : buf_(window, 0.0) {}

  void add(double v) {
    buf_[head_ % buf_.size()] = v;
    ++head_;
    max_all_ = std::max(max_all_, v);
  }

  LatencySummary summary() const {
    LatencySummary s;
    s.count = head_;
    s.max_all = max_all_;
    const size_t n = std::min<size_t>(head_, buf_.size());
    if (n == 0) return s;
    std::vector<double> v(buf_.begin(), buf_.begin() + static_cast<long>(n));
    double sum = 0, sq = 0;
    for (double x : v) { sum += x; sq += x * x; }
    s.mean = sum / n;
    s.stddev = std::sqrt(std::max(0.0, sq / n - s.mean * s.mean));
    std::sort(v.begin(), v.end());
    s.p50 = v[n / 2];
    s.p99 = v[std::min(n - 1, static_cast<size_t>(std::ceil(0.99 * n)) - 1)];
    s.max = v.back();
    return s;
  }

  void reset() { head_ = 0; max_all_ = 0.0; }

 private:
  std::vector<double> buf_;
  uint64_t head_ = 0;
  double max_all_ = 0.0;
};

/// 이벤트 발생률 [Hz] (지수이동평균)
class RateMeter {
 public:
  void tick(int64_t mono_ns) {
    if (last_ns_ > 0) {
      const double dt = (mono_ns - last_ns_) * 1e-9;
      if (dt > 0) rate_ = rate_ <= 0 ? 1.0 / dt : 0.95 * rate_ + 0.05 / dt;
    }
    last_ns_ = mono_ns;
  }
  double rate() const { return rate_; }

 private:
  int64_t last_ns_ = 0;
  double rate_ = 0.0;
};

}  // namespace pva
