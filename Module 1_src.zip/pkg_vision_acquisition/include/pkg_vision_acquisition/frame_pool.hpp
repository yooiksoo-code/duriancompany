// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 채널별 사전할당 프레임 풀.
//   acquire()  : 수집(grab) 스레드 전용  - free 링의 소비자
//   release()  : 워커 스레드 전용        - free 링의 생산자
// 두 링 모두 SPSC 조건을 만족하므로 전 구간 Lock-Free.
#pragma once

#include <cstdint>
#include <vector>

#include "pkg_vision_acquisition/spsc_ring_buffer.hpp"
#include "pkg_vision_acquisition/types.hpp"

namespace pva {

class FramePool {
 public:
  static constexpr uint32_t kInvalid = UINT32_MAX;

  FramePool(size_t num_buffers, int width, int height)
      : buffers_(num_buffers), free_(num_buffers + 1) {
    for (size_t i = 0; i < num_buffers; ++i) {
      buffers_[i].allocate(width, height);
      free_.tryPush(static_cast<uint32_t>(i));
    }
  }

  uint32_t acquire() {
    uint32_t idx = kInvalid;
    return free_.tryPop(idx) ? idx : kInvalid;
  }
  void release(uint32_t idx) {
    if (idx != kInvalid) free_.tryPush(idx);
  }

  FrameBuffer& at(uint32_t idx) { return buffers_[idx]; }
  const FrameBuffer& at(uint32_t idx) const { return buffers_[idx]; }
  size_t size() const { return buffers_.size(); }
  size_t freeApprox() const { return free_.sizeApprox(); }

 private:
  std::vector<FrameBuffer> buffers_;
  SpscRingBuffer<uint32_t> free_;
};

}  // namespace pva
