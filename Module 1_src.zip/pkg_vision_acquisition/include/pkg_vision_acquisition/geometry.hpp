// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// 기하 정의 및 설정 파일 입출력 (내부/외부 파라미터, Tag Bundle)
#pragma once

#include <array>
#include <map>
#include <set>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "pkg_vision_acquisition/types.hpp"

namespace pva {

/// 강체 변환 T_a_b : p_a = R * p_b + t
struct Pose3 {
  cv::Matx33d R = cv::Matx33d::eye();
  cv::Vec3d t{0, 0, 0};

  cv::Vec3d operator*(const cv::Vec3d& p) const { return R * p + t; }
  Pose3 operator*(const Pose3& o) const { return Pose3{R * o.R, R * o.t + t}; }
  Pose3 inverse() const {
    const cv::Matx33d Rt = R.t();
    return Pose3{Rt, -(Rt * t)};
  }
};

cv::Matx33d rotationFromRpyDeg(double roll, double pitch, double yaw);
cv::Matx33d rotationFromQuaternion(double qw, double qx, double qy, double qz);

/// Tag Bundle 내 단일 태그 정의 (잠수함 선체 body 좌표계 기준)
struct TagDef {
  int id = -1;
  double size = 0.1;  ///< 검정 외곽 테두리 한 변 길이 [m] (AprilTag tag size 정의)
  Pose3 T_body_tag;
};

struct TagBundle {
  std::string name = "submarine_hull";
  std::vector<TagDef> tags;

  std::set<int> ids() const {
    std::set<int> s;
    for (const auto& t : tags) s.insert(t.id);
    return s;
  }
  /// 번들 전체 코너의 body 좌표 (동적 ROI 투영용)
  std::vector<cv::Point3d> allCornersBody() const;
};

/// 태그 좌표계 기준 코너 4점. AprilTag 3 의 det->p[i] 순서와 동일:
///   (-s/2, +s/2), (+s/2, +s/2), (+s/2, -s/2), (-s/2, -s/2)
/// 태그 좌표계: x 오른쪽, y 아래, z 태그 안쪽 (apriltag_pose 규약)
std::array<cv::Point3d, 4> tagCornersInTagFrame(double size);

/// 내부 파라미터 로드. 지원 포맷:
///  (1) ROS camera_calibration 포맷 (image_width, camera_matrix.data, distortion_coefficients.data ...)
///  (2) 간이 포맷 (width, height, K: [9], D: [N])
bool loadIntrinsics(const std::string& path, CameraIntrinsics& out, std::string& err);
bool saveIntrinsicsRos(const std::string& path, const CameraIntrinsics& in, double rms_error = -1.0);

/// 외부 파라미터 로드 (T_world_cam). 반환 map key = camera_id (1~4)
bool loadExtrinsics(const std::string& path, std::map<int, Pose3>& out, std::string& world_frame,
                    std::string& err);

bool loadTagBundle(const std::string& path, TagBundle& out, std::string& err);

}  // namespace pva
