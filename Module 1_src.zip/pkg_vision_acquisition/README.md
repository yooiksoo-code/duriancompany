# pkg_vision_acquisition — [모듈 1] 3D 위치 데이터 수집 SW 모듈

손원일급 잠수함 자동 INHAUL 시스템 구축을 위한 3D 위치 데이터 수집 및 분석 SW 개발
주식회사 두리안컴퍼니 · 연구책임자 박완선 · SW총괄 유익수
설계 근거: 연구노트 「SW 개발 설계계획서 — 3D 위치 데이터 수집 SW 모듈」(2026.10.20)

4대의 글로벌셔터 GigE 카메라를 시간 동기 수집하고, LUT 왜곡보정 → AprilTag 3(tag36h11) 서브픽셀 코너 검출 →
반사/오검출 필터링을 거쳐 `inhaul_msgs/msg/TagDetectionArray` 로 [모듈 2] `pose_estimation_node` 에 전달합니다.

---

## 1. 구성

```
inhaul_ws/src/
├── inhaul_msgs/                       # 공용 메시지 (설계서 5장 ② 그대로)
│   └── msg/TagDetection.msg, TagDetectionArray.msg
└── pkg_vision_acquisition/
    ├── include/pkg_vision_acquisition/
    │   ├── acquisition_pipeline.hpp   # 오케스트레이터 (수집/워커/집계 스레드)
    │   ├── camera_driver.hpp          # 드라이버 추상화 (aravis / hikmvs / sim)
    │   ├── image_preprocessor.hpp     # [세부 2] LUT 왜곡보정 + ROI 부분 remap + CLAHE
    │   ├── apriltag_detector_core.hpp # [세부 3] AprilTag 3 서브픽셀 검출
    │   ├── outlier_rejection_filter.hpp # [세부 4] 신뢰도/ID/기하/거울상/중복 필터
    │   ├── dynamic_roi.hpp            # 동적 ROI (EKF 자세 투영 / 자기추적 / Full Frame)
    │   ├── spsc_ring_buffer.hpp       # Lock-Free SPSC 링, Doorbell, SeqLock
    │   ├── frame_pool.hpp             # 사전할당 프레임 풀 (루프 내 동적할당 없음)
    │   ├── config_builder.hpp         # ROS 파라미터 / YAML → PipelineConfig (단일 기본값)
    │   └── vision_acquisition_node.hpp# ROS2 LifecycleNode
    ├── src/core, src/drivers, src/ros
    ├── config/                        # 파라미터, 내부/외부 파라미터, Tag Bundle, DDS
    ├── launch/vision_acquisition.launch.py
    ├── systemd/vision-acquisition.service
    ├── scripts/setup_gige_network.sh, check_ptp_sync.sh
    ├── tools/vision_acq_bench.cpp     # KPI 계측 도구 (설계서 8장)
    ├── tools/intrinsic_calibrator.cpp # 체커보드 내부 파라미터 보정 (2단계 산출물)
    ├── test/                          # gtest 23건
    └── docs/test_reports/             # vision_acq_bench 보고서 (1ch/4ch/지터 1,000프레임)
```

## 2. 처리 구조 (설계서 4장 구현)

```
 Cam1..4 (HW 트리거 + PTP)
   │  grab 스레드 ×4  (MultiCamSyncGrabber: SDK 수신, seq 누락/패킷손실 계수, 단절 감지·재연결)
   ▼  SPSC Lock-Free 링 (프레임 인덱스) + 사전할당 FramePool
 워커 스레드 ×4 (채널 독립)
   │  DynamicRoi → ImagePreprocessor(ROI 영역 LUT만 remap) → AprilTagDetectorCore → OutlierRejectionFilter
   │  ROI 탐색 결과 0개 → 같은 프레임에서 즉시 Full Frame 재탐색
   ▼  SPSC 링 (ChannelResult)
 집계 스레드 ×1
   │  노출 타임스탬프로 동기 주기 매칭 (window_us) → 전 채널 도착 또는 max_wait_ms 경과 시 발행
   │  active_camera_mask = 이번 주기 정상 수신 채널, header.stamp = 기여 채널 PTP 노출시각 평균
   ▼
 /vision/tag_detections (inhaul_msgs/TagDetectionArray)
```

- 데이터 경로는 전부 SPSC 원자 인덱스(뮤텍스·할당 없음). 워커는 밀린 프레임을 버리고 **최신 프레임만** 처리하여 지연 누적을 차단합니다.
- 한 채널이 느리거나 끊겨도 다른 채널은 독립 진행하며, 집계는 `max_wait_ms` 로 대기 상한을 보장합니다.

### 좌표 계약 (하류 6DoF 모듈과 반드시 일치)
- `corners`/`center` 는 **왜곡 보정된 이상적 핀홀 좌표계, 카메라 행렬 = 해당 채널 `K` 그대로, 왜곡 D = 0**. → `solvePnP(obj, corners, K, noArray())`.
- 픽셀 중심 규약은 OpenCV(정수 좌표 = 픽셀 중심). AprilTag 3 원출력(픽셀 중심 = i+0.5)을 −0.5 보정했습니다.
- 코너 순서: AprilTag 3 표준, 태그 좌표 (−s/2,+s/2) → (+s/2,+s/2) → (+s/2,−s/2) → (−s/2,−s/2) (`tagCornersInTagFrame`).

## 3. 빌드

```bash
# 의존성 (Ubuntu 22.04 + ROS2 Humble)
sudo apt install ros-humble-apriltag ros-humble-rmw-cyclonedds-cpp libopencv-dev libyaml-cpp-dev libaravis-dev
cd inhaul_ws && colcon build --merge-install --cmake-args -DCMAKE_BUILD_TYPE=Release -DPVA_NATIVE_ARCH=ON
colcon test --packages-select pkg_vision_acquisition && colcon test-result --verbose

# Hikrobot MVS 드라이버 포함 시
colcon build --cmake-args -DWITH_HIK_MVS=ON -DHIK_MVS_ROOT=/opt/MVS [-DHIK_MVS_SDK_V4=ON]

# ROS 없이 코어/시험/벤치마크만 (알고리즘 개발·CI)
cmake -S src/pkg_vision_acquisition -B build_core -DPVA_CORE_ONLY=ON && cmake --build build_core -j && ctest --test-dir build_core
```

## 4. 실행

```bash
# 시뮬레이터 (카메라 없이 전체 파이프라인 + ROS 인터페이스 검증)
ros2 launch pkg_vision_acquisition vision_acquisition.launch.py sim:=true
# 실장비 (config/vision_acquisition.yaml 의 chN.device_id 에 시리얼/IP 기입)
ros2 launch pkg_vision_acquisition vision_acquisition.launch.py
# 6DoF 모듈과 동일 프로세스 (intra-process zero-copy, 라이프사이클은 외부에서 전이)
ros2 launch pkg_vision_acquisition vision_acquisition.launch.py composed:=true

ros2 topic hz /vision/tag_detections       # KPI: 30~60 Hz
ros2 topic echo /hmi/vision_alerts         # WARN_CAM_DROPOUT 등
ros2 lifecycle set /vision_acquisition_node deactivate|activate
```

운영 배포: `systemd/vision-acquisition.service` (Type=notify, `Restart=always`, `RestartSec=100ms`, `WatchdogSec=1s`).
설치 전 `sudo scripts/setup_gige_network.sh <카메라 NIC×4>` 와 `scripts/check_ptp_sync.sh` 로 네트워크·PTP를 점검합니다.

## 5. 인터페이스

| 구분 | 토픽 | 타입 | 비고 |
|---|---|---|---|
| 출력 | `/vision/tag_detections` | `inhaul_msgs/TagDetectionArray` | reliable, keep_last 5 |
| 출력(선택) | `/camera_n/detected_tags` | 동일 | `publish_per_camera_topics: true` |
| 출력 | `/hmi/vision_alerts` | `std_msgs/String` | `코드\|ch=N\|메시지` |
| 출력 | `/diagnostics` | `diagnostic_msgs/DiagnosticArray` | 파이프라인 + 채널별 fps/지연/손실/ROI |
| 입력(선택) | `/sub_pose_filtered` | `nav_msgs/Odometry` | EKF 자세 → 동적 ROI 투영 (world frame = `cam_extrinsics.yaml` 의 `world_frame`) |
| 입력 | `config/cam_intrinsics_ch1~4.yaml` | ROS camera_info YAML | `intrinsic_calibrator` 출력 그대로 사용 |

이벤트 코드: `WARN_CAM_DROPOUT`, `INFO_CAM_RECOVERED`, `WARN_TOTAL_OCCLUSION`, `WARN_SYNC_VIOLATION`, `WARN_PACKET_LOSS`.

## 6. 예외 처리 (설계서 6장)

| 요구 | 구현 |
|---|---|
| (가) 카메라 1~2대 단절 시 노드 정지 없이 나머지 발행 | 채널별 독립 스레드. 단절 채널은 집계 기대 마스크에서 즉시 제외, `active_camera_mask` 갱신, `WARN_CAM_DROPOUT` 발행, `reconnect_interval_ms` 주기 재연결 후 `INFO_CAM_RECOVERED` |
| (나) 전면 차폐 시 빈 배열 + 정확한 타임스탬프 즉시 발행 | 태그 0개여도 카메라 수신이 정상이면 매 주기 `detections=[]` 를 PTP 노출시각으로 발행 → EKF 가 대기 없이 Dead-Reckoning 전환. 연속 N주기 시 `WARN_TOTAL_OCCLUSION` |
| (다) 500ms 이내 자가 복구 | 프로세스 비정상 종료 → systemd `RestartSec=100ms`. 집계 루프 hang → watchdog 통지 중단 → `WatchdogSec` 만료 후 재기동. 라이프사이클 `on_error` → FAILURE → 종료코드 4 → 재기동 |

## 7. 시험 결과 (2026-10-31, 개발 컨테이너: Xeon 2.1GHz **2 vCPU**, 실시간 커널 아님)

### 정밀도 (합성 영상, 정답 대비)
| 항목 | 결과 |
|---|---|
| AprilTag 원출력 픽셀중심 편향 (보정 전) | (+0.507, +0.499) px → 보정 후 단일태그 RMS 0.0097 px |
| 무작위 자세 30개 코너 RMS (decimate 1 / 2) | 0.029 / 0.037 px, 검출 30/30 |
| 왜곡 렌즈: remap 모드 / corners 모드 / 보정 미적용 | 0.040 / 0.059 / **4.01** px |
| 정지 모형 1,000프레임 (4채널) 코너 지터 σ | mean 0.0085 / max 0.0109 px |
| 정지 모형 1,000프레임 재투영 오차 (KPI ≤ 0.25 px) | **mean 0.051 / max 0.100 px — PASS** |

### 실시간성 / 통신
| 항목 | 결과 |
|---|---|
| 1채널 60fps (경합 없음) 처리지연 | **avg 2.66 / p50 2.06 ms (KPI ≤ 4 ms PASS)**, p99 11.3, max 16.6 ms |
| 4채널 60fps 20초 (2코어에 8스레드 경합) | 발행 61.8 fps, 프레임 손실 0, ROI 사용 93%, 지연 avg 10.6 ms (경합 지배) |
| 노출 동기 (시뮬 지터 σ20us 주입) | 기준 대비 max ±66.9 us, 위반 0 (KPI ±100 us) |
| ROS2 노드 (sim, 30fps) | `ros2 topic hz` 30.0 Hz, lifecycle 전이, CH3 단절 2초 주입 → 경고·재연결·복구 확인 |
| 내부 파라미터 보정기 (합성 체커보드 16장) | fx/fy 오차 < 0.005 px, cx 0.22 px, RMS 0.020 px |

### 개발 중 발견·반영한 사항
1. **AprilTag 3 좌표 규약 0.5px 편향** — 미보정 시 KPI(0.25px)의 2배 오차. `pixel_center_offset=-0.5` 적용, 시험으로 고정.
2. **`min_white_black_diff` 기본값(5)의 성능 함정** — 센서 노이즈(±2DN)만으로 가짜 클러스터가 폭증. 20 으로 상향 시 1.5MP 전체 검출 30.5 → 3.4 ms(9배), 검출·정밀도 동일. 저조도 환경은 10~15 권장.
3. **동적 ROI 마진** — 선체 길이방향으로 늘어선 번들은 가로 띠 형태라 등방 마진 시 ROI 가 60% 상한을 넘어 중앙 카메라에서 ROI 0%. 축별 마진으로 수정 후 93%.
4. **코너 와인딩 부호** — AprilTag 코너는 영상 좌표계에서 외적 < 0. 거울 반사상 판별 기준으로 실측 고정.
5. **보정기 k3 과적합** — 저왜곡 렌즈에서 k2/k3 상관. 기본 k3 고정(`--k3` 로 해제).

## 8. 한계 및 실장비 검증 필요 사항 (정직 고지)

- **실시간 KPI(≤4 ms 평균, <10 ms 최대)는 목표 하드웨어에서 재측정 필요.** 본 수치는 2 vCPU 컨테이너 결과로, 4채널 동시 지연은 CPU 경합이 지배적입니다. 목표 엣지PC(i7-13700K, 채널별 전용 코어 + Preempt-RT + SCHED_FIFO)에서 `vision_acq_bench --duration 3600` 으로 확인하십시오. 꼬리지연(p99)은 주로 `full_frame_every_n` 주기 전체탐색에서 발생하므로, 필요 시 `detector.nthreads: 2~3` 또는 `roi.full_frame_every_n` 상향으로 조정합니다.
- **정밀도 수치는 합성 영상 기준**(가우시안 노이즈, 이상적 초점)으로 낙관적입니다. 실제 모션블러·초점·수면 반사 조건의 지터는 5단계 테스트베드 시험으로 확정해야 합니다.
- **Hikrobot MVS 드라이버는 SDK 미설치 환경이라 컴파일 검증되지 않았습니다.** Aravis 드라이버는 libaravis 0.8.30 으로 컴파일 검증, 실카메라 미시험입니다. GenICam 노드명(PtpEnable/GevIEEE1588, TriggerSelector 값)은 모델별로 확인하십시오.
- **Zero-Copy**: `TagDetectionArray` 는 가변 길이 배열이라 CycloneDDS SHM(iceoryx) loan 대상이 아닙니다. 6DoF 모듈과의 무복사 전달은 `composed:=true` (intra-process) 로 구현했습니다. 메시지 크기는 수 KB 수준이라 DDS 경유도 지연 영향이 작습니다.
- `config/cam_intrinsics_ch*.yaml`, `cam_extrinsics.yaml` 은 **설계 초기값**입니다. 2단계 보정 결과로 교체해야 합니다.
- 하드웨어 트리거 모드에서 PTP 미지원 카메라는 장치 타임스탬프가 공통 시계가 아니므로 `timestamp_source: host` 와 `sync.window_us` 확대가 필요합니다.

## 9. 설계서 일정 대비 진행

| 단계 | 산출물 | 상태 |
|---|---|---|
| 1단계 (M1~M2) | 카메라 동기 수집 모듈, 네트워크 설정 명세서 | 수집기/드라이버(Aravis·MVS)·`setup_gige_network.sh`·`check_ptp_sync.sh` 구현. **실장비 연동 시험 필요** |
| 2단계 (M3~M4) | vision_acquisition_node 초안, 내부 파라미터 YAML | 노드·LUT 보정·멀티스레드 검출 완료, `intrinsic_calibrator` 제공. **실카메라 보정 필요** |
| 3단계 (M5~M6) | 노이즈 필터링, 동적 ROI, 단위시험 결과서 | 필터·ROI·EKF 피드백 구현, 단위시험 23건 통과 |
| 4단계 (M7~M9) | 통합 연동, 지연시간 프로파일 | 컴포넌트/intra-process 경로, `vision_acq_bench` 프로파일러 제공. **목표 HW 프로파일 필요** |
| 5단계 (M10~M12) | 테스트베드 실증 | 미착수 |
