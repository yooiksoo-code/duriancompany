cmake_minimum_required(VERSION 3.16)
project(pkg_vision_acquisition VERSION 0.1.0 LANGUAGES C CXX)

# ─────────────────────────────────────────────────────────────────────────────
#  [모듈 1] 3D 위치수집 SW Module (vision_acquisition_node)
#   - PVA_CORE_ONLY=ON : ROS 비의존 코어 + 단위시험 + 벤치마크만 빌드 (알고리즘 개발/CI 용)
#   - 기본            : ament/ROS2 Humble 패키지 빌드 (colcon)
# ─────────────────────────────────────────────────────────────────────────────
option(PVA_CORE_ONLY "Build ROS-independent core library only" OFF)
option(WITH_ARAVIS "Build Aravis (GenICam) GigE driver if available" ON)
option(WITH_HIK_MVS "Build Hikrobot MVS SDK driver" OFF)
option(HIK_MVS_SDK_V4 "MVS SDK v4.x (requires MV_CC_Initialize)" OFF)
set(HIK_MVS_ROOT "/opt/MVS" CACHE PATH "Hikrobot MVS SDK root")
option(PVA_NATIVE_ARCH "Compile with -march=native (target edge PC only)" OFF)
option(PVA_BUILD_TESTS "Build unit tests" ON)

if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
add_compile_options(-Wall -Wextra -Wno-unused-parameter)
if(CMAKE_BUILD_TYPE STREQUAL "Release")
  add_compile_options(-O3)
  if(PVA_NATIVE_ARCH)
    add_compile_options(-march=native)
  endif()
endif()

find_package(Threads REQUIRED)
find_package(OpenCV 4 REQUIRED COMPONENTS core imgproc calib3d)
find_package(apriltag REQUIRED)
find_package(yaml-cpp REQUIRED)
if(TARGET yaml-cpp::yaml-cpp)
  set(PVA_YAML_TARGET yaml-cpp::yaml-cpp)
else()
  set(PVA_YAML_TARGET yaml-cpp)
endif()

# ── 코어 라이브러리 (ROS 비의존)
set(PVA_CORE_SOURCES
  src/core/geometry.cpp
  src/core/image_preprocessor.cpp
  src/core/apriltag_detector_core.cpp
  src/core/outlier_rejection_filter.cpp
  src/core/dynamic_roi.cpp
  src/core/acquisition_pipeline.cpp
  src/core/config_builder.cpp
  src/drivers/camera_factory.cpp
  src/drivers/sim_camera.cpp
)
add_library(pva_core SHARED ${PVA_CORE_SOURCES})
target_include_directories(pva_core PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)
target_link_libraries(pva_core PUBLIC ${OpenCV_LIBS} apriltag::apriltag ${PVA_YAML_TARGET} Threads::Threads)

if(WITH_ARAVIS)
  find_package(PkgConfig)
  if(PkgConfig_FOUND)
    pkg_check_modules(ARAVIS IMPORTED_TARGET aravis-0.8)
  endif()
  if(ARAVIS_FOUND)
    message(STATUS "pkg_vision_acquisition: Aravis ${ARAVIS_VERSION} 드라이버 포함")
    target_sources(pva_core PRIVATE src/drivers/aravis_camera.cpp)
    target_compile_definitions(pva_core PRIVATE HAVE_ARAVIS)
    target_link_libraries(pva_core PRIVATE PkgConfig::ARAVIS)
  else()
    message(WARNING "pkg_vision_acquisition: aravis-0.8 미발견 → aravis 드라이버 제외")
  endif()
endif()

if(WITH_HIK_MVS)
  find_path(MVS_INCLUDE_DIR MvCameraControl.h PATHS ${HIK_MVS_ROOT}/include REQUIRED)
  find_library(MVS_LIBRARY MvCameraControl PATHS ${HIK_MVS_ROOT}/lib/64 ${HIK_MVS_ROOT}/lib/aarch64 REQUIRED)
  message(STATUS "pkg_vision_acquisition: Hikrobot MVS 드라이버 포함 (${MVS_LIBRARY})")
  target_sources(pva_core PRIVATE src/drivers/hik_mvs_camera.cpp)
  target_compile_definitions(pva_core PRIVATE HAVE_HIK_MVS $<$<BOOL:${HIK_MVS_SDK_V4}>:HIK_MVS_SDK_V4>)
  target_include_directories(pva_core PRIVATE ${MVS_INCLUDE_DIR})
  target_link_libraries(pva_core PRIVATE ${MVS_LIBRARY})
endif()

# ── 도구 (ROS 비의존)
add_executable(vision_acq_bench tools/vision_acq_bench.cpp)
target_link_libraries(vision_acq_bench pva_core)
add_executable(intrinsic_calibrator tools/intrinsic_calibrator.cpp)
target_link_libraries(intrinsic_calibrator pva_core ${OpenCV_LIBS})
find_package(OpenCV 4 QUIET COMPONENTS imgcodecs)
if(OpenCV_imgcodecs_FOUND OR TARGET opencv_imgcodecs)
  target_link_libraries(intrinsic_calibrator opencv_imgcodecs)
  target_compile_definitions(intrinsic_calibrator PRIVATE HAVE_IMGCODECS)
endif()

if(PVA_CORE_ONLY)
  # ───────────── ROS 비의존 빌드 ─────────────
  if(PVA_BUILD_TESTS)
    enable_testing()
    find_package(GTest REQUIRED)
    file(GLOB PVA_TESTS test/test_*.cpp)
    foreach(t ${PVA_TESTS})
      get_filename_component(n ${t} NAME_WE)
      add_executable(${n} ${t})
      target_link_libraries(${n} pva_core GTest::gtest_main)
      target_compile_definitions(${n} PRIVATE PVA_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
      add_test(NAME ${n} COMMAND ${n})
    endforeach()
  endif()
  return()
endif()

# ───────────── ROS2 (ament) 빌드 ─────────────
find_package(ament_cmake REQUIRED)
find_package(ament_index_cpp REQUIRED)
find_package(rclcpp REQUIRED)
find_package(rclcpp_lifecycle REQUIRED)
find_package(rclcpp_components REQUIRED)
find_package(lifecycle_msgs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(diagnostic_msgs REQUIRED)
find_package(inhaul_msgs REQUIRED)

add_library(vision_acquisition_component SHARED
  src/ros/vision_acquisition_node.cpp
  src/ros/sd_notify.cpp)
target_include_directories(vision_acquisition_component PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)
target_link_libraries(vision_acquisition_component pva_core)
ament_target_dependencies(vision_acquisition_component
  rclcpp rclcpp_lifecycle rclcpp_components lifecycle_msgs ament_index_cpp
  std_msgs nav_msgs geometry_msgs diagnostic_msgs inhaul_msgs)
rclcpp_components_register_node(vision_acquisition_component
  PLUGIN "pva::VisionAcquisitionNode"
  EXECUTABLE vision_acquisition_component_node)

# 단독 실행 파일 (systemd 서비스용, 자동 configure/activate + watchdog)
add_executable(vision_acquisition_node src/ros/main.cpp)
target_link_libraries(vision_acquisition_node vision_acquisition_component)
ament_target_dependencies(vision_acquisition_node rclcpp rclcpp_lifecycle)

install(TARGETS pva_core vision_acquisition_component
  EXPORT export_${PROJECT_NAME}
  LIBRARY DESTINATION lib ARCHIVE DESTINATION lib RUNTIME DESTINATION bin)
install(TARGETS vision_acquisition_node vision_acq_bench intrinsic_calibrator
  RUNTIME DESTINATION lib/${PROJECT_NAME})
install(DIRECTORY include/ DESTINATION include)
install(DIRECTORY config launch systemd DESTINATION share/${PROJECT_NAME})
install(PROGRAMS scripts/setup_gige_network.sh scripts/check_ptp_sync.sh DESTINATION lib/${PROJECT_NAME})

if(BUILD_TESTING AND PVA_BUILD_TESTS)
  find_package(ament_cmake_gtest REQUIRED)
  file(GLOB PVA_TESTS test/test_*.cpp)
  foreach(t ${PVA_TESTS})
    get_filename_component(n ${t} NAME_WE)
    ament_add_gtest(${n} ${t} TIMEOUT 300)
    target_link_libraries(${n} pva_core)
    target_compile_definitions(${n} PRIVATE PVA_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
  endforeach()
endif()

ament_export_include_directories(include)
ament_export_libraries(pva_core)
ament_export_targets(export_${PROJECT_NAME} HAS_LIBRARY_TARGET)
ament_export_dependencies(OpenCV apriltag yaml-cpp)
ament_package()
