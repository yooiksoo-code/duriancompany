#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  GigE Vision 카메라 전용 NIC 튜닝 (인텔 쿼드포트 GigE: 카메라 1대 = 포트 1개)
#   - Jumbo Frame (MTU 9000)          : camera.packet_size 8192 와 짝
#   - RX 링 버퍼 최대화, 인터럽트 병합 최소화 : 버스트 수신 시 패킷 드롭 방지
#   - 소켓 수신 버퍼 상향 (rmem_max)     : Aravis/MVS 스트림 소켓
#   - Reverse-path filter 완화          : 카메라 서브넷 다중 NIC 환경
#   - IRQ 를 수집 스레드 CPU 근처로 고정  (선택)
#  사용: sudo ./setup_gige_network.sh enp3s0f0 enp3s0f1 enp3s0f2 enp3s0f3
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "root 권한 필요 (sudo)"; exit 1; }
[[ $# -ge 1 ]] || { echo "usage: $0 <cam_nic1> [cam_nic2 ...]"; exit 1; }

MTU=${MTU:-9000}
RMEM=${RMEM:-67108864}   # 64MB

sysctl -qw net.core.rmem_max=$RMEM
sysctl -qw net.core.rmem_default=$((RMEM / 2))
sysctl -qw net.core.netdev_max_backlog=10000
sysctl -qw net.ipv4.conf.all.rp_filter=2

for IF in "$@"; do
  echo "== $IF"
  ip link set dev "$IF" mtu "$MTU"
  # RX 링 최대치
  MAXRX=$(ethtool -g "$IF" 2>/dev/null | awk '/Pre-set maximums/{f=1} f&&/^RX:/{print $2; exit}')
  [[ -n "${MAXRX:-}" ]] && ethtool -G "$IF" rx "$MAXRX" || true
  # 인터럽트 병합: 지연 최소화 (프레임 수신 완료 시점 지터 감소)
  ethtool -C "$IF" adaptive-rx off rx-usecs 0 rx-frames 1 2>/dev/null || true
  # 흐름 제어 해제 (카메라→호스트 단방향 스트림)
  ethtool -A "$IF" rx off tx off 2>/dev/null || true
  ip -d link show "$IF" | grep -o "mtu [0-9]*"
done

cat <<'MSG'
완료. 영구 적용은 netplan(mtu: 9000) 및 /etc/sysctl.d/90-gige.conf 에 동일 값 기록 권장.
카메라 측: 각 카메라 IP 를 NIC 별 서브넷(예: 192.168.1x.0/24)으로 분리하고
           GevSCPSPacketSize=8192 (vision_acquisition.yaml camera.packet_size) 확인.
검증: arv-tool-0.8 -n <cam> control GevSCPSPacketSize / 장시간 bench 후 seq 누락 0 확인.
MSG
