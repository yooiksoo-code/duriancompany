#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  IEEE 1588 PTP 동기 상태 점검
#   구성(권장): 엣지PC NIC(하드웨어 타임스탬프 지원) = Grandmaster
#     sudo ptp4l -i <ptp_nic> -m -H --masterOnly 1     # 카메라 4대의 PTP 마스터
#     sudo phc2sys -s <ptp_nic> -c CLOCK_REALTIME -w -m # NIC PHC → 시스템시계 (ROS stamp 기준)
#   카메라: PtpEnable/GevIEEE1588=true → 상태 Slave 확인
#  사용: ./check_ptp_sync.sh <ptp_nic> [aravis_camera_name ...]
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
NIC=${1:?"usage: $0 <ptp_nic> [camera ...]"}; shift || true
echo "== NIC 하드웨어 타임스탬프 지원"
ethtool -T "$NIC" | grep -E "hardware-transmit|hardware-receive|PTP Hardware Clock" || echo "  (ethtool -T 실패)"
echo "== ptp4l / phc2sys 프로세스"
pgrep -a ptp4l || echo "  ptp4l 미실행"
pgrep -a phc2sys || echo "  phc2sys 미실행"
if command -v pmc >/dev/null; then
  echo "== PTP 포트/오프셋 (pmc)"
  pmc -u -b 0 'GET CURRENT_DATA_SET' 2>/dev/null | grep -E "offsetFromMaster|meanPathDelay" || true
  pmc -u -b 0 'GET PORT_DATA_SET' 2>/dev/null | grep -E "portState" || true
fi
for CAM in "$@"; do
  echo "== 카메라 $CAM"
  for F in PtpStatus GevIEEE1588Status PtpEnable GevIEEE1588; do
    arv-tool-0.8 -n "$CAM" control "$F" 2>/dev/null && break
  done
done
echo "판정 기준: 각 카메라 Slave 상태, 마스터 offset |x| < 1us 수렴, vision_acq_bench 노출편차 max < ±100us"
