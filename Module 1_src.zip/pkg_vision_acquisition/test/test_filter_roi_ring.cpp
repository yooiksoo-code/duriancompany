// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
// [세부모듈 4] OutlierRejectionFilter / 동적 ROI / Lock-Free 링 버퍼 단위시험
#include <gtest/gtest.h>

#include <atomic>
#include <thread>

#include "pkg_vision_acquisition/dynamic_roi.hpp"
#include "pkg_vision_acquisition/frame_pool.hpp"
#include "pkg_vision_acquisition/outlier_rejection_filter.hpp"
#include "pkg_vision_acquisition/spsc_ring_buffer.hpp"
#include "test_common.hpp"

using namespace pva;

// ───────────────────────── OutlierRejectionFilter ─────────────────────────
namespace {
Detection square(int id, float cx, float cy, float s, float margin = 80.f, int hamming = 0) {
  Detection d;
  d.tag_id = id;
  d.decision_margin = margin;
  d.hamming = static_cast<uint8_t>(hamming);
  // AprilTag 정상 와인딩 (이미지 좌표 외적 < 0): (-1,1)->(1,1)->(1,-1)->(-1,-1) , y 아래
  d.corners = {cv::Point2f(cx - s, cy + s), cv::Point2f(cx + s, cy + s), cv::Point2f(cx + s, cy - s),
               cv::Point2f(cx - s, cy - s)};
  d.center = {cx, cy};
  return d;
}
FilterConfig defaultFilter() {
  FilterConfig c;
  c.whitelist = {0, 1, 2, 3, 4, 5, 6, 7};
  return c;
}
}  // namespace

TEST(Filter, PassesValidDetection) {
  OutlierRejectionFilter f(defaultFilter());
  std::vector<Detection> d{square(1, 500, 400, 30)};
  EXPECT_EQ(f.check(d[0]), OutlierRejectionFilter::Reason::kPass);
  EXPECT_EQ(f.apply(d), 0u);
  EXPECT_EQ(d.size(), 1u);
}

TEST(Filter, RejectsLowMarginHammingAndUnknownId) {
  OutlierRejectionFilter f(defaultFilter());
  std::vector<Detection> d{square(1, 500, 400, 30, 34.9f), square(2, 600, 400, 30, 80.f, 2), square(99, 700, 400, 30),
                           square(3, 800, 400, 30)};
  EXPECT_EQ(f.apply(d), 3u);
  ASSERT_EQ(d.size(), 1u);
  EXPECT_EQ(d[0].tag_id, 3);
  EXPECT_EQ(f.stats().low_margin, 1u);
  EXPECT_EQ(f.stats().high_hamming, 1u);
  EXPECT_EQ(f.stats().not_whitelisted, 1u);
}

TEST(Filter, RejectsBadGeometryAndMirror) {
  OutlierRejectionFilter f(defaultFilter());
  Detection tiny = square(1, 100, 100, 3);           // 6px 변
  Detection skew = square(2, 300, 300, 30);
  skew.corners[1].x += 200;                           // 변 길이 비 과대
  Detection mirror = square(3, 500, 500, 30);
  std::swap(mirror.corners[1], mirror.corners[3]);    // 와인딩 반전 (거울상)
  Detection concave = square(4, 700, 500, 30);
  concave.corners[2] = {690, 510};                    // 대각선 안쪽으로 함몰 → 비볼록
  EXPECT_EQ(f.check(tiny), OutlierRejectionFilter::Reason::kBadGeometry);
  EXPECT_EQ(f.check(skew), OutlierRejectionFilter::Reason::kBadGeometry);
  EXPECT_EQ(f.check(mirror), OutlierRejectionFilter::Reason::kBadGeometry);
  EXPECT_EQ(f.check(concave), OutlierRejectionFilter::Reason::kBadGeometry);
}

TEST(Filter, KeepsBestOfDuplicateIds) {
  OutlierRejectionFilter f(defaultFilter());
  std::vector<Detection> d{square(5, 500, 400, 30, 60.f), square(5, 500, 700, 30, 90.f), square(6, 100, 100, 30)};
  f.apply(d);
  ASSERT_EQ(d.size(), 2u);
  for (const auto& x : d) {
    if (x.tag_id == 5) {
      EXPECT_FLOAT_EQ(x.decision_margin, 90.f);
    }
  }
  EXPECT_EQ(f.stats().duplicate, 1u);
}

// ───────────────────────── DynamicRoi ─────────────────────────
namespace {
struct RoiFixture {
  CameraIntrinsics intr;
  Pose3 T_world_cam;
  TagBundle bundle;
  RoiFixture() {
    auto sc = pva_test::makeScene(false);
    intr = sc.intrinsics;
    T_world_cam = sc.T_world_cam;
    bundle.tags = {pva_test::makeTag(0, -0.2, 0.05), pva_test::makeTag(1, 0.2, -0.05)};
  }
  PoseSnapshot pose(double x, int64_t stamp) const {
    PoseSnapshot p;
    p.stamp_ns = stamp;
    p.t_world_body[0] = x;
    p.t_world_body[2] = 0.25;
    return p;
  }
};
}  // namespace

TEST(DynamicRoi, PoseFeedbackRoiContainsAllProjectedCorners) {
  RoiFixture fx;
  RoiConfig cfg;
  cfg.full_frame_every_n = 0;
  DynamicRoi roi(cfg, fx.intr, fx.T_world_cam, fx.bundle);
  const int64_t t = 1'000'000'000;
  RoiSource src;
  const cv::Rect r = roi.compute(t, nullptr, &src);
  EXPECT_EQ(r.area(), 0);  // 정보 없음 → Full Frame
  auto p = fx.pose(0.1, t);
  const cv::Rect r2 = roi.compute(t, &p, &src);
  ASSERT_GT(r2.area(), 0);
  EXPECT_EQ(src, RoiSource::kPose);
  for (const auto& c : roi.projectBundle(p, t)) EXPECT_TRUE(r2.contains(cv::Point(cvRound(c.x), cvRound(c.y))));
  EXPECT_LT(r2.area(), 0.5 * fx.intr.width * fx.intr.height);
  EXPECT_EQ(r2.x % cfg.align_px, 0);
}

TEST(DynamicRoi, ExtrapolatesWithVelocityAndIgnoresStalePose) {
  RoiFixture fx;
  RoiConfig cfg;
  cfg.full_frame_every_n = 0;
  cfg.use_detection_tracking = false;
  DynamicRoi roi(cfg, fx.intr, fx.T_world_cam, fx.bundle);
  auto p = fx.pose(0.0, 0);
  p.v_body[0] = 0.5;  // 0.5 m/s
  const auto at0 = roi.projectBundle(p, 0);
  const auto at100 = roi.projectBundle(p, 100'000'000);  // 100ms 후 → 5cm 이동
  ASSERT_EQ(at0.size(), at100.size());
  // 하향 카메라(rpy 180,0,0): world x 이동 → 영상 x 이동 (약 1740*0.05/1.95 ≈ 44.6px)
  EXPECT_NEAR(at100[0].x - at0[0].x, 1740.0 * 0.05 / 1.95, 2.0);
  RoiSource src;
  EXPECT_EQ(roi.compute(500'000'000, &p, &src).area(), 0);  // 500ms 경과 자세 → 미사용
  EXPECT_EQ(src, RoiSource::kFull);
}

TEST(DynamicRoi, TrackingFallbackAndPeriodicFullFrame) {
  RoiFixture fx;
  RoiConfig cfg;
  cfg.full_frame_every_n = 4;
  DynamicRoi roi(cfg, fx.intr, std::nullopt, fx.bundle);  // 외부파라미터 없음 → 자기추적만
  Detection d;
  d.corners = {cv::Point2f(700, 560), cv::Point2f(760, 560), cv::Point2f(760, 500), cv::Point2f(700, 500)};
  RoiSource src;
  EXPECT_EQ(roi.compute(0, nullptr, &src).area(), 0);  // frame 1
  roi.update({d});
  const cv::Rect r = roi.compute(0, nullptr, &src);    // frame 2
  EXPECT_EQ(src, RoiSource::kTracking);
  EXPECT_TRUE(r.contains(cv::Point(700, 500)) && r.contains(cv::Point(759, 559)));
  roi.compute(0, nullptr, &src);                       // frame 3
  EXPECT_EQ(roi.compute(0, nullptr, &src).area(), 0);  // frame 4 → 주기적 전체 탐색
  EXPECT_EQ(roi.compute(0, nullptr, &src).area(), 0);  // frame 5 → 추적 만료 (age 4 > 3)
}

// ───────────────────────── Lock-Free 자료구조 ─────────────────────────
TEST(SpscRing, BasicSemantics) {
  SpscRingBuffer<int> q(3);
  EXPECT_EQ(q.capacity(), 4u);
  for (int i = 0; i < 4; ++i) EXPECT_TRUE(q.tryPush(i));
  EXPECT_FALSE(q.tryPush(99));
  int v = -1;
  for (int i = 0; i < 4; ++i) {
    ASSERT_TRUE(q.tryPop(v));
    EXPECT_EQ(v, i);
  }
  EXPECT_FALSE(q.tryPop(v));
}

TEST(SpscRing, ConcurrentOrderingStress) {
  SpscRingBuffer<uint64_t> q(64);
  constexpr uint64_t N = 2'000'000;
  std::thread prod([&] {
    for (uint64_t i = 1; i <= N;)
      if (q.tryPush(i)) ++i;
  });
  uint64_t expect = 1, v = 0;
  while (expect <= N)
    if (q.tryPop(v)) {
      ASSERT_EQ(v, expect);
      ++expect;
    }
  prod.join();
}

TEST(FramePool, AcquireReleaseAcrossThreads) {
  FramePool pool(4, 64, 48);
  SpscRingBuffer<uint32_t> filled(5);
  std::atomic<bool> done{false};
  std::atomic<uint64_t> consumed{0};
  std::thread worker([&] {
    uint32_t idx;
    while (!done || !filled.emptyApprox())
      if (filled.tryPop(idx)) {
        EXPECT_EQ(pool.at(idx).data[0], static_cast<uint8_t>(pool.at(idx).meta.frame_seq & 0xff));
        pool.release(idx);
        ++consumed;
      }
  });
  uint64_t produced = 0;
  for (uint64_t k = 0; k < 200000; ++k) {
    const uint32_t idx = pool.acquire();
    if (idx == FramePool::kInvalid) continue;
    pool.at(idx).meta.frame_seq = k;
    pool.at(idx).data[0] = static_cast<uint8_t>(k & 0xff);
    ASSERT_TRUE(filled.tryPush(idx));
    ++produced;
  }
  done = true;
  worker.join();
  EXPECT_EQ(consumed.load(), produced);
  EXPECT_EQ(pool.freeApprox(), 4u);
}

TEST(SeqLock, ReaderNeverSeesTornValue) {
  struct V { uint64_t a, b, c, d; };
  SeqLock<V> s;
  std::atomic<bool> stop{false};
  std::thread w([&] {
    for (uint64_t i = 1; !stop; ++i) s.store(V{i, i, i, i});
  });
  V v{};
  int reads = 0;
  for (int i = 0; i < 500000; ++i)
    if (s.load(v)) {
      ++reads;
      ASSERT_TRUE(v.a == v.b && v.b == v.c && v.c == v.d);
    }
  stop = true;
  w.join();
  EXPECT_GT(reads, 0);
}
