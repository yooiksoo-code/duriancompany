// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
// 단위시험 공용 헬퍼
#pragma once

#include <cmath>
#include <string>
#include <vector>

#include "pkg_vision_acquisition/geometry.hpp"
#include "pkg_vision_acquisition/sim_camera.hpp"

#ifndef PVA_SOURCE_DIR
#define PVA_SOURCE_DIR "."
#endif

namespace pva_test {

inline std::string configPath(const std::string& name) { return std::string(PVA_SOURCE_DIR) + "/config/" + name; }

/// 하향 카메라 1대 + 단일/복수 태그 장면
inline pva::SimSceneConfig makeScene(bool distortion, int width = 1440, int height = 1080) {
  pva::SimSceneConfig sc;
  sc.intrinsics.width = width;
  sc.intrinsics.height = height;
  sc.intrinsics.K = cv::Matx33d(1740.0, 0, (width - 1) / 2.0 + 3.3, 0, 1739.0, (height - 1) / 2.0 - 2.1, 0, 0, 1);
  sc.intrinsics.D = cv::Mat::zeros(1, 5, CV_64F);
  if (distortion) sc.intrinsics.D = (cv::Mat_<double>(1, 5) << -0.0812, 0.1187, 0.00021, -0.00013, 0.0);
  sc.T_world_cam.R = pva::rotationFromRpyDeg(180, 0, 0);
  sc.T_world_cam.t = cv::Vec3d(0, 0, 2.2);
  sc.T_world_body0.t = cv::Vec3d(0, 0, 0.25);
  sc.hull_length_m = 1.2;
  sc.noise_sigma = 2.0;
  sc.supersample = 4;
  sc.glints = false;
  return sc;
}

inline pva::TagDef makeTag(int id, double x, double y, double size = 0.08, double yaw_deg = 0.0) {
  pva::TagDef t;
  t.id = id;
  t.size = size;
  t.T_body_tag.t = cv::Vec3d(x, y, 0);
  t.T_body_tag.R = pva::rotationFromRpyDeg(180, 0, yaw_deg);
  return t;
}

/// 정답과 검출 코너 비교: 동일 ID 매칭 후 코너 오차 벡터 목록 반환
template <typename Det>
inline std::vector<cv::Point2f> cornerErrors(const std::vector<Det>& dets, const std::vector<pva::SimGroundTruth>& gt,
                                             int* matched = nullptr) {
  std::vector<cv::Point2f> errs;
  int m = 0;
  for (const auto& g : gt)
    for (const auto& d : dets)
      if (d.tag_id == g.tag_id) {
        ++m;
        for (int k = 0; k < 4; ++k) errs.push_back(d.corners[k] - g.corners[k]);
      }
  if (matched) *matched = m;
  return errs;
}

inline double rms(const std::vector<cv::Point2f>& e) {
  if (e.empty()) return 1e9;
  double s = 0;
  for (const auto& v : e) s += v.x * v.x + v.y * v.y;
  return std::sqrt(s / e.size());
}

inline cv::Point2f meanVec(const std::vector<cv::Point2f>& e) {
  cv::Point2f m(0, 0);
  for (const auto& v : e) m += v;
  return e.empty() ? m : m * (1.0f / e.size());
}

}  // namespace pva_test
