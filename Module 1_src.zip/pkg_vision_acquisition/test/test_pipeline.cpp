// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
// 4채널 시뮬레이션 통합시험: 동기 집계, 채널 단절 내성(가), 전면 차폐 시 빈 배열 발행(나)
//  ※ 개발 컨테이너(2코어) 부하를 고려해 fps 를 낮춰 기능을 검증한다. 성능은 vision_acq_bench 로 측정.
#include <gtest/gtest.h>

#include <map>
#include <mutex>
#include <thread>

#include "pkg_vision_acquisition/config_builder.hpp"
#include "test_common.hpp"

using namespace pva;
using namespace pva_test;

namespace {

struct Capture {
  std::mutex m;
  std::vector<SyncedResult> results;
  std::vector<PipelineEvent> events;
};

PipelineConfig loadSimConfig(const std::map<std::string, std::string>& overrides) {
  YamlParamSource p(configPath("vision_acquisition.yaml"), "vision_acquisition_node");
  p.overlay(configPath("vision_acquisition_sim.yaml"), "vision_acquisition_node");
  p.set("camera.fps", "8.0");
  p.set("sim.prerender_frames", "6");
  p.set("sim.supersample", "2");
  p.set("detector.nthreads", "1");
  p.set("sync.max_wait_ms", "110.0");  // 8fps(125ms 주기), 2코어 환경에서 4채널 전체 대기
  p.set("health.reconnect_interval_ms", "300");
  for (const auto& kv : overrides) p.set(kv.first, kv.second);
  PipelineConfig cfg;
  std::string err;
  const auto resolve = [](const std::string& s) {
    const std::string pfx = "package://pkg_vision_acquisition/";
    return s.rfind(pfx, 0) == 0 ? std::string(PVA_SOURCE_DIR) + "/" + s.substr(pfx.size()) : s;
  };
  EXPECT_TRUE(buildPipelineConfig(p, resolve, cfg, err)) << err;
  return cfg;
}

void run(AcquisitionPipeline& pl, Capture& cap, double seconds) {
  pl.setResultCallback([&](SyncedResult& r) {
    std::lock_guard<std::mutex> lk(cap.m);
    cap.results.push_back(r);
  });
  pl.setEventCallback([&](const PipelineEvent& e) {
    std::lock_guard<std::mutex> lk(cap.m);
    cap.events.push_back(e);
    std::printf("    [event] %s ch%d %s\n", eventCodeName(e.code), e.camera_id, e.message.c_str());
  });
  std::string err;
  ASSERT_TRUE(pl.start(err)) << err;
  std::this_thread::sleep_for(std::chrono::duration<double>(seconds));
  pl.stop();
}

bool hasEvent(const Capture& c, EventCode code, int cam = -1) {
  for (const auto& e : c.events)
    if (e.code == code && (cam < 0 || e.camera_id == cam)) return true;
  return false;
}

}  // namespace

TEST(Pipeline, FourChannelSynchronizedPublishing) {
  AcquisitionPipeline pl(loadSimConfig({}));
  Capture cap;
  run(pl, cap, 3.0);
  const auto st = pl.stats();
  std::printf("  발행 %llu, 부분발행 %llu, 지연 avg %.2f / max %.2f ms, 노출편차 max ±%.1f us\n",
              (unsigned long long)st.published, (unsigned long long)st.partial_published, st.processing_ms.mean,
              st.processing_ms.max_all, st.stamp_dev_us.max_all);
  ASSERT_GE(cap.results.size(), 16u);  // 8fps × 3s × ~0.7
  int full_mask = 0, with_tags = 0;
  int64_t prev = 0;
  for (const auto& r : cap.results) {
    if (r.active_camera_mask == 0x0F) ++full_mask;
    if (!r.detections.empty()) ++with_tags;
    EXPECT_GT(r.stamp_ns, prev);  // 타임스탬프 단조 증가
    prev = r.stamp_ns;
    for (const auto& d : r.detections) {
      EXPECT_TRUE(r.active_camera_mask & (1u << (d.camera_id - 1)));
      EXPECT_GE(d.tag_id, 0);
      EXPECT_LE(d.tag_id, 7);
    }
  }
  EXPECT_GE(full_mask, static_cast<int>(cap.results.size() * 0.9));
  EXPECT_EQ(with_tags, static_cast<int>(cap.results.size()));
  EXPECT_LE(st.sync_violations, cap.results.size() / 20);
  EXPECT_FALSE(hasEvent(cap, EventCode::kCamDropout));
  for (const auto& c : st.channels) {
    EXPECT_EQ(c.seq_gaps, 0u);
    EXPECT_EQ(c.disconnects, 0u);
  }
}

TEST(Pipeline, CameraDropoutKeepsPublishingWithReducedMask) {
  AcquisitionPipeline pl(loadSimConfig(
      {{"sim.dropout_camera", "2"}, {"sim.dropout_start_s", "1.0"}, {"sim.dropout_duration_s", "1.2"}}));
  Capture cap;
  run(pl, cap, 4.0);
  EXPECT_TRUE(hasEvent(cap, EventCode::kCamDropout, 2));
  EXPECT_TRUE(hasEvent(cap, EventCode::kCamRecovered, 2));
  int reduced = 0;
  int64_t max_gap = 0, prev = 0;
  for (const auto& r : cap.results) {
    if (r.active_camera_mask == 0x0D) ++reduced;  // 0b1101: CH2 누락
    if (prev) max_gap = std::max(max_gap, r.stamp_ns - prev);
    prev = r.stamp_ns;
  }
  std::printf("  CH2 누락 상태 발행 %d건, 최대 발행 간격 %.0f ms\n", reduced, max_gap * 1e-6);
  EXPECT_GE(reduced, 5);
  EXPECT_LT(max_gap, 3 * 125'000'000);  // 단절 중에도 발행 공백 < 3주기
  EXPECT_EQ(cap.results.back().active_camera_mask, 0x0F);  // 복구 후 전 채널
  const auto st = pl.stats();
  EXPECT_GE(st.channels[1].reconnects, 1u);
}

TEST(Pipeline, TotalOcclusionPublishesEmptyArraysImmediately) {
  AcquisitionPipeline pl(loadSimConfig({{"sim.occlusion_start_s", "1.0"},
                                        {"sim.occlusion_duration_s", "1.0"},
                                        {"health.occlusion_warn_cycles", "3"}}));
  Capture cap;
  run(pl, cap, 3.0);
  int empty = 0;
  for (const auto& r : cap.results)
    if (r.detections.empty()) {
      ++empty;
      EXPECT_EQ(r.active_camera_mask, 0x0F);  // 카메라는 정상, 태그만 0개
      EXPECT_GT(r.stamp_ns, 0);
    }
  std::printf("  차폐 구간 빈 배열 발행 %d건\n", empty);
  EXPECT_GE(empty, 5);
  EXPECT_TRUE(hasEvent(cap, EventCode::kTotalOcclusion));
}
