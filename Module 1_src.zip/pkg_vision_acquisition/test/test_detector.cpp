// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
// [세부모듈 3] AprilTagDetectorCore 단위시험: 서브픽셀 정밀도, 좌표 규약, 코너 순서, ROI 오프셋
#include <gtest/gtest.h>

#include <cstdio>

#include "pkg_vision_acquisition/apriltag_detector_core.hpp"
#include "pkg_vision_acquisition/outlier_rejection_filter.hpp"
#include "test_common.hpp"

using namespace pva;
using namespace pva_test;

namespace {
struct Rendered {
  cv::Mat img;
  std::vector<SimGroundTruth> gt;
};

Rendered render(SimSceneConfig sc, const std::vector<TagDef>& tags, uint64_t seed = 7) {
  sc.bundle.tags = tags;
  cv::RNG rng(seed);
  Rendered r;
  r.img = SimCamera::renderFrame(sc, sc.T_world_body0, sc.intrinsics.width, sc.intrinsics.height, rng, &r.gt, false);
  return r;
}
}  // namespace

// AprilTag 3 은 픽셀 중심을 (i+0.5) 로 정의 → OpenCV(i) 대비 +0.5px 편향.
// pixel_center_offset = -0.5 로 보정되는지, 그리고 det->p 코너 순서가 tagCornersInTagFrame 과 일치하는지 검증.
TEST(Detector, PixelCenterConventionAndCornerOrder) {
  const auto sc = makeScene(false);
  const auto r = render(sc, {makeTag(3, 0.013, -0.021, 0.08, 17.0)});
  ASSERT_EQ(r.gt.size(), 1u);

  DetectorConfig raw_cfg;
  raw_cfg.quad_decimate = 1.0f;
  raw_cfg.pixel_center_offset = 0.0f;
  AprilTagDetectorCore raw(raw_cfg);
  std::vector<Detection> d0;
  raw.detect(r.img, {0, 0}, 1, d0);
  ASSERT_EQ(d0.size(), 1u);
  EXPECT_EQ(d0[0].tag_id, 3);
  const cv::Point2f bias = meanVec(cornerErrors(d0, r.gt));
  std::printf("  [보정 전] 평균 코너 편향 = (%.3f, %.3f) px\n", bias.x, bias.y);
  EXPECT_NEAR(bias.x, 0.5, 0.15);
  EXPECT_NEAR(bias.y, 0.5, 0.15);

  DetectorConfig cfg = raw_cfg;
  cfg.pixel_center_offset = -0.5f;
  AprilTagDetectorCore det(cfg);
  std::vector<Detection> d1;
  det.detect(r.img, {0, 0}, 1, d1);
  ASSERT_EQ(d1.size(), 1u);
  const auto e = cornerErrors(d1, r.gt);
  std::printf("  [보정 후] 코너 RMS 오차 = %.4f px\n", rms(e));
  EXPECT_LT(rms(e), 0.12);  // 코너 순서가 틀리면 수십 px 오차
}

// 무작위 자세 30개 (서브픽셀 위치, 회전, 원근 기울기) 에서 코너 정밀도 ≤ 0.1px RMS (KPI: 재투영 ≤ 0.25px)
TEST(Detector, SubpixelAccuracyRandomPoses) {
  cv::RNG rng(42);
  for (float decimate : {1.0f, 2.0f}) {
    DetectorConfig cfg;
    cfg.quad_decimate = decimate;
    AprilTagDetectorCore det(cfg);
    std::vector<cv::Point2f> all;
    int found = 0, total = 0;
    for (int i = 0; i < 30; ++i) {
      auto sc = makeScene(false);
      sc.T_world_body0.t = cv::Vec3d(rng.uniform(-0.4, 0.4), rng.uniform(-0.3, 0.3), 0.25);
      sc.T_world_body0.R = rotationFromRpyDeg(rng.uniform(-15.0, 15.0), rng.uniform(-15.0, 15.0), rng.uniform(-180.0, 180.0));
      const auto r = render(sc, {makeTag(i % 8, 0, 0, 0.08)}, 100 + i);
      if (r.gt.empty()) continue;
      ++total;
      std::vector<Detection> d;
      det.detect(r.img, {0, 0}, 1, d);
      int m = 0;
      const auto e = cornerErrors(d, r.gt, &m);
      found += m;
      all.insert(all.end(), e.begin(), e.end());
    }
    std::printf("  decimate=%.0f: 검출 %d/%d, 코너 RMS = %.4f px\n", decimate, found, total, rms(all));
    EXPECT_EQ(found, total);
    EXPECT_LT(rms(all), 0.10);
  }
}

// ROI(부분 뷰) 검출 결과가 전체 영상 검출과 동일 좌표계인지
TEST(Detector, RoiOffsetConsistency) {
  const auto r = render(makeScene(false), {makeTag(5, 0.1, 0.05)});
  DetectorConfig cfg;
  AprilTagDetectorCore det(cfg);
  std::vector<Detection> full, roi;
  det.detect(r.img, {0, 0}, 1, full);
  ASSERT_EQ(full.size(), 1u);
  const cv::Rect box = cv::Rect(cv::Point(cvRound(full[0].center.x) - 120, cvRound(full[0].center.y) - 100), cv::Size(240, 200));
  det.detect(r.img(box), cv::Point2f(static_cast<float>(box.x), static_cast<float>(box.y)), 1, roi);
  ASSERT_EQ(roi.size(), 1u);
  for (int k = 0; k < 4; ++k) EXPECT_NEAR(cv::norm(roi[0].corners[k] - full[0].corners[k]), 0.0, 0.05);
}

// 코너 와인딩 방향: 정상 영상 = expectedWindingSign, 좌우 반전(수면 거울상) = 반대 → 필터 폐기
TEST(Detector, WindingSignAndMirrorRejection) {
  const auto r = render(makeScene(false), {makeTag(0, -0.1, 0.0), makeTag(1, 0.0, 0.0), makeTag(2, 0.1, 0.0),
                                           makeTag(4, -0.1, 0.12), makeTag(6, 0.1, 0.12)});
  AprilTagDetectorCore det(DetectorConfig{});
  std::vector<Detection> d;
  det.detect(r.img, {0, 0}, 1, d);
  ASSERT_GE(d.size(), 5u);
  for (const auto& x : d) {
    const auto& c = x.corners;
    const float z = (c[1].x - c[0].x) * (c[2].y - c[0].y) - (c[1].y - c[0].y) * (c[2].x - c[0].x);
    EXPECT_EQ(z > 0 ? 1 : -1, OutlierRejectionFilter::expectedWindingSign());
  }
  // 거울상: 디코딩되는 경우(드묾)에도 와인딩 검사로 폐기되어야 함
  cv::Mat mirrored;
  cv::flip(r.img, mirrored, 1);
  std::vector<Detection> dm;
  DetectorConfig loose;
  loose.max_hamming = 2;
  AprilTagDetectorCore det2(loose);
  det2.detect(mirrored, {0, 0}, 1, dm);
  FilterConfig fc;
  fc.enable_whitelist = false;
  fc.min_decision_margin = 0;
  fc.max_hamming = 3;
  OutlierRejectionFilter filt(fc);
  const size_t before = dm.size();
  filt.apply(dm);
  std::printf("  거울상 디코딩 %zu건 → 필터 후 %zu건\n", before, dm.size());
  EXPECT_EQ(dm.size(), 0u);
}
