// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
// [세부모듈 2] ImagePreprocessor 단위시험: LUT 왜곡보정 정확도, ROI 부분 remap 동일성, 성능
#include <gtest/gtest.h>

#include <chrono>
#include <cstdio>

#include "pkg_vision_acquisition/apriltag_detector_core.hpp"
#include "pkg_vision_acquisition/image_preprocessor.hpp"
#include "test_common.hpp"

using namespace pva;
using namespace pva_test;

namespace {
struct Fixture {
  SimSceneConfig sc = makeScene(true);
  cv::Mat img;
  std::vector<SimGroundTruth> gt;
  Fixture() {
    // 왜곡이 큰 화면 주변부 포함 배치
    sc.bundle.tags = {makeTag(0, -0.55, -0.40), makeTag(1, 0.0, 0.0), makeTag(2, 0.55, 0.38), makeTag(3, -0.55, 0.38),
                      makeTag(4, 0.55, -0.40), makeTag(5, 0.3, 0.0)};
    sc.hull_length_m = 0.01;
    cv::RNG rng(3);
    img = SimCamera::renderFrame(sc, sc.T_world_body0, sc.intrinsics.width, sc.intrinsics.height, rng, &gt, false);
  }
};

double detectRms(ImagePreprocessor& pre, const cv::Mat& img, const std::vector<SimGroundTruth>& gt, int* matched) {
  AprilTagDetectorCore det(DetectorConfig{});
  const auto out = pre.process(img, cv::Rect());
  std::vector<Detection> d;
  det.detect(out.image, out.offset, 1, d);
  if (!out.rectified) {
    std::vector<cv::Point2f> pts;
    for (auto& x : d) pts.insert(pts.end(), x.corners.begin(), x.corners.end());
    pre.rectifyPoints(pts);
    for (size_t i = 0; i < d.size(); ++i)
      for (int k = 0; k < 4; ++k) d[i].corners[k] = pts[i * 4 + k];
  }
  return rms(cornerErrors(d, gt, matched));
}
}  // namespace

TEST(Preprocessor, RemapModeAccuracyOnDistortedImage) {
  Fixture f;
  ASSERT_GE(f.gt.size(), 5u);
  PreprocessConfig cfg;
  cfg.undistort_mode = UndistortMode::kRemap;
  ImagePreprocessor pre(f.sc.intrinsics, cfg);
  int m = 0;
  const double e = detectRms(pre, f.img, f.gt, &m);
  std::printf("  remap 모드: %d/%zu 검출, 코너 RMS = %.4f px\n", m, f.gt.size(), e);
  EXPECT_EQ(m, static_cast<int>(f.gt.size()));
  EXPECT_LT(e, 0.15);

  // 왜곡 보정을 생략하면 주변부 오차가 커져야 함 (보정의 필요성 확인)
  PreprocessConfig none;
  none.undistort_mode = UndistortMode::kNone;
  ImagePreprocessor pre_none(f.sc.intrinsics, none);
  const double e_none = detectRms(pre_none, f.img, f.gt, &m);
  std::printf("  보정 미적용 시 코너 RMS = %.3f px\n", e_none);
  EXPECT_GT(e_none, 1.0);
}

TEST(Preprocessor, CornersOnlyModeAccuracy) {
  Fixture f;
  PreprocessConfig cfg;
  cfg.undistort_mode = UndistortMode::kCornersOnly;
  ImagePreprocessor pre(f.sc.intrinsics, cfg);
  int m = 0;
  const double e = detectRms(pre, f.img, f.gt, &m);
  std::printf("  corners 모드: %d/%zu 검출, 코너 RMS = %.4f px\n", m, f.gt.size(), e);
  EXPECT_EQ(m, static_cast<int>(f.gt.size()));
  EXPECT_LT(e, 0.15);
}

TEST(Preprocessor, RoiRemapIdenticalToFullRemap) {
  Fixture f;
  PreprocessConfig cfg;
  ImagePreprocessor pre(f.sc.intrinsics, cfg);
  const cv::Mat full = pre.process(f.img, cv::Rect()).image.clone();
  const cv::Rect roi(320, 208, 400, 300);
  const auto part = pre.process(f.img, roi);
  EXPECT_EQ(part.offset, cv::Point2f(320, 208));
  EXPECT_EQ(cv::norm(part.image, full(roi), cv::NORM_INF), 0.0);
}

TEST(Preprocessor, RectifiedRoiToRawCoversRegion) {
  Fixture f;
  PreprocessConfig cfg;
  cfg.undistort_mode = UndistortMode::kCornersOnly;
  ImagePreprocessor pre(f.sc.intrinsics, cfg);
  const cv::Rect roi(1100, 50, 300, 250);  // 왜곡 큰 우상단
  const cv::Rect raw = pre.rectifiedRoiToRaw(roi);
  // 원본 raw ROI 내 모든 픽셀을 보정하면 roi 를 덮어야 함 → 역으로 roi 테두리점의 왜곡 위치가 raw 안에 있어야 함
  std::vector<cv::Point2f> raw_pts;
  for (int y = raw.y; y < raw.y + raw.height; y += 4)
    for (int x = raw.x; x < raw.x + raw.width; x += 4) raw_pts.emplace_back(static_cast<float>(x), static_cast<float>(y));
  pre.undistortPoints(raw_pts);
  const cv::Rect covered = cv::boundingRect(raw_pts);
  EXPECT_LE(covered.x, roi.x + 4);
  EXPECT_LE(covered.y, roi.y + 4);
  EXPECT_GE(covered.x + covered.width, roi.x + roi.width - 4);
  EXPECT_GE(covered.y + covered.height, roi.y + roi.height - 4);
}

TEST(Preprocessor, RemapTimingFullAndRoi) {
  Fixture f;
  PreprocessConfig cfg;
  ImagePreprocessor pre(f.sc.intrinsics, cfg);
  auto time_it = [&](const cv::Rect& r) {
    for (int i = 0; i < 5; ++i) pre.process(f.img, r);
    const auto t0 = std::chrono::steady_clock::now();
    const int n = 50;
    for (int i = 0; i < n; ++i) pre.process(f.img, r);
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / n;
  };
  const double full = time_it(cv::Rect());
  const double roi = time_it(cv::Rect(400, 300, 480, 360));
  std::printf("  LUT remap 1440x1080: %.3f ms / ROI 480x360: %.3f ms (본 개발환경 기준)\n", full, roi);
  EXPECT_LT(roi, full);
}
