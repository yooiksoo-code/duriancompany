// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// intrinsic_calibrator : 체커보드 기반 카메라 내부 파라미터 보정 (2단계 M3~M4 산출물)
//   intrinsic_calibrator --images <dir> --board 9x6 --square 0.030 --out cam_intrinsics_ch1.yaml [--name dock_cam_ch1]
//   - board 는 내부 코너 수 (cols x rows)
//   - 결과는 ROS camera_calibration 호환 YAML (config/cam_intrinsics_chN.yaml 에 그대로 사용)
//   - 권장: 화면 전역(특히 모서리)을 덮는 20~40장, 다양한 기울기, 글로벌셔터 + 짧은 노출
//   - 기본적으로 k3 = 0 고정: 6mm 급 저왜곡 렌즈에서 k2/k3 상관으로 인한 과적합 방지 (--k3 로 해제)
#include <algorithm>
#include <cstdio>
#include <filesystem>
#include <string>
#include <vector>

#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>
#ifdef HAVE_IMGCODECS
#include <opencv2/imgcodecs.hpp>
#endif

#include "pkg_vision_acquisition/geometry.hpp"

int main(int argc, char** argv) {
#ifndef HAVE_IMGCODECS
  std::fputs("opencv_imgcodecs 없이 빌드되어 이미지 로드를 지원하지 않습니다.\n", stderr);
  return 1;
#else
  std::string dir, out = "cam_intrinsics.yaml", name = "dock_cam";
  int bw = 9, bh = 6;
  double square = 0.03;
  bool use_k3 = false;
  for (int i = 1; i < argc; ++i) {
    const std::string k = argv[i];
    if (k == "--k3") { use_k3 = true; continue; }
    if (i + 1 >= argc) break;
    const std::string v = argv[++i];
    if (k == "--images") dir = v;
    else if (k == "--out") out = v;
    else if (k == "--name") name = v;
    else if (k == "--square") square = std::stod(v);
    else if (k == "--board") std::sscanf(v.c_str(), "%dx%d", &bw, &bh);
  }
  if (dir.empty()) {
    std::puts("usage: intrinsic_calibrator --images <dir> --board 9x6 --square 0.030 --out <yaml> [--name cam] [--k3]");
    return 2;
  }
  const cv::Size board(bw, bh);
  std::vector<cv::Point3f> obj;
  for (int y = 0; y < bh; ++y)
    for (int x = 0; x < bw; ++x) obj.emplace_back(static_cast<float>(x * square), static_cast<float>(y * square), 0.f);

  std::vector<std::vector<cv::Point3f>> objs;
  std::vector<std::vector<cv::Point2f>> imgs;
  std::vector<std::string> used;
  cv::Size size;
  std::vector<std::filesystem::path> files;
  for (const auto& e : std::filesystem::directory_iterator(dir)) files.push_back(e.path());
  std::sort(files.begin(), files.end());
  for (const auto& f : files) {
    const std::string ext = f.extension().string();
    if (ext != ".png" && ext != ".bmp" && ext != ".jpg" && ext != ".tif" && ext != ".tiff" && ext != ".pgm") continue;
    cv::Mat im = cv::imread(f.string(), cv::IMREAD_GRAYSCALE);
    if (im.empty()) continue;
    if (size.area() == 0) size = im.size();
    if (im.size() != size) {
      std::fprintf(stderr, "  건너뜀(해상도 불일치): %s\n", f.filename().c_str());
      continue;
    }
    std::vector<cv::Point2f> corners;
    // SB(섹터 기반) 검출기: 기본 findChessboardCorners + cornerSubPix 보다 정밀/강건
    if (!cv::findChessboardCornersSB(im, board, corners, cv::CALIB_CB_EXHAUSTIVE | cv::CALIB_CB_ACCURACY)) {
      std::fprintf(stderr, "  검출 실패: %s\n", f.filename().c_str());
      continue;
    }
    objs.push_back(obj);
    imgs.push_back(corners);
    used.push_back(f.filename().string());
  }
  std::fprintf(stderr, "유효 영상 %zu / %zu\n", imgs.size(), files.size());
  if (imgs.size() < 8) {
    std::fputs("유효 영상이 8장 미만입니다. 더 많은 자세로 촬영하십시오.\n", stderr);
    return 1;
  }
  cv::Mat K, D;
  std::vector<cv::Mat> rvecs, tvecs;
  cv::Mat std_in, std_ex, per_view;
  const double rms = cv::calibrateCamera(objs, imgs, size, K, D, rvecs, tvecs, std_in, std_ex, per_view, use_k3 ? 0 : cv::CALIB_FIX_K3,
                                         cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 100, 1e-9));
  std::printf("재투영 RMS = %.4f px\n", rms);
  for (int i = 0; i < per_view.rows; ++i)
    std::printf("  %-32s %.4f px%s\n", used[static_cast<size_t>(i)].c_str(), per_view.at<double>(i),
                per_view.at<double>(i) > 2 * rms ? "  ← 이상치 후보" : "");
  pva::CameraIntrinsics intr;
  intr.camera_name = name;
  intr.width = size.width;
  intr.height = size.height;
  intr.K = cv::Matx33d(K);
  intr.D = D.reshape(1, 1);
  intr.distortion_model = "plumb_bob";
  if (!pva::saveIntrinsicsRos(out, intr, rms)) {
    std::fprintf(stderr, "저장 실패: %s\n", out.c_str());
    return 1;
  }
  std::printf("저장: %s\n", out.c_str());
  return rms < 0.5 ? 0 : 3;
#endif
}
