// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// vision_acq_bench : ROS 비의존 파이프라인 성능/정밀도 시험 도구 (설계서 8장 KPI 계측)
//
//  사용 예)
//   # 1) 시뮬레이터 4채널 60fps 처리지연/프레임레이트
//   vision_acq_bench --params config/vision_acquisition.yaml --params config/vision_acquisition_sim.yaml --duration 20
//   # 2) 정지 모형 코너 지터/재투영 오차 (1,000 프레임)
//   vision_acq_bench ... --jitter --frames 1000 --set sim.static_scene=true
//   # 3) 실장비: --params config/vision_acquisition.yaml (camera.driver=aravis) --duration 3600 --csv log.csv
//
//  출력: Markdown KPI 보고서 (stdout, --report 파일), 주기별 CSV (--csv)
#include <atomic>
#include <cmath>
#include <csignal>
#include <cstdio>
#include <fstream>
#include <map>
#include <mutex>
#include <sstream>
#include <thread>

#include "pkg_vision_acquisition/config_builder.hpp"
#include "pkg_vision_acquisition/sim_camera.hpp"

using namespace pva;

namespace {
std::atomic<bool> g_stop{false};
void onSignal(int) { g_stop = true; }

struct Args {
  std::vector<std::string> params;
  std::vector<std::pair<std::string, std::string>> sets;
  double duration_s = 10.0;
  long frames = 0;
  bool jitter = false;
  std::string csv, report;
  std::string pkg_dir = ".";
};

void usage() {
  std::puts(
      "vision_acq_bench --params <yaml> [--params <overlay.yaml>]... [--set key=value]...\n"
      "                 [--duration sec] [--frames N] [--jitter] [--csv file] [--report file] [--pkg-dir dir]");
}

struct Welford {
  long n = 0;
  double mean = 0, m2 = 0;
  void add(double x) {
    ++n;
    const double d = x - mean;
    mean += d / n;
    m2 += d * (x - mean);
  }
  double stddev() const { return n > 1 ? std::sqrt(m2 / (n - 1)) : 0.0; }
};

const char* pf(bool ok) { return ok ? "**PASS**" : "**FAIL**"; }
}  // namespace

int main(int argc, char** argv) {
  Args a;
  for (int i = 1; i < argc; ++i) {
    const std::string s = argv[i];
    auto next = [&]() -> std::string {
      if (i + 1 >= argc) { usage(); std::exit(2); }
      return argv[++i];
    };
    if (s == "--params") a.params.push_back(next());
    else if (s == "--set") {
      const std::string kv = next();
      const auto eq = kv.find('=');
      if (eq == std::string::npos) { usage(); return 2; }
      a.sets.emplace_back(kv.substr(0, eq), kv.substr(eq + 1));
    } else if (s == "--duration") a.duration_s = std::stod(next());
    else if (s == "--frames") a.frames = std::stol(next());
    else if (s == "--jitter") a.jitter = true;
    else if (s == "--csv") a.csv = next();
    else if (s == "--report") a.report = next();
    else if (s == "--pkg-dir") a.pkg_dir = next();
    else { usage(); return s == "-h" || s == "--help" ? 0 : 2; }
  }
  if (a.params.empty()) { usage(); return 2; }
  if (a.jitter) {
    a.sets.insert(a.sets.begin(), {"sim.static_scene", "true"});
    a.sets.insert(a.sets.begin(), {"roi.enable", "true"});
  }

  // ── 설정
  std::unique_ptr<YamlParamSource> p;
  try {
    p = std::make_unique<YamlParamSource>(a.params[0], "vision_acquisition_node");
    for (size_t i = 1; i < a.params.size(); ++i) p->overlay(a.params[i], "vision_acquisition_node");
    for (const auto& kv : a.sets) p->set(kv.first, kv.second);
  } catch (const std::exception& e) {
    std::fprintf(stderr, "파라미터 파일 오류: %s\n", e.what());
    return 1;
  }
  const std::string pkg_dir = a.pkg_dir;
  const auto resolve = [&](const std::string& s) {
    const std::string pfx = "package://pkg_vision_acquisition/";
    return s.rfind(pfx, 0) == 0 ? pkg_dir + "/" + s.substr(pfx.size()) : s;
  };
  PipelineConfig cfg;
  std::string err;
  if (!buildPipelineConfig(*p, resolve, cfg, err)) {
    std::fprintf(stderr, "설정 오류: %s\n", err.c_str());
    return 1;
  }
  const double fps = cfg.channels.front().camera.fps;
  const bool is_sim = cfg.channels.front().camera.driver == "sim";

  // 정답 코너 (시뮬레이터 정지 장면): 보정 좌표계 = K 핀홀 투영
  std::map<std::pair<int, int>, std::array<cv::Point2f, 4>> truth;  // (camera, tag) → corners
  if (is_sim) {
    for (const auto& ch : cfg.channels) {
      const auto& sc = *ch.camera.sim;
      const Pose3 T_cam_body = sc.T_world_cam.inverse() * sc.T_world_body0;
      for (const auto& t : sc.bundle.tags) {
        std::array<cv::Point2f, 4> c{};
        bool ok = true;
        const auto tc = tagCornersInTagFrame(t.size);
        for (int k = 0; k < 4; ++k) {
          const cv::Vec3d pc = T_cam_body * (t.T_body_tag * cv::Vec3d(tc[k].x, tc[k].y, tc[k].z));
          if (pc[2] <= 0) { ok = false; break; }
          c[k] = cv::Point2f(static_cast<float>(ch.intrinsics.K(0, 0) * pc[0] / pc[2] + ch.intrinsics.K(0, 2)),
                             static_cast<float>(ch.intrinsics.K(1, 1) * pc[1] / pc[2] + ch.intrinsics.K(1, 2)));
        }
        if (ok) truth[std::make_pair(static_cast<int>(ch.camera.camera_id), t.id)] = c;
      }
    }
  }

  // ── 실행
  AcquisitionPipeline pl(cfg);
  std::mutex m;
  std::map<std::tuple<int, int, int>, std::pair<Welford, Welford>> corner_stats;  // (cam,tag,corner) → x,y
  Welford reproj;  // 정답 대비 코너 오차 크기
  double reproj_max = 0;
  long cycles = 0, cycles_full_mask = 0, total_dets = 0;
  std::ofstream csv;
  if (!a.csv.empty()) {
    csv.open(a.csv);
    csv << "sync_seq,stamp_ns,active_camera_mask,num_detections,processing_time_ms,stamp_spread_us,stamp_max_dev_us\n";
  }
  uint8_t all_mask = 0;
  for (const auto& ch : cfg.channels) all_mask |= static_cast<uint8_t>(1u << (ch.camera.camera_id - 1));

  pl.setResultCallback([&](SyncedResult& r) {
    std::lock_guard<std::mutex> lk(m);
    ++cycles;
    if (r.active_camera_mask == all_mask) ++cycles_full_mask;
    total_dets += static_cast<long>(r.detections.size());
    if (csv) csv << r.sync_seq << "," << r.stamp_ns << "," << int(r.active_camera_mask) << "," << r.detections.size()
                 << "," << r.processing_time_ms << "," << r.stamp_spread_ns * 1e-3 << "," << r.stamp_max_dev_ns * 1e-3 << "\n";
    if (a.jitter) {
      for (const auto& d : r.detections) {
        for (int k = 0; k < 4; ++k) {
          auto& s = corner_stats[{d.camera_id, d.tag_id, k}];
          s.first.add(d.corners[k].x);
          s.second.add(d.corners[k].y);
        }
        auto it = truth.find(std::make_pair(static_cast<int>(d.camera_id), static_cast<int>(d.tag_id)));
        if (it != truth.end())
          for (int k = 0; k < 4; ++k) {
            const double e = cv::norm(d.corners[k] - it->second[k]);
            reproj.add(e);
            reproj_max = std::max(reproj_max, e);
          }
      }
    }
    if (a.frames > 0 && cycles >= a.frames) g_stop = true;
  });
  std::vector<std::string> event_log;
  pl.setEventCallback([&](const PipelineEvent& e) {
    std::ostringstream os;
    os << eventCodeName(e.code) << " ch" << int(e.camera_id) << ": " << e.message;
    std::fprintf(stderr, "[event] %s\n", os.str().c_str());
    std::lock_guard<std::mutex> lk(m);
    if (event_log.size() < 50) event_log.push_back(os.str());
  });

  std::signal(SIGINT, onSignal);
  std::signal(SIGTERM, onSignal);
  std::fprintf(stderr, "파이프라인 시작 (%zu채널, %s, %.0f fps)...\n", cfg.channels.size(),
               cfg.channels.front().camera.driver.c_str(), fps);
  if (!pl.start(err)) {
    std::fprintf(stderr, "시작 실패: %s\n", err.c_str());
    return 1;
  }
  const auto t0 = std::chrono::steady_clock::now();
  // 워밍업 1초 후 통계 초기화 효과를 위해 그 시점 스냅샷을 기준으로 사용하지 않고 전체 구간 보고
  while (!g_stop) {
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    const double el = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    if (a.frames <= 0 && el >= a.duration_s) break;
    if (a.frames > 0 && el >= a.duration_s * 20) break;  // 안전 타임아웃
  }
  const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  const PipelineStats st = pl.stats();
  pl.stop();

  // ── 보고서
  std::ostringstream R;
  R << "# vision_acquisition 성능 시험 보고서\n\n";
  R << "- 드라이버: `" << cfg.channels.front().camera.driver << "`, 채널 " << cfg.channels.size() << ", 해상도 "
    << cfg.channels.front().camera.width << "x" << cfg.channels.front().camera.height << ", 설정 " << fps << " fps\n";
  R << "- 왜곡보정 모드: `" << (cfg.preprocess.undistort_mode == UndistortMode::kRemap ? "remap"
                                : cfg.preprocess.undistort_mode == UndistortMode::kCornersOnly ? "corners" : "none")
    << "`, quad_decimate " << cfg.detector.quad_decimate << ", nthreads/채널 " << cfg.detector.nthreads
    << ", 동적 ROI " << (cfg.roi.enable ? "ON" : "OFF") << "\n";
  R << "- 시험 시간 " << elapsed << " s, 발행 주기 " << cycles << " (전 채널 " << cycles_full_mask << "), 평균 태그/주기 "
    << (cycles ? static_cast<double>(total_dets) / cycles : 0.0) << "\n";
  R << "- 하드웨어 동시성: " << std::thread::hardware_concurrency() << " 논리코어\n\n";

  R << "## 채널별\n\n| CH | fps | 수집 | 처리 | stale skip | 풀고갈 | seq 누락 | 불완전 | ROI 사용 | ROI→Full | 작업 avg/p99/max [ms] | 필터 폐기 |\n";
  R << "|---|---|---|---|---|---|---|---|---|---|---|---|\n";
  uint64_t frames_all = 0, gaps_all = 0, incomplete_all = 0, missing_pk = 0;
  for (const auto& c : st.channels) {
    frames_all += c.frames_grabbed;
    gaps_all += c.seq_gaps;
    incomplete_all += c.frames_incomplete;
    missing_pk += c.camera.packets_missing + c.lost_packets;
    char buf[512];
    std::snprintf(buf, sizeof(buf), "| %d | %.1f | %llu | %llu | %llu | %llu | %llu | %llu | %.0f%% | %llu | %.2f / %.2f / %.2f | %llu |\n",
                  c.camera_id, c.fps, (unsigned long long)c.frames_grabbed, (unsigned long long)c.frames_processed,
                  (unsigned long long)c.frames_skipped_stale, (unsigned long long)c.frames_dropped_nobuf,
                  (unsigned long long)c.seq_gaps, (unsigned long long)c.frames_incomplete,
                  c.frames_processed ? 100.0 * c.roi_frames / c.frames_processed : 0.0,
                  (unsigned long long)c.roi_fallbacks, c.work_ms.mean, c.work_ms.p99, c.work_ms.max_all,
                  (unsigned long long)c.filter.total_rejected());
    R << buf;
  }

  const double min_fps_target = std::min(30.0, fps * 0.98);
  const bool fps_ok = st.publish_fps >= min_fps_target;
  const bool lat_ok = st.processing_ms.mean <= 4.0;
  const bool loop_ok = st.processing_ms.max_all < 10.0;
  const double loss_rate = frames_all ? static_cast<double>(gaps_all + incomplete_all) / (frames_all + gaps_all) : 0.0;
  R << "\n## KPI (설계서 8장)\n\n| 평가 항목 | 목표 | 측정 | 판정 |\n|---|---|---|---|\n";
  char b[512];
  std::snprintf(b, sizeof(b), "| 다중 카메라 캡처 프레임레이트 | 30~60 FPS 연속 | %.2f FPS (발행) | %s |\n", st.publish_fps, pf(fps_ok));
  R << b;
  std::snprintf(b, sizeof(b), "| 단일 프레임 처리 지연 (평균) | ≤ 4.0 ms | avg %.3f / p50 %.3f / p99 %.3f ms | %s |\n",
                st.processing_ms.mean, st.processing_ms.p50, st.processing_ms.p99, pf(lat_ok));
  R << b;
  std::snprintf(b, sizeof(b), "| 전체 루프 지원 (최대) | < 10 ms | max %.3f ms | %s |\n", st.processing_ms.max_all, pf(loop_ok));
  R << b;
  std::snprintf(b, sizeof(b), "| 카메라 간 노출 동기 | ±%.0f us | 기준대비 편차 avg ±%.1f / max ±%.1f us (위반 %llu) | %s |\n",
                cfg.sync.tolerance_us, st.stamp_dev_us.mean, st.stamp_dev_us.max_all, (unsigned long long)st.sync_violations,
                pf(st.sync_violations == 0));
  R << b;
  std::snprintf(b, sizeof(b), "| 통신 패킷/프레임 손실률 | 0.00%% | %.4f%% (seq 누락 %llu, 불완전 %llu, 패킷 %llu) | %s |\n",
                loss_rate * 100, (unsigned long long)gaps_all, (unsigned long long)incomplete_all,
                (unsigned long long)missing_pk, pf(loss_rate == 0.0 && missing_pk == 0));
  R << b;
  if (a.jitter) {
    double jmax = 0, jmean = 0;
    long nj = 0;
    for (const auto& kv : corner_stats) {
      if (kv.second.first.n < 10) continue;
      const double j = std::hypot(kv.second.first.stddev(), kv.second.second.stddev());
      jmax = std::max(jmax, j);
      jmean += j;
      ++nj;
    }
    jmean = nj ? jmean / nj : 0.0;
    std::snprintf(b, sizeof(b), "| 코너 지터 (정지, 표준편차) | (참고) | mean %.4f / max %.4f px (%ld 코너) | - |\n", jmean, jmax, nj);
    R << b;
    if (reproj.n > 0) {
      std::snprintf(b, sizeof(b), "| 코너 재투영 오차 (정답 대비) | ≤ 0.25 px | mean %.4f / max %.4f px (%ld 샘플) | %s |\n",
                    reproj.mean, reproj_max, reproj.n, pf(reproj.mean <= 0.25));
      R << b;
    }
  }
  R << "\n- 발행: " << st.published << " / 부분(일부 채널 누락) " << st.partial_published << " / 빈 배열 "
    << st.empty_published << " / 지연 도착 폐기 " << st.late_results << "\n";
  if (!event_log.empty()) {
    R << "\n## 이벤트\n\n";
    for (const auto& e : event_log) R << "- " << e << "\n";
  }
  std::fputs(R.str().c_str(), stdout);
  if (!a.report.empty()) std::ofstream(a.report) << R.str();
  return 0;
}
