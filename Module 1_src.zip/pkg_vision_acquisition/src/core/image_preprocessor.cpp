// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/image_preprocessor.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>

#include <opencv2/calib3d.hpp>

namespace pva {

UndistortMode parseUndistortMode(const std::string& s) {
  if (s == "remap") return UndistortMode::kRemap;
  if (s == "corners" || s == "corners_only") return UndistortMode::kCornersOnly;
  if (s == "none") return UndistortMode::kNone;
  throw std::invalid_argument("undistort_mode must be remap|corners|none, got: " + s);
}

ImagePreprocessor::ImagePreprocessor(const CameraIntrinsics& intr, const PreprocessConfig& cfg)
    : intr_(intr), cfg_(cfg) {
  if (!intr_.valid()) throw std::invalid_argument("ImagePreprocessor: invalid intrinsics");
  const cv::Size size(intr_.width, intr_.height);
  if (cfg_.undistort_mode == UndistortMode::kRemap) {
    cv::Mat m1f, m2f;
    // newCameraMatrix = K : 보정 후에도 동일 K 를 사용 (하류 모듈 계약 단순화)
    cv::initUndistortRectifyMap(cv::Mat(intr_.K), intr_.D, cv::noArray(), cv::Mat(intr_.K), size,
                                CV_32FC1, m1f, m2f);
    // 고정소수점 맵: remap 속도 약 2배 (보간 정밀도 1/32 px, 서브픽셀 정밀도에 영향 미미)
    cv::convertMaps(m1f, m2f, map1_, map2_, CV_16SC2, false);
    rect_buf_.create(size, CV_8UC1);
  }
  if (cfg_.clahe_enable) {
    clahe_ = cv::createCLAHE(cfg_.clahe_clip_limit, cv::Size(cfg_.clahe_tile_grid, cfg_.clahe_tile_grid));
    clahe_buf_.create(size, CV_8UC1);
  }
}

PreprocessOutput ImagePreprocessor::process(const cv::Mat& raw, const cv::Rect& roi_in) {
  CV_Assert(raw.type() == CV_8UC1 && raw.cols == intr_.width && raw.rows == intr_.height);
  const cv::Rect full(0, 0, raw.cols, raw.rows);
  cv::Rect roi = roi_in.area() > 0 ? (roi_in & full) : full;
  if (roi.area() <= 0) roi = full;

  PreprocessOutput out;
  switch (cfg_.undistort_mode) {
    case UndistortMode::kRemap: {
      // 출력 ROI 영역에 해당하는 LUT 부분만 사용 → ROI 면적에 비례하는 연산량
      cv::Mat dst = rect_buf_(roi);
      cv::remap(raw, dst, map1_(roi), map2_(roi), cfg_.interpolation, cv::BORDER_CONSTANT,
                cv::Scalar(0));
      out.image = dst;
      out.offset = cv::Point2f(static_cast<float>(roi.x), static_cast<float>(roi.y));
      out.rectified = true;
      break;
    }
    case UndistortMode::kCornersOnly: {
      const cv::Rect raw_roi = (roi == full) ? full : (rectifiedRoiToRaw(roi) & full);
      out.image = raw(raw_roi);  // zero-copy 부분 뷰
      out.offset = cv::Point2f(static_cast<float>(raw_roi.x), static_cast<float>(raw_roi.y));
      out.rectified = false;
      roi = raw_roi;
      break;
    }
    case UndistortMode::kNone:
      out.image = raw(roi);
      out.offset = cv::Point2f(static_cast<float>(roi.x), static_cast<float>(roi.y));
      out.rectified = true;
      break;
  }

  if (cfg_.clahe_enable && clahe_) {
    cv::Mat dst = clahe_buf_(roi);
    clahe_->apply(out.image, dst);
    out.image = dst;
  }
  return out;
}

void ImagePreprocessor::undistortPoints(std::vector<cv::Point2f>& pts) const {
  if (pts.empty()) return;
  std::vector<cv::Point2f> outp;
  cv::undistortPoints(pts, outp, cv::Mat(intr_.K), intr_.D, cv::noArray(), cv::Mat(intr_.K));
  pts.swap(outp);
}

void ImagePreprocessor::rectifyPoints(std::vector<cv::Point2f>& pts) const {
  if (cfg_.undistort_mode != UndistortMode::kCornersOnly) return;
  // 반복법 기본 5회 대신 정밀 수렴 조건 사용 (광각 주변부 오차 억제)
  if (pts.empty()) return;
  std::vector<cv::Point2f> outp;
  cv::undistortPoints(pts, outp, cv::Mat(intr_.K), intr_.D, cv::noArray(), cv::Mat(intr_.K),
                      cv::TermCriteria(cv::TermCriteria::COUNT | cv::TermCriteria::EPS, 20, 1e-6));
  pts.swap(outp);
}

cv::Rect ImagePreprocessor::rectifiedRoiToRaw(const cv::Rect& roi) const {
  // 보정 좌표계 ROI 의 테두리 샘플점을 원본(왜곡) 좌표로 투영하여 bounding box 산출
  std::vector<cv::Point3f> obj;
  const int n = 8;
  const double fx = intr_.K(0, 0), fy = intr_.K(1, 1), cx = intr_.K(0, 2), cy = intr_.K(1, 2);
  for (int i = 0; i <= n; ++i) {
    const double a = roi.x + roi.width * static_cast<double>(i) / n;
    const double b = roi.y + roi.height * static_cast<double>(i) / n;
    const double xs[4] = {a, a, static_cast<double>(roi.x), static_cast<double>(roi.x + roi.width)};
    const double ys[4] = {static_cast<double>(roi.y), static_cast<double>(roi.y + roi.height), b, b};
    for (int k = 0; k < 4; ++k)
      obj.emplace_back(static_cast<float>((xs[k] - cx) / fx), static_cast<float>((ys[k] - cy) / fy), 1.f);
  }
  std::vector<cv::Point2f> img;
  cv::projectPoints(obj, cv::Vec3d(0, 0, 0), cv::Vec3d(0, 0, 0), cv::Mat(intr_.K), intr_.D, img);
  cv::Rect r = cv::boundingRect(img);
  r.x -= 2; r.y -= 2; r.width += 4; r.height += 4;
  return r;
}

}  // namespace pva
