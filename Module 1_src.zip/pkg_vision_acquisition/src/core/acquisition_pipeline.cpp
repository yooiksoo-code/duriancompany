// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/acquisition_pipeline.hpp"

#include <pthread.h>
#include <sched.h>

#include <algorithm>
#include <climits>
#include <cstring>
#include <map>
#include <sstream>

#include "pkg_vision_acquisition/sim_camera.hpp"

namespace pva {

// ───────────────────────────── 스레드 설정 ─────────────────────────────
bool configureCurrentThread(const char* name, int rt_priority, int cpu, std::string& err) {
  bool ok = true;
  std::ostringstream es;
  pthread_setname_np(pthread_self(), name);
  if (cpu >= 0) {
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    if (pthread_setaffinity_np(pthread_self(), sizeof(set), &set) != 0) {
      es << name << ": CPU" << cpu << " 고정 실패; ";
      ok = false;
    }
  }
  if (rt_priority > 0) {
    sched_param sp{};
    sp.sched_priority = std::min(rt_priority, sched_get_priority_max(SCHED_FIFO));
    if (pthread_setschedparam(pthread_self(), SCHED_FIFO, &sp) != 0) {
      es << name << ": SCHED_FIFO(" << rt_priority << ") 설정 실패 (CAP_SYS_NICE/rtprio limit 확인); ";
      ok = false;
    }
  }
  err = es.str();
  return ok;
}

// ───────────────────────────── 채널 상태 ─────────────────────────────
struct AcquisitionPipeline::Channel {
  ChannelConfig cfg;
  size_t index = 0;
  uint8_t bit = 0;

  std::unique_ptr<ICameraDriver> drv;
  std::unique_ptr<FramePool> pool;
  std::unique_ptr<SpscRingBuffer<uint32_t>> filled;       // grab → worker
  std::unique_ptr<SpscRingBuffer<ChannelResult>> results; // worker → aggregator
  Doorbell frame_bell;

  std::unique_ptr<ImagePreprocessor> pre;
  std::unique_ptr<AprilTagDetectorCore> det;
  std::unique_ptr<OutlierRejectionFilter> filt;
  std::unique_ptr<DynamicRoi> roi;
  FrameBuffer scratch;  // 풀 고갈 시 SDK 큐 배출용

  std::thread grab_th, work_th;

  std::atomic<bool> link_up{false};     // 장치 open/start 상태
  std::atomic<bool> streaming{false};   // 최근 dropout_timeout 내 프레임 수신 여부 (동기 집계 기대 마스크)
  std::atomic<int64_t> last_frame_mono{0};
  int64_t next_reconnect_mono = 0;
  bool has_last_seq = false;
  uint64_t last_seq = 0;

  // 카운터 (단일 작성자 원자 변수)
  std::atomic<uint64_t> frames_grabbed{0}, frames_processed{0}, frames_skipped{0}, frames_nobuf{0},
      frames_incomplete{0}, seq_gaps{0}, lost_packets{0}, timeouts{0}, disconnects{0}, reconnects{0},
      roi_frames{0}, roi_fallbacks{0}, detections{0}, results_dropped{0};

  // 워커/수집 스레드가 갱신, stats() 가 읽음 (비경합 mutex)
  std::mutex st_mtx;
  LatencyStats work_lat{2048};
  FilterStats filt_snapshot;
  CameraStats cam_snapshot;
  RateMeter rate;

  std::vector<Detection> det_buf;
  std::vector<cv::Point2f> pt_buf;
};

// ───────────────────────────── 생성/시작/정지 ─────────────────────────────
AcquisitionPipeline::AcquisitionPipeline(PipelineConfig cfg) : cfg_(std::move(cfg)) {}

AcquisitionPipeline::~AcquisitionPipeline() { stop(); }

uint8_t AcquisitionPipeline::connectedMask() const {
  uint8_t m = 0;
  for (const auto& ch : channels_)
    if (ch->streaming.load(std::memory_order_relaxed)) m |= ch->bit;
  return m;
}

bool AcquisitionPipeline::start(std::string& err, bool require_all) {
  if (running_) return true;
  if (cfg_.channels.empty() || cfg_.channels.size() > static_cast<size_t>(kMaxCameras)) {
    err = "채널 수는 1~4 이어야 합니다";
    return false;
  }
  if (cfg_.filter.enable_whitelist && cfg_.filter.whitelist.empty()) cfg_.filter.whitelist = cfg_.bundle.ids();

  // sim 채널 공유 트리거 클럭
  std::shared_ptr<SimTriggerClock> sim_clock;
  for (auto& c : cfg_.channels)
    if (c.camera.driver == "sim" && c.camera.sim && c.camera.sim->clock) sim_clock = c.camera.sim->clock;

  channels_.clear();
  uint8_t used_bits = 0;
  for (size_t i = 0; i < cfg_.channels.size(); ++i) {
    auto ch = std::make_unique<Channel>();
    ch->cfg = cfg_.channels[i];
    ch->index = i;
    const int id = ch->cfg.camera.camera_id;
    if (id < 1 || id > kMaxCameras) {
      err = "camera_id 는 1~4 이어야 합니다";
      return false;
    }
    ch->bit = static_cast<uint8_t>(1u << (id - 1));
    if (used_bits & ch->bit) {
      err = "camera_id 중복: " + std::to_string(id);
      return false;
    }
    used_bits |= ch->bit;
    const auto& cam = ch->cfg.camera;
    const auto& intr = ch->cfg.intrinsics;
    if (intr.width != cam.width || intr.height != cam.height) {
      err = "ch" + std::to_string(id) + ": 내부파라미터 해상도(" + std::to_string(intr.width) + "x" +
            std::to_string(intr.height) + ")와 카메라 해상도 불일치";
      return false;
    }
    if (cam.driver == "sim" && cam.sim && !cam.sim->clock) {
      if (!sim_clock) sim_clock = std::make_shared<SimTriggerClock>(cam.fps);
      cam.sim->clock = sim_clock;
      ch->cfg.camera.sim->clock = sim_clock;
    }
    ch->drv = createCameraDriver(ch->cfg.camera, err);
    if (!ch->drv) return false;

    const size_t nbuf = static_cast<size_t>(std::max(3, cfg_.pool_buffers));
    ch->pool = std::make_unique<FramePool>(nbuf, cam.width, cam.height);
    // filled 링 용량 ≥ 풀 크기 → push 실패 불가 (free 링의 SPSC 조건 유지)
    ch->filled = std::make_unique<SpscRingBuffer<uint32_t>>(nbuf + 1);
    ch->results = std::make_unique<SpscRingBuffer<ChannelResult>>(static_cast<size_t>(std::max(4, cfg_.ring_capacity)));
    ch->scratch.allocate(cam.width, cam.height);
    try {
      ch->pre = std::make_unique<ImagePreprocessor>(intr, cfg_.preprocess);
      ch->det = std::make_unique<AprilTagDetectorCore>(cfg_.detector);
    } catch (const std::exception& e) {
      err = "ch" + std::to_string(id) + ": " + e.what();
      return false;
    }
    ch->filt = std::make_unique<OutlierRejectionFilter>(cfg_.filter);
    ch->roi = std::make_unique<DynamicRoi>(cfg_.roi, intr, ch->cfg.T_world_cam, cfg_.bundle);
    ch->det_buf.reserve(64);
    channels_.push_back(std::move(ch));
  }

  // 초기 연결
  for (auto& ch : channels_) {
    std::string e;
    if (ch->drv->open(e) && ch->drv->start(e)) {
      ch->link_up = true;
      ch->streaming = true;
      ch->last_frame_mono = monoNowNs();
      pushEvent(EventCode::kInfo, ch->cfg.camera.camera_id, "연결: " + ch->drv->describe());
    } else {
      ch->drv->close();
      if (require_all) {
        err = "ch" + std::to_string(ch->cfg.camera.camera_id) + " 연결 실패: " + e;
        channels_.clear();
        return false;
      }
      ch->next_reconnect_mono = monoNowNs() + static_cast<int64_t>(cfg_.health.reconnect_interval_ms) * 1'000'000;
      pushEvent(EventCode::kCamDropout, ch->cfg.camera.camera_id, "초기 연결 실패: " + e);
    }
  }

  // 시뮬레이터: 사전렌더 완료 후 트리거 클럭 원점 재설정 (장애 주입 시각 기준점)
  if (sim_clock) sim_clock->restart();

  running_ = true;
  heartbeat_mono_ns_ = monoNowNs();
  for (auto& ch : channels_) {
    Channel* c = ch.get();
    c->grab_th = std::thread([this, c] { grabLoop(*c); });
    c->work_th = std::thread([this, c] { workerLoop(*c); });
  }
  aggregator_ = std::thread([this] { aggregatorLoop(); });
  return true;
}

void AcquisitionPipeline::stop() {
  if (!running_.exchange(false)) return;
  for (auto& ch : channels_) ch->frame_bell.notify();
  agg_bell_.notify();
  for (auto& ch : channels_) {
    if (ch->grab_th.joinable()) ch->grab_th.join();
    if (ch->work_th.joinable()) ch->work_th.join();
  }
  if (aggregator_.joinable()) aggregator_.join();
  for (auto& ch : channels_) {
    ch->drv->stop();
    ch->drv->close();
    ch->link_up = false;
    ch->streaming = false;
  }
}

// ───────────────────────────── 이벤트 ─────────────────────────────
void AcquisitionPipeline::pushEvent(EventCode code, uint8_t cam, const std::string& msg) {
  std::lock_guard<std::mutex> lk(event_mtx_);
  events_.push_back(PipelineEvent{code, cam, msg});
}

void AcquisitionPipeline::drainEvents() {
  std::vector<PipelineEvent> ev;
  {
    std::lock_guard<std::mutex> lk(event_mtx_);
    if (events_.empty()) return;
    ev.swap(events_);
  }
  // 동일 (코드, 채널) 이벤트 반복 억제
  static thread_local std::map<int, int64_t> last_emit;
  const int64_t now = monoNowNs();
  const int64_t throttle = static_cast<int64_t>(cfg_.health.event_throttle_ms) * 1'000'000;
  for (const auto& e : ev) {
    const int key = static_cast<int>(e.code) * 16 + e.camera_id;
    const bool always = e.code == EventCode::kCamDropout || e.code == EventCode::kCamRecovered ||
                        e.code == EventCode::kInfo;
    auto it = last_emit.find(key);
    if (!always && it != last_emit.end() && now - it->second < throttle) continue;
    last_emit[key] = now;
    if (on_event_) on_event_(e);
  }
}

// ───────────────────────────── 수집 스레드 (MultiCamSyncGrabber) ─────────────────────────────
void AcquisitionPipeline::grabLoop(Channel& ch) {
  const uint8_t id = ch.cfg.camera.camera_id;
  {
    std::string e;
    const std::string name = "pva_grab" + std::to_string(id);
    const int cpu = ch.index < cfg_.threads.cpu_grab.size() ? cfg_.threads.cpu_grab[ch.index] : -1;
    if (!configureCurrentThread(name.c_str(), cfg_.threads.rt_priority_grab, cpu, e))
      pushEvent(EventCode::kInfo, id, e);
  }
  const int64_t dropout_ns = static_cast<int64_t>(cfg_.health.dropout_timeout_ms) * 1'000'000;
  const int64_t reconnect_ns = static_cast<int64_t>(cfg_.health.reconnect_interval_ms) * 1'000'000;
  uint32_t held = FramePool::kInvalid;  // 수집 스레드가 보유한 빈 버퍼 (반납 없이 재사용 → SPSC 유지)
  uint64_t n = 0;

  auto linkDown = [&](const std::string& why) {
    ch.drv->stop();
    ch.drv->close();
    ch.link_up = false;
    if (ch.streaming.exchange(false)) pushEvent(EventCode::kCamDropout, id, why);
    ++ch.disconnects;
    ch.next_reconnect_mono = monoNowNs() + reconnect_ns;
    agg_bell_.notify();  // 기대 마스크 즉시 갱신
  };

  while (running_.load(std::memory_order_relaxed)) {
    if (!ch.link_up) {
      const int64_t now = monoNowNs();
      if (now < ch.next_reconnect_mono) {
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
        continue;
      }
      std::string e;
      if (ch.drv->open(e) && ch.drv->start(e)) {
        ch.link_up = true;
        ch.has_last_seq = false;
        ch.last_frame_mono = monoNowNs();
        ++ch.reconnects;
        pushEvent(EventCode::kInfo, id, "재연결 성공: " + ch.drv->describe());
      } else {
        ch.drv->close();
        ch.next_reconnect_mono = now + reconnect_ns;
      }
      continue;
    }

    if (held == FramePool::kInvalid) held = ch.pool->acquire();
    FrameBuffer& buf = (held != FramePool::kInvalid) ? ch.pool->at(held) : ch.scratch;
    const auto st = ch.drv->grab(buf, ch.cfg.camera.grab_timeout_ms);
    const int64_t now = monoNowNs();

    switch (st) {
      case ICameraDriver::GrabStatus::kOk: {
        buf.meta.recv_mono_ns = now;
        ch.last_frame_mono.store(now, std::memory_order_relaxed);
        if (!ch.streaming.exchange(true)) pushEvent(EventCode::kCamRecovered, id, "프레임 수신 재개");
        ch.frames_grabbed.fetch_add(1, std::memory_order_relaxed);
        if (ch.has_last_seq && buf.meta.frame_seq > ch.last_seq + 1)
          ch.seq_gaps.fetch_add(buf.meta.frame_seq - ch.last_seq - 1, std::memory_order_relaxed);
        ch.last_seq = buf.meta.frame_seq;
        ch.has_last_seq = true;
        if (buf.meta.lost_packets) ch.lost_packets.fetch_add(buf.meta.lost_packets, std::memory_order_relaxed);
        if (held == FramePool::kInvalid) {
          ch.frames_nobuf.fetch_add(1, std::memory_order_relaxed);  // 워커 과부하
        } else {
          ch.filled->tryPush(held);  // 용량 보장 → 실패 없음
          held = FramePool::kInvalid;
          ch.frame_bell.notify();
        }
        break;
      }
      case ICameraDriver::GrabStatus::kTimeout:
        ch.timeouts.fetch_add(1, std::memory_order_relaxed);
        // 장치는 살아있으나 프레임 없음 (트리거 정지/케이블 일부 이상) → 집계 기대 마스크에서 제외
        if (now - ch.last_frame_mono.load() > dropout_ns && ch.streaming.exchange(false)) {
          pushEvent(EventCode::kCamDropout, id,
                    "프레임 미수신 " + std::to_string(cfg_.health.dropout_timeout_ms) + "ms 초과");
          agg_bell_.notify();
        }
        break;
      case ICameraDriver::GrabStatus::kIncomplete:
        ch.frames_incomplete.fetch_add(1, std::memory_order_relaxed);
        ch.last_frame_mono.store(now, std::memory_order_relaxed);
        pushEvent(EventCode::kPacketLoss, id, "불완전 프레임 (GVSP 패킷 손실)");
        break;
      case ICameraDriver::GrabStatus::kDisconnected:
        linkDown("카메라 통신 단절 (링크/전원)");
        break;
    }
    if ((++n & 63u) == 0) {
      const CameraStats cs = ch.drv->stats();
      std::lock_guard<std::mutex> lk(ch.st_mtx);
      ch.cam_snapshot = cs;
    }
  }
}

// ───────────────────────────── 워커 스레드 ─────────────────────────────
void AcquisitionPipeline::workerLoop(Channel& ch) {
  const uint8_t id = ch.cfg.camera.camera_id;
  {
    std::string e;
    const std::string name = "pva_work" + std::to_string(id);
    const int cpu = ch.index < cfg_.threads.cpu_worker.size() ? cfg_.threads.cpu_worker[ch.index] : -1;
    if (!configureCurrentThread(name.c_str(), cfg_.threads.rt_priority_worker, cpu, e))
      pushEvent(EventCode::kInfo, id, e);
  }
  while (running_.load(std::memory_order_relaxed)) {
    if (!ch.frame_bell.wait(std::chrono::milliseconds(50), cfg_.threads.worker_spin_us)) continue;
    // 최신 프레임만 처리 (지연 누적 방지). 오래된 프레임은 즉시 풀에 반납.
    uint32_t latest = FramePool::kInvalid, idx = 0;
    while (ch.filled->tryPop(idx)) {
      if (latest != FramePool::kInvalid) {
        ch.pool->release(latest);
        ch.frames_skipped.fetch_add(1, std::memory_order_relaxed);
      }
      latest = idx;
    }
    if (latest == FramePool::kInvalid) continue;

    ChannelResult res;
    processFrame(ch, ch.pool->at(latest), res);
    ch.pool->release(latest);
    if (!ch.results->tryPush(std::move(res))) ch.results_dropped.fetch_add(1, std::memory_order_relaxed);
    agg_bell_.notify();
  }
}

void AcquisitionPipeline::processFrame(Channel& ch, FrameBuffer& frame, ChannelResult& res) {
  const int64_t t0 = monoNowNs();
  const uint8_t id = ch.cfg.camera.camera_id;
  res.meta = frame.meta;

  PoseSnapshot ps;
  const bool has_pose = pose_.load(ps);
  RoiSource src = RoiSource::kFull;
  const cv::Rect roi = ch.roi->compute(frame.meta.stamp_ns, has_pose ? &ps : nullptr, &src);
  const cv::Mat raw = frame.view();
  auto& dets = ch.det_buf;
  uint32_t rejected = 0;

  auto runOnce = [&](const cv::Rect& r) {
    const int64_t a = monoNowNs();
    const PreprocessOutput pre = ch.pre->process(raw, r);
    const int64_t b = monoNowNs();
    dets.clear();
    ch.det->detect(pre.image, pre.offset, id, dets);
    if (!pre.rectified && !dets.empty()) {
      auto& pts = ch.pt_buf;
      pts.clear();
      for (const auto& d : dets) {
        pts.insert(pts.end(), d.corners.begin(), d.corners.end());
        pts.push_back(d.center);
      }
      ch.pre->rectifyPoints(pts);
      for (size_t i = 0; i < dets.size(); ++i) {
        for (int k = 0; k < 4; ++k) dets[i].corners[k] = pts[i * 5 + k];
        dets[i].center = pts[i * 5 + 4];
      }
    }
    const int64_t c = monoNowNs();
    rejected += ch.filt->apply(dets);
    const int64_t d = monoNowNs();
    res.preprocess_ms += (b - a) * 1e-6;
    res.detect_ms += (c - b) * 1e-6;
    res.filter_ms += (d - c) * 1e-6;
  };

  runOnce(roi);
  res.roi_used = roi.area() > 0;
  res.roi = res.roi_used ? roi : cv::Rect(0, 0, raw.cols, raw.rows);
  if (res.roi_used && dets.empty() && cfg_.roi.retry_full_frame_on_miss) {
    runOnce(cv::Rect());  // 설계 요구: 태그 미검출 시 즉시 Full Frame 탐색 복귀
    res.roi_fallback = true;
  }
  ch.roi->update(dets);
  res.detections.assign(dets.begin(), dets.end());
  res.rejected = rejected;
  res.done_mono_ns = monoNowNs();

  ch.frames_processed.fetch_add(1, std::memory_order_relaxed);
  ch.detections.fetch_add(dets.size(), std::memory_order_relaxed);
  if (res.roi_used) ch.roi_frames.fetch_add(1, std::memory_order_relaxed);
  if (res.roi_fallback) ch.roi_fallbacks.fetch_add(1, std::memory_order_relaxed);
  std::lock_guard<std::mutex> lk(ch.st_mtx);
  ch.work_lat.add((res.done_mono_ns - t0) * 1e-6);
  ch.filt_snapshot = ch.filt->stats();
  ch.rate.tick(res.done_mono_ns);
}

// ───────────────────────────── 동기 집계 스레드 ─────────────────────────────
namespace {
struct Slot {
  bool used = false;
  int64_t stamp_ref = 0;
  uint8_t mask = 0;
  int64_t first_arrival = 0;
  std::array<ChannelResult, kMaxCameras> res;
};
}  // namespace

void AcquisitionPipeline::aggregatorLoop() {
  {
    std::string e;
    if (!configureCurrentThread("pva_agg", cfg_.threads.rt_priority_aggregator, cfg_.threads.cpu_aggregator, e))
      pushEvent(EventCode::kInfo, 0, e);
  }
  const int64_t window_ns = static_cast<int64_t>(cfg_.sync.window_us * 1e3);
  const int64_t tol_ns = static_cast<int64_t>(cfg_.sync.tolerance_us * 1e3);
  const int64_t max_wait_ns = static_cast<int64_t>(cfg_.sync.max_wait_ms * 1e6);

  std::array<Slot, 8> slots;
  std::array<int, kMaxCameras + 1> cam_to_idx{};
  cam_to_idx.fill(-1);
  for (const auto& ch : channels_) cam_to_idx[ch->cfg.camera.camera_id] = static_cast<int>(ch->index);

  int64_t last_pub_stamp = INT64_MIN;
  uint64_t sync_seq = 0;
  int empty_streak = 0;
  SyncedResult out;
  out.detections.reserve(128);

  auto publish = [&](Slot& s, uint8_t expected) {
    out.detections.clear();
    out.channel_work_ms.fill(0.0);
    out.channel_roi_used.fill(false);
    int64_t smin = INT64_MAX, smax = INT64_MIN, base = 0, acc = 0, earliest = INT64_MAX;
    int n = 0;
    for (const auto& ch : channels_) {
      if (!(s.mask & ch->bit)) continue;
      const ChannelResult& r = s.res[ch->index];
      if (n == 0) base = r.meta.stamp_ns;
      acc += r.meta.stamp_ns - base;
      ++n;
      smin = std::min(smin, r.meta.stamp_ns);
      smax = std::max(smax, r.meta.stamp_ns);
      earliest = std::min(earliest, r.meta.recv_mono_ns);
      out.detections.insert(out.detections.end(), r.detections.begin(), r.detections.end());
      out.channel_work_ms[ch->index] = r.preprocess_ms + r.detect_ms + r.filter_ms;
      out.channel_roi_used[ch->index] = r.roi_used;
    }
    s.used = false;
    if (n == 0) return;
    out.sync_seq = ++sync_seq;
    out.stamp_ns = base + acc / n;
    out.stamp_spread_ns = smax - smin;
    out.stamp_max_dev_ns = 0;
    for (const auto& ch : channels_)
      if (s.mask & ch->bit)
        out.stamp_max_dev_ns = std::max<int64_t>(out.stamp_max_dev_ns, std::llabs(s.res[ch->index].meta.stamp_ns - out.stamp_ns));
    out.active_camera_mask = s.mask;
    out.earliest_recv_mono_ns = earliest;
    last_pub_stamp = std::max(last_pub_stamp, smax);

    const int64_t now = monoNowNs();
    out.processing_time_ms = static_cast<double>(now - earliest) * 1e-6;
    if (on_result_) on_result_(out);

    const bool partial = (s.mask & expected) != expected || expected == 0;
    const bool empty = out.detections.empty();
    {
      std::lock_guard<std::mutex> lk(stats_mtx_);
      ++agg_stats_.published;
      if (partial) ++agg_stats_.partial_published;
      if (empty) ++agg_stats_.empty_published;
      processing_lat_.add(out.processing_time_ms);
      spread_lat_.add(out.stamp_max_dev_ns * 1e-3);
      publish_rate_.tick(now);
      if (n > 1 && out.stamp_max_dev_ns > tol_ns) ++agg_stats_.sync_violations;
    }
    if (n > 1 && out.stamp_max_dev_ns > tol_ns)
      pushEvent(EventCode::kSyncViolation, 0,
                "노출 시점 편차 ±" + std::to_string(out.stamp_max_dev_ns / 1000) + "us > 허용 ±" +
                    std::to_string(tol_ns / 1000) + "us");
    if (empty) {
      if (++empty_streak == cfg_.health.occlusion_warn_cycles)
        pushEvent(EventCode::kTotalOcclusion, 0, "연속 " + std::to_string(empty_streak) + " 주기 태그 미검출 (차폐/역광)");
    } else {
      empty_streak = 0;
    }
  };

  auto place = [&](ChannelResult&& r) {
    const int ci = (r.meta.camera_id <= kMaxCameras) ? cam_to_idx[r.meta.camera_id] : -1;
    if (ci < 0) return;
    if (last_pub_stamp != INT64_MIN && r.meta.stamp_ns - last_pub_stamp < window_ns) {
      std::lock_guard<std::mutex> lk(stats_mtx_);
      ++agg_stats_.late_results;  // 이미 발행된(또는 더 과거) 주기의 결과
      return;
    }
    const uint8_t bit = channels_[static_cast<size_t>(ci)]->bit;
    Slot* target = nullptr;
    for (auto& s : slots)
      if (s.used && std::llabs(r.meta.stamp_ns - s.stamp_ref) <= window_ns && !(s.mask & bit)) {
        target = &s;
        break;
      }
    if (!target) {
      for (auto& s : slots)
        if (!s.used) { target = &s; break; }
      if (!target) {  // 슬롯 포화 → 가장 오래된 슬롯 강제 발행
        Slot* oldest = &slots[0];
        for (auto& s : slots)
          if (s.stamp_ref < oldest->stamp_ref) oldest = &s;
        publish(*oldest, connectedMask());
        target = oldest;
      }
      target->used = true;
      target->mask = 0;
      target->stamp_ref = r.meta.stamp_ns;
      target->first_arrival = monoNowNs();
    }
    target->res[static_cast<size_t>(ci)] = std::move(r);
    target->mask |= bit;
  };

  while (running_.load(std::memory_order_relaxed)) {
    const int64_t now0 = monoNowNs();
    heartbeat_mono_ns_.store(now0, std::memory_order_relaxed);
    int64_t wait_ns = 20'000'000;
    for (const auto& s : slots)
      if (s.used) wait_ns = std::min(wait_ns, std::max<int64_t>(0, s.first_arrival + max_wait_ns - now0));
    agg_bell_.wait(std::chrono::nanoseconds(wait_ns));

    for (auto& ch : channels_) {
      ChannelResult r;
      while (ch->results->tryPop(r)) place(std::move(r));
    }

    // 타임스탬프 순 발행
    for (;;) {
      Slot* oldest = nullptr;
      for (auto& s : slots)
        if (s.used && (!oldest || s.stamp_ref < oldest->stamp_ref)) oldest = &s;
      if (!oldest) break;
      const uint8_t expected = connectedMask();
      uint8_t have = oldest->mask;
      for (const auto& s : slots)  // 더 최신 주기를 이미 보낸 채널은 이 주기를 건너뛴 것
        if (s.used && s.stamp_ref > oldest->stamp_ref) have |= s.mask;
      const bool complete = expected != 0 && (have & expected) == expected;
      const bool expired = monoNowNs() >= oldest->first_arrival + max_wait_ns;
      if (!(complete || expired)) break;
      publish(*oldest, expected);
    }
    drainEvents();
  }
}

// ───────────────────────────── 통계 ─────────────────────────────
PipelineStats AcquisitionPipeline::stats() {
  PipelineStats s;
  {
    std::lock_guard<std::mutex> lk(stats_mtx_);
    s = agg_stats_;
    s.processing_ms = processing_lat_.summary();
    s.stamp_dev_us = spread_lat_.summary();
    s.publish_fps = publish_rate_.rate();
  }
  s.channels.clear();
  for (auto& ch : channels_) {
    ChannelStats c;
    c.camera_id = ch->cfg.camera.camera_id;
    c.connected = ch->streaming.load();
    c.frames_grabbed = ch->frames_grabbed.load();
    c.frames_processed = ch->frames_processed.load();
    c.frames_skipped_stale = ch->frames_skipped.load();
    c.frames_dropped_nobuf = ch->frames_nobuf.load();
    c.frames_incomplete = ch->frames_incomplete.load();
    c.seq_gaps = ch->seq_gaps.load();
    c.lost_packets = ch->lost_packets.load();
    c.timeouts = ch->timeouts.load();
    c.disconnects = ch->disconnects.load();
    c.reconnects = ch->reconnects.load();
    c.roi_frames = ch->roi_frames.load();
    c.roi_fallbacks = ch->roi_fallbacks.load();
    c.detections = ch->detections.load();
    {
      std::lock_guard<std::mutex> lk(ch->st_mtx);
      c.filter = ch->filt_snapshot;
      c.camera = ch->cam_snapshot;
      c.fps = ch->rate.rate();
      c.work_ms = ch->work_lat.summary();
    }
    s.channels.push_back(c);
  }
  return s;
}

}  // namespace pva
