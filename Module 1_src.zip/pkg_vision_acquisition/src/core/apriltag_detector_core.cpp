// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/apriltag_detector_core.hpp"

#include <cmath>
#include <stdexcept>

extern "C" {
#include <apriltag/apriltag.h>
#include <apriltag/tag36h11.h>
}

namespace pva {

AprilTagDetectorCore::AprilTagDetectorCore(const DetectorConfig& cfg) : cfg_(cfg) {
  tf_ = tag36h11_create();
  td_ = apriltag_detector_create();
  if (!tf_ || !td_) throw std::runtime_error("apriltag detector 생성 실패");
  // max_hamming 은 사전 생성되는 디코딩 해시 테이블 크기와 오검출률을 좌우 (≤1 권장)
  apriltag_detector_add_family_bits(td_, tf_, cfg_.max_hamming);

  td_->quad_decimate = cfg_.quad_decimate;
  td_->quad_sigma = cfg_.quad_sigma;
  td_->nthreads = cfg_.nthreads;
  td_->refine_edges = cfg_.refine_edges;
  td_->decode_sharpening = cfg_.decode_sharpening;
  td_->debug = false;

  td_->qtp.min_white_black_diff = cfg_.min_white_black_diff;
  td_->qtp.min_cluster_pixels = cfg_.min_cluster_pixels;
  td_->qtp.max_nmaxima = cfg_.max_nmaxima;
  td_->qtp.critical_rad = static_cast<float>(cfg_.critical_angle_deg * M_PI / 180.0);
  td_->qtp.cos_critical_rad = std::cos(td_->qtp.critical_rad);
  td_->qtp.max_line_fit_mse = cfg_.max_line_fit_mse;
  td_->qtp.deglitch = cfg_.deglitch;
}

AprilTagDetectorCore::~AprilTagDetectorCore() {
  if (td_) apriltag_detector_destroy(td_);
  if (tf_) tag36h11_destroy(tf_);
}

void AprilTagDetectorCore::detect(const cv::Mat& image, const cv::Point2f& offset, uint8_t camera_id,
                                  std::vector<Detection>& out) {
  CV_Assert(image.type() == CV_8UC1);
  if (image.cols < 16 || image.rows < 16) return;

  // cv::Mat (ROI 뷰 포함) 를 복사 없이 image_u8_t 로 래핑
  image_u8_t im{image.cols, image.rows, static_cast<int32_t>(image.step[0]),
                const_cast<uint8_t*>(image.ptr<uint8_t>(0))};

  zarray_t* dets = apriltag_detector_detect(td_, &im);
  const float ox = offset.x + cfg_.pixel_center_offset;
  const float oy = offset.y + cfg_.pixel_center_offset;
  const int n = zarray_size(dets);
  out.reserve(out.size() + static_cast<size_t>(n));
  for (int i = 0; i < n; ++i) {
    apriltag_detection_t* d = nullptr;
    zarray_get(dets, i, &d);
    Detection o;
    o.camera_id = camera_id;
    o.tag_id = d->id;
    o.decision_margin = d->decision_margin;
    o.hamming = static_cast<uint8_t>(d->hamming);
    for (int k = 0; k < 4; ++k)
      o.corners[k] = cv::Point2f(static_cast<float>(d->p[k][0]) + ox, static_cast<float>(d->p[k][1]) + oy);
    o.center = cv::Point2f(static_cast<float>(d->c[0]) + ox, static_cast<float>(d->c[1]) + oy);
    out.push_back(o);
  }
  apriltag_detections_destroy(dets);
}

}  // namespace pva
