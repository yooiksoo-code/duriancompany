// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/geometry.hpp"

#include <cmath>
#include <fstream>

#include <yaml-cpp/yaml.h>

namespace pva {

namespace {
constexpr double kDeg2Rad = M_PI / 180.0;

std::vector<double> readVec(const YAML::Node& n) {
  std::vector<double> v;
  if (!n) return v;
  // ROS 포맷: {rows, cols, data: [...]} / 간이 포맷: [...]
  const YAML::Node data = (n.IsMap() && n["data"]) ? n["data"] : n;
  if (!data.IsSequence()) return v;
  for (const auto& e : data) v.push_back(e.as<double>());
  return v;
}

Pose3 readPose(const YAML::Node& n) {
  Pose3 p;
  if (!n) return p;
  if (n["position"]) {
    const auto t = readVec(n["position"]);
    if (t.size() == 3) p.t = cv::Vec3d(t[0], t[1], t[2]);
  }
  if (n["x"]) p.t = cv::Vec3d(n["x"].as<double>(), n["y"].as<double>(), n["z"].as<double>());
  if (n["rpy_deg"]) {
    const auto r = readVec(n["rpy_deg"]);
    if (r.size() == 3) p.R = rotationFromRpyDeg(r[0], r[1], r[2]);
  } else if (n["quaternion"]) {  // [qw, qx, qy, qz]
    const auto q = readVec(n["quaternion"]);
    if (q.size() == 4) p.R = rotationFromQuaternion(q[0], q[1], q[2], q[3]);
  } else if (n["qw"]) {
    p.R = rotationFromQuaternion(n["qw"].as<double>(), n["qx"].as<double>(), n["qy"].as<double>(),
                                 n["qz"].as<double>());
  } else if (n["rotation"]) {  // row-major 3x3
    const auto r = readVec(n["rotation"]);
    if (r.size() == 9) p.R = cv::Matx33d(r.data());
  }
  return p;
}
}  // namespace

cv::Matx33d rotationFromRpyDeg(double roll, double pitch, double yaw) {
  const double r = roll * kDeg2Rad, p = pitch * kDeg2Rad, y = yaw * kDeg2Rad;
  const cv::Matx33d Rx(1, 0, 0, 0, std::cos(r), -std::sin(r), 0, std::sin(r), std::cos(r));
  const cv::Matx33d Ry(std::cos(p), 0, std::sin(p), 0, 1, 0, -std::sin(p), 0, std::cos(p));
  const cv::Matx33d Rz(std::cos(y), -std::sin(y), 0, std::sin(y), std::cos(y), 0, 0, 0, 1);
  return Rz * Ry * Rx;  // ROS 규약 (고정축 XYZ = 회전축 ZYX)
}

cv::Matx33d rotationFromQuaternion(double w, double x, double y, double z) {
  const double n = std::sqrt(w * w + x * x + y * y + z * z);
  if (n < 1e-12) return cv::Matx33d::eye();
  w /= n; x /= n; y /= n; z /= n;
  return cv::Matx33d(1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w),
                     2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w),
                     2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y));
}

std::array<cv::Point3d, 4> tagCornersInTagFrame(double size) {
  const double s = size * 0.5;
  return {cv::Point3d(-s, s, 0), cv::Point3d(s, s, 0), cv::Point3d(s, -s, 0), cv::Point3d(-s, -s, 0)};
}

std::vector<cv::Point3d> TagBundle::allCornersBody() const {
  std::vector<cv::Point3d> pts;
  pts.reserve(tags.size() * 4);
  for (const auto& t : tags) {
    for (const auto& c : tagCornersInTagFrame(t.size)) {
      const cv::Vec3d pb = t.T_body_tag * cv::Vec3d(c.x, c.y, c.z);
      pts.emplace_back(pb[0], pb[1], pb[2]);
    }
  }
  return pts;
}

bool loadIntrinsics(const std::string& path, CameraIntrinsics& out, std::string& err) {
  try {
    const YAML::Node y = YAML::LoadFile(path);
    out = CameraIntrinsics{};
    out.camera_name = y["camera_name"] ? y["camera_name"].as<std::string>() : "";
    if (y["image_width"]) {
      out.width = y["image_width"].as<int>();
      out.height = y["image_height"].as<int>();
    } else {
      out.width = y["width"].as<int>();
      out.height = y["height"].as<int>();
    }
    auto K = readVec(y["camera_matrix"] ? y["camera_matrix"] : y["K"]);
    auto D = readVec(y["distortion_coefficients"] ? y["distortion_coefficients"] : y["D"]);
    if (K.size() != 9) {
      err = path + ": camera_matrix/K 는 9개 원소가 필요합니다";
      return false;
    }
    out.K = cv::Matx33d(K.data());
    if (D.empty()) D = {0, 0, 0, 0, 0};
    out.D = cv::Mat(1, static_cast<int>(D.size()), CV_64F);
    for (size_t i = 0; i < D.size(); ++i) out.D.at<double>(0, static_cast<int>(i)) = D[i];
    if (y["distortion_model"]) out.distortion_model = y["distortion_model"].as<std::string>();
    if (out.distortion_model != "plumb_bob" && out.distortion_model != "rational_polynomial") {
      err = path + ": 지원하지 않는 distortion_model '" + out.distortion_model + "'";
      return false;
    }
    if (!out.valid()) {
      err = path + ": 유효하지 않은 내부 파라미터";
      return false;
    }
    return true;
  } catch (const std::exception& e) {
    err = path + ": " + e.what();
    return false;
  }
}

bool saveIntrinsicsRos(const std::string& path, const CameraIntrinsics& in, double rms_error) {
  YAML::Emitter e;
  e << YAML::BeginMap;
  e << YAML::Key << "image_width" << YAML::Value << in.width;
  e << YAML::Key << "image_height" << YAML::Value << in.height;
  e << YAML::Key << "camera_name" << YAML::Value << in.camera_name;
  e << YAML::Key << "camera_matrix" << YAML::Value << YAML::BeginMap;
  e << YAML::Key << "rows" << YAML::Value << 3 << YAML::Key << "cols" << YAML::Value << 3;
  e << YAML::Key << "data" << YAML::Value << YAML::Flow << YAML::BeginSeq;
  for (int i = 0; i < 9; ++i) e << in.K.val[i];
  e << YAML::EndSeq << YAML::EndMap;
  e << YAML::Key << "distortion_model" << YAML::Value << in.distortion_model;
  e << YAML::Key << "distortion_coefficients" << YAML::Value << YAML::BeginMap;
  e << YAML::Key << "rows" << YAML::Value << 1 << YAML::Key << "cols" << YAML::Value
    << static_cast<int>(in.D.total());
  e << YAML::Key << "data" << YAML::Value << YAML::Flow << YAML::BeginSeq;
  for (size_t i = 0; i < in.D.total(); ++i) e << in.D.at<double>(0, static_cast<int>(i));
  e << YAML::EndSeq << YAML::EndMap;
  // 하류(pose_estimation_node) 참고용: 보정 후 영상은 K 동일, D = 0 인 이상적 핀홀
  e << YAML::Key << "rectification_matrix" << YAML::Value << YAML::BeginMap;
  e << YAML::Key << "rows" << YAML::Value << 3 << YAML::Key << "cols" << YAML::Value << 3;
  e << YAML::Key << "data" << YAML::Value << YAML::Flow << YAML::BeginSeq << 1 << 0 << 0 << 0 << 1
    << 0 << 0 << 0 << 1 << YAML::EndSeq << YAML::EndMap;
  e << YAML::Key << "projection_matrix" << YAML::Value << YAML::BeginMap;
  e << YAML::Key << "rows" << YAML::Value << 3 << YAML::Key << "cols" << YAML::Value << 4;
  e << YAML::Key << "data" << YAML::Value << YAML::Flow << YAML::BeginSeq << in.K(0, 0) << in.K(0, 1)
    << in.K(0, 2) << 0 << in.K(1, 0) << in.K(1, 1) << in.K(1, 2) << 0 << 0 << 0 << 1 << 0
    << YAML::EndSeq << YAML::EndMap;
  if (rms_error >= 0) e << YAML::Key << "calibration_rms_px" << YAML::Value << rms_error;
  e << YAML::EndMap;
  std::ofstream f(path);
  if (!f) return false;
  f << e.c_str() << "\n";
  return static_cast<bool>(f);
}

bool loadExtrinsics(const std::string& path, std::map<int, Pose3>& out, std::string& world_frame,
                    std::string& err) {
  try {
    const YAML::Node y = YAML::LoadFile(path);
    out.clear();
    world_frame = y["world_frame"] ? y["world_frame"].as<std::string>() : "dock";
    const YAML::Node cams = y["cameras"];
    if (!cams || !cams.IsSequence()) {
      err = path + ": 'cameras' 시퀀스가 필요합니다";
      return false;
    }
    for (const auto& c : cams) {
      const int id = c["camera_id"].as<int>();
      out[id] = readPose(c["T_world_cam"]);
    }
    return true;
  } catch (const std::exception& e) {
    err = path + ": " + e.what();
    return false;
  }
}

bool loadTagBundle(const std::string& path, TagBundle& out, std::string& err) {
  try {
    const YAML::Node y = YAML::LoadFile(path);
    out = TagBundle{};
    if (y["name"]) out.name = y["name"].as<std::string>();
    const double default_size = y["default_size"] ? y["default_size"].as<double>() : 0.1;
    const YAML::Node layout = y["layout"];
    if (!layout || !layout.IsSequence()) {
      err = path + ": 'layout' 시퀀스가 필요합니다";
      return false;
    }
    for (const auto& n : layout) {
      TagDef t;
      t.id = n["id"].as<int>();
      t.size = n["size"] ? n["size"].as<double>() : default_size;
      t.T_body_tag = readPose(n);
      out.tags.push_back(t);
    }
    return !out.tags.empty();
  } catch (const std::exception& e) {
    err = path + ": " + e.what();
    return false;
  }
}

}  // namespace pva
