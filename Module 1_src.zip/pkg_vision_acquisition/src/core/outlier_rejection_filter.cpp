// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/outlier_rejection_filter.hpp"

#include <algorithm>
#include <cmath>
#include <unordered_map>

namespace pva {

namespace {
inline float cross(const cv::Point2f& o, const cv::Point2f& a, const cv::Point2f& b) {
  return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}
inline float dist(const cv::Point2f& a, const cv::Point2f& b) { return std::hypot(a.x - b.x, a.y - b.y); }
}  // namespace

int OutlierRejectionFilter::expectedWindingSign() {
  // AprilTag 3: det->p 는 태그 좌표 (-1,1)->(1,1)->(1,-1)->(-1,-1) 순 ("counter-clockwise").
  // 정상 영상에서는 이미지 좌표(y 아래) 외적 (p1-p0)x(p2-p0) < 0 이며,
  // 수면 거울 반사상은 좌우가 뒤집혀 부호가 반대가 된다.
  // (test_detector.WindingSignAndMirrorRejection 에서 실측 검증된 값)
  return -1;
}

OutlierRejectionFilter::OutlierRejectionFilter(const FilterConfig& cfg) : cfg_(cfg) {}

OutlierRejectionFilter::Reason OutlierRejectionFilter::check(const Detection& d) const {
  if (d.hamming > cfg_.max_hamming) return Reason::kHighHamming;
  if (d.decision_margin < cfg_.min_decision_margin) return Reason::kLowMargin;
  if (cfg_.enable_whitelist && cfg_.whitelist.find(d.tag_id) == cfg_.whitelist.end())
    return Reason::kNotWhitelisted;

  // 기하 검사
  const auto& c = d.corners;
  float smin = 1e9f, smax = 0.f;
  for (int i = 0; i < 4; ++i) {
    const float s = dist(c[i], c[(i + 1) % 4]);
    smin = std::min(smin, s);
    smax = std::max(smax, s);
  }
  if (smin < cfg_.min_side_px) return Reason::kBadGeometry;
  if (smax / std::max(smin, 1e-3f) > cfg_.max_side_ratio) return Reason::kBadGeometry;

  // 볼록성 + 와인딩: 4개 연속 외적 부호가 모두 같아야 함
  int pos = 0, neg = 0;
  for (int i = 0; i < 4; ++i) {
    const float z = cross(c[i], c[(i + 1) % 4], c[(i + 2) % 4]);
    (z > 0 ? pos : neg)++;
  }
  if (pos != 4 && neg != 4) return Reason::kBadGeometry;  // 비볼록 (반사/물결 왜곡)
  if (cfg_.check_winding && ((pos == 4 ? 1 : -1) != expectedWindingSign())) return Reason::kBadGeometry;

  // 면적 (shoelace)
  float area = 0.f;
  for (int i = 0; i < 4; ++i) area += c[i].x * c[(i + 1) % 4].y - c[(i + 1) % 4].x * c[i].y;
  if (std::fabs(area) * 0.5f < cfg_.min_area_px) return Reason::kBadGeometry;
  return Reason::kPass;
}

uint32_t OutlierRejectionFilter::apply(std::vector<Detection>& dets) {
  const size_t before = dets.size();
  size_t w = 0;
  for (size_t r = 0; r < dets.size(); ++r) {
    switch (check(dets[r])) {
      case Reason::kPass:
        if (w != r) dets[w] = dets[r];
        ++w;
        break;
      case Reason::kLowMargin: ++stats_.low_margin; break;
      case Reason::kHighHamming: ++stats_.high_hamming; break;
      case Reason::kNotWhitelisted: ++stats_.not_whitelisted; break;
      case Reason::kBadGeometry: ++stats_.bad_geometry; break;
      default: break;
    }
  }
  dets.resize(w);

  if (cfg_.reject_duplicates && dets.size() > 1) {
    // 동일 프레임 내 동일 ID 다중 검출 → 최고 신뢰도 1개만 유지 (일반적으로 태그 수 < 32)
    std::vector<Detection> kept;
    kept.reserve(dets.size());
    for (const auto& d : dets) {
      auto it = std::find_if(kept.begin(), kept.end(), [&](const Detection& k) { return k.tag_id == d.tag_id; });
      if (it == kept.end()) {
        kept.push_back(d);
      } else {
        ++stats_.duplicate;
        if (d.decision_margin > it->decision_margin) *it = d;
      }
    }
    dets.swap(kept);
  }
  stats_.passed += dets.size();
  return static_cast<uint32_t>(before - dets.size());
}

}  // namespace pva
