// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/config_builder.hpp"

#include <sstream>

#include <yaml-cpp/yaml.h>

#include "pkg_vision_acquisition/sim_camera.hpp"

namespace pva {

// ───────────────────────────── YamlParamSource ─────────────────────────────
YamlParamSource::YamlParamSource(const std::string& path, const std::string& node_name)
    : root_(std::make_unique<YAML::Node>()) {
  const YAML::Node file = YAML::LoadFile(path);
  for (const std::string& key : {node_name, "/" + node_name, std::string("/**")}) {
    if (file[key] && file[key]["ros__parameters"]) {
      root_->reset(file[key]["ros__parameters"]);
      return;
    }
  }
  root_->reset(file);
}
YamlParamSource::~YamlParamSource() = default;

std::unique_ptr<YAML::Node> YamlParamSource::lookup(const std::string& name) const {
  // 평면 키("a.b") 우선, 이후 중첩 맵 탐색
  // (yaml-cpp 주의: 비-const operator[] / Node 대입은 트리를 변경하므로 const 접근 + reset 사용)
  const YAML::Node& r = *root_;
  if (!r.IsMap()) return nullptr;
  if (r[name]) return std::make_unique<YAML::Node>(r[name]);
  YAML::Node cur;
  cur.reset(r);
  std::stringstream ss(name);
  std::string part;
  while (std::getline(ss, part, '.')) {
    const YAML::Node& cc = cur;
    if (!cc.IsMap()) return nullptr;
    const YAML::Node nx = cc[part];
    if (!nx) return nullptr;
    cur.reset(nx);
  }
  return std::make_unique<YAML::Node>(cur);
}

namespace {
void flatten(const YAML::Node& n, const std::string& prefix, std::vector<std::pair<std::string, YAML::Node>>& out) {
  if (n.IsMap()) {
    for (const auto& kv : n) flatten(kv.second, prefix.empty() ? kv.first.as<std::string>()
                                                              : prefix + "." + kv.first.as<std::string>(), out);
  } else {
    out.emplace_back(prefix, n);
  }
}
YAML::Node selectParams(const YAML::Node& file, const std::string& node_name) {
  for (const std::string& key : {node_name, "/" + node_name, std::string("/**")})
    if (file[key] && file[key]["ros__parameters"]) return file[key]["ros__parameters"];
  return file;
}
}  // namespace

void YamlParamSource::overlay(const std::string& path, const std::string& node_name) {
  const YAML::Node file = YAML::LoadFile(path);
  std::vector<std::pair<std::string, YAML::Node>> flat;
  flatten(selectParams(file, node_name), "", flat);
  for (auto& kv : flat) (*root_)[kv.first] = kv.second;  // 평면 키가 중첩 키보다 우선
}

void YamlParamSource::set(const std::string& name, const std::string& value) { (*root_)[name] = YAML::Load(value); }

bool YamlParamSource::getBool(const std::string& n, bool d) { auto v = lookup(n); return v ? v->as<bool>() : d; }
int64_t YamlParamSource::getInt(const std::string& n, int64_t d) { auto v = lookup(n); return v ? v->as<int64_t>() : d; }
double YamlParamSource::getDouble(const std::string& n, double d) { auto v = lookup(n); return v ? v->as<double>() : d; }
std::string YamlParamSource::getString(const std::string& n, const std::string& d) {
  auto v = lookup(n);
  return v ? v->as<std::string>() : d;
}
std::vector<int64_t> YamlParamSource::getIntArray(const std::string& n, const std::vector<int64_t>& d) {
  auto v = lookup(n);
  return v ? v->as<std::vector<int64_t>>() : d;
}
std::vector<double> YamlParamSource::getDoubleArray(const std::string& n, const std::vector<double>& d) {
  auto v = lookup(n);
  return v ? v->as<std::vector<double>>() : d;
}

// ───────────────────────────── buildPipelineConfig ─────────────────────────────
namespace {
std::vector<int> toIntVec(const std::vector<int64_t>& v) { return std::vector<int>(v.begin(), v.end()); }
}  // namespace

bool buildPipelineConfig(ParamSource& p, const PathResolver& resolve, PipelineConfig& out, std::string& err) {
  out = PipelineConfig{};
  try {
    // ── Tag Bundle / 외부 파라미터
    const std::string bundle_file = resolve(p.getString("tag_bundle_file", "package://pkg_vision_acquisition/config/tag_bundle.yaml"));
    if (!loadTagBundle(bundle_file, out.bundle, err)) return false;
    std::map<int, Pose3> extr;
    std::string world_frame;
    const std::string extr_file = resolve(p.getString("extrinsics_file", ""));
    if (!extr_file.empty() && !loadExtrinsics(extr_file, extr, world_frame, err)) return false;

    // ── 카메라 공통
    CameraConfig base;
    base.driver = p.getString("camera.driver", "aravis");
    base.width = static_cast<int>(p.getInt("camera.width", 1440));
    base.height = static_cast<int>(p.getInt("camera.height", 1080));
    base.offset_x = static_cast<int>(p.getInt("camera.offset_x", 0));
    base.offset_y = static_cast<int>(p.getInt("camera.offset_y", 0));
    base.fps = p.getDouble("camera.fps", 60.0);
    base.exposure_us = p.getDouble("camera.exposure_us", 2000.0);
    base.gain_db = p.getDouble("camera.gain_db", 6.0);
    base.trigger_mode = parseTriggerMode(p.getString("camera.trigger_mode", "hardware"));
    base.trigger_source = p.getString("camera.trigger_source", "Line0");
    base.trigger_activation = p.getString("camera.trigger_activation", "RisingEdge");
    base.ptp_enable = p.getBool("camera.ptp_enable", true);
    base.timestamp_source = parseTimestampSource(p.getString("camera.timestamp_source", "device_ptp"));
    base.host_latency_compensation_us = p.getDouble("camera.host_latency_compensation_us", 0.0);
    base.ptp_tai_utc_offset_ns = static_cast<int64_t>(p.getDouble("camera.ptp_tai_utc_offset_s", 0.0) * 1e9);
    base.packet_size = static_cast<int>(p.getInt("camera.packet_size", 8192));
    base.packet_delay = static_cast<int>(p.getInt("camera.packet_delay", 0));
    base.num_sdk_buffers = static_cast<int>(p.getInt("camera.num_sdk_buffers", 16));
    base.packet_resend = p.getBool("camera.packet_resend", true);
    base.grab_timeout_ms = static_cast<int>(p.getInt("camera.grab_timeout_ms", 100));

    // ── 시뮬레이터 공통 (driver == sim)
    std::shared_ptr<SimTriggerClock> sim_clock;
    const int sim_dropout_cam = static_cast<int>(p.getInt("sim.dropout_camera", 0));

    const int num = static_cast<int>(p.getInt("num_cameras", 4));
    if (num < 1 || num > kMaxCameras) {
      err = "num_cameras 는 1~4";
      return false;
    }
    for (int i = 1; i <= num; ++i) {
      const std::string pre = "ch" + std::to_string(i) + ".";
      if (!p.getBool(pre + "enabled", true)) continue;
      ChannelConfig ch;
      ch.camera = base;
      ch.camera.camera_id = static_cast<uint8_t>(i);
      ch.camera.driver = p.getString(pre + "driver", base.driver);
      ch.camera.device_id = p.getString(pre + "device_id", "");
      const std::string intr_file =
          resolve(p.getString(pre + "intrinsics_file",
                              "package://pkg_vision_acquisition/config/cam_intrinsics_ch" + std::to_string(i) + ".yaml"));
      if (!loadIntrinsics(intr_file, ch.intrinsics, err)) return false;
      if (ch.intrinsics.width != ch.camera.width || ch.intrinsics.height != ch.camera.height) {
        err = intr_file + ": 해상도가 camera.width/height 와 다릅니다";
        return false;
      }
      auto it = extr.find(i);
      if (it != extr.end()) ch.T_world_cam = it->second;

      if (ch.camera.driver == "sim") {
        if (!ch.T_world_cam) {
          err = "sim 드라이버는 extrinsics_file 에 ch" + std::to_string(i) + " 외부파라미터가 필요합니다";
          return false;
        }
        if (!sim_clock) sim_clock = std::make_shared<SimTriggerClock>(base.fps);
        auto sc = std::make_shared<SimSceneConfig>();
        sc->intrinsics = ch.intrinsics;
        sc->T_world_cam = *ch.T_world_cam;
        sc->bundle = out.bundle;
        const auto bp = p.getDoubleArray("sim.body_position", {0.0, 0.0, 0.0});
        const auto br = p.getDoubleArray("sim.body_rpy_deg", {0.0, 0.0, 0.0});
        if (bp.size() == 3) sc->T_world_body0.t = cv::Vec3d(bp[0], bp[1], bp[2]);
        if (br.size() == 3) sc->T_world_body0.R = rotationFromRpyDeg(br[0], br[1], br[2]);
        sc->hull_length_m = p.getDouble("sim.hull_length_m", 2.4);
        sc->hull_beam_m = p.getDouble("sim.hull_beam_m", 0.40);
        sc->motion_amp_m = p.getDouble("sim.motion_amp_m", 0.02);
        sc->roll_amp_deg = p.getDouble("sim.roll_amp_deg", 0.5);
        sc->static_scene = p.getBool("sim.static_scene", false);
        sc->noise_sigma = p.getDouble("sim.noise_sigma", 2.0);
        sc->prerender_frames = static_cast<int>(p.getInt("sim.prerender_frames", 48));
        sc->supersample = static_cast<int>(p.getInt("sim.supersample", 3));
        sc->glints = p.getBool("sim.glints", true);
        sc->timestamp_jitter_us = p.getDouble("sim.timestamp_jitter_us", 20.0);
        sc->arrival_jitter_us = p.getDouble("sim.arrival_jitter_us", 300.0);
        if (sim_dropout_cam == i) {
          sc->dropout_start_s = p.getDouble("sim.dropout_start_s", -1.0);
          sc->dropout_duration_s = p.getDouble("sim.dropout_duration_s", 0.0);
        }
        sc->occlusion_start_s = p.getDouble("sim.occlusion_start_s", -1.0);
        sc->occlusion_duration_s = p.getDouble("sim.occlusion_duration_s", 0.0);
        sc->seed = static_cast<uint32_t>(p.getInt("sim.seed", 1234));
        sc->clock = sim_clock;
        ch.camera.sim = sc;
      }
      out.channels.push_back(ch);
    }
    if (out.channels.empty()) {
      err = "활성 채널이 없습니다";
      return false;
    }

    // ── 전처리
    out.preprocess.undistort_mode = parseUndistortMode(p.getString("preprocess.undistort_mode", "remap"));
    out.preprocess.clahe_enable = p.getBool("preprocess.clahe_enable", false);
    out.preprocess.clahe_clip_limit = p.getDouble("preprocess.clahe_clip_limit", 2.0);
    out.preprocess.clahe_tile_grid = static_cast<int>(p.getInt("preprocess.clahe_tile_grid", 8));

    // ── 검출기
    auto& d = out.detector;
    d.quad_decimate = static_cast<float>(p.getDouble("detector.quad_decimate", 2.0));
    d.quad_sigma = static_cast<float>(p.getDouble("detector.quad_sigma", 0.0));
    d.nthreads = static_cast<int>(p.getInt("detector.nthreads", 2));
    d.refine_edges = p.getBool("detector.refine_edges", true);
    d.decode_sharpening = p.getDouble("detector.decode_sharpening", 0.25);
    d.max_hamming = static_cast<int>(p.getInt("detector.max_hamming", 1));
    d.min_white_black_diff = static_cast<int>(p.getInt("detector.min_white_black_diff", 20));
    d.min_cluster_pixels = static_cast<int>(p.getInt("detector.min_cluster_pixels", 5));
    d.max_nmaxima = static_cast<int>(p.getInt("detector.max_nmaxima", 10));
    d.critical_angle_deg = static_cast<float>(p.getDouble("detector.critical_angle_deg", 10.0));
    d.max_line_fit_mse = static_cast<float>(p.getDouble("detector.max_line_fit_mse", 10.0));
    d.deglitch = p.getBool("detector.deglitch", false);
    d.pixel_center_offset = static_cast<float>(p.getDouble("detector.pixel_center_offset", -0.5));

    // ── 필터
    auto& f = out.filter;
    f.min_decision_margin = static_cast<float>(p.getDouble("filter.min_decision_margin", 35.0));
    f.max_hamming = static_cast<int>(p.getInt("filter.max_hamming", 1));
    f.enable_whitelist = p.getBool("filter.enable_whitelist", true);
    f.whitelist = out.bundle.ids();
    for (auto id : p.getIntArray("filter.extra_whitelist_ids", {})) f.whitelist.insert(static_cast<int>(id));
    f.min_side_px = static_cast<float>(p.getDouble("filter.min_side_px", 8.0));
    f.max_side_ratio = static_cast<float>(p.getDouble("filter.max_side_ratio", 4.0));
    f.min_area_px = static_cast<float>(p.getDouble("filter.min_area_px", 64.0));
    f.reject_duplicates = p.getBool("filter.reject_duplicates", true);
    f.check_winding = p.getBool("filter.check_winding", true);

    // ── 동적 ROI
    auto& r = out.roi;
    r.enable = p.getBool("roi.enable", true);
    r.use_pose_feedback = p.getBool("roi.use_pose_feedback", true);
    r.use_detection_tracking = p.getBool("roi.use_detection_tracking", true);
    r.margin_px = static_cast<int>(p.getInt("roi.margin_px", 40));
    r.margin_ratio = p.getDouble("roi.margin_ratio", 0.25);
    r.pose_timeout_ms = p.getDouble("roi.pose_timeout_ms", 150.0);
    r.track_max_age_frames = static_cast<int>(p.getInt("roi.track_max_age_frames", 3));
    r.full_frame_every_n = static_cast<int>(p.getInt("roi.full_frame_every_n", 15));
    r.max_area_ratio = p.getDouble("roi.max_area_ratio", 0.6);
    r.min_size_px = static_cast<int>(p.getInt("roi.min_size_px", 96));
    r.retry_full_frame_on_miss = p.getBool("roi.retry_full_frame_on_miss", true);

    // ── 동기/상태감시/스레드
    out.sync.window_us = p.getDouble("sync.window_us", 2000.0);
    out.sync.tolerance_us = p.getDouble("sync.tolerance_us", 100.0);
    out.sync.max_wait_ms = p.getDouble("sync.max_wait_ms", 8.0);
    out.health.dropout_timeout_ms = static_cast<int>(p.getInt("health.dropout_timeout_ms", 250));
    out.health.reconnect_interval_ms = static_cast<int>(p.getInt("health.reconnect_interval_ms", 1000));
    out.health.occlusion_warn_cycles = static_cast<int>(p.getInt("health.occlusion_warn_cycles", 15));
    out.health.event_throttle_ms = static_cast<int>(p.getInt("health.event_throttle_ms", 1000));
    out.threads.rt_priority_grab = static_cast<int>(p.getInt("threads.rt_priority_grab", 0));
    out.threads.rt_priority_worker = static_cast<int>(p.getInt("threads.rt_priority_worker", 0));
    out.threads.rt_priority_aggregator = static_cast<int>(p.getInt("threads.rt_priority_aggregator", 0));
    out.threads.cpu_grab = toIntVec(p.getIntArray("threads.cpu_grab", {}));
    out.threads.cpu_worker = toIntVec(p.getIntArray("threads.cpu_worker", {}));
    out.threads.cpu_aggregator = static_cast<int>(p.getInt("threads.cpu_aggregator", -1));
    out.threads.worker_spin_us = static_cast<int>(p.getInt("threads.worker_spin_us", 50));
    out.pool_buffers = static_cast<int>(p.getInt("pool_buffers", 6));
    out.ring_capacity = static_cast<int>(p.getInt("ring_capacity", 4));

    // 동기 창 검증: 프레임 주기의 절반 미만이어야 인접 주기와 혼동 없음
    const double period_us = 1e6 / base.fps;
    if (out.sync.window_us >= 0.5 * period_us) {
      err = "sync.window_us(" + std::to_string(out.sync.window_us) + ") 는 프레임 주기의 1/2(" +
            std::to_string(0.5 * period_us) + "us) 미만이어야 합니다";
      return false;
    }
    return true;
  } catch (const std::exception& e) {
    err = std::string("파라미터 오류: ") + e.what();
    return false;
  }
}

}  // namespace pva
