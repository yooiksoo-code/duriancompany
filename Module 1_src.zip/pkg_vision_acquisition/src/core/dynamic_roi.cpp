// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/dynamic_roi.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>

namespace pva {

DynamicRoi::DynamicRoi(const RoiConfig& cfg, const CameraIntrinsics& intr,
                       std::optional<Pose3> T_world_cam, const TagBundle& bundle)
    : cfg_(cfg), intr_(intr), bundle_pts_(bundle.allCornersBody()) {
  if (T_world_cam) T_cam_world_ = T_world_cam->inverse();
}

std::vector<cv::Point2f> DynamicRoi::projectBundle(const PoseSnapshot& p, int64_t stamp_ns) const {
  std::vector<cv::Point2f> out;
  if (!T_cam_world_) return out;
  const double dt = std::clamp((stamp_ns - p.stamp_ns) * 1e-9, -0.2, 0.2);

  cv::Matx33d R(p.R_world_body);
  const cv::Vec3d t(p.t_world_body[0], p.t_world_body[1], p.t_world_body[2]);
  const cv::Vec3d v(p.v_body[0], p.v_body[1], p.v_body[2]);
  const cv::Vec3d w(p.w_body[0], p.w_body[1], p.w_body[2]);
  // 등속 외삽: t' = t + R v dt,  R' = R exp([w dt]x)
  const cv::Vec3d t_pred = t + R * v * dt;
  cv::Matx33d dR = cv::Matx33d::eye();
  const cv::Vec3d rv = w * dt;
  if (cv::norm(rv) > 1e-9) cv::Rodrigues(rv, dR);
  const Pose3 T_world_body{R * dR, t_pred};
  const Pose3 T_cam_body = (*T_cam_world_) * T_world_body;

  const double fx = intr_.K(0, 0), fy = intr_.K(1, 1), cx = intr_.K(0, 2), cy = intr_.K(1, 2);
  out.reserve(bundle_pts_.size());
  for (const auto& pb : bundle_pts_) {
    const cv::Vec3d pc = T_cam_body * cv::Vec3d(pb.x, pb.y, pb.z);
    if (pc[2] < 0.05) continue;  // 카메라 후방
    out.emplace_back(static_cast<float>(fx * pc[0] / pc[2] + cx), static_cast<float>(fy * pc[1] / pc[2] + cy));
  }
  return out;
}

cv::Rect DynamicRoi::finalize(const cv::Rect2f& box) const {
  // 축별 마진: 선체 길이방향으로 길게 늘어선 번들(가로 띠)에서 세로 마진이 과대해지지 않도록
  // 각 축 크기에 비례 + 고정 마진. 하한은 태그 1개 크기(짧은 축) 수준.
  const float mx = static_cast<float>(cfg_.margin_px + cfg_.margin_ratio * box.width);
  const float my = static_cast<float>(cfg_.margin_px + cfg_.margin_ratio * std::max(box.height, 0.25f * box.width));
  float x0 = box.x - mx, y0 = box.y - my, x1 = box.x + box.width + mx, y1 = box.y + box.height + my;
  // 최소 크기 보장
  const float minsz = static_cast<float>(cfg_.min_size_px);
  if (x1 - x0 < minsz) { const float c = 0.5f * (x0 + x1); x0 = c - minsz / 2; x1 = c + minsz / 2; }
  if (y1 - y0 < minsz) { const float c = 0.5f * (y0 + y1); y0 = c - minsz / 2; y1 = c + minsz / 2; }

  const int W = intr_.width, H = intr_.height;
  int ix0 = std::max(0, static_cast<int>(std::floor(x0)));
  int iy0 = std::max(0, static_cast<int>(std::floor(y0)));
  int ix1 = std::min(W, static_cast<int>(std::ceil(x1)));
  int iy1 = std::min(H, static_cast<int>(std::ceil(y1)));
  if (ix1 <= ix0 || iy1 <= iy0) return {};  // 화면 밖 → Full Frame

  const int a = std::max(1, cfg_.align_px);
  ix0 = (ix0 / a) * a;
  ix1 = std::min(W, ((ix1 + a - 1) / a) * a);
  const cv::Rect r(ix0, iy0, ix1 - ix0, iy1 - iy0);
  if (r.area() > cfg_.max_area_ratio * static_cast<double>(W) * H) return {};
  return r;
}

cv::Rect DynamicRoi::compute(int64_t stamp_ns, const PoseSnapshot* pose, RoiSource* source) {
  if (source) *source = RoiSource::kFull;
  ++frame_counter_;
  ++track_age_;
  if (!cfg_.enable) return {};
  if (cfg_.full_frame_every_n > 0 && (frame_counter_ % static_cast<uint64_t>(cfg_.full_frame_every_n)) == 0)
    return {};

  // 1) EKF 자세 피드백
  if (cfg_.use_pose_feedback && pose && T_cam_world_ && pose->stamp_ns > 0) {
    const double age_ms = std::fabs(stamp_ns - pose->stamp_ns) * 1e-6;
    if (age_ms <= cfg_.pose_timeout_ms) {
      const auto pts = projectBundle(*pose, stamp_ns);
      if (!pts.empty()) {
        const cv::Rect r = finalize(cv::boundingRect(pts));
        if (r.area() > 0) {
          if (source) *source = RoiSource::kPose;
          return r;
        }
      }
    }
  }
  // 2) 자기 추적
  if (cfg_.use_detection_tracking && track_age_ <= cfg_.track_max_age_frames && last_track_box_.area() > 0) {
    const cv::Rect r = finalize(last_track_box_);
    if (r.area() > 0) {
      if (source) *source = RoiSource::kTracking;
      return r;
    }
  }
  return {};
}

void DynamicRoi::update(const std::vector<Detection>& dets) {
  if (dets.empty()) return;  // 미검출 시 이전 박스 유지 (age 증가로 자연 만료)
  float x0 = std::numeric_limits<float>::max(), y0 = x0, x1 = -x0, y1 = -x0;
  for (const auto& d : dets)
    for (const auto& c : d.corners) {
      x0 = std::min(x0, c.x); y0 = std::min(y0, c.y);
      x1 = std::max(x1, c.x); y1 = std::max(y1, c.y);
    }
  last_track_box_ = cv::Rect2f(x0, y0, x1 - x0, y1 - y0);
  track_age_ = 0;
}

}  // namespace pva
