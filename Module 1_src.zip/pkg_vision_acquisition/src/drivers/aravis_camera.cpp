// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// Aravis(GenICam/GigE Vision) 드라이버. libaravis-0.8 필요 (HAVE_ARAVIS).
//  - PTP: SFNC "PtpEnable" (신형) → "GevIEEE1588" (구형) 순으로 시도
//  - 트리거: TriggerSelector=FrameStart, TriggerMode=On, TriggerSource=Line0
//  - 네트워크: GevSCPSPacketSize(점보프레임), GevSCPD, packet-resend, socket buffer
//  - 패킷 손실 통계: arv_gv_stream_get_statistics (resent / missing)
#ifdef HAVE_ARAVIS

#include <arv.h>

#include <cstring>
#include <sstream>

#include "pkg_vision_acquisition/camera_driver.hpp"

namespace pva {

namespace {
std::string takeError(GError*& e) {
  std::string s = e ? e->message : "unknown error";
  if (e) g_clear_error(&e);
  return s;
}
}  // namespace

class AravisCamera : public ICameraDriver {
 public:
  explicit AravisCamera(const CameraConfig& cfg) : cfg_(cfg) {}
  ~AravisCamera() override { close(); }

  bool open(std::string& err) override {
    GError* e = nullptr;
    cam_ = arv_camera_new(cfg_.device_id.empty() ? nullptr : cfg_.device_id.c_str(), &e);
    if (!cam_) {
      err = "arv_camera_new(" + cfg_.device_id + "): " + takeError(e);
      return false;
    }
    if (!arv_camera_is_gv_device(cam_)) {
      err = "GigE Vision 장치가 아닙니다: " + cfg_.device_id;
      close();
      return false;
    }
    // 하드웨어 설정 (실패 항목은 경고성 - 모델별 노드 차이 허용, 필수 항목만 실패 처리)
    arv_camera_set_pixel_format(cam_, ARV_PIXEL_FORMAT_MONO_8, &e);
    if (e) { err = "PixelFormat Mono8: " + takeError(e); close(); return false; }
    arv_camera_set_region(cam_, cfg_.offset_x, cfg_.offset_y, cfg_.width, cfg_.height, &e);
    if (e) { err = "Region: " + takeError(e); close(); return false; }

    trySetBool("AcquisitionFrameRateEnable", cfg_.trigger_mode != TriggerMode::kHardware);
    if (cfg_.trigger_mode != TriggerMode::kHardware) {
      arv_camera_set_frame_rate(cam_, cfg_.fps, &e);
      if (e) warnings_ << "FrameRate: " << takeError(e) << "; ";
    }
    trySetString("ExposureAuto", "Off");
    arv_camera_set_exposure_time(cam_, cfg_.exposure_us, &e);
    if (e) warnings_ << "Exposure: " << takeError(e) << "; ";
    trySetString("GainAuto", "Off");
    arv_camera_set_gain(cam_, cfg_.gain_db, &e);
    if (e) warnings_ << "Gain: " << takeError(e) << "; ";

    // 트리거
    trySetString("TriggerSelector", "FrameStart");
    if (cfg_.trigger_mode == TriggerMode::kHardware) {
      trySetString("TriggerMode", "On");
      trySetString("TriggerSource", cfg_.trigger_source.c_str());
      trySetString("TriggerActivation", cfg_.trigger_activation.c_str());
    } else {
      trySetString("TriggerMode", "Off");
    }

    // PTP (IEEE 1588)
    if (cfg_.ptp_enable) {
      if (!trySetBool("PtpEnable", true) && !trySetBool("GevIEEE1588", true))
        warnings_ << "PTP 노드(PtpEnable/GevIEEE1588) 미지원; ";
    }

    // GigE 패킷/네트워크
    if (cfg_.packet_size > 0) {
      arv_camera_gv_set_packet_size(cam_, cfg_.packet_size, &e);
      if (e) warnings_ << "PacketSize: " << takeError(e) << "; ";
    } else {
      arv_camera_gv_auto_packet_size(cam_, &e);
      if (e) warnings_ << "AutoPacketSize: " << takeError(e) << "; ";
    }
    arv_camera_gv_set_packet_delay(cam_, cfg_.packet_delay, &e);
    if (e) warnings_ << "PacketDelay: " << takeError(e) << "; ";

    // 스트림 생성
    stream_ = arv_camera_create_stream(cam_, nullptr, nullptr, &e);
    if (!stream_) {
      err = "create_stream: " + takeError(e);
      close();
      return false;
    }
    if (ARV_IS_GV_STREAM(stream_)) {
      g_object_set(stream_, "packet-resend",
                   cfg_.packet_resend ? ARV_GV_STREAM_PACKET_RESEND_ALWAYS : ARV_GV_STREAM_PACKET_RESEND_NEVER,
                   "socket-buffer", ARV_GV_STREAM_SOCKET_BUFFER_AUTO, nullptr);
    }
    payload_ = arv_camera_get_payload(cam_, &e);
    if (e) { err = "payload: " + takeError(e); close(); return false; }
    for (int i = 0; i < cfg_.num_sdk_buffers; ++i) arv_stream_push_buffer(stream_, arv_buffer_new(payload_, nullptr));
    return true;
  }

  bool start(std::string& err) override {
    GError* e = nullptr;
    arv_camera_start_acquisition(cam_, &e);
    if (e) { err = "start_acquisition: " + takeError(e); return false; }
    return true;
  }

  void stop() override {
    if (cam_) {
      GError* e = nullptr;
      arv_camera_stop_acquisition(cam_, &e);
      if (e) g_clear_error(&e);
    }
  }

  void close() override {
    stop();
    if (stream_) { g_object_unref(stream_); stream_ = nullptr; }
    if (cam_) { g_object_unref(cam_); cam_ = nullptr; }
  }

  GrabStatus grab(FrameBuffer& out, int timeout_ms) override {
    if (!stream_) return GrabStatus::kDisconnected;
    ArvBuffer* buf = arv_stream_timeout_pop_buffer(stream_, static_cast<guint64>(timeout_ms) * 1000);
    if (!buf) {
      // 장치 제어채널 생존 확인 (하트비트 실패 → 단절)
      return deviceLost() ? GrabStatus::kDisconnected : GrabStatus::kTimeout;
    }
    GrabStatus st = GrabStatus::kOk;
    const ArvBufferStatus bs = arv_buffer_get_status(buf);
    if (bs != ARV_BUFFER_STATUS_SUCCESS) {
      st = GrabStatus::kIncomplete;
      ++stats_.frames_incomplete;
    } else {
      size_t sz = 0;
      const auto* data = static_cast<const uint8_t*>(arv_buffer_get_data(buf, &sz));
      const int w = arv_buffer_get_image_width(buf), h = arv_buffer_get_image_height(buf);
      if (w != out.width || h != out.height || sz < static_cast<size_t>(w) * h) {
        st = GrabStatus::kIncomplete;
      } else {
        for (int y = 0; y < h; ++y)
          std::memcpy(out.data.data() + static_cast<size_t>(y) * out.stride, data + static_cast<size_t>(y) * w, w);
        out.meta.camera_id = cfg_.camera_id;
        out.meta.frame_seq = arv_buffer_get_frame_id(buf);
        out.meta.lost_packets = 0;
        if (cfg_.timestamp_source == TimestampSource::kDevicePtp) {
          out.meta.stamp_ns = static_cast<int64_t>(arv_buffer_get_timestamp(buf)) - cfg_.ptp_tai_utc_offset_ns;
        } else {
          out.meta.stamp_ns = static_cast<int64_t>(arv_buffer_get_system_timestamp(buf)) -
                              static_cast<int64_t>(cfg_.host_latency_compensation_us * 1e3);
        }
        ++stats_.frames_completed;
      }
    }
    arv_stream_push_buffer(stream_, buf);  // 버퍼 재사용 (할당 없음)
    return st;
  }

  CameraStats stats() const override {
    CameraStats s = stats_;
    if (stream_ && ARV_IS_GV_STREAM(stream_)) {
      guint64 resent = 0, missing = 0;
      arv_gv_stream_get_statistics(ARV_GV_STREAM(stream_), &resent, &missing);
      s.packets_resent = resent;
      s.packets_missing = missing;
    }
    return s;
  }

  std::string describe() const override {
    std::ostringstream os;
    os << "AravisCamera[ch" << int(cfg_.camera_id) << " '" << cfg_.device_id << "'";
    if (cam_) {
      GError* e = nullptr;
      const char* model = arv_camera_get_model_name(cam_, &e);
      if (e) g_clear_error(&e);
      if (model) os << " model=" << model;
    }
    os << " payload=" << payload_ << "]";
    const std::string w = warnings_.str();
    if (!w.empty()) os << " warnings: " << w;
    return os.str();
  }

 private:
  bool trySetBool(const char* feat, bool v) {
    GError* e = nullptr;
    arv_camera_set_boolean(cam_, feat, v ? TRUE : FALSE, &e);
    if (e) { g_clear_error(&e); return false; }
    return true;
  }
  bool trySetString(const char* feat, const char* v) {
    GError* e = nullptr;
    arv_camera_set_string(cam_, feat, v, &e);
    if (e) { g_clear_error(&e); return false; }
    return true;
  }
  bool deviceLost() {
    if (!cam_) return true;
    GError* e = nullptr;
    // 제어채널 레지스터 읽기 실패 시 장치 단절로 판단
    (void)arv_camera_get_integer(cam_, "Width", &e);
    if (e) { g_clear_error(&e); return true; }
    return false;
  }

  CameraConfig cfg_;
  ArvCamera* cam_ = nullptr;
  ArvStream* stream_ = nullptr;
  size_t payload_ = 0;
  CameraStats stats_;
  std::ostringstream warnings_;
};

std::unique_ptr<ICameraDriver> makeAravisCamera(const CameraConfig& cfg) {
  return std::make_unique<AravisCamera>(cfg);
}

}  // namespace pva

#endif  // HAVE_ARAVIS
