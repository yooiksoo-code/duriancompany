// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// Hikrobot MVS SDK 드라이버 (HAVE_HIK_MVS). /opt/MVS 설치 필요.
//  - MV_CC_GetOneFrameTimeout 으로 사전할당 버퍼에 직접 수신 (추가 memcpy 없음, stride==width 시)
//  - nDevTimeStampHigh/Low: GevIEEE1588 활성 시 PTP ns 타임스탬프
//  - nLostPacket: 프레임별 손실 패킷 수 → 패킷 손실률 KPI 계측
//  - 예외 콜백(MV_EXCEPTION_DEV_DISCONNECT) 으로 단절 즉시 감지
//
// ※ 이 파일은 MVS SDK 헤더(MvCameraControl.h)가 있는 환경에서만 컴파일됩니다.
//   개발 환경(SDK 미설치)에서는 컴파일 검증되지 않았으므로 실장비 빌드 시 API 버전을 확인하십시오.
#ifdef HAVE_HIK_MVS

#include <MvCameraControl.h>
#ifndef __stdcall
#define __stdcall
#endif

#include <atomic>
#include <cstring>
#include <sstream>

#include "pkg_vision_acquisition/camera_driver.hpp"

namespace pva {

class HikMvsCamera : public ICameraDriver {
 public:
  explicit HikMvsCamera(const CameraConfig& cfg) : cfg_(cfg) {}
  ~HikMvsCamera() override { close(); }

  bool open(std::string& err) override {
#ifdef HIK_MVS_SDK_V4
    MV_CC_Initialize();
#endif
    MV_CC_DEVICE_INFO_LIST list;
    std::memset(&list, 0, sizeof(list));
    int rc = MV_CC_EnumDevices(MV_GIGE_DEVICE, &list);
    if (rc != MV_OK || list.nDeviceNum == 0) {
      err = "MV_CC_EnumDevices: GigE 장치 없음 (rc=" + hex(rc) + ")";
      return false;
    }
    MV_CC_DEVICE_INFO* sel = nullptr;
    for (unsigned i = 0; i < list.nDeviceNum; ++i) {
      MV_CC_DEVICE_INFO* d = list.pDeviceInfo[i];
      if (!d || d->nTLayerType != MV_GIGE_DEVICE) continue;
      const auto& g = d->SpecialInfo.stGigEInfo;
      const std::string serial(reinterpret_cast<const char*>(g.chSerialNumber));
      const std::string user(reinterpret_cast<const char*>(g.chUserDefinedName));
      const unsigned ip = g.nCurrentIp;
      std::ostringstream ips;
      ips << ((ip >> 24) & 0xff) << "." << ((ip >> 16) & 0xff) << "." << ((ip >> 8) & 0xff) << "." << (ip & 0xff);
      if (cfg_.device_id.empty() || cfg_.device_id == serial || cfg_.device_id == user || cfg_.device_id == ips.str()) {
        sel = d;
        break;
      }
    }
    if (!sel) {
      err = "MVS: device_id '" + cfg_.device_id + "' 에 해당하는 장치 없음";
      return false;
    }
    if ((rc = MV_CC_CreateHandle(&handle_, sel)) != MV_OK) { err = "CreateHandle " + hex(rc); return false; }
    if ((rc = MV_CC_OpenDevice(handle_, MV_ACCESS_Exclusive, 0)) != MV_OK) {
      err = "OpenDevice " + hex(rc);
      close();
      return false;
    }
    MV_CC_RegisterExceptionCallBack(handle_, &HikMvsCamera::onException, this);

    // 네트워크: 점보프레임 패킷 크기
    int pkt = cfg_.packet_size;
    if (pkt <= 0) pkt = MV_CC_GetOptimalPacketSize(handle_);
    if (pkt > 0) MV_CC_SetIntValue(handle_, "GevSCPSPacketSize", static_cast<unsigned>(pkt));
    MV_CC_SetIntValue(handle_, "GevSCPD", static_cast<unsigned>(cfg_.packet_delay));
    MV_GIGE_SetResend(handle_, cfg_.packet_resend ? 1 : 0, 10, 50);

    // 영상 포맷/영역
    MV_CC_SetEnumValue(handle_, "PixelFormat", PixelType_Gvsp_Mono8);
    MV_CC_SetIntValue(handle_, "Width", static_cast<unsigned>(cfg_.width));
    MV_CC_SetIntValue(handle_, "Height", static_cast<unsigned>(cfg_.height));
    MV_CC_SetIntValue(handle_, "OffsetX", static_cast<unsigned>(cfg_.offset_x));
    MV_CC_SetIntValue(handle_, "OffsetY", static_cast<unsigned>(cfg_.offset_y));

    MV_CC_SetEnumValueByString(handle_, "ExposureAuto", "Off");
    MV_CC_SetFloatValue(handle_, "ExposureTime", static_cast<float>(cfg_.exposure_us));
    MV_CC_SetEnumValueByString(handle_, "GainAuto", "Off");
    MV_CC_SetFloatValue(handle_, "Gain", static_cast<float>(cfg_.gain_db));

    MV_CC_SetEnumValueByString(handle_, "TriggerSelector", "FrameBurstStart");
    if (cfg_.trigger_mode == TriggerMode::kHardware) {
      MV_CC_SetEnumValueByString(handle_, "TriggerMode", "On");
      MV_CC_SetEnumValueByString(handle_, "TriggerSource", cfg_.trigger_source.c_str());
      MV_CC_SetEnumValueByString(handle_, "TriggerActivation", cfg_.trigger_activation.c_str());
      MV_CC_SetBoolValue(handle_, "AcquisitionFrameRateEnable", false);
    } else {
      MV_CC_SetEnumValueByString(handle_, "TriggerMode", "Off");
      MV_CC_SetBoolValue(handle_, "AcquisitionFrameRateEnable", true);
      MV_CC_SetFloatValue(handle_, "AcquisitionFrameRate", static_cast<float>(cfg_.fps));
    }
    if (cfg_.ptp_enable) {
      if (MV_CC_SetBoolValue(handle_, "GevIEEE1588", true) != MV_OK) warnings_ << "GevIEEE1588 미지원; ";
    }
    MV_CC_SetImageNodeNum(handle_, static_cast<unsigned>(cfg_.num_sdk_buffers));
    disconnected_ = false;
    return true;
  }

  bool start(std::string& err) override {
    const int rc = MV_CC_StartGrabbing(handle_);
    if (rc != MV_OK) { err = "StartGrabbing " + hex(rc); return false; }
    return true;
  }
  void stop() override {
    if (handle_) MV_CC_StopGrabbing(handle_);
  }
  void close() override {
    if (handle_) {
      MV_CC_StopGrabbing(handle_);
      MV_CC_CloseDevice(handle_);
      MV_CC_DestroyHandle(handle_);
      handle_ = nullptr;
    }
  }

  GrabStatus grab(FrameBuffer& out, int timeout_ms) override {
    if (!handle_ || disconnected_.load()) return GrabStatus::kDisconnected;
    MV_FRAME_OUT_INFO_EX info;
    std::memset(&info, 0, sizeof(info));
    // stride == width 인 경우 사전할당 버퍼로 직접 수신, 아니면 중간 버퍼 경유
    const bool direct = (out.stride == out.width);
    if (!direct && scratch_.size() < static_cast<size_t>(out.width) * out.height)
      scratch_.resize(static_cast<size_t>(out.width) * out.height);
    unsigned char* dst = direct ? out.data.data() : scratch_.data();
    const unsigned cap = static_cast<unsigned>(direct ? out.data.size() : scratch_.size());
    const int rc = MV_CC_GetOneFrameTimeout(handle_, dst, cap, &info, static_cast<unsigned>(timeout_ms));
    if (rc != MV_OK) return disconnected_.load() ? GrabStatus::kDisconnected : GrabStatus::kTimeout;
    if (info.nWidth != out.width || info.nHeight != out.height) return GrabStatus::kIncomplete;
    if (!direct)
      for (int y = 0; y < out.height; ++y)
        std::memcpy(out.data.data() + static_cast<size_t>(y) * out.stride, dst + static_cast<size_t>(y) * out.width,
                    static_cast<size_t>(out.width));
    out.meta.camera_id = cfg_.camera_id;
    out.meta.frame_seq = info.nFrameNum;
    out.meta.lost_packets = info.nLostPacket;
    stats_.packets_missing += info.nLostPacket;
    if (cfg_.timestamp_source == TimestampSource::kDevicePtp) {
      const uint64_t ts = (static_cast<uint64_t>(info.nDevTimeStampHigh) << 32) | info.nDevTimeStampLow;
      out.meta.stamp_ns = static_cast<int64_t>(ts) - cfg_.ptp_tai_utc_offset_ns;
    } else {
      out.meta.stamp_ns = wallNowNs() - static_cast<int64_t>(cfg_.host_latency_compensation_us * 1e3);
    }
    ++stats_.frames_completed;
    if (info.nLostPacket > 0) {
      ++stats_.frames_incomplete;
      return GrabStatus::kIncomplete;
    }
    return GrabStatus::kOk;
  }

  CameraStats stats() const override { return stats_; }
  std::string describe() const override {
    std::ostringstream os;
    os << "HikMvsCamera[ch" << int(cfg_.camera_id) << " '" << cfg_.device_id << "']";
    const std::string w = warnings_.str();
    if (!w.empty()) os << " warnings: " << w;
    return os.str();
  }

 private:
  static void __stdcall onException(unsigned int msg_type, void* user) {
    auto* self = static_cast<HikMvsCamera*>(user);
    if (msg_type == MV_EXCEPTION_DEV_DISCONNECT) self->disconnected_ = true;
  }
  static std::string hex(int v) {
    std::ostringstream os;
    os << "0x" << std::hex << static_cast<unsigned>(v);
    return os.str();
  }

  CameraConfig cfg_;
  void* handle_ = nullptr;
  std::atomic<bool> disconnected_{false};
  std::vector<unsigned char> scratch_;
  CameraStats stats_;
  std::ostringstream warnings_;
};

std::unique_ptr<ICameraDriver> makeHikMvsCamera(const CameraConfig& cfg) {
  return std::make_unique<HikMvsCamera>(cfg);
}

}  // namespace pva

#endif  // HAVE_HIK_MVS
