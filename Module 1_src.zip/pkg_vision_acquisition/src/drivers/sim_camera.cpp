// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/sim_camera.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>
#include <sstream>
#include <thread>

#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>

extern "C" {
#include <apriltag/apriltag.h>
#include <apriltag/tag36h11.h>
}

namespace pva {

// ───────────────────────────── SimTriggerClock ─────────────────────────────
SimTriggerClock::SimTriggerClock(double fps)
    : fps_(fps),
      period_ns_(static_cast<int64_t>(std::llround(1e9 / fps))),
      start_mono_ns_(monoNowNs() + 50'000'000),  // 50ms 뒤 첫 트리거
      start_wall_ns_(wallNowNs() + 50'000'000) {}

void SimTriggerClock::restart() {
  start_mono_ns_ = monoNowNs() + 50'000'000;
  start_wall_ns_ = wallNowNs() + 50'000'000;
}

uint64_t SimTriggerClock::nextIndex() const {
  const int64_t now = monoNowNs();
  if (now <= start_mono_ns_) return 0;
  return static_cast<uint64_t>((now - start_mono_ns_) / period_ns_) + 1;
}

// ───────────────────────────── 렌더링 유틸 ─────────────────────────────
namespace {

constexpr int kTexCellPx = 32;

cv::Mat tagTexture(int id) {
  static std::mutex m;
  static std::map<int, cv::Mat> cache;
  std::lock_guard<std::mutex> lk(m);
  auto it = cache.find(id);
  if (it != cache.end()) return it->second;
  apriltag_family_t* tf = tag36h11_create();
  image_u8_t* im = apriltag_to_image(tf, static_cast<uint32_t>(id));
  cv::Mat small(im->height, im->width, CV_8UC1);
  for (int y = 0; y < im->height; ++y) std::memcpy(small.ptr(y), im->buf + y * im->stride, im->width);
  image_u8_destroy(im);
  tag36h11_destroy(tf);
  cv::Mat big;
  cv::resize(small, big, cv::Size(), kTexCellPx, kTexCellPx, cv::INTER_NEAREST);
  // 인쇄 태그의 실제 반사율 범위 (흰색 230 / 검정 25 DN)
  big.convertTo(big, CV_8U, (230.0 - 25.0) / 255.0, 25.0);
  cache[id] = big;
  return big;
}

void buildDistortMaps(const CameraIntrinsics& intr, cv::Mat& mapx, cv::Mat& mapy) {
  const int W = intr.width, H = intr.height;
  std::vector<cv::Point2f> pix;
  pix.reserve(static_cast<size_t>(W) * H);
  for (int y = 0; y < H; ++y)
    for (int x = 0; x < W; ++x) pix.emplace_back(static_cast<float>(x), static_cast<float>(y));
  std::vector<cv::Point2f> und;
  cv::undistortPoints(pix, und, cv::Mat(intr.K), intr.D, cv::noArray(), cv::Mat(intr.K),
                      cv::TermCriteria(cv::TermCriteria::COUNT | cv::TermCriteria::EPS, 20, 1e-7));
  mapx.create(H, W, CV_32F);
  mapy.create(H, W, CV_32F);
  for (int y = 0; y < H; ++y) {
    float* px = mapx.ptr<float>(y);
    float* py = mapy.ptr<float>(y);
    for (int x = 0; x < W; ++x) {
      const auto& p = und[static_cast<size_t>(y) * W + x];
      px[x] = p.x;
      py[x] = p.y;
    }
  }
}

bool hasDistortion(const CameraIntrinsics& intr) {
  return !intr.D.empty() && cv::norm(intr.D) > 1e-12;
}

/// 이상적(무왜곡) 영상 렌더
cv::Mat renderIdeal(const SimSceneConfig& sc, const Pose3& T_world_body, int W, int H, cv::RNG& rng,
                    std::vector<SimGroundTruth>* gt, bool add_glints) {
  const int S = std::max(1, sc.supersample);
  const Pose3 T_cam_body = sc.T_world_cam.inverse() * T_world_body;
  const auto& K = sc.intrinsics.K;
  const double fx = K(0, 0), fy = K(1, 1), cx = K(0, 2), cy = K(1, 2);

  auto projLow = [&](const cv::Vec3d& pb, cv::Point2d& uv) -> bool {
    const cv::Vec3d pc = T_cam_body * pb;
    if (pc[2] <= 0.05) return false;
    uv = cv::Point2d(fx * pc[0] / pc[2] + cx, fy * pc[1] / pc[2] + cy);
    return true;
  };
  auto toHi = [&](const cv::Point2d& p) {
    return cv::Point2f(static_cast<float>(S * p.x + (S - 1) * 0.5), static_cast<float>(S * p.y + (S - 1) * 0.5));
  };

  cv::Mat canvas(H * S, W * S, CV_8UC1);
  // 배경: 도크 수면 (완만한 세로 그라디언트)
  for (int y = 0; y < canvas.rows; ++y) canvas.row(y).setTo(cv::Scalar(55 + 25.0 * y / canvas.rows));

  // 선체 (body z=0 평면의 타원 갑판)
  std::vector<cv::Point> hull;
  for (int i = 0; i < 96; ++i) {
    const double a = 2 * M_PI * i / 96;
    cv::Point2d uv;
    if (projLow(cv::Vec3d(0.5 * sc.hull_length_m * std::cos(a), 0.5 * sc.hull_beam_m * std::sin(a), 0.0), uv)) {
      const auto h = toHi(uv);
      hull.emplace_back(cvRound(h.x), cvRound(h.y));
    }
  }
  if (hull.size() >= 3) cv::fillPoly(canvas, std::vector<std::vector<cv::Point>>{hull}, cv::Scalar(120), cv::LINE_AA);

  std::vector<cv::Rect> tag_boxes;
  if (gt) gt->clear();
  for (const auto& tag : sc.bundle.tags) {
    const cv::Mat tex = tagTexture(tag.id);
    // 텍스처에서 검정 외곽 테두리(width_at_border=8 셀) 꼭짓점 (OpenCV 픽셀 중심 규약)
    const float a = -0.5f + 1.0f * kTexCellPx, b = -0.5f + 9.0f * kTexCellPx;
    const cv::Point2f src[4] = {{a, a}, {b, a}, {b, b}, {a, b}};
    const double s = tag.size * 0.5;
    // 텍스처 좌상단 = 태그좌표 (-s,-s) : 태그 좌표계 x 오른쪽, y 아래
    const cv::Vec3d tagpts[4] = {{-s, -s, 0}, {s, -s, 0}, {s, s, 0}, {-s, s, 0}};
    cv::Point2f dst[4];
    bool ok = true;
    for (int i = 0; i < 4; ++i) {
      cv::Point2d uv;
      if (!projLow(tag.T_body_tag * tagpts[i], uv)) { ok = false; break; }
      dst[i] = toHi(uv);
    }
    if (!ok) continue;
    const cv::Mat Hm = cv::getPerspectiveTransform(src, dst);
    // 텍스처 전체(흰 여백 포함) 투영 bbox 영역만 warp
    std::vector<cv::Point2f> tc = {{-0.5f, -0.5f}, {tex.cols - 0.5f, -0.5f}, {tex.cols - 0.5f, tex.rows - 0.5f},
                                   {-0.5f, tex.rows - 0.5f}};
    std::vector<cv::Point2f> tcp;
    cv::perspectiveTransform(tc, tcp, Hm);
    cv::Rect box = cv::boundingRect(tcp);
    box.x -= 2; box.y -= 2; box.width += 4; box.height += 4;
    box &= cv::Rect(0, 0, canvas.cols, canvas.rows);
    if (box.area() <= 0) continue;
    cv::Mat T = (cv::Mat_<double>(3, 3) << 1, 0, -box.x, 0, 1, -box.y, 0, 0, 1);
    cv::Mat sub = canvas(box);
    cv::warpPerspective(tex, sub, T * Hm, sub.size(), cv::INTER_LINEAR, cv::BORDER_TRANSPARENT);
    tag_boxes.emplace_back(box.x / S, box.y / S, box.width / S + 1, box.height / S + 1);

    if (gt) {
      // 정답 코너: AprilTag det->p 순서 (tagCornersInTagFrame)
      SimGroundTruth g{tag.id, {}};
      bool inside = true;
      const auto tcs = tagCornersInTagFrame(tag.size);
      for (int i = 0; i < 4; ++i) {
        cv::Point2d uv;
        projLow(tag.T_body_tag * cv::Vec3d(tcs[i].x, tcs[i].y, tcs[i].z), uv);
        g.corners[i] = cv::Point2f(static_cast<float>(uv.x), static_cast<float>(uv.y));
        if (uv.x < 4 || uv.y < 4 || uv.x > W - 5 || uv.y > H - 5) inside = false;
      }
      if (inside) gt->push_back(g);
    }
  }

  // 수면 글린트 (포화 반점). 태그 영역은 회피하여 정답 비교 가능성 유지
  if (add_glints) {
    for (int i = 0; i < 10; ++i) {
      const cv::Point2f c(rng.uniform(0.f, static_cast<float>(W)), rng.uniform(0.f, static_cast<float>(H)));
      bool hit = false;
      for (const auto& bx : tag_boxes)
        if ((bx + cv::Size(40, 40) - cv::Point(20, 20)).contains(c)) hit = true;
      if (hit) continue;
      const cv::Size ax(rng.uniform(3, 14) * S, rng.uniform(2, 6) * S);
      cv::ellipse(canvas, cv::Point(cvRound(c.x * S), cvRound(c.y * S)), ax, rng.uniform(0.0, 180.0), 0, 360,
                  cv::Scalar(255), cv::FILLED, cv::LINE_AA);
    }
  }

  cv::Mat ideal;
  if (S > 1) cv::resize(canvas, ideal, cv::Size(W, H), 0, 0, cv::INTER_AREA);
  else ideal = canvas;
  return ideal;
}

cv::Mat finalizeFrame(const SimSceneConfig& sc, const cv::Mat& ideal, const cv::Mat& mapx, const cv::Mat& mapy,
                      cv::RNG& rng) {
  cv::Mat img;
  if (!mapx.empty()) cv::remap(ideal, img, mapx, mapy, cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(0));
  else img = ideal.clone();
  if (sc.noise_sigma > 0) {
    cv::Mat noise(img.size(), CV_16S);
    rng.fill(noise, cv::RNG::NORMAL, 0, sc.noise_sigma);
    cv::Mat out;
    cv::add(img, noise, out, cv::noArray(), CV_8U);
    img = out;
  }
  return img;
}

Pose3 animatedPose(const SimSceneConfig& sc, size_t k, size_t n) {
  if (sc.static_scene || n == 0) return sc.T_world_body0;
  const double ph = 2 * M_PI * static_cast<double>(k) / static_cast<double>(n);
  Pose3 d;
  d.t = cv::Vec3d(sc.motion_amp_m * std::sin(ph), 0, 0);
  d.R = rotationFromRpyDeg(sc.roll_amp_deg * std::sin(ph), 0, 0);
  return sc.T_world_body0 * d;
}

}  // namespace

cv::Mat SimCamera::renderFrame(const SimSceneConfig& scene, const Pose3& T_world_body, int width, int height,
                               cv::RNG& rng, std::vector<SimGroundTruth>* gt, bool add_glints) {
  cv::Mat mapx, mapy;
  if (hasDistortion(scene.intrinsics)) buildDistortMaps(scene.intrinsics, mapx, mapy);
  const cv::Mat ideal = renderIdeal(scene, T_world_body, width, height, rng, gt, add_glints);
  return finalizeFrame(scene, ideal, mapx, mapy, rng);
}

// ───────────────────────────── SimCamera ─────────────────────────────
SimCamera::SimCamera(const CameraConfig& cfg) : cfg_(cfg), scene_(cfg.sim), rng_(cfg.sim ? cfg.sim->seed + cfg.camera_id : 1) {}
SimCamera::~SimCamera() { close(); }

void SimCamera::prerender() {
  const int W = cfg_.width, H = cfg_.height;
  cv::Mat mapx, mapy;
  if (hasDistortion(scene_->intrinsics)) buildDistortMaps(scene_->intrinsics, mapx, mapy);
  const size_t n = static_cast<size_t>(std::max(1, scene_->prerender_frames));
  frames_.resize(n);
  gt_.resize(n);
  for (size_t k = 0; k < n; ++k) {
    const cv::Mat ideal = renderIdeal(*scene_, animatedPose(*scene_, k, n), W, H, rng_, &gt_[k], scene_->glints);
    frames_[k] = finalizeFrame(*scene_, ideal, mapx, mapy, rng_);
  }
  // 전면 차폐(역광/물보라) 프레임: 화면 대부분 포화
  occluded_frame_ = cv::Mat(H, W, CV_8UC1, cv::Scalar(245));
  cv::Mat noise(occluded_frame_.size(), CV_16S);
  rng_.fill(noise, cv::RNG::NORMAL, 0, 6.0);
  cv::add(occluded_frame_, noise, occluded_frame_, cv::noArray(), CV_8U);
}

bool SimCamera::open(std::string& err) {
  if (!scene_ || !scene_->clock) {
    err = "sim: scene/clock 미설정";
    return false;
  }
  const double t_s = (monoNowNs() - scene_->clock->startMonoNs()) * 1e-9;
  if (inWindow(t_s, scene_->dropout_start_s, scene_->dropout_duration_s)) {
    err = "sim: 장치 응답 없음 (dropout 주입 구간)";
    return false;
  }
  if (cfg_.width != scene_->intrinsics.width || cfg_.height != scene_->intrinsics.height) {
    err = "sim: 해상도와 내부파라미터 크기 불일치";
    return false;
  }
  if (frames_.empty()) prerender();
  open_ = true;
  return true;
}

bool SimCamera::start(std::string& err) {
  if (!open_) {
    err = "sim: not open";
    return false;
  }
  index_init_ = false;  // 첫 grab 시점에 트리거 인덱스 결정 (클럭 restart 반영)
  running_ = true;
  return true;
}

void SimCamera::stop() { running_ = false; }
void SimCamera::close() {
  running_ = false;
  open_ = false;
}

ICameraDriver::GrabStatus SimCamera::grab(FrameBuffer& out, int timeout_ms) {
  if (!running_) return GrabStatus::kDisconnected;
  const auto& clk = *scene_->clock;
  if (!index_init_) {
    next_index_ = clk.nextIndex();
    index_init_ = true;
  }
  uint64_t k = next_index_;
  const uint64_t now_idx = clk.nextIndex();
  if (now_idx > k + 2) k = now_idx - 1;  // 수집 지연 누적 시 최신 트리거로 건너뜀 (프레임 손실로 계수됨)

  const int64_t exposure_ns = static_cast<int64_t>(cfg_.exposure_us * 1e3);
  const int64_t arrival = clk.triggerMonoNs(k) + exposure_ns +
                          static_cast<int64_t>(rng_.uniform(0.0, std::max(1.0, scene_->arrival_jitter_us)) * 1e3);
  const int64_t now = monoNowNs();
  if (arrival - now > static_cast<int64_t>(timeout_ms) * 1'000'000) {
    std::this_thread::sleep_for(std::chrono::milliseconds(timeout_ms));
    return GrabStatus::kTimeout;
  }
  std::this_thread::sleep_until(SteadyClock::time_point(std::chrono::nanoseconds(arrival)));

  const double t_s = (clk.triggerMonoNs(k) - clk.startMonoNs()) * 1e-9;
  if (inWindow(t_s, scene_->dropout_start_s, scene_->dropout_duration_s)) {
    running_ = false;  // 랜선 탈락 모사
    return GrabStatus::kDisconnected;
  }
  next_index_ = k + 1;

  const cv::Mat& src = inWindow(t_s, scene_->occlusion_start_s, scene_->occlusion_duration_s)
                           ? occluded_frame_
                           : frames_[k % frames_.size()];
  for (int y = 0; y < src.rows; ++y)
    std::memcpy(out.data.data() + static_cast<size_t>(y) * out.stride, src.ptr(y), static_cast<size_t>(src.cols));

  out.meta.camera_id = cfg_.camera_id;
  out.meta.frame_seq = k;
  out.meta.lost_packets = 0;
  if (cfg_.timestamp_source == TimestampSource::kDevicePtp) {
    out.meta.stamp_ns = clk.startWallNs() + static_cast<int64_t>(k) * clk.periodNs() +
                        static_cast<int64_t>(rng_.gaussian(scene_->timestamp_jitter_us) * 1e3);
  } else {
    out.meta.stamp_ns = wallNowNs() - static_cast<int64_t>(cfg_.host_latency_compensation_us * 1e3);
  }
  ++stats_.frames_completed;
  return GrabStatus::kOk;
}

CameraStats SimCamera::stats() const { return stats_; }

const std::vector<SimGroundTruth>& SimCamera::groundTruth(size_t frame_index) const {
  return gt_[frame_index % gt_.size()];
}

std::string SimCamera::describe() const {
  std::ostringstream os;
  os << "SimCamera[ch" << int(cfg_.camera_id) << " " << cfg_.width << "x" << cfg_.height << " @" << cfg_.fps
     << "fps, prerender=" << frames_.size() << "]";
  return os.str();
}

}  // namespace pva
