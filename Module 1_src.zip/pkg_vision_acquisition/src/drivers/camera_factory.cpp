// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include <stdexcept>

#include "pkg_vision_acquisition/camera_driver.hpp"
#include "pkg_vision_acquisition/sim_camera.hpp"

namespace pva {

#ifdef HAVE_ARAVIS
std::unique_ptr<ICameraDriver> makeAravisCamera(const CameraConfig& cfg);
#endif
#ifdef HAVE_HIK_MVS
std::unique_ptr<ICameraDriver> makeHikMvsCamera(const CameraConfig& cfg);
#endif

std::unique_ptr<ICameraDriver> createCameraDriver(const CameraConfig& cfg, std::string& err) {
  if (cfg.driver == "sim") {
    if (!cfg.sim) {
      err = "sim 드라이버에는 SimSceneConfig 가 필요합니다";
      return nullptr;
    }
    return std::make_unique<SimCamera>(cfg);
  }
  if (cfg.driver == "aravis") {
#ifdef HAVE_ARAVIS
    return makeAravisCamera(cfg);
#else
    err = "aravis 드라이버가 빌드에 포함되지 않았습니다 (libaravis-0.8-dev 설치 후 재빌드)";
    return nullptr;
#endif
  }
  if (cfg.driver == "hikmvs") {
#ifdef HAVE_HIK_MVS
    return makeHikMvsCamera(cfg);
#else
    err = "hikmvs 드라이버가 빌드에 포함되지 않았습니다 (MVS SDK 설치 후 -DWITH_HIK_MVS=ON 재빌드)";
    return nullptr;
#endif
  }
  err = "알 수 없는 카메라 드라이버: " + cfg.driver;
  return nullptr;
}

TriggerMode parseTriggerMode(const std::string& s) {
  if (s == "free_run") return TriggerMode::kFreeRun;
  if (s == "hardware") return TriggerMode::kHardware;
  if (s == "ptp_scheduled") return TriggerMode::kPtpScheduled;
  throw std::invalid_argument("trigger_mode must be free_run|hardware|ptp_scheduled, got: " + s);
}

TimestampSource parseTimestampSource(const std::string& s) {
  if (s == "device_ptp") return TimestampSource::kDevicePtp;
  if (s == "host") return TimestampSource::kHost;
  throw std::invalid_argument("timestamp_source must be device_ptp|host, got: " + s);
}

}  // namespace pva
