// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#include "pkg_vision_acquisition/vision_acquisition_node.hpp"

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <rclcpp_components/register_node_macro.hpp>

#include <cstdio>

#include "pkg_vision_acquisition/config_builder.hpp"

namespace pva {

namespace {

/// ROS2 파라미터 기반 ParamSource. 동적 타입 선언으로 YAML 의 정수/실수 표기 차이를 허용한다.
class RosParamSource : public ParamSource {
 public:
  explicit RosParamSource(rclcpp_lifecycle::LifecycleNode& n) : n_(n) {}

  bool getBool(const std::string& name, bool d) override { return get(name, rclcpp::ParameterValue(d)).get<bool>(); }
  int64_t getInt(const std::string& name, int64_t d) override {
    const auto v = get(name, rclcpp::ParameterValue(d));
    return v.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE ? static_cast<int64_t>(v.get<double>())
                                                                   : v.get<int64_t>();
  }
  double getDouble(const std::string& name, double d) override {
    const auto v = get(name, rclcpp::ParameterValue(d));
    return v.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER ? static_cast<double>(v.get<int64_t>())
                                                                    : v.get<double>();
  }
  std::string getString(const std::string& name, const std::string& d) override {
    return get(name, rclcpp::ParameterValue(d)).get<std::string>();
  }
  std::vector<int64_t> getIntArray(const std::string& name, const std::vector<int64_t>& d) override {
    const auto v = get(name, rclcpp::ParameterValue(d.empty() ? std::vector<int64_t>{-1} : d));
    std::vector<int64_t> out = v.get<std::vector<int64_t>>();
    // ROS2 YAML 은 빈 배열 타입을 추론할 수 없어 [-1] 을 '빈 값' 표기로 사용
    if (d.empty() && out.size() == 1 && out[0] == -1) out.clear();
    return out;
  }
  std::vector<double> getDoubleArray(const std::string& name, const std::vector<double>& d) override {
    const auto v = get(name, rclcpp::ParameterValue(d));
    if (v.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER_ARRAY) {
      const auto iv = v.get<std::vector<int64_t>>();
      return std::vector<double>(iv.begin(), iv.end());
    }
    return v.get<std::vector<double>>();
  }

 private:
  rclcpp::ParameterValue get(const std::string& name, const rclcpp::ParameterValue& def) {
    if (!n_.has_parameter(name)) {
      rcl_interfaces::msg::ParameterDescriptor desc;
      desc.dynamic_typing = true;
      desc.read_only = true;  // 활성 중 변경 불가 (재구성은 cleanup → configure)
      return n_.declare_parameter(name, def, desc);
    }
    return n_.get_parameter(name).get_parameter_value();
  }
  rclcpp_lifecycle::LifecycleNode& n_;
};

builtin_interfaces::msg::Time toRosTime(int64_t ns) {
  builtin_interfaces::msg::Time t;
  t.sec = static_cast<int32_t>(ns / 1'000'000'000);
  t.nanosec = static_cast<uint32_t>(ns % 1'000'000'000);
  return t;
}

diagnostic_msgs::msg::KeyValue kv(const std::string& k, const std::string& v) {
  diagnostic_msgs::msg::KeyValue x;
  x.key = k;
  x.value = v;
  return x;
}
std::string f2(double v) {
  char b[32];
  std::snprintf(b, sizeof(b), "%.2f", v);
  return b;
}

}  // namespace

VisionAcquisitionNode::VisionAcquisitionNode(const rclcpp::NodeOptions& options)
    : rclcpp_lifecycle::LifecycleNode("vision_acquisition_node", options) {
  autostart_ = declare_parameter<bool>("autostart", true);
  RCLCPP_INFO(get_logger(), "vision_acquisition_node 생성 (unconfigured)");
}

VisionAcquisitionNode::~VisionAcquisitionNode() { stopPipeline(); }

std::string VisionAcquisitionNode::resolvePath(const std::string& p) const {
  const std::string pfx = "package://";
  if (p.rfind(pfx, 0) != 0) return p;
  const auto rest = p.substr(pfx.size());
  const auto slash = rest.find('/');
  const std::string pkg = rest.substr(0, slash);
  return ament_index_cpp::get_package_share_directory(pkg) + (slash == std::string::npos ? "" : rest.substr(slash));
}

VisionAcquisitionNode::CallbackReturn VisionAcquisitionNode::on_configure(const rclcpp_lifecycle::State&) {
  RosParamSource params(*this);
  try {
    frame_id_ = params.getString("frame_id", "dock_vision");
    per_camera_topics_ = params.getBool("publish_per_camera_topics", false);
    watchdog_stall_ns_ = params.getInt("watchdog_stall_ms", 300) * 1'000'000;
    const auto out_topic = params.getString("output_topic", "/vision/tag_detections");
    const auto pose_topic = params.getString("pose_feedback_topic", "/sub_pose_filtered");
    const auto alert_topic = params.getString("alert_topic", "/hmi/vision_alerts");
    const auto diag_ms = params.getInt("diagnostics_period_ms", 1000);

    std::string err;
    if (!buildPipelineConfig(params, [this](const std::string& s) { return resolvePath(s); }, cfg_, err)) {
      RCLCPP_ERROR(get_logger(), "설정 실패: %s", err.c_str());
      return CallbackReturn::FAILURE;
    }
    std::map<int, Pose3> dummy;
    const auto extr = resolvePath(params.getString("extrinsics_file", ""));
    if (!extr.empty()) loadExtrinsics(extr, dummy, world_frame_, err);

    // QoS: 센서 데이터는 최신값 우선(keep_last 5, reliable - 후단 EKF 손실 방지)
    const auto qos = rclcpp::QoS(rclcpp::KeepLast(5)).reliable().durability_volatile();
    pub_ = create_publisher<TagArray>(out_topic, qos);
    if (per_camera_topics_)
      for (const auto& ch : cfg_.channels)
        cam_pubs_[ch.camera.camera_id - 1] =
            create_publisher<TagArray>("/camera_" + std::to_string(ch.camera.camera_id) + "/detected_tags", qos);
    alert_pub_ = create_publisher<std_msgs::msg::String>(alert_topic, rclcpp::QoS(20).reliable());
    diag_pub_ = create_publisher<diagnostic_msgs::msg::DiagnosticArray>("/diagnostics", rclcpp::QoS(10));

    if (cfg_.roi.enable && cfg_.roi.use_pose_feedback && !pose_topic.empty()) {
      pose_sub_ = create_subscription<nav_msgs::msg::Odometry>(
          pose_topic, rclcpp::SensorDataQoS(),
          [this](nav_msgs::msg::Odometry::ConstSharedPtr m) { onPose(m); });
    }
    diag_timer_ = create_wall_timer(std::chrono::milliseconds(diag_ms), [this] { publishDiagnostics(); });
    diag_timer_->cancel();

    pipeline_ = std::make_unique<AcquisitionPipeline>(cfg_);
    pipeline_->setResultCallback([this](SyncedResult& r) { onResult(r); });
    pipeline_->setEventCallback([this](const PipelineEvent& e) { onEvent(e); });

    RCLCPP_INFO(get_logger(), "configured: %zu채널, driver=%s, %dx%d@%.0ffps, undistort=%s, ROI=%s, 출력=%s",
                cfg_.channels.size(), cfg_.channels.front().camera.driver.c_str(), cfg_.channels.front().camera.width,
                cfg_.channels.front().camera.height, cfg_.channels.front().camera.fps,
                cfg_.preprocess.undistort_mode == UndistortMode::kRemap ? "remap" : "corners/none",
                cfg_.roi.enable ? "on" : "off", out_topic.c_str());
    return CallbackReturn::SUCCESS;
  } catch (const std::exception& e) {
    RCLCPP_ERROR(get_logger(), "configure 예외: %s", e.what());
    return CallbackReturn::FAILURE;
  }
}

VisionAcquisitionNode::CallbackReturn VisionAcquisitionNode::on_activate(const rclcpp_lifecycle::State&) {
  pub_->on_activate();
  for (auto& p : cam_pubs_)
    if (p) p->on_activate();
  alert_pub_->on_activate();
  diag_pub_->on_activate();

  std::string err;
  active_ = true;  // 시작 직후 발행 콜백이 들어오므로 먼저 설정
  if (!pipeline_->start(err, false)) {
    active_ = false;
    RCLCPP_ERROR(get_logger(), "파이프라인 시작 실패: %s", err.c_str());
    return CallbackReturn::FAILURE;
  }
  diag_timer_->reset();
  RCLCPP_INFO(get_logger(), "activated: 수집 시작 (연결 마스크 0x%02x)", pipeline_->connectedMask());
  return CallbackReturn::SUCCESS;
}

void VisionAcquisitionNode::stopPipeline() {
  active_ = false;
  if (pipeline_) pipeline_->stop();
}

VisionAcquisitionNode::CallbackReturn VisionAcquisitionNode::on_deactivate(const rclcpp_lifecycle::State&) {
  stopPipeline();
  if (diag_timer_) diag_timer_->cancel();
  pub_->on_deactivate();
  for (auto& p : cam_pubs_)
    if (p) p->on_deactivate();
  alert_pub_->on_deactivate();
  diag_pub_->on_deactivate();
  RCLCPP_INFO(get_logger(), "deactivated: 수집 정지");
  return CallbackReturn::SUCCESS;
}

VisionAcquisitionNode::CallbackReturn VisionAcquisitionNode::on_cleanup(const rclcpp_lifecycle::State&) {
  stopPipeline();
  pipeline_.reset();
  diag_timer_.reset();
  pose_sub_.reset();
  pub_.reset();
  for (auto& p : cam_pubs_) p.reset();
  alert_pub_.reset();
  diag_pub_.reset();
  return CallbackReturn::SUCCESS;
}

VisionAcquisitionNode::CallbackReturn VisionAcquisitionNode::on_shutdown(const rclcpp_lifecycle::State&) {
  stopPipeline();
  return CallbackReturn::SUCCESS;
}

VisionAcquisitionNode::CallbackReturn VisionAcquisitionNode::on_error(const rclcpp_lifecycle::State&) {
  RCLCPP_FATAL(get_logger(), "오류 상태 진입 → 파이프라인 정지. 프로세스 재기동(systemd) 필요");
  stopPipeline();
  return CallbackReturn::FAILURE;  // finalized → main 이 비정상 종료코드로 종료 → systemd Restart
}

bool VisionAcquisitionNode::healthy() const {
  if (!active_ || !pipeline_) return true;  // 의도적 비활성 상태는 정상
  return monoNowNs() - pipeline_->heartbeatMonoNs() < watchdog_stall_ns_;
}

// ───────────────────────────── 발행 (집계 스레드) ─────────────────────────────
void VisionAcquisitionNode::onResult(SyncedResult& r) {
  if (!active_.load(std::memory_order_relaxed)) return;
  auto msg = std::make_unique<TagArray>();  // intra-process 시 zero-copy 전달
  msg->header.stamp = toRosTime(r.stamp_ns);
  msg->header.frame_id = frame_id_;
  msg->active_camera_mask = r.active_camera_mask;
  msg->detections.resize(r.detections.size());
  for (size_t i = 0; i < r.detections.size(); ++i) {
    const auto& d = r.detections[i];
    auto& o = msg->detections[i];
    o.camera_id = d.camera_id;
    o.tag_id = d.tag_id;
    o.decision_margin = d.decision_margin;
    o.hamming_error = d.hamming;
    for (int k = 0; k < 4; ++k) {
      o.corners[k].x = d.corners[k].x;
      o.corners[k].y = d.corners[k].y;
      o.corners[k].z = 0.f;
    }
    o.center.x = d.center.x;
    o.center.y = d.center.y;
    o.center.z = 0.f;
  }

  if (per_camera_topics_) {
    for (const auto& ch : cfg_.channels) {
      auto& p = cam_pubs_[ch.camera.camera_id - 1];
      if (!p) continue;
      auto cm = std::make_unique<TagArray>();
      cm->header = msg->header;
      cm->header.frame_id = frame_id_ + "/camera_" + std::to_string(ch.camera.camera_id);
      const uint8_t bit = static_cast<uint8_t>(1u << (ch.camera.camera_id - 1));
      cm->active_camera_mask = r.active_camera_mask & bit;
      for (const auto& d : msg->detections)
        if (d.camera_id == ch.camera.camera_id) cm->detections.push_back(d);
      cm->processing_time_ms = static_cast<float>((monoNowNs() - r.earliest_recv_mono_ns) * 1e-6);
      p->publish(std::move(cm));
    }
  }
  // 설계 정의: 버퍼 수신 ~ 토픽 발행 시점. 메시지 변환까지 포함하여 발행 직전에 계측.
  msg->processing_time_ms = static_cast<float>((monoNowNs() - r.earliest_recv_mono_ns) * 1e-6);
  r.processing_time_ms = msg->processing_time_ms;
  try {
    pub_->publish(std::move(msg));
  } catch (const std::exception& e) {
    if (publish_errors_.fetch_add(1) % 100 == 0) RCLCPP_ERROR(get_logger(), "publish 실패: %s", e.what());
  }
}

void VisionAcquisitionNode::onEvent(const PipelineEvent& e) {
  const std::string text = std::string(eventCodeName(e.code)) + "|ch=" + std::to_string(e.camera_id) + "|" + e.message;
  switch (e.code) {
    case EventCode::kInfo:
    case EventCode::kCamRecovered: RCLCPP_INFO(get_logger(), "%s", text.c_str()); break;
    case EventCode::kPipelineStall: RCLCPP_ERROR(get_logger(), "%s", text.c_str()); break;
    default: RCLCPP_WARN(get_logger(), "%s", text.c_str()); break;
  }
  if (e.code != EventCode::kInfo && alert_pub_ && alert_pub_->is_activated()) {
    std_msgs::msg::String m;
    m.data = text;
    alert_pub_->publish(m);
  }
}

void VisionAcquisitionNode::onPose(const nav_msgs::msg::Odometry::ConstSharedPtr& m) {
  if (!pipeline_) return;
  if (!world_frame_.empty() && m->header.frame_id != world_frame_ && !pose_frame_warned_.exchange(true))
    RCLCPP_WARN(get_logger(), "pose_feedback frame '%s' ≠ 외부파라미터 world_frame '%s' (동적 ROI 오차 가능)",
                m->header.frame_id.c_str(), world_frame_.c_str());
  PoseSnapshot p;
  p.stamp_ns = static_cast<int64_t>(m->header.stamp.sec) * 1'000'000'000 + m->header.stamp.nanosec;
  const auto& q = m->pose.pose.orientation;
  const cv::Matx33d R = rotationFromQuaternion(q.w, q.x, q.y, q.z);
  for (int i = 0; i < 9; ++i) p.R_world_body[i] = R.val[i];
  p.t_world_body[0] = m->pose.pose.position.x;
  p.t_world_body[1] = m->pose.pose.position.y;
  p.t_world_body[2] = m->pose.pose.position.z;
  p.v_body[0] = m->twist.twist.linear.x;
  p.v_body[1] = m->twist.twist.linear.y;
  p.v_body[2] = m->twist.twist.linear.z;
  p.w_body[0] = m->twist.twist.angular.x;
  p.w_body[1] = m->twist.twist.angular.y;
  p.w_body[2] = m->twist.twist.angular.z;
  pipeline_->setPoseFeedback(p);
}

void VisionAcquisitionNode::publishDiagnostics() {
  if (!pipeline_ || !diag_pub_ || !diag_pub_->is_activated()) return;
  const PipelineStats s = pipeline_->stats();
  diagnostic_msgs::msg::DiagnosticArray arr;
  arr.header.stamp = now();
  using DS = diagnostic_msgs::msg::DiagnosticStatus;

  DS ps;
  ps.name = "vision_acquisition: pipeline";
  ps.hardware_id = frame_id_;
  ps.level = DS::OK;
  ps.message = "OK";
  if (s.processing_ms.p99 > 10.0) { ps.level = DS::WARN; ps.message = "처리지연 p99 > 10ms"; }
  if (pipeline_->connectedMask() == 0) { ps.level = DS::ERROR; ps.message = "수신 중인 카메라 없음"; }
  ps.values = {kv("publish_fps", f2(s.publish_fps)), kv("published", std::to_string(s.published)),
               kv("partial_published", std::to_string(s.partial_published)),
               kv("empty_published", std::to_string(s.empty_published)),
               kv("late_results", std::to_string(s.late_results)),
               kv("processing_ms_mean", f2(s.processing_ms.mean)), kv("processing_ms_p99", f2(s.processing_ms.p99)),
               kv("processing_ms_max", f2(s.processing_ms.max_all)),
               kv("exposure_dev_us_max", f2(s.stamp_dev_us.max)), kv("sync_violations", std::to_string(s.sync_violations)),
               kv("active_camera_mask", std::to_string(pipeline_->connectedMask()))};
  arr.status.push_back(ps);

  for (const auto& c : s.channels) {
    DS cs;
    cs.name = "vision_acquisition: camera_" + std::to_string(c.camera_id);
    for (const auto& ch : cfg_.channels)
      if (ch.camera.camera_id == c.camera_id) cs.hardware_id = ch.camera.device_id;
    cs.level = c.connected ? DS::OK : DS::ERROR;
    cs.message = c.connected ? "streaming" : "WARN_CAM_DROPOUT";
    if (c.connected && (c.seq_gaps > 0 || c.frames_incomplete > 0)) { cs.level = DS::WARN; cs.message = "프레임/패킷 손실 발생"; }
    cs.values = {kv("fps", f2(c.fps)), kv("frames_grabbed", std::to_string(c.frames_grabbed)),
                 kv("frames_processed", std::to_string(c.frames_processed)),
                 kv("frames_skipped_stale", std::to_string(c.frames_skipped_stale)),
                 kv("seq_gaps", std::to_string(c.seq_gaps)), kv("frames_incomplete", std::to_string(c.frames_incomplete)),
                 kv("packets_missing", std::to_string(c.camera.packets_missing)),
                 kv("packets_resent", std::to_string(c.camera.packets_resent)),
                 kv("disconnects", std::to_string(c.disconnects)), kv("reconnects", std::to_string(c.reconnects)),
                 kv("work_ms_mean", f2(c.work_ms.mean)), kv("work_ms_p99", f2(c.work_ms.p99)),
                 kv("roi_ratio", f2(c.frames_processed ? double(c.roi_frames) / c.frames_processed : 0.0)),
                 kv("roi_fallbacks", std::to_string(c.roi_fallbacks)),
                 kv("filter_rejected", std::to_string(c.filter.total_rejected()))};
    arr.status.push_back(cs);
  }
  diag_pub_->publish(arr);
}

}  // namespace pva

RCLCPP_COMPONENTS_REGISTER_NODE(pva::VisionAcquisitionNode)
