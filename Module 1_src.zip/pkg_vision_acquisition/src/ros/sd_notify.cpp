// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// systemd sd_notify 최소 구현 (libsystemd 의존성 없이 NOTIFY_SOCKET 데이터그램 전송)
#include "sd_notify.hpp"

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <string>

namespace pva {

bool sdNotify(const std::string& state) {
  const char* path = std::getenv("NOTIFY_SOCKET");
  if (!path || !*path) return false;
  sockaddr_un addr{};
  addr.sun_family = AF_UNIX;
  const size_t len = std::strlen(path);
  if (len >= sizeof(addr.sun_path)) return false;
  std::memcpy(addr.sun_path, path, len);
  if (addr.sun_path[0] == '@') addr.sun_path[0] = '\0';  // abstract namespace
  const int fd = ::socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (fd < 0) return false;
  const auto alen = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + len);
  const ssize_t n = ::sendto(fd, state.data(), state.size(), MSG_NOSIGNAL, reinterpret_cast<sockaddr*>(&addr), alen);
  ::close(fd);
  return n == static_cast<ssize_t>(state.size());
}

int64_t sdWatchdogUsec() {
  const char* us = std::getenv("WATCHDOG_USEC");
  if (!us) return 0;
  const char* pid = std::getenv("WATCHDOG_PID");
  if (pid && std::strtol(pid, nullptr, 10) != static_cast<long>(::getpid())) return 0;
  return std::strtoll(us, nullptr, 10);
}

}  // namespace pva
