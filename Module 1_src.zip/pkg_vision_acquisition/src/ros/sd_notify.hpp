// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
#pragma once

#include <cstdint>
#include <string>

namespace pva {

/// systemd 로 상태 통지 ("READY=1", "WATCHDOG=1", "STATUS=..."). systemd 하가 아니면 false.
bool sdNotify(const std::string& state);

/// systemd WatchdogSec 설정값 [us] (미설정 시 0)
int64_t sdWatchdogUsec();

}  // namespace pva
