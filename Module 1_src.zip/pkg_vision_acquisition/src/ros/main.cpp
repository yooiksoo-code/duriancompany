// Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
//
// vision_acquisition_node 단독 실행 진입점 (systemd 서비스용)
//  - autostart=true 이면 configure → activate 자동 전이
//  - systemd Type=notify: 활성화 완료 시 READY=1, 파이프라인 정상 시에만 WATCHDOG=1
//    → 집계 루프 정지(hang) 시 watchdog 만료로 강제 재기동, 비정상 종료 시 Restart=always
#include <algorithm>

#include <lifecycle_msgs/msg/state.hpp>
#include <rclcpp/rclcpp.hpp>

#include "pkg_vision_acquisition/vision_acquisition_node.hpp"
#include "sd_notify.hpp"

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions opts;
  opts.use_intra_process_comms(false);  // 단독 프로세스: DDS(CycloneDDS) 경유
  auto node = std::make_shared<pva::VisionAcquisitionNode>(opts);
  rclcpp::executors::SingleThreadedExecutor exec;
  exec.add_node(node->get_node_base_interface());

  using lifecycle_msgs::msg::State;
  int exit_code = 0;
  if (node->autostart()) {
    if (node->configure().id() != State::PRIMARY_STATE_INACTIVE) {
      RCLCPP_FATAL(node->get_logger(), "configure 실패");
      rclcpp::shutdown();
      return 2;
    }
    if (node->activate().id() != State::PRIMARY_STATE_ACTIVE) {
      RCLCPP_FATAL(node->get_logger(), "activate 실패");
      rclcpp::shutdown();
      return 3;
    }
  }

  // systemd 연동
  pva::sdNotify("READY=1\nSTATUS=vision_acquisition active");
  // 감시 타이머: (1) 오류로 finalized 되면 비정상 종료코드로 빠져나가 systemd 재기동 유도
  //            (2) watchdog 사용 시 파이프라인 정상일 때만 WATCHDOG=1 (hang → 만료 → 강제 재기동)
  const int64_t wd_us = pva::sdWatchdogUsec();
  const int64_t period_us = wd_us > 0 ? std::clamp<int64_t>(wd_us / 3, 10'000, 200'000) : 200'000;
  auto sup_timer = node->create_wall_timer(std::chrono::microseconds(period_us), [node, &exec, &exit_code, wd_us] {
    if (node->get_current_state().id() == State::PRIMARY_STATE_FINALIZED) {
      exit_code = 4;
      exec.cancel();
      return;
    }
    if (wd_us > 0 && node->healthy()) pva::sdNotify("WATCHDOG=1");
  });
  if (wd_us > 0) RCLCPP_INFO(node->get_logger(), "systemd watchdog 활성 (WatchdogSec=%.0f ms)", wd_us / 1000.0);

  exec.spin();

  pva::sdNotify("STOPPING=1");
  if (node->get_current_state().id() == State::PRIMARY_STATE_ACTIVE) node->deactivate();
  if (node->get_current_state().id() == State::PRIMARY_STATE_INACTIVE) node->cleanup();
  rclcpp::shutdown();
  return exit_code;
}
