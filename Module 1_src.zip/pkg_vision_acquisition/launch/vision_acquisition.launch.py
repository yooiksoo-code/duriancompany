# Copyright (c) 2026 주식회사 두리안컴퍼니. All rights reserved.
"""vision_acquisition_node 실행.

  ros2 launch pkg_vision_acquisition vision_acquisition.launch.py                # 실장비 (Aravis)
  ros2 launch pkg_vision_acquisition vision_acquisition.launch.py sim:=true      # 시뮬레이터
  ros2 launch pkg_vision_acquisition vision_acquisition.launch.py composed:=true # 컴포넌트(intra-process zero-copy)
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import ComposableNodeContainer, Node
from launch_ros.descriptions import ComposableNode


def _setup(context):
    share = get_package_share_directory('pkg_vision_acquisition')
    params = [LaunchConfiguration('params_file').perform(context)]
    if LaunchConfiguration('sim').perform(context).lower() == 'true':
        params.append(os.path.join(share, 'config', 'vision_acquisition_sim.yaml'))
    log_level = LaunchConfiguration('log_level').perform(context)

    if LaunchConfiguration('composed').perform(context).lower() == 'true':
        # 컴포넌트 실행 시 라이프사이클 전이는 외부(lifecycle manager / ros2 lifecycle set)에서 수행
        return [ComposableNodeContainer(
            name='inhaul_vision_container', namespace='', package='rclcpp_components',
            executable='component_container_mt', output='screen',
            arguments=['--ros-args', '--log-level', log_level],
            composable_node_descriptions=[
                ComposableNode(
                    package='pkg_vision_acquisition', plugin='pva::VisionAcquisitionNode',
                    name='vision_acquisition_node', parameters=params,
                    extra_arguments=[{'use_intra_process_comms': True}]),
                # [모듈 2] pose_estimation_node 를 같은 컨테이너에 추가하면 TagDetectionArray 가 복사 없이 전달됨
            ])]
    return [Node(
        package='pkg_vision_acquisition', executable='vision_acquisition_node',
        name='vision_acquisition_node', output='screen', emulate_tty=True,
        parameters=params, arguments=['--ros-args', '--log-level', log_level])]


def generate_launch_description():
    share = get_package_share_directory('pkg_vision_acquisition')
    return LaunchDescription([
        DeclareLaunchArgument('sim', default_value='false', description='시뮬레이션 카메라 사용'),
        DeclareLaunchArgument('composed', default_value='false', description='컴포넌트 컨테이너 실행'),
        DeclareLaunchArgument('params_file', default_value=os.path.join(share, 'config', 'vision_acquisition.yaml')),
        DeclareLaunchArgument('log_level', default_value='info'),
        SetEnvironmentVariable('RMW_IMPLEMENTATION', 'rmw_cyclonedds_cpp'),
        SetEnvironmentVariable('CYCLONEDDS_URI', 'file://' + os.path.join(share, 'config', 'cyclonedds.xml')),
        OpaqueFunction(function=_setup),
    ])
