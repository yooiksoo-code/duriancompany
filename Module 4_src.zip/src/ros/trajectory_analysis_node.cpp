#include "pkg_inhaul_trajectory/trajectory_analysis_node.hpp"

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <lifecycle_msgs/msg/state.hpp>
#include <rclcpp_components/register_node_macro.hpp>

namespace pit {
namespace {
// libsystemd 의존 없이 sd_notify (Type=notify, WatchdogSec)
bool sdNotify(const char* state) {
  const char* path = std::getenv("NOTIFY_SOCKET");
  if (!path || !*path) return false;
  const int fd = ::socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (fd < 0) return false;
  sockaddr_un addr{};
  addr.sun_family = AF_UNIX;
  const size_t n = std::min(std::strlen(path), sizeof(addr.sun_path) - 1);
  std::memcpy(addr.sun_path, path, n);
  if (addr.sun_path[0] == '@') addr.sun_path[0] = '\0';  // abstract namespace
  const socklen_t len = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + n);
  const bool ok = ::sendto(fd, state, std::strlen(state), MSG_NOSIGNAL,
                           reinterpret_cast<sockaddr*>(&addr), len) >= 0;
  ::close(fd);
  return ok;
}
}  // namespace

int64_t TrajectoryAnalysisNode::steadyNs() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
             std::chrono::steady_clock::now().time_since_epoch())
      .count();
}

TrajectoryAnalysisNode::TrajectoryAnalysisNode(const rclcpp::NodeOptions& options)
    : rclcpp_lifecycle::LifecycleNode("trajectory_analysis_node", options) {
  std::string def_cfg;
  try {
    def_cfg = ament_index_cpp::get_package_share_directory("pkg_inhaul_trajectory") +
              "/config/dock_trajectory_profile.yaml";
  } catch (...) {
  }
  declare_parameter("config_file", def_cfg);
  declare_parameter("pose_topic", "/sub_pose_filtered");
  declare_parameter("tension_topic", "/winch_tension_raw");
  declare_parameter("upstream_interlock_topic", "/sensor_fusion/safety_interlock");
  declare_parameter("status_topic", "/inhaul/alignment_status");
  declare_parameter("diagnostics_topic", "/inhaul/trajectory_diagnostics");
  declare_parameter("interlock_topic", "/inhaul/safety_interlock");
  declare_parameter("alerts_topic", "/hmi/trajectory_alerts");
  declare_parameter("twist_in_child_frame", true);   // nav_msgs 규약 (모듈 3 I3)
  declare_parameter("watchdog_period_ms", 2.0);
  declare_parameter("lost_publish_period_ms", 10.0); // 포즈 상실 중 지령 0 발행 주기
  declare_parameter("diagnostics_every_n", 1);
  declare_parameter("autostart", true);              // 단독 실행 시 configure→activate 자동

  if (get_parameter("autostart").as_bool()) {
    autostart_timer_ = create_wall_timer(std::chrono::milliseconds(0), [this]() {
      autostart_timer_->cancel();
      if (configure().id() != lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE) {
        RCLCPP_FATAL(get_logger(), "configure 실패 → 종료");
        rclcpp::shutdown();
        return;
      }
      activate();
    });
  }
}

TrajectoryAnalysisNode::~TrajectoryAnalysisNode() { sdNotify("STOPPING=1"); }

TrajectoryAnalysisNode::CallbackReturn TrajectoryAnalysisNode::on_configure(
    const rclcpp_lifecycle::State&) {
  config_file_ = get_parameter("config_file").as_string();
  cfg_ = TrajectoryConfig{};
  std::string err;
  if (!config_file_.empty() && !loadTrajectoryConfig(config_file_, &cfg_, &err)) {
    RCLCPP_ERROR(get_logger(), "설정 로드 실패: %s", err.c_str());
    return CallbackReturn::FAILURE;
  }
  if (!engine_.configure(cfg_, &err)) {
    RCLCPP_ERROR(get_logger(), "설정 검증 실패: %s", err.c_str());
    return CallbackReturn::FAILURE;
  }
  twist_in_child_ = get_parameter("twist_in_child_frame").as_bool();
  lost_publish_period_s_ = get_parameter("lost_publish_period_ms").as_double() * 1e-3;
  diag_every_n_ = std::max<int>(1, get_parameter("diagnostics_every_n").as_int());

  status_pub_ = create_publisher<inhaul_msgs::msg::AlignmentStatus>(
      get_parameter("status_topic").as_string(), rclcpp::QoS(10).reliable());
  diag_pub_ = create_publisher<inhaul_msgs::msg::TrajectoryDiagnostics>(
      get_parameter("diagnostics_topic").as_string(), rclcpp::QoS(10).reliable());
  alert_pub_ = create_publisher<std_msgs::msg::String>(get_parameter("alerts_topic").as_string(),
                                                       rclcpp::QoS(50).reliable());
  // transient_local 은 intra-process 와 호환되지 않음 (모듈 3 8.4-3) → 이 발행자만 비활성
  rclcpp::PublisherOptions latched_opts;
  latched_opts.use_intra_process_comm = rclcpp::IntraProcessSetting::Disable;
  interlock_pub_ = create_publisher<std_msgs::msg::Bool>(
      get_parameter("interlock_topic").as_string(), rclcpp::QoS(1).reliable().transient_local(),
      latched_opts);

  RCLCPP_INFO(get_logger(),
              "설정: %s | 중심선 %zu점 L=%.3f m, 목표 s=%.3f m, frame=%s | v_max %.2f m/min, "
              "감속거리 %.3f m | 펜스 %.0f/%.0f mm, %.1f/%.1f° | pose_timeout %.0f ms",
              config_file_.c_str(), cfg_.dock.centerline.size(),
              engine_.deviation().centerline().length(), engine_.deviation().targetArcLength(),
              cfg_.dock.frame_id.c_str(), cfg_.profile.v_max_mpm,
              engine_.profile().profile().decelDistance(), cfg_.safety.y_warn_m * 1e3,
              cfg_.safety.y_danger_m * 1e3, cfg_.safety.yaw_warn_deg, cfg_.safety.yaw_danger_deg,
              cfg_.safety.pose_timeout_s * 1e3);
  return CallbackReturn::SUCCESS;
}

TrajectoryAnalysisNode::CallbackReturn TrajectoryAnalysisNode::on_activate(
    const rclcpp_lifecycle::State& st) {
  LifecycleNode::on_activate(st);
  engine_.reset();
  frame_warned_ = false;
  interlock_published_ = false;
  out_count_ = 0;
  active_ = true;

  const auto sensor_qos = rclcpp::QoS(10).best_effort();  // reliable 발행자도 수신
  pose_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      get_parameter("pose_topic").as_string(), sensor_qos,
      [this](nav_msgs::msg::Odometry::SharedPtr m) { onPose(m); });
  tension_sub_ = create_subscription<inhaul_msgs::msg::WinchTensionArray>(
      get_parameter("tension_topic").as_string(), sensor_qos,
      [this](inhaul_msgs::msg::WinchTensionArray::SharedPtr m) { onTension(m); });
  // transient_local 구독도 intra-process 와 비호환 (composed:=true 에서 activate 실패 → on_error 재현) → 비활성
  rclcpp::SubscriptionOptions latched_sub_opts;
  latched_sub_opts.use_intra_process_comm = rclcpp::IntraProcessSetting::Disable;
  upstream_sub_ = create_subscription<std_msgs::msg::Bool>(
      get_parameter("upstream_interlock_topic").as_string(),
      rclcpp::QoS(1).reliable().transient_local(),
      [this](std_msgs::msg::Bool::SharedPtr m) { onUpstreamInterlock(m); }, latched_sub_opts);

  const double wd_ms = std::max(0.5, get_parameter("watchdog_period_ms").as_double());
  watchdog_timer_ = create_wall_timer(std::chrono::microseconds(static_cast<int64_t>(wd_ms * 1e3)),
                                      [this]() { onWatchdog(); });
  heartbeat_timer_ = create_wall_timer(std::chrono::milliseconds(100), [this]() { onHeartbeat(); });
  publishInterlock(true, true);  // 첫 포즈 전 = 미초기화 → 인터록
  sd_watchdog_ = sdNotify("READY=1");
  RCLCPP_INFO(get_logger(), "활성화 — %s 대기", get_parameter("pose_topic").as_string().c_str());
  return CallbackReturn::SUCCESS;
}

TrajectoryAnalysisNode::CallbackReturn TrajectoryAnalysisNode::on_deactivate(
    const rclcpp_lifecycle::State& st) {
  active_ = false;
  publishInterlock(true, true);
  pose_sub_.reset();
  tension_sub_.reset();
  upstream_sub_.reset();
  watchdog_timer_.reset();
  heartbeat_timer_.reset();
  LifecycleNode::on_deactivate(st);
  return CallbackReturn::SUCCESS;
}

TrajectoryAnalysisNode::CallbackReturn TrajectoryAnalysisNode::on_cleanup(
    const rclcpp_lifecycle::State&) {
  status_pub_.reset();
  diag_pub_.reset();
  interlock_pub_.reset();
  alert_pub_.reset();
  return CallbackReturn::SUCCESS;
}

TrajectoryAnalysisNode::CallbackReturn TrajectoryAnalysisNode::on_shutdown(
    const rclcpp_lifecycle::State&) {
  active_ = false;
  sdNotify("STOPPING=1");
  return CallbackReturn::SUCCESS;
}

TrajectoryAnalysisNode::CallbackReturn TrajectoryAnalysisNode::on_error(
    const rclcpp_lifecycle::State&) {
  RCLCPP_FATAL(get_logger(), "on_error → 프로세스 종료(4), systemd 재기동");
  std::_Exit(4);
}

void TrajectoryAnalysisNode::onPose(const nav_msgs::msg::Odometry::SharedPtr msg) {
  const int64_t t0 = steadyNs();
  if (!active_) return;
  if (msg->header.frame_id != cfg_.dock.frame_id) {
    if (!frame_warned_)
      RCLCPP_WARN(get_logger(), "포즈 frame_id '%s' ≠ '%s' → 기각", msg->header.frame_id.c_str(),
                  cfg_.dock.frame_id.c_str());
    frame_warned_ = true;
    return;
  }
  PoseInput p;
  p.stamp_ns = rclcpp::Time(msg->header.stamp).nanoseconds();
  const auto& pp = msg->pose.pose.position;
  const auto& q = msg->pose.pose.orientation;
  const auto& v = msg->twist.twist.linear;
  const auto& w = msg->twist.twist.angular;
  p.p = Vec3(pp.x, pp.y, pp.z);
  p.q = Quat(q.w, q.x, q.y, q.z);
  p.v = Vec3(v.x, v.y, v.z);
  p.w = Vec3(w.x, w.y, w.z);
  p.twist_in_child_frame = twist_in_child_;
  p.twist_valid = true;
  auto out = engine_.onPose(t0, p);
  if (out) publish(*out, rclcpp::Time(msg->header.stamp), t0);
  flushAlerts();
}

void TrajectoryAnalysisNode::onTension(const inhaul_msgs::msg::WinchTensionArray::SharedPtr msg) {
  if (!active_) return;
  TensionInput in;
  in.stamp_ns = rclcpp::Time(msg->header.stamp).nanoseconds();
  for (int i = 0; i < kNumWinch; ++i) {
    in.tension_kn[i] = msg->tension[i];
    in.hw_status[i] = msg->channel_status[i];
  }
  last_tension_rx_ = steadyNs();
  engine_.onTension(last_tension_rx_, in);
}

void TrajectoryAnalysisNode::onUpstreamInterlock(const std_msgs::msg::Bool::SharedPtr msg) {
  if (!active_) return;
  engine_.onUpstreamInterlock(steadyNs(), msg->data);
  flushAlerts();
}

void TrajectoryAnalysisNode::onWatchdog() {
  if (!active_) return;
  const int64_t now = steadyNs();
  auto z = engine_.checkWatchdog(now);
  if (z) {
    if (nsToSec(now - last_lost_pub_) >= lost_publish_period_s_ - 1e-4) {
      last_lost_pub_ = now;
      publish(*z, this->now(), now);
    } else {
      publishInterlock(true, false);
    }
  }
  flushAlerts();
}

void TrajectoryAnalysisNode::onHeartbeat() {
  if (!active_) return;
  publishInterlock(!engine_.initialized() || engine_.poseLost() || engine_.last().interlock, true);
  if (sd_watchdog_) sdNotify("WATCHDOG=1");  // 실행기가 멈추면 WatchdogSec 후 재기동
}

void TrajectoryAnalysisNode::publishInterlock(bool active, bool force) {
  if (!interlock_pub_ || !interlock_pub_->is_activated()) return;
  if (!force && interlock_published_ && active == last_interlock_) return;  // force = 하트비트
  std_msgs::msg::Bool b;
  b.data = active;
  interlock_pub_->publish(b);
  last_interlock_ = active;
  interlock_published_ = true;
}

void TrajectoryAnalysisNode::publish(const AlignmentOutput& o, const rclcpp::Time& stamp,
                                     int64_t cb_start_ns) {
  if (!status_pub_ || !status_pub_->is_activated()) return;
  inhaul_msgs::msg::AlignmentStatus m;
  m.header.stamp = stamp;
  m.header.frame_id = cfg_.dock.frame_id;
  m.x_remain = static_cast<float>(o.x_remain_m);
  m.y_error = static_cast<float>(o.y_error_m);
  m.yaw_error = static_cast<float>(o.yaw_error_deg);
  m.z_error = static_cast<float>(o.z_error_m);
  m.delta_tension_bow = static_cast<float>(o.delta_tension_bow_kn);
  m.delta_tension_stern = static_cast<float>(o.delta_tension_stern_kn);
  m.target_inhaul_speed = static_cast<float>(o.target_inhaul_speed_mpm);
  m.correction_moment_z = static_cast<float>(o.correction_moment_z_knm);
  m.safety_status_code = o.safety_status_code;
  m.is_aligned = o.is_aligned;
  status_pub_->publish(m);
  // 인터록 전이는 같은 콜백에서 즉시 (KPI 6)
  publishInterlock(o.interlock || o.pose_lost, false);

  if ((out_count_++ % diag_every_n_) != 0) return;
  inhaul_msgs::msg::TrajectoryDiagnostics d;
  d.header = m.header;
  d.feedback_mode = static_cast<uint8_t>(o.tension.mode);
  d.tension_cause = static_cast<uint8_t>(o.tension.cause);
  d.initialized = engine_.initialized();
  d.pose_lost = o.pose_lost;
  d.upstream_interlock = o.upstream_interlock;
  d.interlock = o.interlock || o.pose_lost;
  d.hold_override = o.hold_override;
  d.speed_scale = static_cast<float>(o.speed_scale);
  d.v_ref_mpm = static_cast<float>(o.v_ref_mpm);
  d.v_target_mpm = static_cast<float>(o.v_target_mpm);
  d.y_error_rate_mps = static_cast<float>(o.y_error_rate_mps);
  d.yaw_error_rate_dps = static_cast<float>(o.yaw_error_rate_dps);
  d.along_speed_mps = static_cast<float>(o.along_speed_mps);
  d.s_along_m = static_cast<float>(o.s_along_m);
  d.segment = static_cast<uint16_t>(o.segment);
  d.lateral_metric_m = static_cast<float>(o.lateral_metric_m);
  d.mz_saturated = o.mz_saturated;
  d.correction_force_y_kn = static_cast<float>(o.correction_force_y_kn);
  for (int i = 0; i < kNumWinch; ++i) {
    d.channel_valid[i] = o.tension.channel_valid[i];
    d.channel_fault[i] = static_cast<uint8_t>(o.tension.fault[i]);
    d.tension_kn[i] = static_cast<float>(o.tension.tension_kn[i]);
    d.winch_speed_weight[i] = static_cast<float>(o.tension.speed_weight[i]);
  }
  d.residual_bow_kn = static_cast<float>(o.tension.residual_bow_kn);
  d.residual_stern_kn = static_cast<float>(o.tension.residual_stern_kn);
  d.mismatch_bow_kn = static_cast<float>(o.tension.mismatch_bow_kn);
  d.mismatch_stern_kn = static_cast<float>(o.tension.mismatch_stern_kn);
  d.compute_time_us = static_cast<float>(o.compute_time_us);
  const int64_t now_st = steadyNs();
  d.callback_time_us = static_cast<float>((now_st - cb_start_ns) * 1e-3);
  d.pose_age_ms = static_cast<float>((this->now() - stamp).seconds() * 1e3);
  d.tension_age_ms =
      last_tension_rx_ > 0 ? static_cast<float>((now_st - last_tension_rx_) * 1e-6) : -1.0f;
  const auto c = engine_.counters();
  d.poses = c.poses;
  d.poses_rejected = c.poses_rejected;
  d.pose_timeouts = c.pose_timeouts;
  d.danger_events = c.danger_events;
  d.hold_events = c.hold_events;
  d.loadcell_faults = c.loadcell_faults;
  d.upstream_interlocks = c.upstream_interlocks;
  diag_pub_->publish(d);
}

void TrajectoryAnalysisNode::flushAlerts() {
  auto alerts = engine_.takeAlerts();
  if (alerts.empty() || !alert_pub_ || !alert_pub_->is_activated()) return;
  for (const auto& a : alerts) {
    std_msgs::msg::String s;
    s.data = a.code + "|" + a.info;
    alert_pub_->publish(s);
    if (a.code.rfind("ERROR", 0) == 0 || a.code.rfind("ALARM", 0) == 0)
      RCLCPP_ERROR(get_logger(), "%s", s.data.c_str());
    else if (a.code.rfind("WARN", 0) == 0)
      RCLCPP_WARN(get_logger(), "%s", s.data.c_str());
    else
      RCLCPP_INFO(get_logger(), "%s", s.data.c_str());
  }
}

}  // namespace pit

RCLCPP_COMPONENTS_REGISTER_NODE(pit::TrajectoryAnalysisNode)
