// synthetic_inhaul_publisher — 모듈 3·윈치 제어반·윈치 연계(모듈 5) 없이 궤적분석 노드 전체를 폐루프로 검증
//  TestbedSim(선체+4점 와이어+윈치 에뮬레이터)을 벽시계로 진행하며
//   발행: /sub_pose_filtered (Odometry, 100 Hz, stamp = 발행 시각), /winch_tension_raw (100 Hz),
//         /sensor_fusion/safety_interlock (시나리오 펄스, transient_local), /sim/ground_truth_pose (Odometry)
//   구독: /inhaul/alignment_status (속도·모멘트 지령), /inhaul/trajectory_diagnostics (가중치·F_y 제안)
//  파라미터: scenario (T1~T6, T2a/T2b/T3a/T3b/T4a/T4b), loop (종료 후 재시작), noise
#include <chrono>
#include <inhaul_msgs/msg/alignment_status.hpp>
#include <inhaul_msgs/msg/trajectory_diagnostics.hpp>
#include <inhaul_msgs/msg/winch_tension_array.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/bool.hpp>

#include "pkg_inhaul_trajectory/sim_testbed.hpp"

using namespace std::chrono_literals;
using namespace pit;
using namespace pit::sim;

class SyntheticInhaulPublisher : public rclcpp::Node {
 public:
  SyntheticInhaulPublisher() : Node("synthetic_inhaul_publisher") {
    scenario_name_ = declare_parameter("scenario", "T1");
    loop_ = declare_parameter("loop", true);
    noise_ = declare_parameter("noise", true);
    frame_ = declare_parameter("frame_id", "dock_world_frame");
    start_delay_s_ = declare_parameter("start_delay_s", 1.0);
    pose_pub_ = create_publisher<nav_msgs::msg::Odometry>("/sub_pose_filtered", rclcpp::QoS(10).reliable());
    truth_pub_ = create_publisher<nav_msgs::msg::Odometry>("/sim/ground_truth_pose", rclcpp::QoS(10).reliable());
    tension_pub_ = create_publisher<inhaul_msgs::msg::WinchTensionArray>("/winch_tension_raw",
                                                                         rclcpp::QoS(10).reliable());
    upstream_pub_ = create_publisher<std_msgs::msg::Bool>(
        "/sensor_fusion/safety_interlock", rclcpp::QoS(1).reliable().transient_local());
    status_sub_ = create_subscription<inhaul_msgs::msg::AlignmentStatus>(
        "/inhaul/alignment_status", rclcpp::QoS(10).reliable(),
        [this](inhaul_msgs::msg::AlignmentStatus::SharedPtr m) {
          v_cmd_ = m->target_inhaul_speed / kMps2Mpm;
          mz_ = m->correction_moment_z;
          sim_.setCommand(v_cmd_, mz_, fy_, w_);
        });
    diag_sub_ = create_subscription<inhaul_msgs::msg::TrajectoryDiagnostics>(
        "/inhaul/trajectory_diagnostics", rclcpp::QoS(10).reliable(),
        [this](inhaul_msgs::msg::TrajectoryDiagnostics::SharedPtr d) {
          fy_ = d->correction_force_y_kn;
          for (int i = 0; i < kNumWinch; ++i) w_[i] = d->winch_speed_weight[i];
        });
    restart();
    timer_ = create_wall_timer(1ms, [this]() { tick(); });
    RCLCPP_INFO(get_logger(), "시나리오 %s (%.0f s, loop=%d) — 지령 수신 시 폐루프", sc_.name.c_str(),
                sc_.duration_s, loop_);
  }

 private:
  void restart() {
    sc_ = makeScenario(scenario_name_);
    sc_.noise = noise_;
    sc_.seed = static_cast<uint32_t>(7 + runs_);
    sim_.reset(sc_);
    v_cmd_ = mz_ = fy_ = 0.0;
    w_.fill(0.0);
    k_ = 0;
    upstream_ = false;
    publishUpstream(false);
    wall0_ = now();
    ++runs_;
  }
  void publishUpstream(bool v) {
    std_msgs::msg::Bool b;
    b.data = v;
    upstream_pub_->publish(b);
  }
  void tick() {
    // 벽시계를 따라 1 ms 물리 스텝 (지연 시 따라잡기, 최대 20 스텝)
    const double wall = (now() - wall0_).seconds() - start_delay_s_;
    if (wall < 0) return;
    int steps = 0;
    while (sim_.time() + 0.0005 < wall && steps++ < 20) {
      sim_.step(0.001);
      ++k_;
      const double t = sim_.time();
      if (sc_.upstream_interlock_pulse) {
        const bool u = t >= sc_.upstream_t0 && t < sc_.upstream_t1;
        if (u != upstream_) publishUpstream(u);
        upstream_ = u;
      }
      if (k_ % 10 == 3 && !inWindows(t, sc_.tension_blackouts)) publishTension();
      if (k_ % 10 == 0) {
        const auto stamp = now();
        if (!inWindows(t, sc_.pose_blackouts)) publishPose(sim_.measurePose(sc_.noise), stamp, pose_pub_);
        publishPose(sim_.measurePose(false), stamp, truth_pub_);
      }
      if (t >= sc_.duration_s) {
        if (!loop_) {
          RCLCPP_INFO(get_logger(), "시나리오 종료");
          timer_->cancel();
          return;
        }
        RCLCPP_INFO(get_logger(), "시나리오 %s 재시작 (%d회)", sc_.name.c_str(), runs_);
        restart();
        return;
      }
    }
  }
  void publishPose(const PoseInput& p, const rclcpp::Time& stamp,
                   const rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr& pub) {
    nav_msgs::msg::Odometry o;
    o.header.stamp = stamp;
    o.header.frame_id = frame_;
    o.child_frame_id = "submarine_base_link";
    o.pose.pose.position.x = p.p.x();
    o.pose.pose.position.y = p.p.y();
    o.pose.pose.position.z = p.p.z();
    o.pose.pose.orientation.w = p.q.w();
    o.pose.pose.orientation.x = p.q.x();
    o.pose.pose.orientation.y = p.q.y();
    o.pose.pose.orientation.z = p.q.z();
    o.twist.twist.linear.x = p.v.x();
    o.twist.twist.linear.y = p.v.y();
    o.twist.twist.linear.z = p.v.z();
    o.twist.twist.angular.x = p.w.x();
    o.twist.twist.angular.y = p.w.y();
    o.twist.twist.angular.z = p.w.z();
    pub->publish(o);
  }
  void publishTension() {
    const TensionInput in = sim_.measureTension(sc_.noise);
    inhaul_msgs::msg::WinchTensionArray m;
    m.header.stamp = now();
    m.header.frame_id = "winch_panel";
    for (int i = 0; i < kNumWinch; ++i) {
      m.tension[i] = static_cast<float>(in.tension_kn[i]);
      m.channel_status[i] = 0;
    }
    tension_pub_->publish(m);
  }

  std::string scenario_name_, frame_;
  bool loop_ = true, noise_ = true, upstream_ = false;
  double start_delay_s_ = 1.0;
  int runs_ = 0;
  long k_ = 0;
  Scenario sc_;
  TestbedSim sim_;
  double v_cmd_ = 0, mz_ = 0, fy_ = 0;
  std::array<double, kNumWinch> w_{{0, 0, 0, 0}};
  rclcpp::Time wall0_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr pose_pub_, truth_pub_;
  rclcpp::Publisher<inhaul_msgs::msg::WinchTensionArray>::SharedPtr tension_pub_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr upstream_pub_;
  rclcpp::Subscription<inhaul_msgs::msg::AlignmentStatus>::SharedPtr status_sub_;
  rclcpp::Subscription<inhaul_msgs::msg::TrajectoryDiagnostics>::SharedPtr diag_sub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SyntheticInhaulPublisher>());
  rclcpp::shutdown();
  return 0;
}
