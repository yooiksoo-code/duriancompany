// config/dock_trajectory_profile.yaml 로더 (YAML-CPP). 없는 키는 trajectory_config.hpp 기본값 유지.
#include <yaml-cpp/yaml.h>

#include "pkg_inhaul_trajectory/trajectory_analysis_engine.hpp"

namespace pit {
namespace {
template <typename T>
void get(const YAML::Node& n, const char* key, T* out) {
  if (n && n[key]) *out = n[key].as<T>();
}
bool readVec2(const YAML::Node& n, Vec2* out) {
  if (!n || !n.IsSequence() || n.size() != 2) return false;
  *out = Vec2(n[0].as<double>(), n[1].as<double>());
  return true;
}
}  // namespace

bool loadTrajectoryConfig(const std::string& path, TrajectoryConfig* cfg, std::string* err) {
  try {
    YAML::Node root = YAML::LoadFile(path);
    if (root["trajectory_analysis_node"]) {
      // ROS2 파라미터 파일 형식과 겸용 허용 (node: ros__parameters: 아래에 둔 경우)
      YAML::Node p = root["trajectory_analysis_node"]["ros__parameters"];
      if (p) root = p;
    }
    if (const YAML::Node d = root["dock"]) {
      auto& c = cfg->dock;
      get(d, "frame_id", &c.frame_id);
      if (const YAML::Node cl = d["centerline"]) {
        if (!cl.IsSequence()) throw std::runtime_error("dock.centerline 은 [[x,y],...] 목록");
        c.centerline.clear();
        for (const auto& pt : cl) {
          Vec2 v;
          if (!readVec2(pt, &v)) throw std::runtime_error("dock.centerline 원소는 [x, y]");
          c.centerline.push_back(v);
        }
      }
      if (d["target_point"] && !d["target_point"].IsNull()) {
        if (!readVec2(d["target_point"], &c.target))
          throw std::runtime_error("dock.target_point 는 [x, y]");
        c.has_target = true;
      }
      get(d, "z_ref_m", &c.z_ref_m);
      get(d, "bow_length_m", &c.bow_length_m);
      get(d, "stern_length_m", &c.stern_length_m);
    }
    if (const YAML::Node t = root["tolerance"]) {
      auto& c = cfg->tolerance;
      get(t, "x_remain_m", &c.x_remain_m);
      get(t, "y_error_m", &c.y_error_m);
      get(t, "yaw_error_deg", &c.yaw_error_deg);
      get(t, "dwell_s", &c.dwell_s);
      get(t, "release_factor", &c.release_factor);
    }
    if (const YAML::Node p = root["profile"]) {
      auto& c = cfg->profile;
      get(p, "v_max_mpm", &c.v_max_mpm);
      get(p, "a_max_mps2", &c.a_max_mps2);
      get(p, "j_max_mps3", &c.j_max_mps3);
      get(p, "v_creep_mpm", &c.v_creep_mpm);
      get(p, "stop_tolerance_m", &c.stop_tolerance_m);
      get(p, "limiter_accel_factor", &c.limiter_accel_factor);
      get(p, "limiter_jerk_factor", &c.limiter_jerk_factor);
      get(p, "table_resolution_s", &c.table_resolution_s);
    }
    if (const YAML::Node s = root["safety"]) {
      auto& c = cfg->safety;
      get(s, "y_warn_m", &c.y_warn_m);
      get(s, "y_danger_m", &c.y_danger_m);
      get(s, "yaw_warn_deg", &c.yaw_warn_deg);
      get(s, "yaw_danger_deg", &c.yaw_danger_deg);
      get(s, "hysteresis_y_m", &c.hysteresis_y_m);
      get(s, "hysteresis_yaw_deg", &c.hysteresis_yaw_deg);
      get(s, "warn_min_speed_scale", &c.warn_min_speed_scale);
      get(s, "check_extremities", &c.check_extremities);
      get(s, "danger_zero_moment", &c.danger_zero_moment);
      get(s, "overshoot_m", &c.overshoot_m);
      get(s, "override_y_rate_mps", &c.override_y_rate_mps);
      get(s, "override_yaw_rate_dps", &c.override_yaw_rate_dps);
      get(s, "override_min_y_m", &c.override_min_y_m);
      get(s, "override_min_yaw_deg", &c.override_min_yaw_deg);
      get(s, "override_hold_scale", &c.override_hold_scale);
      get(s, "override_release_s", &c.override_release_s);
      get(s, "pose_timeout_s", &c.pose_timeout_s);
      get(s, "tension_timeout_s", &c.tension_timeout_s);
      get(s, "honor_upstream_interlock", &c.honor_upstream_interlock);
    }
    if (const YAML::Node m = root["moment"]) {
      auto& c = cfg->moment;
      get(m, "kp_y", &c.kp_y);
      get(m, "kd_y", &c.kd_y);
      get(m, "kp_yaw", &c.kp_yaw);
      get(m, "kd_yaw", &c.kd_yaw);
      get(m, "mz_max_knm", &c.mz_max_knm);
      get(m, "kp_fy", &c.kp_fy);
      get(m, "ki_fy", &c.ki_fy);
      get(m, "kd_fy", &c.kd_fy);
      get(m, "fy_max_kn", &c.fy_max_kn);
      get(m, "use_twist", &c.use_twist);
      get(m, "derivative_lpf_tau_s", &c.derivative_lpf_tau_s);
    }
    if (const YAML::Node t = root["tension"]) {
      auto& c = cfg->tension;
      get(t, "overrange_kn", &c.overrange_kn);
      get(t, "zero_kn", &c.zero_kn);
      get(t, "dropout_ref_kn", &c.dropout_ref_kn);
      get(t, "negative_kn", &c.negative_kn);
      get(t, "wire_stiffness_kn_per_m", &c.wire_stiffness_kn_per_m);
      get(t, "max_step_kn", &c.max_step_kn);
      get(t, "frozen_s", &c.frozen_s);
      get(t, "recover_s", &c.recover_s);
      get(t, "lpf_tau_s", &c.lpf_tau_s);
      get(t, "balance_deadband_kn", &c.balance_deadband_kn);
      get(t, "wire_lateral_gain", &c.wire_lateral_gain);
      get(t, "bow_lever_m", &c.bow_lever_m);
      get(t, "stern_lever_m", &c.stern_lever_m);
      get(t, "motion_v_th_mps", &c.motion_v_th_mps);
      get(t, "motion_r_th_dps", &c.motion_r_th_dps);
      get(t, "cause_persist_s", &c.cause_persist_s);
      get(t, "command_compensation", &c.command_compensation);
      get(t, "actuator_tau_s", &c.actuator_tau_s);
      get(t, "force_y_applied", &c.force_y_applied);
      get(t, "weight_gain", &c.weight_gain);
      get(t, "weight_ref_kn", &c.weight_ref_kn);
      get(t, "weight_max", &c.weight_max);
    }
  } catch (const std::exception& e) {
    if (err) *err = path + ": " + e.what();
    return false;
  }
  return true;
}

}  // namespace pit
