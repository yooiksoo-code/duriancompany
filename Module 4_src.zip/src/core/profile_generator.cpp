#include "pkg_inhaul_trajectory/profile_generator.hpp"

#include <algorithm>
#include <cmath>

namespace pit {
namespace {
double clampAbs(double v, double m) { return std::max(-m, std::min(m, v)); }
double sgn(double v) { return (v > 0) - (v < 0); }
}  // namespace

void SCurveProfile::build(const ProfileConfig& c) {
  d_.clear(); v_.clear();
  v_max_ = std::max(0.0, c.v_max_mpm / kMps2Mpm);
  const double j = std::max(1e-6, c.j_max_mps3);
  const double amax = std::max(1e-6, c.a_max_mps2);
  if (v_max_ <= 0.0) { decel_dist_ = 0.0; d_ = {0.0}; v_ = {0.0}; return; }
  // 최대 감속 크기: v_max < a²/j 이면 삼각 프로파일
  const double ap = std::min(amax, std::sqrt(v_max_ * j));
  const double tj = ap / j;
  const double tc = std::max(0.0, (v_max_ - ap * ap / j) / ap);
  const double dt = std::max(1e-4, c.table_resolution_s);

  std::vector<double> xs, vs;
  auto push = [&](double x, double v) { xs.push_back(x); vs.push_back(std::max(0.0, v)); };
  const double v0 = v_max_;
  // 1) 저크 −j
  const int n1 = std::max(1, static_cast<int>(std::ceil(tj / dt)));
  for (int k = 0; k <= n1; ++k) {
    const double t = tj * k / n1;
    push(v0 * t - j * t * t * t / 6.0, v0 - 0.5 * j * t * t);
  }
  const double x1 = xs.back(), v1 = v0 - 0.5 * j * tj * tj;
  // 2) 감속 −a_p 유지
  const int n2 = static_cast<int>(std::ceil(tc / dt));
  for (int k = 1; k <= n2; ++k) {
    const double t = tc * k / n2;
    push(x1 + v1 * t - 0.5 * ap * t * t, v1 - ap * t);
  }
  const double x2 = x1 + v1 * tc - 0.5 * ap * tc * tc, v2 = v1 - ap * tc;
  // 3) 저크 +j → a = 0, v = 0
  for (int k = 1; k <= n1; ++k) {
    const double t = tj * k / n1;
    push(x2 + v2 * t - 0.5 * ap * t * t + j * t * t * t / 6.0, v2 - ap * t + 0.5 * j * t * t);
  }
  decel_dist_ = xs.back();
  vs.back() = 0.0;
  // 잔여거리 오름차순으로 뒤집기
  const size_t n = xs.size();
  d_.resize(n); v_.resize(n);
  for (size_t i = 0; i < n; ++i) {
    d_[i] = decel_dist_ - xs[n - 1 - i];
    v_[i] = vs[n - 1 - i];
  }
  d_[0] = 0.0;
}

double SCurveProfile::referenceSpeed(double x) const {
  if (d_.empty() || x <= 0.0) return 0.0;
  if (x >= decel_dist_) return v_max_;
  const auto it = std::upper_bound(d_.begin(), d_.end(), x);
  const size_t i = static_cast<size_t>(it - d_.begin());
  if (i == 0) return v_.front();
  if (i >= d_.size()) return v_.back();
  const double w = (x - d_[i - 1]) / std::max(1e-15, d_[i] - d_[i - 1]);
  return v_[i - 1] + w * (v_[i] - v_[i - 1]);
}

double SCurveProfile::referenceAccel(double x) const {
  if (x <= 0.0 || x >= decel_dist_) return 0.0;
  const double h = std::max(1e-5, 1e-3 * x);
  const double lo = std::max(0.0, x - h), hi = std::min(decel_dist_, x + h);
  const double dvdx = (referenceSpeed(hi) - referenceSpeed(lo)) / (hi - lo);
  return -referenceSpeed(x) * dvdx;  // dX/dt = −V
}

double JerkLimitedTracker::update(double target, double dt, double a_lim, double j_lim) {
  if (!(dt > 0.0)) return v_;
  double a_ff = have_prev_target_ ? (target - prev_target_) / dt : 0.0;
  if (std::abs(a_ff) > a_lim) a_ff = 0.0;  // 계단 변화 = 앞먹임 없이 저크 제한 추종
  prev_target_ = target;
  have_prev_target_ = true;

  const double e = target - v_;
  // 저크 제한 하에서 오차를 0 으로 수렴시키는 상대가속도 (√(2 j |e|) 제동곡선)
  const double a_fb = sgn(e) * std::min(std::sqrt(2.0 * j_lim * std::abs(e)), a_lim);
  const double a_des = clampAbs(a_ff + a_fb, a_lim);
  a_ += clampAbs(a_des - a_, j_lim * dt);
  const double v_next = v_ + a_ * dt;
  // 목표 통과 시 스냅 (상대가속도가 이미 작으면 과도 오버슈트 없음)
  if (sgn(target - v_next) != sgn(e) && std::abs(a_ - a_ff) <= j_lim * dt + 1e-12) {
    v_ = target;
    a_ = a_ff;
  } else {
    v_ = v_next;
  }
  return v_;
}

void ProfileGenerator::configure(const ProfileConfig& p, const MomentConfig& m) {
  pc_ = p;
  mc_ = m;
  prof_.build(p);
  reset();
}

void ProfileGenerator::reset() {
  trk_.reset(0.0);
  fy_int_ = 0.0;
}

ProfileOutput ProfileGenerator::update(double dt, double x_remain, double y_err, double y_rate,
                                       double yaw_err, double yaw_rate, double speed_scale,
                                       bool hard_stop, bool zero_moment) {
  ProfileOutput o;
  speed_scale = std::max(0.0, std::min(1.0, speed_scale));
  o.v_ref = prof_.referenceSpeed(x_remain);
  const double v_cap = prof_.vMax() * speed_scale;
  const double v_creep = pc_.v_creep_mpm / kMps2Mpm;
  const bool at_stop = x_remain <= pc_.stop_tolerance_m;
  o.v_target = at_stop ? 0.0 : std::min(v_cap, std::max(o.v_ref, v_creep));

  if (hard_stop || at_stop) {
    trk_.reset(0.0);
    o.v_cmd = 0.0;
  } else {
    o.v_cmd = trk_.update(o.v_target, dt, pc_.a_max_mps2 * pc_.limiter_accel_factor,
                          pc_.j_max_mps3 * pc_.limiter_jerk_factor);
    o.v_cmd = std::max(0.0, o.v_cmd);
  }

  if (!zero_moment) {
    const double raw = -(mc_.kp_y * y_err + mc_.kd_y * y_rate + mc_.kp_yaw * yaw_err +
                         mc_.kd_yaw * yaw_rate);
    o.mz_cmd = clampAbs(raw, mc_.mz_max_knm);
    o.mz_saturated = std::abs(raw) > mc_.mz_max_knm;
    const double pd = -(mc_.kp_fy * y_err + mc_.kd_fy * y_rate);
    const double cand_int = fy_int_ + y_err * dt;
    const double raw_f = pd - mc_.ki_fy * cand_int;
    if (std::abs(raw_f) <= mc_.fy_max_kn || std::abs(pd - mc_.ki_fy * fy_int_) > std::abs(raw_f))
      fy_int_ = cand_int;  // 포화 시 포화를 키우는 방향의 적분 정지
    o.fy_cmd = clampAbs(pd - mc_.ki_fy * fy_int_, mc_.fy_max_kn);
  } else {
    fy_int_ = 0.0;
  }
  return o;
}

}  // namespace pit
