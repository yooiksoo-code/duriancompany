#include "pkg_inhaul_trajectory/tension_imbalance_analyzer.hpp"

#include <algorithm>
#include <cstdio>

namespace pit {
namespace {
const char* kChName[kNumWinch] = {"W1(함수좌)", "W2(함수우)", "W3(함미좌)", "W4(함미우)"};
double clampAbs(double v, double m) { return std::max(-m, std::min(m, v)); }
}  // namespace

void TensionImbalanceAnalyzer::configure(const TensionConfig& cfg, double tension_timeout_s) {
  c_ = cfg;
  timeout_s_ = tension_timeout_s;
  reset();
}

void TensionImbalanceAnalyzer::reset() {
  st_ = TensionState{};
  for (auto& c : ch_) {
    c = Channel{};
    c.latched = ChannelFault::kStale;
  }
  have_rx_ = false;
  filt_init_ = false;
  f_bow_ = f_stern_ = cmd_dt_bow_ = cmd_dt_stern_ = 0.0;
  candidate_ = TensionCause::kUnknown;
  candidate_time_ = 0.0;
  prev_mode_ = FeedbackMode::kPoseOnly;
  mode_reported_ = false;
  alerts_.clear();
}

ChannelFault TensionImbalanceAnalyzer::check(int i, int64_t rx_ns, double v, uint8_t hw,
                                             bool others_active) {
  Channel& c = ch_[i];
  ChannelFault inst = ChannelFault::kOk;
  if (!std::isfinite(v)) {
    inst = ChannelFault::kInvalid;
  } else if (hw != 0) {
    inst = ChannelFault::kHwStatus;
  } else if (v < c_.negative_kn) {
    inst = ChannelFault::kInvalid;
  } else if (v > c_.overrange_kn) {
    inst = ChannelFault::kOverrange;
  } else if (c.have_prev && std::abs(v - c.prev) > c_.max_step_kn) {
    inst = ChannelFault::kSpike;
  } else if (v < c_.zero_kn && c.ever_valid && c.last_good >= c_.dropout_ref_kn) {
    inst = ChannelFault::kDropout;  // 정상 장력에서 0 으로 — 단선 (0 유지 중에도 계속 단선)
  } else if (c_.frozen_s > 0.0 && others_active && c.have_prev &&
             nsToSec(rx_ns - c.last_change) >= c_.frozen_s) {
    // 값 고착: 다른 채널(2개 이상)은 변하는데 이 채널만 frozen_s 동안 비트 단위로 같은 값
    // (모든 채널이 정지값이면 정적 하중으로 보고 판정하지 않음)
    inst = ChannelFault::kFrozen;
  }
  if (std::isfinite(v)) {
    c.prev = v;
    c.have_prev = true;
  }

  if (inst == ChannelFault::kOk && c.latched == ChannelFault::kOk) c.last_good = v;
  char buf[128];
  if (inst != ChannelFault::kOk) {
    if (c.reported != inst && !(c.reported != ChannelFault::kOk && inst == ChannelFault::kSpike)) {
      ++fault_events_;
      std::snprintf(buf, sizeof(buf), "%s %s %.3f kN", kChName[i], toString(inst),
                    std::isfinite(v) ? v : -1.0);
      alerts_.push_back({"WARN_LOADCELL_FAULT", buf});
      c.reported = inst;
    }
    if (c.latched == ChannelFault::kOk || c.latched == ChannelFault::kStale ||
        inst != ChannelFault::kSpike || c.latched == ChannelFault::kSpike)
      c.latched = inst;  // 더 구체적인 원인(단선 등)을 스파이크로 덮어쓰지 않음
    c.good_since = -1;
    return inst;
  }
  if (c.latched != ChannelFault::kOk) {
    if (c.good_since < 0) c.good_since = rx_ns;
    if (nsToSec(rx_ns - c.good_since) >= c_.recover_s) {
      if (c.ever_valid) {
        std::snprintf(buf, sizeof(buf), "%s (%s 해제)", kChName[i], toString(c.latched));
        alerts_.push_back({"INFO_LOADCELL_RECOVERED", buf});
      }
      c.ever_valid = true;
      c.last_good = v;
      c.reported = ChannelFault::kOk;
      c.latched = ChannelFault::kOk;
      c.good_since = -1;
      return ChannelFault::kOk;
    }
    return ChannelFault::kRecovering;
  }
  return ChannelFault::kOk;
}

void TensionImbalanceAnalyzer::onTension(int64_t rx_ns, const TensionInput& in) {
  for (int i = 0; i < kNumWinch; ++i) {
    Channel& c = ch_[i];
    if (!c.have_prev || in.tension_kn[i] != c.prev) c.last_change = rx_ns;
  }
  for (int i = 0; i < kNumWinch; ++i) {
    // 다른 채널 2개 이상이 지금도 변하고 있을 때만 고착 판정 (단일 채널 계단 변화로 오판 방지)
    int active = 0;
    for (int j = 0; j < kNumWinch; ++j)
      if (j != i && nsToSec(rx_ns - ch_[j].last_change) < 0.1 * c_.frozen_s) ++active;
    const bool others = active >= 2;
    st_.fault[i] = check(i, rx_ns, in.tension_kn[i], in.hw_status[i], others);
    st_.tension_kn[i] = in.tension_kn[i];
  }
  have_rx_ = true;
  st_.last_rx_ns = rx_ns;
}

const TensionState& TensionImbalanceAnalyzer::update(int64_t now_ns, double dt, double y_err,
                                                     double yaw_err, double y_rate,
                                                     double yaw_rate, double prev_mz_cmd_knm,
                                                     double prev_fy_cmd_kn) {
  // 1) 토픽 타임아웃
  const bool timed_out = !have_rx_ || nsToSec(now_ns - st_.last_rx_ns) > timeout_s_;
  if (timed_out) {
    if (have_rx_ && st_.data_valid)
      alerts_.push_back({"WARN_TENSION_TIMEOUT", "장력 토픽 수신 중단 → 자세 단독 피드백"});
    for (int i = 0; i < kNumWinch; ++i) {
      if (ch_[i].latched == ChannelFault::kOk) ++fault_events_;
      ch_[i].latched = ChannelFault::kStale;
      ch_[i].good_since = -1;
      st_.fault[i] = ChannelFault::kStale;
    }
  }
  st_.data_valid = !timed_out;
  bool all_ok = !timed_out;
  for (int i = 0; i < kNumWinch; ++i) {
    st_.channel_valid[i] = !timed_out && ch_[i].latched == ChannelFault::kOk;
    all_ok = all_ok && st_.channel_valid[i];
  }
  st_.mode = all_ok ? FeedbackMode::kFull : FeedbackMode::kPoseOnly;
  if (!mode_reported_ || st_.mode != prev_mode_) {
    if (mode_reported_ || st_.mode == FeedbackMode::kFull)
      alerts_.push_back(st_.mode == FeedbackMode::kFull
                            ? Alert{"INFO_FEEDBACK_FULL", "4채널 정상 → 장력+자세 피드백"}
                            : Alert{"WARN_FEEDBACK_POSE_ONLY", "로드셀 배제 → 자세 단독 피드백"});
    mode_reported_ = true;
    prev_mode_ = st_.mode;
  }

  // 2) ΔT (유효 쌍만)
  const auto& T = st_.tension_kn;
  st_.bow_valid = st_.channel_valid[0] && st_.channel_valid[1];
  st_.stern_valid = st_.channel_valid[2] && st_.channel_valid[3];
  st_.delta_bow_kn = st_.bow_valid ? T[0] - T[1] : 0.0;
  st_.delta_stern_kn = st_.stern_valid ? T[2] - T[3] : 0.0;

  // 3) 자체 지령이 만든 장력차 모델 (배분식 + 1차 지연)
  const double g = c_.wire_lateral_gain;
  const double lever_sum = c_.bow_lever_m + c_.stern_lever_m;
  double tgt_b = 0.0, tgt_s = 0.0;
  if (g > 1e-9 && lever_sum > 1e-9) {
    tgt_b = (prev_mz_cmd_knm + c_.stern_lever_m * prev_fy_cmd_kn) / (g * lever_sum);
    tgt_s = (c_.bow_lever_m * prev_fy_cmd_kn - prev_mz_cmd_knm) / (g * lever_sum);
  }
  if (dt > 0.0) {
    const double a = dt / (c_.actuator_tau_s + dt);
    cmd_dt_bow_ += a * (tgt_b - cmd_dt_bow_);
    cmd_dt_stern_ += a * (tgt_s - cmd_dt_stern_);
  }
  const double cmp_bow = c_.command_compensation ? cmd_dt_bow_ : 0.0;
  const double cmp_stern = c_.command_compensation ? cmd_dt_stern_ : 0.0;

  // 4) LPF + 원인 판정 (FULL 모드에서만)
  if (st_.mode != FeedbackMode::kFull) {
    filt_init_ = false;
    st_.residual_bow_kn = st_.residual_stern_kn = 0.0;
    st_.mismatch_bow_kn = st_.mismatch_stern_kn = 0.0;
    st_.wire_force_y_kn = st_.wire_moment_z_knm = st_.wire_power = 0.0;
    st_.cause = TensionCause::kUnknown;
    candidate_ = TensionCause::kUnknown;
    candidate_time_ = 0.0;
    st_.speed_weight = {0, 0, 0, 0};
    return st_;
  }
  if (!filt_init_) {
    f_bow_ = st_.delta_bow_kn;
    f_stern_ = st_.delta_stern_kn;
    filt_init_ = true;
  } else if (dt > 0.0) {
    const double a = dt / (c_.lpf_tau_s + dt);
    f_bow_ += a * (st_.delta_bow_kn - f_bow_);
    f_stern_ += a * (st_.delta_stern_kn - f_stern_);
  }
  st_.residual_bow_kn = f_bow_ - cmp_bow;
  st_.residual_stern_kn = f_stern_ - cmp_stern;
  st_.wire_force_y_kn = g * (st_.residual_bow_kn + st_.residual_stern_kn);
  st_.wire_moment_z_knm = g * (c_.bow_lever_m * st_.residual_bow_kn -
                               c_.stern_lever_m * st_.residual_stern_kn);
  st_.wire_power = st_.wire_force_y_kn * y_rate + st_.wire_moment_z_knm * yaw_rate;

  const double k = c_.wire_stiffness_kn_per_m;
  const double y_bow = y_err + c_.bow_lever_m * std::sin(yaw_err);
  const double y_stern = y_err - c_.stern_lever_m * std::sin(yaw_err);
  TensionCause inst;
  if (k > 0.0) {
    st_.mismatch_bow_kn = st_.residual_bow_kn + 2.0 * k * g * y_bow;
    st_.mismatch_stern_kn = st_.residual_stern_kn + 2.0 * k * g * y_stern;
    const double res = std::max(std::abs(st_.residual_bow_kn), std::abs(st_.residual_stern_kn));
    const double mis = std::max(std::abs(st_.mismatch_bow_kn), std::abs(st_.mismatch_stern_kn));
    if (std::max(res, mis) < c_.balance_deadband_kn) inst = TensionCause::kBalanced;
    else inst = mis > res ? TensionCause::kWinchMismatch : TensionCause::kExternalForce;
  } else {
    st_.mismatch_bow_kn = st_.residual_bow_kn;
    st_.mismatch_stern_kn = st_.residual_stern_kn;
    if (std::abs(st_.residual_bow_kn) < c_.balance_deadband_kn &&
        std::abs(st_.residual_stern_kn) < c_.balance_deadband_kn) {
      inst = TensionCause::kBalanced;
    } else {
      const bool moving = std::abs(y_rate) > c_.motion_v_th_mps ||
                          std::abs(yaw_rate) > c_.motion_r_th_dps * kDeg2Rad;
      if (moving) {
        inst = st_.wire_power < 0.0 ? TensionCause::kExternalForce : TensionCause::kWinchMismatch;
      } else {
        const double S = st_.wire_force_y_kn * y_err + st_.wire_moment_z_knm * yaw_err;
        inst = S < 0.0 ? TensionCause::kExternalForce : TensionCause::kWinchMismatch;
      }
    }
  }
  if (inst != candidate_) {
    candidate_ = inst;
    candidate_time_ = 0.0;
  } else {
    candidate_time_ += dt;
  }
  if (st_.cause == TensionCause::kUnknown || candidate_time_ >= c_.cause_persist_s)
    st_.cause = candidate_;

  // 5) 차등 속도 보정 가중치 (권취 속도 오차일 때만)
  st_.speed_weight = {0, 0, 0, 0};
  if (st_.cause == TensionCause::kWinchMismatch && c_.weight_ref_kn > 0.0) {
    const double kb = c_.weight_gain * 0.5 * st_.mismatch_bow_kn / c_.weight_ref_kn;
    const double ks = c_.weight_gain * 0.5 * st_.mismatch_stern_kn / c_.weight_ref_kn;
    st_.speed_weight[0] = clampAbs(-kb, c_.weight_max);  // W1 장력이 높으면 W1 감속
    st_.speed_weight[1] = clampAbs(+kb, c_.weight_max);
    st_.speed_weight[2] = clampAbs(-ks, c_.weight_max);
    st_.speed_weight[3] = clampAbs(+ks, c_.weight_max);
  }
  return st_;
}

std::vector<Alert> TensionImbalanceAnalyzer::takeAlerts() {
  std::vector<Alert> out;
  out.swap(alerts_);
  return out;
}

}  // namespace pit
