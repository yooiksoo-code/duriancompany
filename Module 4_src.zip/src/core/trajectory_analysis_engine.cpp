#include "pkg_inhaul_trajectory/trajectory_analysis_engine.hpp"

#include <chrono>
#include <cstdio>

namespace pit {

bool TrajectoryAnalysisEngine::configure(const TrajectoryConfig& cfg, std::string* err) {
  cfg_ = cfg;
  const auto& s = cfg.safety;
  if (!(s.y_warn_m < s.y_danger_m) || !(s.yaw_warn_deg < s.yaw_danger_deg)) {
    if (err) *err = "safety: warn < danger 이어야 함";
    return false;
  }
  if (!(cfg.profile.v_max_mpm >= 0.0) || !(cfg.profile.a_max_mps2 > 0.0) ||
      !(cfg.profile.j_max_mps3 > 0.0)) {
    if (err) *err = "profile: v_max ≥ 0, a_max > 0, j_max > 0";
    return false;
  }
  if (!(s.pose_timeout_s > 0.0)) {
    if (err) *err = "safety.pose_timeout_s > 0";
    return false;
  }
  if (!dev_.configure(cfg.dock, cfg.moment, err)) return false;
  ten_.configure(cfg.tension, s.tension_timeout_s);
  safe_.configure(s);
  prof_.configure(cfg.profile, cfg.moment);
  reset();
  return true;
}

void TrajectoryAnalysisEngine::reset() {
  dev_.reset();
  ten_.reset();
  safe_.reset();
  prof_.reset();
  have_pose_ = pose_lost_ = upstream_ = aligned_ = nan_reported_ = was_interlock_ = was_hold_ = false;
  last_pose_rx_ = last_pose_stamp_ = 0;
  prev_mz_ = prev_fy_ = aligned_timer_ = 0.0;
  last_ = AlignmentOutput{};
  cnt_ = EngineCounters{};
  alerts_.clear();
}

void TrajectoryAnalysisEngine::onTension(int64_t rx_ns, const TensionInput& in) {
  ++cnt_.tensions;
  ten_.onTension(rx_ns, in);
}

void TrajectoryAnalysisEngine::onUpstreamInterlock(int64_t /*rx_ns*/, bool active) {
  if (!cfg_.safety.honor_upstream_interlock) active = false;
  if (active && !upstream_) {
    ++cnt_.upstream_interlocks;
    alerts_.push_back({"WARN_UPSTREAM_INTERLOCK", "모듈 3 인터록 ON → 속도 지령 0"});
  } else if (!active && upstream_) {
    alerts_.push_back({"INFO_UPSTREAM_INTERLOCK_CLEARED", "모듈 3 인터록 해제"});
  }
  upstream_ = active;
}

AlignmentOutput TrajectoryAnalysisEngine::zeroOutput(int64_t stamp_ns) const {
  AlignmentOutput o = last_;           // 편차 지표는 마지막 값 유지 (HMI 표시용)
  o.stamp_ns = stamp_ns;
  o.target_inhaul_speed_mpm = 0.0;
  o.correction_moment_z_knm = 0.0;
  o.correction_force_y_kn = 0.0;
  o.safety_status_code = static_cast<uint8_t>(SafetyLevel::kDanger);
  o.is_aligned = false;
  o.pose_lost = true;
  o.interlock = true;
  o.speed_scale = 0.0;
  o.v_target_mpm = 0.0;
  o.compute_time_us = 0.0;
  return o;
}

std::optional<AlignmentOutput> TrajectoryAnalysisEngine::onPose(int64_t rx_ns,
                                                                 const PoseInput& pose) {
  const auto t0 = std::chrono::steady_clock::now();
  if (!pose.p.allFinite() || !pose.q.coeffs().allFinite() || pose.q.norm() < 0.5 ||
      (pose.twist_valid && (!pose.v.allFinite() || !pose.w.allFinite()))) {
    ++cnt_.poses_rejected;
    if (!nan_reported_) alerts_.push_back({"WARN_POSE_INVALID", "NaN/비정상 쿼터니언 포즈 기각"});
    nan_reported_ = true;
    return std::nullopt;
  }
  if (have_pose_ && pose.stamp_ns <= last_pose_stamp_) {
    ++cnt_.poses_rejected;  // 역순·중복 (모듈 3 은 단조 증가 보장)
    return std::nullopt;
  }
  double dt = have_pose_ ? nsToSec(pose.stamp_ns - last_pose_stamp_) : 0.01;
  dt = std::max(1e-4, std::min(dt, 0.05));  // 공백 후 첫 샘플의 적분 폭주 방지
  const bool recovering = pose_lost_;
  if (recovering) {
    pose_lost_ = false;
    prof_.reset();  // 지령 0 에서 저크 제한 재출발
    alerts_.push_back({"INFO_POSE_RECOVERED", "/sub_pose_filtered 수신 재개"});
  }
  have_pose_ = true;
  last_pose_rx_ = rx_ns;
  last_pose_stamp_ = pose.stamp_ns;
  ++cnt_.poses;

  const DeviationState d = dev_.compute(pose);
  const TensionState& ts =
      ten_.update(rx_ns, dt, d.y_error, d.yaw_error, d.y_error_rate, d.yaw_error_rate, prev_mz_,
                  cfg_.tension.force_y_applied ? prev_fy_ : 0.0);
  const SafetyState& ss = safe_.update(dt, d);
  const bool hard_stop = ss.danger || upstream_;
  const bool zero_moment = ss.danger && cfg_.safety.danger_zero_moment;
  const ProfileOutput po = prof_.update(dt, d.x_remain, d.y_error, d.y_error_rate, d.yaw_error,
                                        d.yaw_error_rate, ss.speed_scale, hard_stop, zero_moment);
  prev_mz_ = po.mz_cmd;
  prev_fy_ = po.fy_cmd;

  // 정렬 완료: 공차 내 dwell_s 연속 → 래치, 공차 × release_factor 초과 시 해제
  const auto& tol = cfg_.tolerance;
  const double ax = std::abs(d.x_remain), ay = std::abs(d.y_error),
               ayaw = std::abs(d.yaw_error) * kRad2Deg;
  const bool within = ax <= tol.x_remain_m && ay <= tol.y_error_m && ayaw <= tol.yaw_error_deg;
  const double rf = tol.release_factor;
  if (aligned_) {
    if (ax > rf * tol.x_remain_m || ay > rf * tol.y_error_m || ayaw > rf * tol.yaw_error_deg) {
      aligned_ = false;
      aligned_timer_ = 0.0;
      alerts_.push_back({"WARN_ALIGNMENT_LOST", "정렬 공차 이탈"});
    }
  } else {
    aligned_timer_ = within ? aligned_timer_ + dt : 0.0;
    if (aligned_timer_ >= tol.dwell_s) {
      aligned_ = true;
      char b[128];
      std::snprintf(b, sizeof(b), "Xrem=%.1f mm Yerr=%.1f mm Yaw=%.3f deg", d.x_remain * 1e3,
                    d.y_error * 1e3, d.yaw_error * kRad2Deg);
      alerts_.push_back({"INFO_ALIGNED", b});
    }
  }

  AlignmentOutput o;
  o.stamp_ns = pose.stamp_ns;
  o.x_remain_m = d.x_remain;
  o.y_error_m = d.y_error;
  o.yaw_error_deg = d.yaw_error * kRad2Deg;
  o.z_error_m = d.z_error;
  o.delta_tension_bow_kn = ts.delta_bow_kn;
  o.delta_tension_stern_kn = ts.delta_stern_kn;
  o.target_inhaul_speed_mpm = po.v_cmd * kMps2Mpm;
  o.correction_moment_z_knm = po.mz_cmd;
  o.upstream_interlock = upstream_;
  o.interlock = hard_stop;
  o.safety_status_code = static_cast<uint8_t>(hard_stop ? SafetyLevel::kDanger : ss.level);
  o.is_aligned = aligned_;
  o.hold_override = ss.hold_override;
  o.speed_scale = ss.speed_scale;
  o.v_ref_mpm = po.v_ref * kMps2Mpm;
  o.v_target_mpm = po.v_target * kMps2Mpm;
  o.y_error_rate_mps = d.y_error_rate;
  o.yaw_error_rate_dps = d.yaw_error_rate * kRad2Deg;
  o.along_speed_mps = d.along_speed;
  o.s_along_m = d.s;
  o.segment = d.segment;
  o.lateral_metric_m = ss.lateral_metric;
  o.mz_saturated = po.mz_saturated;
  o.correction_force_y_kn = po.fy_cmd;
  o.tension = ts;

  if (ss.hold_override && !was_hold_)
    alerts_.push_back({"WARN_RAMPDOWN_OVERRIDE", ss.reason + " → 전진 보류"});
  if (!ss.hold_override && was_hold_)
    alerts_.push_back({"INFO_RAMPDOWN_RELEASED", "편차 안정 → 전진 재개"});
  was_hold_ = ss.hold_override;
  if (o.interlock && !was_interlock_ && ss.danger)
    alerts_.push_back({"ERROR_SAFETY_INTERLOCK", ss.reason});
  if (!o.interlock && was_interlock_)
    alerts_.push_back({"INFO_SAFETY_INTERLOCK_CLEARED", "인터록 해제"});
  was_interlock_ = o.interlock;
  if (recovering) o.pose_lost = false;

  for (auto& a : ten_.takeAlerts()) alerts_.push_back(std::move(a));
  o.compute_time_us =
      std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count();
  last_ = o;
  return o;
}

std::optional<AlignmentOutput> TrajectoryAnalysisEngine::checkWatchdog(int64_t now_ns) {
  if (!have_pose_) return std::nullopt;  // 최초 수신 전: 노드가 미초기화 상태를 별도로 표시
  if (nsToSec(now_ns - last_pose_rx_) <= cfg_.safety.pose_timeout_s) return std::nullopt;
  if (!pose_lost_) {
    pose_lost_ = true;
    ++cnt_.pose_timeouts;
    char b[96];
    std::snprintf(b, sizeof(b), "%.1f ms 미수신 → 제어 지령 0",
                  nsToSec(now_ns - last_pose_rx_) * 1e3);
    alerts_.push_back({"ALARM_POSE_LOST", b});
    aligned_ = false;
    aligned_timer_ = 0.0;
    prev_mz_ = prev_fy_ = 0.0;
    prof_.reset();
    was_interlock_ = true;
  }
  last_ = zeroOutput(last_pose_stamp_);
  return last_;
}

EngineCounters TrajectoryAnalysisEngine::counters() const {
  EngineCounters c = cnt_;
  c.danger_events = safe_.dangerEvents();
  c.hold_events = safe_.holdEvents();
  c.loadcell_faults = ten_.faultEvents();
  return c;
}

std::vector<Alert> TrajectoryAnalysisEngine::takeAlerts() {
  for (auto& a : ten_.takeAlerts()) alerts_.push_back(std::move(a));
  std::vector<Alert> out;
  out.swap(alerts_);
  return out;
}

}  // namespace pit
