#include "pkg_inhaul_trajectory/safety_boundary_checker.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace pit {
namespace {
// 히스테리시스 3단 판정
SafetyLevel classify(SafetyLevel prev, double v, double warn, double danger, double hyst) {
  if (v > danger) return SafetyLevel::kDanger;
  if (prev == SafetyLevel::kDanger && v > danger - hyst) return SafetyLevel::kDanger;
  if (v > warn) return SafetyLevel::kWarning;
  if (prev != SafetyLevel::kNormal && v > warn - hyst) return SafetyLevel::kWarning;
  return SafetyLevel::kNormal;
}
double warnScale(double v, double warn, double danger, double min_scale) {
  if (v <= warn) return 1.0;
  const double r = std::min(1.0, (v - warn) / std::max(1e-9, danger - warn));
  return 1.0 - r * (1.0 - min_scale);
}
}  // namespace

void SafetyBoundaryChecker::configure(const SafetyConfig& cfg) {
  c_ = cfg;
  reset();
}

void SafetyBoundaryChecker::reset() {
  st_ = SafetyState{};
  y_level_ = yaw_level_ = SafetyLevel::kNormal;
  overshoot_ = false;
  release_timer_ = 0.0;
}

const SafetyState& SafetyBoundaryChecker::update(double dt, const DeviationState& d) {
  const double ey = c_.check_extremities
                        ? std::max({std::abs(d.y_error), std::abs(d.bow_lateral),
                                    std::abs(d.stern_lateral)})
                        : std::abs(d.y_error);
  const double eyaw = std::abs(d.yaw_error) * kRad2Deg;
  y_level_ = classify(y_level_, ey, c_.y_warn_m, c_.y_danger_m, c_.hysteresis_y_m);
  yaw_level_ = classify(yaw_level_, eyaw, c_.yaw_warn_deg, c_.yaw_danger_deg,
                        c_.hysteresis_yaw_deg);
  overshoot_ = d.x_remain < -c_.overshoot_m ||
               (overshoot_ && d.x_remain < -c_.overshoot_m + c_.hysteresis_y_m);

  SafetyLevel lvl = std::max(y_level_, yaw_level_);
  if (overshoot_) lvl = SafetyLevel::kDanger;

  // Ramp-down Override: 편차가 커지는 방향의 변화율
  if (d.rate_valid) {
    const double grow_y = (d.y_error * d.y_error_rate > 0.0 &&
                           std::abs(d.y_error) > c_.override_min_y_m)
                              ? std::abs(d.y_error_rate) : 0.0;
    const double grow_yaw = (d.yaw_error * d.yaw_error_rate > 0.0 &&
                             std::abs(d.yaw_error) * kRad2Deg > c_.override_min_yaw_deg)
                                ? std::abs(d.yaw_error_rate) * kRad2Deg : 0.0;
    const bool trigger = grow_y > c_.override_y_rate_mps || grow_yaw > c_.override_yaw_rate_dps;
    const bool calm = std::abs(d.y_error_rate) < 0.5 * c_.override_y_rate_mps &&
                      std::abs(d.yaw_error_rate) * kRad2Deg < 0.5 * c_.override_yaw_rate_dps;
    if (trigger) {
      if (!st_.hold_override) {
        ++hold_events_;
        char b[96];
        std::snprintf(b, sizeof(b), "편차 급증 dY=%.1f mm/s dYaw=%.2f deg/s",
                      d.y_error_rate * 1e3, d.yaw_error_rate * kRad2Deg);
        st_.reason = b;
      }
      st_.hold_override = true;
      release_timer_ = 0.0;
    } else if (st_.hold_override) {
      release_timer_ = (calm && lvl != SafetyLevel::kDanger) ? release_timer_ + dt : 0.0;
      if (release_timer_ >= c_.override_release_s) st_.hold_override = false;
    }
  }

  const bool was_danger = st_.danger;
  st_.level = lvl;
  st_.danger = lvl == SafetyLevel::kDanger;
  if (st_.danger && !was_danger) {
    ++danger_events_;
    char b[128];
    std::snprintf(b, sizeof(b), "%s Yerr=%.1f mm(판정 %.1f) Yaw=%.2f deg Xrem=%.3f m",
                  overshoot_ ? "종점 초과" : "안전 펜스 침범", d.y_error * 1e3, ey * 1e3,
                  d.yaw_error * kRad2Deg, d.x_remain);
    st_.reason = b;
  }
  st_.lateral_metric = ey;

  double scale = std::min(warnScale(ey, c_.y_warn_m, c_.y_danger_m, c_.warn_min_speed_scale),
                          warnScale(eyaw, c_.yaw_warn_deg, c_.yaw_danger_deg,
                                    c_.warn_min_speed_scale));
  if (st_.hold_override) scale = std::min(scale, c_.override_hold_scale);
  if (st_.danger) scale = 0.0;
  st_.speed_scale = scale;
  if (st_.hold_override && st_.level == SafetyLevel::kNormal) st_.level = SafetyLevel::kWarning;
  return st_;
}

}  // namespace pit
