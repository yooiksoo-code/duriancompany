#include "pkg_inhaul_trajectory/spatial_deviation_engine.hpp"

#include <limits>

namespace pit {

bool DockCenterline::build(const std::vector<Vec2>& pts, std::string* err) {
  pts_.clear(); cum_.clear(); tan_.clear();
  if (pts.size() < 2) {
    if (err) *err = "centerline: 점이 2개 이상 필요";
    return false;
  }
  cum_.push_back(0.0);
  for (size_t i = 0; i + 1 < pts.size(); ++i) {
    const Vec2 d = pts[i + 1] - pts[i];
    const double len = d.norm();
    if (!(len > 1e-6) || !std::isfinite(len)) {
      if (err) *err = "centerline: 연속 중복점 또는 비정상 좌표 (index " + std::to_string(i) + ")";
      pts_.clear(); cum_.clear(); tan_.clear();
      return false;
    }
    tan_.push_back(d / len);
    cum_.push_back(cum_.back() + len);
  }
  pts_ = pts;
  return true;
}

Projection DockCenterline::project(const Vec2& p) const {
  Projection best;
  double best_d2 = std::numeric_limits<double>::infinity();
  const size_t nseg = numSegments();
  for (size_t i = 0; i < nseg; ++i) {
    const Vec2& a = pts_[i];
    const Vec2& u = tan_[i];
    const double len = cum_[i + 1] - cum_[i];
    double t = (p - a).dot(u);
    // 첫 구간은 시작점 이전, 마지막 구간은 종점 이후로 연장 (진입 전·초과 상태도 연속 계산)
    const double lo = (i == 0) ? -std::numeric_limits<double>::infinity() : 0.0;
    const double hi = (i + 1 == nseg) ? std::numeric_limits<double>::infinity() : len;
    t = std::min(std::max(t, lo), hi);
    const Vec2 foot = a + t * u;
    const double d2 = (p - foot).squaredNorm();
    if (d2 < best_d2 - 1e-15) {
      best_d2 = d2;
      best.s = cum_[i] + t;
      best.segment = static_cast<int>(i);
      best.tangent = u;
      best.normal = Vec2(-u.y(), u.x());
      best.lateral = (p - foot).dot(best.normal);
      best.heading = std::atan2(u.y(), u.x());
    }
  }
  return best;
}

Vec2 DockCenterline::pointAt(double s) const {
  if (pts_.empty()) return Vec2::Zero();
  const size_t nseg = numSegments();
  for (size_t i = 0; i < nseg; ++i) {
    if (s <= cum_[i + 1] || i + 1 == nseg) return pts_[i] + (s - cum_[i]) * tan_[i];
  }
  return pts_.back();
}

bool SpatialDeviationEngine::configure(const DockConfig& dock, const MomentConfig& moment,
                                       std::string* err) {
  dock_ = dock;
  mcfg_ = moment;
  if (!line_.build(dock.centerline, err)) return false;
  s_target_ = dock.has_target ? line_.arcLengthOf(dock.target) : line_.length();
  reset();
  return true;
}

void SpatialDeviationEngine::reset() {
  have_prev_ = false;
  f_ydot_ = f_yawdot_ = 0.0;
}

DeviationState SpatialDeviationEngine::compute(const PoseInput& pose) {
  DeviationState d;
  const Projection pr = line_.project(pose.p.head<2>());
  const double yaw = yawFromQuat(pose.q);
  d.s = pr.s;
  d.segment = pr.segment;
  d.x_remain = s_target_ - pr.s;
  d.y_error = pr.lateral;
  d.yaw_error = wrapPi(yaw - pr.heading);
  d.z_error = pose.p.z() - dock_.z_ref_m;
  d.bow_lateral = d.y_error + dock_.bow_length_m * std::sin(d.yaw_error);
  d.stern_lateral = d.y_error - dock_.stern_length_m * std::sin(d.yaw_error);

  if (mcfg_.use_twist && pose.twist_valid) {
    const Mat3 R = pose.q.normalized().toRotationMatrix();
    const Vec3 v_w = pose.twist_in_child_frame ? Vec3(R * pose.v) : pose.v;
    const Vec3 w_b = pose.twist_in_child_frame ? pose.w : Vec3(R.transpose() * pose.w);
    // ZYX 오일러율: ψ̇ = (ω_y sinφ + ω_z cosφ) / cosθ
    const double roll = std::atan2(R(2, 1), R(2, 2));
    const double pitch = std::asin(std::max(-1.0, std::min(1.0, -R(2, 0))));
    const double cp = std::cos(pitch);
    const double yaw_rate = std::abs(cp) > 1e-6
                                ? (w_b.y() * std::sin(roll) + w_b.z() * std::cos(roll)) / cp
                                : (R * w_b).z();
    d.y_error_rate = v_w.head<2>().dot(pr.normal);
    d.along_speed = v_w.head<2>().dot(pr.tangent);
    d.yaw_error_rate = yaw_rate;  // 직선 구간에서 ψ_ref 는 일정
    d.rate_valid = true;
    have_prev_ = false;  // 대체 경로 재시작 시 초기 스파이크 방지
  } else {
    // 대체: 편차 수치미분 + 1차 저역통과
    if (have_prev_) {
      const double dt = nsToSec(pose.stamp_ns - prev_stamp_);
      if (dt > 1e-4 && dt < 0.2) {
        const double a = dt / (mcfg_.derivative_lpf_tau_s + dt);
        f_ydot_ += a * ((d.y_error - prev_y_) / dt - f_ydot_);
        f_yawdot_ += a * (wrapPi(d.yaw_error - prev_yaw_) / dt - f_yawdot_);
        d.rate_valid = true;
      }
    }
    d.y_error_rate = f_ydot_;
    d.yaw_error_rate = f_yawdot_;
    have_prev_ = true;
    prev_stamp_ = pose.stamp_ns;
    prev_y_ = d.y_error;
    prev_yaw_ = d.yaw_error;
  }
  return d;
}

}  // namespace pit
