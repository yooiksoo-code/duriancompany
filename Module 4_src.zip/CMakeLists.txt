cmake_minimum_required(VERSION 3.16)
project(pkg_inhaul_trajectory VERSION 0.1.0 LANGUAGES CXX)

# PIT_CORE_ONLY=ON: ROS 없이 코어·시험·벤치만 빌드 (알고리즘 개발·CI)
option(PIT_CORE_ONLY "Build ROS-independent core, tests and bench only" OFF)

if(NOT CMAKE_CXX_STANDARD)
  set(CMAKE_CXX_STANDARD 17)
endif()
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
add_compile_options(-Wall -Wextra -Wpedantic)

find_package(Eigen3 REQUIRED NO_MODULE)
find_package(yaml-cpp REQUIRED)
if(TARGET yaml-cpp::yaml-cpp)
  set(PIT_YAML yaml-cpp::yaml-cpp)
else()
  set(PIT_YAML yaml-cpp)
endif()

# ── 코어 (ROS 비의존) ──
add_library(inhaul_trajectory_core STATIC
  src/core/spatial_deviation_engine.cpp
  src/core/tension_imbalance_analyzer.cpp
  src/core/profile_generator.cpp
  src/core/safety_boundary_checker.cpp
  src/core/trajectory_analysis_engine.cpp
  src/core/config_loader.cpp)
target_include_directories(inhaul_trajectory_core PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)
target_link_libraries(inhaul_trajectory_core PUBLIC Eigen3::Eigen ${PIT_YAML})
set_target_properties(inhaul_trajectory_core PROPERTIES POSITION_INDEPENDENT_CODE ON)

add_executable(trajectory_bench tools/trajectory_bench.cpp)
target_link_libraries(trajectory_bench inhaul_trajectory_core)

if(PIT_CORE_ONLY)
  enable_testing()
  find_package(GTest REQUIRED)
  add_executable(test_inhaul_trajectory test/test_inhaul_trajectory.cpp)
  target_compile_definitions(test_inhaul_trajectory PRIVATE
    PIT_CONFIG_DIR="${CMAKE_CURRENT_SOURCE_DIR}/config")
  target_link_libraries(test_inhaul_trajectory inhaul_trajectory_core GTest::gtest_main)
  add_test(NAME test_inhaul_trajectory COMMAND test_inhaul_trajectory)
  return()
endif()

# ── ROS2 ──
find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(rclcpp_lifecycle REQUIRED)
find_package(rclcpp_components REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(inhaul_msgs REQUIRED)
find_package(ament_index_cpp REQUIRED)
find_package(lifecycle_msgs REQUIRED)

add_library(trajectory_analysis_component SHARED src/ros/trajectory_analysis_node.cpp)
target_include_directories(trajectory_analysis_component PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)
target_link_libraries(trajectory_analysis_component inhaul_trajectory_core)
ament_target_dependencies(trajectory_analysis_component
  rclcpp rclcpp_lifecycle rclcpp_components nav_msgs std_msgs inhaul_msgs ament_index_cpp
  lifecycle_msgs)
rclcpp_components_register_node(trajectory_analysis_component
  PLUGIN "pit::TrajectoryAnalysisNode"
  EXECUTABLE trajectory_analysis_node)

add_executable(synthetic_inhaul_publisher src/ros/synthetic_inhaul_publisher.cpp)
target_link_libraries(synthetic_inhaul_publisher inhaul_trajectory_core)
ament_target_dependencies(synthetic_inhaul_publisher
  rclcpp nav_msgs std_msgs geometry_msgs inhaul_msgs)

install(TARGETS inhaul_trajectory_core trajectory_analysis_component
  ARCHIVE DESTINATION lib LIBRARY DESTINATION lib RUNTIME DESTINATION bin)
install(TARGETS synthetic_inhaul_publisher trajectory_bench DESTINATION lib/${PROJECT_NAME})
install(PROGRAMS tools/alignment_kpi_monitor.py DESTINATION lib/${PROJECT_NAME})
install(DIRECTORY include/ DESTINATION include)
install(DIRECTORY config launch systemd DESTINATION share/${PROJECT_NAME})

if(BUILD_TESTING)
  find_package(ament_cmake_gtest REQUIRED)
  ament_add_gtest(test_inhaul_trajectory test/test_inhaul_trajectory.cpp)
  target_compile_definitions(test_inhaul_trajectory PRIVATE
    PIT_CONFIG_DIR="${CMAKE_CURRENT_SOURCE_DIR}/config")
  target_link_libraries(test_inhaul_trajectory inhaul_trajectory_core)
endif()

ament_export_include_directories(include)
ament_export_libraries(inhaul_trajectory_core)
ament_package()
