# alignment_kpi_monitor 보고서

계측 41 s (워밍업 1 s 제외), 수신 4099 건

| 항목 | 결과 |
|---|---|
| KPI 1 발행 주기 | 99.92 Hz (100 Hz 기준 드롭 0.08 %) |
| 수신 간격 | p50 10.00 / p99 11.15 / max 40.02 ms |
| stamp 간격 > 15 ms (포즈 결손 반영) | 3 회, stamp 역순 0 |
| KPI 2 엔진 연산 | p50 4.1 / p99 10.6 / max 5951.4 µs |
| 콜백(수신→발행) | p50 100.4 / p99 827.7 / max 6967.8 µs |
| 포즈 stamp→발행 | p50 0.28 / p99 1.18 / max 9.96 ms |
| 카운터 | poses 3993, 기각 0, 포즈상실 3, 위험 0, 보류 0, 로드셀이상 8, 상위인터록 1 |
| KPI 3 횡편차 vs 참값 | RMSE 0.149 / max 0.601 mm (3896 쌍) |
| KPI 4 방위각 vs 참값 | RMSE 0.0030 / max 0.0100° |
| 안전 단계 분포 | 정상 3846, 경고 0, 위험 253 |
| 정렬 완료 첫 수신 | 32.45 s |
| KPI 6 위험 출력 → 인터록 토픽 | 4 회, max 0.64 ms (같은 콜백 발행, 모니터 수신 순서 기준) |

## 경보

- 1.042 s `INFO_FEEDBACK_FULL|4채널 정상 → 장력+자세 피드백`
- 5.021 s `WARN_UPSTREAM_INTERLOCK|모듈 3 인터록 ON → 속도 지령 0`
- 5.522 s `INFO_UPSTREAM_INTERLOCK_CLEARED|모듈 3 인터록 해제`
- 5.532 s `INFO_SAFETY_INTERLOCK_CLEARED|인터록 해제`
- 10.026 s `WARN_LOADCELL_FAULT|W3(함미좌) DROPOUT 0.000 kN`
- 10.032 s `WARN_FEEDBACK_POSE_ONLY|로드셀 배제 → 자세 단독 피드백`
- 15.025 s `INFO_LOADCELL_RECOVERED|W3(함미좌) (DROPOUT 해제)`
- 15.032 s `INFO_FEEDBACK_FULL|4채널 정상 → 장력+자세 피드백`
- 17.035 s `WARN_LOADCELL_FAULT|W4(함미우) FROZEN 0.995 kN`
- 17.042 s `WARN_FEEDBACK_POSE_ONLY|로드셀 배제 → 자세 단독 피드백`
- 19.035 s `INFO_LOADCELL_RECOVERED|W4(함미우) (FROZEN 해제)`
- 19.041 s `INFO_FEEDBACK_FULL|4채널 정상 → 장력+자세 피드백`
- 20.026 s `WARN_LOADCELL_FAULT|W1(함수좌) INVALID -4.993 kN`
- 20.032 s `WARN_FEEDBACK_POSE_ONLY|로드셀 배제 → 자세 단독 피드백`
- 21.075 s `INFO_LOADCELL_RECOVERED|W1(함수좌) (INVALID 해제)`
- 21.082 s `INFO_FEEDBACK_FULL|4채널 정상 → 장력+자세 피드백`
- 25.026 s `WARN_LOADCELL_FAULT|W2(함수우) OVERRANGE 15.000 kN`
- 25.032 s `WARN_FEEDBACK_POSE_ONLY|로드셀 배제 → 자세 단독 피드백`
- 27.035 s `INFO_LOADCELL_RECOVERED|W2(함수우) (OVERRANGE 해제)`
- 27.043 s `INFO_FEEDBACK_FULL|4채널 정상 → 장력+자세 피드백`
- 30.032 s `ALARM_POSE_LOST|20.3 ms 미수신 → 제어 지령 0`
- 30.071 s `INFO_POSE_RECOVERED|/sub_pose_filtered 수신 재개`
- 30.072 s `INFO_SAFETY_INTERLOCK_CLEARED|인터록 해제`
- 32.453 s `INFO_ALIGNED|Xrem=-2.1 mm Yerr=0.1 mm Yaw=-0.001 deg`
- 33.032 s `ALARM_POSE_LOST|20.3 ms 미수신 → 제어 지령 0`
- 33.041 s `INFO_POSE_RECOVERED|/sub_pose_filtered 수신 재개`
- 33.041 s `INFO_SAFETY_INTERLOCK_CLEARED|인터록 해제`
- 33.522 s `INFO_ALIGNED|Xrem=-3.2 mm Yerr=0.1 mm Yaw=0.004 deg`
- 35.072 s `WARN_TENSION_TIMEOUT|장력 토픽 수신 중단 → 자세 단독 피드백`
- 35.072 s `WARN_FEEDBACK_POSE_ONLY|로드셀 배제 → 자세 단독 피드백`
- 36.225 s `INFO_LOADCELL_RECOVERED|W1(함수좌) (STALE 해제)`
- 36.226 s `INFO_LOADCELL_RECOVERED|W2(함수우) (STALE 해제)`
- 36.226 s `INFO_LOADCELL_RECOVERED|W3(함미좌) (STALE 해제)`
- 36.226 s `INFO_LOADCELL_RECOVERED|W4(함미우) (STALE 해제)`
- 36.233 s `INFO_FEEDBACK_FULL|4채널 정상 → 장력+자세 피드백`
- 40.042 s `ALARM_POSE_LOST|20.8 ms 미수신 → 제어 지령 0`
