# pkg_inhaul_trajectory 벤치 보고서

합성 Physical Twin 테스트베드 폐루프 (선체 200 kg / 와이어 4본 2 kN/m / 윈치 τ 0.25 s / 포즈 100 Hz EKF 수준 잡음). 물리 1 ms, 포즈·장력 100 Hz, 워치독 2 ms.

## KPI 요약 (설계서 8장)

| # | 항목 | 목표 | 결과 | 판정 |
|---|---|---|---|---|
| 1 | 궤적 분석 연산 주기 | ≥ 100 Hz, 드롭 0 % | 포즈 1건당 출력 1건 (이벤트 구동) — ROS 계측은 `alignment_kpi_monitor.py` | ROS 보고서 참조 |
| 2 | 알고리즘 연산 지연 | ≤ 1.0 ms | p50 0.2 µs / p99 0.4 µs / p99.99 31.6 µs / max 173.9 µs (361909 사이클, 3620 s) | **충족** |
| 3 | 횡편차 계산 정밀도 | ±1.0 mm | 기하 연산 max 1.01e-11 mm (float32 출력 7.45e-06 mm), EKF 잡음 포함 RMSE 0.150 / max 0.492 mm | **충족** (연산), 입력 잡음은 모듈 3 정밀도 |
| 4 | 방위각 계산 정밀도 | ±0.05° | 기하 연산 max 8.88e-14° (float32 2.38e-07°), 롤·피치 ±1° 포함, EKF 잡음 포함 RMSE 0.0030 / max 0.0108° | **충족** |
| 5 | 종단 감속 프로파일 추종성 | ≤ 2.0 % | 지령 vs 기준곡선: max 0.824 %FS (V_ref>10% 구간 상대 max 3.496 %) / 선체 실속도 vs 기준곡선: max 4.95 %FS, RMS 3.43 %FS | **충족** (지령), 실속도는 윈치 응답 τ 의존 |
| 6 | 안전 인터록 응답 | ≤ 10 ms | 펜스 침범 포즈 수신 → 위험 플래그: 0.0003 ms (같은 주기). 포즈 상실: timeout 경과 후 1.000 ms 내 ALARM. 상위 인터록 → 속도 0: 0 ms | **충족** |

종단 0.5 m 감속 시작 거리 = 0.427 m (v_max 6.0 m/min, a 0.015 m/s², j 0.008 m/s³).

## 시나리오

| 시나리오 | 조건 | 최종 X_rem / Y / Yaw (참값) | 최대 |Y| / |Yaw| | 복원(|Y|<10 mm·|Yaw|<0.3°) | 정렬 완료 | 위험/보류 | 장력 원인 분포 | 자세단독 % | 최대 가중치 |
|---|---|---|---|---|---|---|---|---|---|
| T1 | 정상 인하울 (초기 +20 mm, +0.5°), 외란 없음 | -0.6 mm / -0.0 mm / -0.005° | 20.0 mm / 0.58° | 0.460 s | 31.54 s | 0 / 1 | BALANCED 97%, EXTERNAL_FORCE 1%, UNKNOWN 2% | 2.2 | 0.000 |
| T2a | 초기 편차 복원 +100 mm / +5° (설계서 5단계 기준) | -0.7 mm / 0.0 mm / -0.005° | 99.9 mm / 4.99° | 1.950 s | 31.99 s | 0 / 1 | BALANCED 95%, EXTERNAL_FORCE 3%, UNKNOWN 2% | 2.2 | 0.000 |
| T2b | 초기 편차 복원 −100 mm / −5° | -0.7 mm / -0.0 mm / -0.005° | 99.9 mm / 4.99° | 1.950 s | 32.01 s | 1 / 1 | BALANCED 95%, EXTERNAL_FORCE 3%, UNKNOWN 2% | 2.2 | 0.000 |
| T3a | 정상 조류 60 N + 돌풍 200 N·40 N·m (12~15 s), 설계서대로 M_z 만 실행 | -0.9 mm / 30.0 mm / -0.937° | 100.8 mm / 4.22° | 0.010 s | **미완료** | 1 / 2 | EXTERNAL_FORCE 98%, UNKNOWN 2% | 1.7 | 0.000 |
| T3b | T3a + [제안] 횡력 지령 F_y 실행 | -0.5 mm / -0.0 mm / 0.000° | 18.5 mm / 1.28° | 0.010 s | 36.30 s | 0 / 3 | BALANCED 90%, EXTERNAL_FORCE 7%, UNKNOWN 2%, WINCH_MISMATCH 1% | 1.7 | 0.200 |
| T4a | W2(함수우) 권취 속도 +5 % 오차, 보정 가중치 미적용 | -0.8 mm / -58.0 mm / -0.366° | 58.0 mm / 0.37° | 0.010 s | **미완료** | 0 / 0 | BALANCED 13%, UNKNOWN 2%, WINCH_MISMATCH 85% | 2.2 | 0.200 |
| T4b | T4a + 차등 속도 보정 가중치 적용 (윈치 연계 에뮬레이터) | -0.8 mm / -7.0 mm / -0.077° | 8.5 mm / 0.14° | 0.010 s | 28.94 s | 0 / 0 | BALANCED 63%, UNKNOWN 2%, WINCH_MISMATCH 35% | 2.2 | 0.093 |
| T5 | 로드셀 단선(W3)·고착(W4)·스파이크(W1)·상한(W2), 포즈 50 ms/15 ms 결손, 장력 토픽 200 ms 결손, 모듈 3 인터록 펄스 | -2.9 mm / 0.0 mm / 0.003° | 0.0 mm / 0.01° | 0.010 s | 32.46 s | 0 / 0 | BALANCED 69%, UNKNOWN 31% | 30.6 | 0.000 |
| T6 | 인터록 응답: 횡 돌풍 280 N (10~13 s) → 펜스 100 mm 침범 | -0.6 mm / 0.0 mm / 0.001° | 145.3 mm / 7.85° | 0.010 s | 36.46 s | 1 / 1 | BALANCED 86%, EXTERNAL_FORCE 11%, UNKNOWN 2%, WINCH_MISMATCH 1% | 2.5 | 0.200 |

## 경보 로그

### T1 — 정상 인하울 (초기 +20 mm, +0.5°), 외란 없음

- 0.800 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=-14.8 mm/s dYaw=0.72 deg/s → 전진 보류
- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 3.010 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 31.540 s `INFO_ALIGNED` Xrem=0.5 mm Yerr=0.0 mm Yaw=0.002 deg

### T2a — 초기 편차 복원 +100 mm / +5° (설계서 5단계 기준)

- 0.520 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=-128.7 mm/s dYaw=0.83 deg/s → 전진 보류
- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 3.380 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 31.990 s `INFO_ALIGNED` Xrem=0.2 mm Yerr=0.1 mm Yaw=0.006 deg

### T2b — 초기 편차 복원 −100 mm / −5°

- 0.010 s `ERROR_SAFETY_INTERLOCK` 안전 펜스 침범 Yerr=-100.1 mm(판정 100.1) Yaw=-5.00 deg Xrem=2.400 m
- 0.110 s `INFO_SAFETY_INTERLOCK_CLEARED` 인터록 해제
- 0.520 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=129.7 mm/s dYaw=-0.79 deg/s → 전진 보류
- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 3.370 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 32.010 s `INFO_ALIGNED` Xrem=0.4 mm Yerr=-0.0 mm Yaw=0.005 deg

### T3a — 정상 조류 60 N + 돌풍 200 N·40 N·m (12~15 s), 설계서대로 M_z 만 실행

- 0.340 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=43.3 mm/s dYaw=-2.20 deg/s → 전진 보류
- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 3.110 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 12.030 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=19.9 mm/s dYaw=0.41 deg/s → 전진 보류
- 13.250 s `ERROR_SAFETY_INTERLOCK` 안전 펜스 침범 Yerr=100.0 mm(판정 100.0) Yaw=-3.93 deg Xrem=1.590 m
- 15.140 s `INFO_SAFETY_INTERLOCK_CLEARED` 인터록 해제
- 18.300 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개

### T3b — T3a + [제안] 횡력 지령 F_y 실행

- 0.530 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=-3.8 mm/s dYaw=-1.06 deg/s → 전진 보류
- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 2.220 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 12.220 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=63.0 mm/s dYaw=-0.66 deg/s → 전진 보류
- 14.920 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 15.270 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=-56.8 mm/s dYaw=1.59 deg/s → 전진 보류
- 17.890 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 36.300 s `INFO_ALIGNED` Xrem=0.3 mm Yerr=0.1 mm Yaw=0.004 deg

### T4a — W2(함수우) 권취 속도 +5 % 오차, 보정 가중치 미적용

- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백

### T4b — T4a + 차등 속도 보정 가중치 적용 (윈치 연계 에뮬레이터)

- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 28.940 s `INFO_ALIGNED` Xrem=0.3 mm Yerr=-7.1 mm Yaw=-0.061 deg

### T5 — 로드셀 단선(W3)·고착(W4)·스파이크(W1)·상한(W2), 포즈 50 ms/15 ms 결손, 장력 토픽 200 ms 결손, 모듈 3 인터록 펄스

- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 5.000 s `WARN_UPSTREAM_INTERLOCK` 모듈 3 인터록 ON → 속도 지령 0
- 5.500 s `INFO_UPSTREAM_INTERLOCK_CLEARED` 모듈 3 인터록 해제
- 5.500 s `INFO_SAFETY_INTERLOCK_CLEARED` 인터록 해제
- 10.003 s `WARN_LOADCELL_FAULT` W3(함미좌) DROPOUT 0.000 kN
- 10.010 s `WARN_FEEDBACK_POSE_ONLY` 로드셀 배제 → 자세 단독 피드백
- 15.003 s `INFO_LOADCELL_RECOVERED` W3(함미좌) (DROPOUT 해제)
- 15.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 17.003 s `WARN_LOADCELL_FAULT` W4(함미우) FROZEN 0.993 kN
- 17.010 s `WARN_FEEDBACK_POSE_ONLY` 로드셀 배제 → 자세 단독 피드백
- 19.003 s `INFO_LOADCELL_RECOVERED` W4(함미우) (FROZEN 해제)
- 19.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 20.003 s `WARN_LOADCELL_FAULT` W1(함수좌) INVALID -4.986 kN
- 20.010 s `WARN_FEEDBACK_POSE_ONLY` 로드셀 배제 → 자세 단독 피드백
- 21.043 s `INFO_LOADCELL_RECOVERED` W1(함수좌) (INVALID 해제)
- 21.050 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 25.003 s `WARN_LOADCELL_FAULT` W2(함수우) OVERRANGE 15.000 kN
- 25.010 s `WARN_FEEDBACK_POSE_ONLY` 로드셀 배제 → 자세 단독 피드백
- 27.013 s `INFO_LOADCELL_RECOVERED` W2(함수우) (OVERRANGE 해제)
- 27.020 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 30.012 s `ALARM_POSE_LOST` 21.0 ms 미수신 → 제어 지령 0
- 30.050 s `INFO_POSE_RECOVERED` /sub_pose_filtered 수신 재개
- 30.050 s `INFO_SAFETY_INTERLOCK_CLEARED` 인터록 해제
- 32.460 s `INFO_ALIGNED` Xrem=-1.7 mm Yerr=0.1 mm Yaw=-0.004 deg
- 33.012 s `ALARM_POSE_LOST` 21.0 ms 미수신 → 제어 지령 0
- 33.020 s `INFO_POSE_RECOVERED` /sub_pose_filtered 수신 재개
- 33.020 s `INFO_SAFETY_INTERLOCK_CLEARED` 인터록 해제
- 33.490 s `INFO_ALIGNED` Xrem=-2.8 mm Yerr=0.1 mm Yaw=-0.004 deg
- 35.050 s `WARN_TENSION_TIMEOUT` 장력 토픽 수신 중단 → 자세 단독 피드백
- 35.050 s `WARN_FEEDBACK_POSE_ONLY` 로드셀 배제 → 자세 단독 피드백
- 36.203 s `INFO_LOADCELL_RECOVERED` W1(함수좌) (STALE 해제)
- 36.203 s `INFO_LOADCELL_RECOVERED` W2(함수우) (STALE 해제)
- 36.203 s `INFO_LOADCELL_RECOVERED` W3(함미좌) (STALE 해제)
- 36.203 s `INFO_LOADCELL_RECOVERED` W4(함미우) (STALE 해제)
- 36.210 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백

### T6 — 인터록 응답: 횡 돌풍 280 N (10~13 s) → 펜스 100 mm 침범

- 1.010 s `INFO_FEEDBACK_FULL` 4채널 정상 → 장력+자세 피드백
- 10.140 s `WARN_RAMPDOWN_OVERRIDE` 편차 급증 dY=141.1 mm/s dYaw=-1.64 deg/s → 전진 보류
- 10.630 s `ERROR_SAFETY_INTERLOCK` 안전 펜스 침범 Yerr=99.5 mm(판정 99.5) Yaw=-5.10 deg Xrem=1.567 m
- 13.330 s `INFO_SAFETY_INTERLOCK_CLEARED` 인터록 해제
- 16.400 s `INFO_RAMPDOWN_RELEASED` 편차 안정 → 전진 재개
- 36.460 s `INFO_ALIGNED` Xrem=0.2 mm Yerr=-0.1 mm Yaw=-0.007 deg
