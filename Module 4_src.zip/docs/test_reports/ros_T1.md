# alignment_kpi_monitor 보고서

계측 46 s (워밍업 1 s 제외), 수신 4606 건

| 항목 | 결과 |
|---|---|
| KPI 1 발행 주기 | 99.95 Hz (100 Hz 기준 드롭 0.05 %) |
| 수신 간격 | p50 10.00 / p99 11.16 / max 25.54 ms |
| stamp 간격 > 15 ms (포즈 결손 반영) | 2 회, stamp 역순 0 |
| KPI 2 엔진 연산 | p50 4.0 / p99 7.3 / max 678.0 µs |
| 콜백(수신→발행) | p50 113.9 / p99 801.1 / max 4359.2 µs |
| 포즈 stamp→발행 | p50 0.30 / p99 1.20 / max 7.15 ms |
| 카운터 | poses 4500, 기각 0, 포즈상실 1, 위험 0, 보류 1, 로드셀이상 0, 상위인터록 0 |
| KPI 3 횡편차 vs 참값 | RMSE 0.151 / max 0.613 mm (4403 쌍) |
| KPI 4 방위각 vs 참값 | RMSE 0.0030 / max 0.0109° |
| 안전 단계 분포 | 정상 4202, 경고 201, 위험 203 |
| 정렬 완료 첫 수신 | 31.51 s |
| KPI 6 위험 출력 → 인터록 토픽 | 1 회, max 0.34 ms (같은 콜백 발행, 모니터 수신 순서 기준) |

## 경보

- 0.824 s `WARN_RAMPDOWN_OVERRIDE|편차 급증 dY=-14.6 mm/s dYaw=0.71 deg/s → 전진 보류`
- 1.044 s `INFO_FEEDBACK_FULL|4채널 정상 → 장력+자세 피드백`
- 3.015 s `INFO_RAMPDOWN_RELEASED|편차 안정 → 전진 재개`
- 31.514 s `INFO_ALIGNED|Xrem=0.2 mm Yerr=0.2 mm Yaw=0.002 deg`
- 45.044 s `ALARM_POSE_LOST|20.1 ms 미수신 → 제어 지령 0`
