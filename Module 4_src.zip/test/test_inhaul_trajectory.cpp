// pkg_inhaul_trajectory 단위·통합 시험 (gtest)
#include <gtest/gtest.h>

#include <fstream>

#include "pkg_inhaul_trajectory/sim_testbed.hpp"
#include "pkg_inhaul_trajectory/trajectory_analysis_engine.hpp"

using namespace pit;

namespace {
PoseInput makePose(double x, double y, double yaw_deg, double t = 0.0, double roll_deg = 0.0,
                   double pitch_deg = 0.0) {
  PoseInput p;
  p.stamp_ns = secToNs(t);
  p.p = Vec3(x, y, 0.0);
  p.q = Quat(Eigen::AngleAxisd(yaw_deg * kDeg2Rad, Vec3::UnitZ()) *
             Eigen::AngleAxisd(pitch_deg * kDeg2Rad, Vec3::UnitY()) *
             Eigen::AngleAxisd(roll_deg * kDeg2Rad, Vec3::UnitX()));
  return p;
}
TensionInput tens(double a, double b, double c, double d, double t = 0) {
  TensionInput in;
  in.stamp_ns = secToNs(t);
  in.tension_kn = {a, b, c, d};
  return in;
}
}  // namespace

// ───────────── 세부 1: 공간 기하 편차 ─────────────
TEST(Deviation, StraightLineSignsAndRemain) {
  SpatialDeviationEngine e;
  DockConfig dock;
  ASSERT_TRUE(e.configure(dock, MomentConfig{}));
  const auto d = e.compute(makePose(1.0, 0.03, 2.0));
  EXPECT_NEAR(d.x_remain, 1.4, 1e-12);          // X_target − x
  EXPECT_NEAR(d.y_error, 0.03, 1e-12);          // 좌 +
  EXPECT_NEAR(d.yaw_error, 2.0 * kDeg2Rad, 1e-12);
  const auto r = e.compute(makePose(1.0, -0.02, -1.0));
  EXPECT_NEAR(r.y_error, -0.02, 1e-12);         // 우 −
}

TEST(Deviation, PolylineProjectionAndExtension) {
  SpatialDeviationEngine e;
  DockConfig dock;
  dock.centerline = {Vec2(0, 0), Vec2(1, 0), Vec2(2, 1)};  // 두번째 구간 45°
  ASSERT_TRUE(e.configure(dock, MomentConfig{}));
  const double L = 1.0 + std::sqrt(2.0);
  EXPECT_NEAR(e.targetArcLength(), L, 1e-12);
  // 두번째 구간 위 점에서 좌측 법선으로 0.05 m
  const Vec2 n(-1 / std::sqrt(2.0), 1 / std::sqrt(2.0));
  const Vec2 p = Vec2(1.5, 0.5) + 0.05 * n;
  const auto d = e.compute(makePose(p.x(), p.y(), 45.0));
  EXPECT_EQ(d.segment, 1);
  EXPECT_NEAR(d.y_error, 0.05, 1e-9);
  EXPECT_NEAR(d.yaw_error, 0.0, 1e-9);
  EXPECT_NEAR(d.x_remain, L - (1.0 + std::sqrt(0.5)), 1e-9);
  // 종점 초과 → 음수, 시작점 이전 → 전체 길이 초과
  EXPECT_LT(e.compute(makePose(2.1, 1.1, 45)).x_remain, 0.0);
  EXPECT_NEAR(e.compute(makePose(-0.3, 0.0, 0)).x_remain, L + 0.3, 1e-9);
}

TEST(Deviation, RejectsDegenerateCenterline) {
  SpatialDeviationEngine e;
  DockConfig dock;
  std::string err;
  dock.centerline = {Vec2(0, 0)};
  EXPECT_FALSE(e.configure(dock, MomentConfig{}, &err));
  dock.centerline = {Vec2(0, 0), Vec2(0, 0), Vec2(1, 0)};
  EXPECT_FALSE(e.configure(dock, MomentConfig{}, &err));
  EXPECT_FALSE(err.empty());
}

TEST(Deviation, YawWrapAndRollPitchInvariance) {
  SpatialDeviationEngine e;
  DockConfig dock;
  dock.centerline = {Vec2(0, 0), Vec2(-2, 0)};  // ψ_ref = 180°
  ASSERT_TRUE(e.configure(dock, MomentConfig{}));
  EXPECT_NEAR(e.compute(makePose(-1, 0, -179.0)).yaw_error * kRad2Deg, 1.0, 1e-9);
  EXPECT_NEAR(e.compute(makePose(-1, 0, 179.0)).yaw_error * kRad2Deg, -1.0, 1e-9);
  // 부유 롤·피치가 있어도 선수축 방위 = ZYX yaw
  SpatialDeviationEngine e2;
  ASSERT_TRUE(e2.configure(DockConfig{}, MomentConfig{}));
  EXPECT_NEAR(e2.compute(makePose(1, 0, 3.0, 0, 2.0, -1.5)).yaw_error * kRad2Deg, 3.0, 1e-9);
}

TEST(Deviation, RatesFromTwist) {
  SpatialDeviationEngine e;
  ASSERT_TRUE(e.configure(DockConfig{}, MomentConfig{}));
  PoseInput p = makePose(1, 0, 90.0);  // 선체 x축 = 월드 +Y
  p.v = Vec3(0.01, 0, 0);              // 선체좌표 전진 10 mm/s → 월드 +Y
  p.w = Vec3(0, 0, 0.02);
  auto d = e.compute(p);
  EXPECT_NEAR(d.y_error_rate, 0.01, 1e-12);
  EXPECT_NEAR(d.along_speed, 0.0, 1e-12);
  EXPECT_NEAR(d.yaw_error_rate, 0.02, 1e-12);
  p.twist_in_child_frame = false;      // 월드좌표 twist
  p.v = Vec3(0.05, -0.003, 0);
  d = e.compute(p);
  EXPECT_NEAR(d.y_error_rate, -0.003, 1e-12);
  EXPECT_NEAR(d.along_speed, 0.05, 1e-12);
}

TEST(Deviation, ExtremityLateral) {
  SpatialDeviationEngine e;
  DockConfig dock;
  dock.bow_length_m = 30.0;
  dock.stern_length_m = 35.0;
  ASSERT_TRUE(e.configure(dock, MomentConfig{}));
  const auto d = e.compute(makePose(1, 0.02, 1.0));
  EXPECT_NEAR(d.bow_lateral, 0.02 + 30.0 * std::sin(kDeg2Rad), 1e-12);
  EXPECT_NEAR(d.stern_lateral, 0.02 - 35.0 * std::sin(kDeg2Rad), 1e-12);
}

// ───────────── 세부 3: S-Curve·모멘트 ─────────────
TEST(Profile, ReferenceCurveRespectsLimits) {
  ProfileConfig pc;
  SCurveProfile prof;
  prof.build(pc);
  const double v = pc.v_max_mpm / 60, a = pc.a_max_mps2, j = pc.j_max_mps3;
  EXPECT_NEAR(prof.decelDistance(), 0.5 * v * (v / a + a / j), 1e-6);  // 해석해
  // 기준곡선을 그대로 따라 움직일 때의 가속도·저크
  // 시간영역 적분(1 ms)으로 따라가며 가속도를 50 ms 창 평균으로 구해 저크 확인 (표 보간 잡음 제거)
  double x = prof.decelDistance() - 1e-9, vel = prof.referenceSpeed(x), max_a = 0, max_j = 0;
  std::vector<double> vs;
  const double dt = 0.001;
  for (int k = 0; k < 20000 && x > 1e-4; ++k) {
    vs.push_back(vel);
    x -= vel * dt;
    vel = prof.referenceSpeed(x);
  }
  const int W = 50;
  double prev_a = 0;
  for (size_t k = W; k < vs.size(); k += W) {
    const double acc = (vs[k] - vs[k - W]) / (W * dt);
    max_a = std::max(max_a, std::abs(acc));
    if (k > static_cast<size_t>(W)) max_j = std::max(max_j, std::abs(acc - prev_a) / (W * dt));
    prev_a = acc;
  }
  EXPECT_LE(max_a, a * 1.02);
  EXPECT_LE(max_j, j * 1.10);
  EXPECT_DOUBLE_EQ(prof.referenceSpeed(1.0), v);
  EXPECT_DOUBLE_EQ(prof.referenceSpeed(0.0), 0.0);
}

TEST(Profile, TriangularCaseWhenVmaxSmall) {
  ProfileConfig pc;
  pc.v_max_mpm = 0.6;  // 0.01 m/s < a²/j = 0.028 → 삼각
  SCurveProfile prof;
  prof.build(pc);
  const double v = 0.01, j = pc.j_max_mps3;
  EXPECT_NEAR(prof.decelDistance(), v * std::sqrt(v / j), 1e-6);
}

TEST(Profile, TrackerSmoothAndStep) {
  JerkLimitedTracker t;
  const double al = 0.045, jl = 0.024, dt = 0.01;
  // 계단 0 → 0.1: 가속도·저크 한계 준수, 오버슈트 없음
  double prev_a = 0, max_v = 0;
  for (int k = 0; k < 3000; ++k) {
    t.update(0.1, dt, al, jl);
    EXPECT_LE(std::abs(t.accel()), al + 1e-12);
    EXPECT_LE(std::abs(t.accel() - prev_a), jl * dt + 1e-12);
    prev_a = t.accel();
    max_v = std::max(max_v, t.value());
  }
  EXPECT_NEAR(t.value(), 0.1, 1e-9);
  EXPECT_LE(max_v, 0.1 * 1.005);  // 이산화 오버슈트 0.5 % 이내
  // 한계 내 램프: 진입 과도 후 정상상태 추종 오차 0
  double tgt = 0.1, max_err = 0;
  for (int k = 0; k < 900; ++k) {
    tgt -= 0.01 * dt;
    t.update(tgt, dt, al, jl);
    if (k > 600) max_err = std::max(max_err, std::abs(t.value() - tgt));
  }
  EXPECT_LT(max_err, 1e-6);
}

TEST(Profile, MomentSignSaturationAndLateralForce) {
  ProfileGenerator g;
  ProfileConfig pc;
  MomentConfig mc;
  g.configure(pc, mc);
  auto o = g.update(0.01, 1.0, 0.02, 0.0, 0.0, 0.0, 1.0, false, false);
  EXPECT_NEAR(o.mz_cmd, -mc.kp_y * 0.02, 1e-12);  // 좌 편차 → 시계방향(−) 복원
  o = g.update(0.01, 1.0, 0.0, 0.0, -0.01, 0.0, 1.0, false, false);
  EXPECT_NEAR(o.mz_cmd, mc.kp_yaw * 0.01, 1e-12);
  o = g.update(0.01, 1.0, 5.0, 0.0, 0.0, 0.0, 1.0, false, false);
  EXPECT_DOUBLE_EQ(o.mz_cmd, -mc.mz_max_knm);
  EXPECT_TRUE(o.mz_saturated);
  // 횡력 적분 와인드업 방지: 장시간 포화 후 편차 반전 시 즉시 부호 반전
  for (int k = 0; k < 2000; ++k) g.update(0.01, 1.0, 0.5, 0.0, 0.0, 0.0, 1.0, false, false);
  o = g.update(0.01, 1.0, -0.2, 0.0, 0.0, 0.0, 1.0, false, false);
  EXPECT_GT(o.fy_cmd, 0.0);
  o = g.update(0.01, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, false, true);  // zero_moment
  EXPECT_EQ(o.mz_cmd, 0.0);
  EXPECT_EQ(o.fy_cmd, 0.0);
}

TEST(Profile, HardStopAndCreep) {
  ProfileGenerator g;
  ProfileConfig pc;
  pc.v_creep_mpm = 1.0;  // 기본값(0.3)은 stop_tol 바깥에서 V_ref 보다 작아 효과 없음 — 시험용 확대
  g.configure(pc, MomentConfig{});
  double v = 0;
  for (int k = 0; k < 2000; ++k) v = g.update(0.01, 1.0, 0, 0, 0, 0, 1.0, false, false).v_cmd;
  EXPECT_NEAR(v * 60, pc.v_max_mpm, 1e-6);
  EXPECT_EQ(g.update(0.01, 1.0, 0, 0, 0, 0, 1.0, true, false).v_cmd, 0.0);   // 즉시 0
  for (int k = 0; k < 2000; ++k) v = g.update(0.01, 0.003, 0, 0, 0, 0, 1.0, false, false).v_cmd;
  EXPECT_NEAR(v * 60, pc.v_creep_mpm, 1e-6);                                 // 종점 직전 크리프
  EXPECT_EQ(g.update(0.01, 0.0015, 0, 0, 0, 0, 1.0, false, false).v_cmd, 0.0);  // stop_tol
}

// ───────────── 세부 4: 안전 한계 ─────────────
TEST(Safety, ThresholdsHysteresisAndScale) {
  SafetyBoundaryChecker s;
  SafetyConfig c;
  s.configure(c);
  DeviationState d;
  d.x_remain = 1.0;
  d.rate_valid = true;
  d.y_error = 0.049;
  EXPECT_EQ(s.update(0.01, d).level, SafetyLevel::kNormal);
  d.y_error = -0.075;
  auto st = s.update(0.01, d);
  EXPECT_EQ(st.level, SafetyLevel::kWarning);
  EXPECT_NEAR(st.speed_scale, 1.0 - 0.5 * (1.0 - c.warn_min_speed_scale), 1e-9);
  d.y_error = 0.101;
  st = s.update(0.01, d);
  EXPECT_EQ(st.level, SafetyLevel::kDanger);
  EXPECT_EQ(st.speed_scale, 0.0);
  d.y_error = 0.097;  // 히스테리시스 5 mm 이내 → 위험 유지
  EXPECT_EQ(s.update(0.01, d).level, SafetyLevel::kDanger);
  d.y_error = 0.094;
  EXPECT_EQ(s.update(0.01, d).level, SafetyLevel::kWarning);
  d.y_error = 0.0;
  d.yaw_error = 5.1 * kDeg2Rad;
  EXPECT_EQ(s.update(0.01, d).level, SafetyLevel::kDanger);
  d.yaw_error = 0.0;
  d.x_remain = -0.03;  // 종점 초과
  EXPECT_EQ(s.update(0.01, d).level, SafetyLevel::kDanger);
  EXPECT_GE(s.dangerEvents(), 2u);
}

TEST(Safety, RampDownOverrideOnlyWhenGrowing) {
  SafetyBoundaryChecker s;
  SafetyConfig c;
  s.configure(c);
  DeviationState d;
  d.x_remain = 1.0;
  d.rate_valid = true;
  d.y_error = 0.03;
  d.y_error_rate = -0.05;  // 빠르게 복원 중 → 보류 아님
  EXPECT_FALSE(s.update(0.01, d).hold_override);
  d.y_error_rate = +0.02;  // 커지는 방향 20 mm/s
  auto st = s.update(0.01, d);
  EXPECT_TRUE(st.hold_override);
  EXPECT_NEAR(st.speed_scale, c.override_hold_scale, 1e-12);
  EXPECT_EQ(st.level, SafetyLevel::kWarning);
  d.y_error_rate = 0.001;  // 잠잠해지면 1 s 후 해제
  for (int k = 0; k < 99; ++k) EXPECT_TRUE(s.update(0.01, d).hold_override);
  EXPECT_FALSE(s.update(0.01, d).hold_override);
  // 중심선 근처(|Yerr| < 10 mm)에서는 율만으로 보류하지 않음
  d.y_error = 0.002;
  d.y_error_rate = 0.03;
  EXPECT_FALSE(s.update(0.01, d).hold_override);
}

TEST(Safety, ExtremityOption) {
  SafetyBoundaryChecker s;
  SafetyConfig c;
  c.check_extremities = true;
  s.configure(c);
  DeviationState d;
  d.x_remain = 1.0;
  d.y_error = 0.02;
  d.bow_lateral = 0.12;  // 선수 끝이 펜스 침범
  d.stern_lateral = -0.08;
  EXPECT_EQ(s.update(0.01, d).level, SafetyLevel::kDanger);
}

// ───────────── 세부 2: 장력 불균형 ─────────────
class TensionTest : public ::testing::Test {
 protected:
  void SetUp() override { a.configure(TensionConfig{}, 0.05); }
  // 100 Hz 로 동일 값 n 회 공급 + update
  const TensionState& feed(const TensionInput& in, int n, double y = 0, double yaw = 0,
                           double yr = 0, double wr = 0) {
    for (int k = 0; k < n; ++k) {
      t += 10'000'000;
      a.onTension(t, in);
      a.update(t, 0.01, y, yaw, yr, wr, 0.0);
    }
    return a.state();
  }
  TensionImbalanceAnalyzer a;
  int64_t t = 0;
};

TEST_F(TensionTest, DeltaAndModes) {
  auto st = feed(tens(1.2, 1.0, 0.9, 1.0), 50);
  EXPECT_EQ(st.mode, FeedbackMode::kPoseOnly);  // 최초 1 s 편입 대기
  st = feed(tens(1.2, 1.0, 0.9, 1.0), 60);
  EXPECT_EQ(st.mode, FeedbackMode::kFull);
  EXPECT_NEAR(st.delta_bow_kn, 0.2, 1e-12);
  EXPECT_NEAR(st.delta_stern_kn, -0.1, 1e-12);
  auto al = a.takeAlerts();
  ASSERT_EQ(al.size(), 1u);
  EXPECT_EQ(al[0].code, "INFO_FEEDBACK_FULL");  // 시작 시 복귀 경보 스팸 없음
}

TEST_F(TensionTest, DropoutExcludedThenRecovers) {
  feed(tens(1, 1, 1, 1), 110);
  auto st = feed(tens(1, 1, 0.0, 1), 1);  // W3 단선
  EXPECT_EQ(st.fault[2], ChannelFault::kDropout);
  EXPECT_FALSE(st.channel_valid[2]);
  EXPECT_FALSE(st.stern_valid);
  EXPECT_TRUE(st.bow_valid);
  EXPECT_EQ(st.mode, FeedbackMode::kPoseOnly);
  EXPECT_EQ(st.delta_stern_kn, 0.0);
  st = feed(tens(1, 1, 0.0, 1), 300);  // 0 유지 = 계속 단선
  EXPECT_EQ(st.fault[2], ChannelFault::kDropout);
  st = feed(tens(1, 1, 1.0, 1), 99);
  EXPECT_EQ(st.fault[2], ChannelFault::kRecovering);
  st = feed(tens(1, 1, 1.0, 1), 2);
  EXPECT_EQ(st.mode, FeedbackMode::kFull);
}

TEST_F(TensionTest, SpikeOverrangeNanFrozenHw) {
  feed(tens(1, 1, 1, 1), 110);
  EXPECT_EQ(feed(tens(5.5, 1, 1, 1), 1).fault[0], ChannelFault::kSpike);
  feed(tens(1, 1, 1, 1), 120);
  EXPECT_EQ(feed(tens(1, 13.0, 1, 1), 1).fault[1], ChannelFault::kOverrange);
  feed(tens(1, 1, 1, 1), 120);
  EXPECT_EQ(feed(tens(1, 1, std::nan(""), 1), 1).fault[2], ChannelFault::kInvalid);
  // 다른 채널은 변하는데 W4 만 고착 → FROZEN
  for (int k = 0; k < 120; ++k) feed(tens(1 + 1e-3 * (k % 3), 1 + 1e-3 * (k % 2), 1, 1.0 + 1e-3 * (k % 2)), 1);
  ChannelFault f4 = ChannelFault::kOk;
  for (int k = 0; k < 110; ++k) f4 = feed(tens(1 + 1e-3 * (k % 3), 1 + 1e-3 * (k % 2), 1, 1.0), 1).fault[3];
  EXPECT_EQ(f4, ChannelFault::kFrozen);
  // 4채널 모두 정지값 = 정적 하중 → 고착 아님
  TensionImbalanceAnalyzer b;
  b.configure(TensionConfig{}, 0.05);
  for (int k = 0; k < 300; ++k) {
    b.onTension(k * 10'000'000LL, tens(1, 1, 1, 1));
    b.update(k * 10'000'000LL, 0.01, 0, 0, 0, 0, 0);
  }
  EXPECT_EQ(b.state().mode, FeedbackMode::kFull);
  feed(tens(1, 1, 1, 1), 120);
  TensionInput hw = tens(1, 1, 1, 1);
  hw.hw_status[0] = 3;
  EXPECT_EQ(feed(hw, 1).fault[0], ChannelFault::kHwStatus);
}

TEST_F(TensionTest, TopicTimeout) {
  feed(tens(1, 1, 1, 1), 110);
  t += 60'000'000;  // 60 ms 공백
  a.update(t, 0.01, 0, 0, 0, 0, 0);
  EXPECT_FALSE(a.state().data_valid);
  EXPECT_EQ(a.state().mode, FeedbackMode::kPoseOnly);
  bool found = false;
  for (auto& al : a.takeAlerts()) found |= al.code == "WARN_TENSION_TIMEOUT";
  EXPECT_TRUE(found);
}

TEST_F(TensionTest, CauseExternalVsWinch) {
  const TensionConfig c;
  const double kg2 = 2.0 * c.wire_stiffness_kn_per_m * c.wire_lateral_gain;
  const double y = 0.05;
  // 외력: 선체가 좌(+y)로 밀림 → 길이가 같은 와이어가 버티며 ΔT = −2kg·y (우측 장력 증가)
  auto st = feed(tens(1 - kg2 * y / 2, 1 + kg2 * y / 2, 1 - kg2 * y / 2, 1 + kg2 * y / 2), 200, y);
  EXPECT_EQ(st.cause, TensionCause::kExternalForce);
  EXPECT_EQ(st.speed_weight[0], 0.0);  // 외력이면 장력 균등화 안 함
  // 권취 속도 오차: 함수 좌 윈치가 더 감아 선체를 좌로 끌어 평형 → ΔT ≈ 0, 변위만 존재
  st = feed(tens(1.05, 1.05, 1, 1), 200, y / 2, std::asin(y / 2 / 1.2));  // 선수만 y
  EXPECT_EQ(st.cause, TensionCause::kWinchMismatch);
  EXPECT_LT(st.speed_weight[0], 0.0);  // W1 감속
  EXPECT_GT(st.speed_weight[1], 0.0);
  // 균형
  st = feed(tens(1, 1, 1, 1), 200);
  EXPECT_EQ(st.cause, TensionCause::kBalanced);
}

TEST_F(TensionTest, CommandCompensation) {
  feed(tens(1, 1, 1, 1), 110);
  // 자체 M_z 지령 0.3 kN·m 이 만든 장력차(ΔT_bow = +0.25, ΔT_stern = −0.25)는 원인 판정에서 제외
  const double M = 0.3, dT = M / (0.5 * 2.4);
  for (int k = 0; k < 300; ++k) {
    t += 10'000'000;
    a.onTension(t, tens(1 + dT / 2, 1 - dT / 2, 1 - dT / 2, 1 + dT / 2));
    a.update(t, 0.01, 0, 0, 0, 0, M);
  }
  EXPECT_NEAR(a.state().residual_bow_kn, 0.0, 1e-3);
  EXPECT_EQ(a.state().cause, TensionCause::kBalanced);
}

// ───────────── 엔진 ─────────────
class EngineTest : public ::testing::Test {
 protected:
  void SetUp() override { ASSERT_TRUE(e.configure(cfg)); }
  std::optional<AlignmentOutput> pose(double x, double y, double yaw_deg) {
    t += 10'000'000;
    PoseInput p = makePose(x, y, yaw_deg, nsToSec(t));
    return e.onPose(t, p);
  }
  TrajectoryConfig cfg;
  TrajectoryAnalysisEngine e;
  int64_t t = 1'000'000'000;
};

TEST_F(EngineTest, PoseTimeoutZeroCommandAndRestart) {
  for (int k = 0; k < 300; ++k) pose(0.5, 0, 0);
  EXPECT_GT(e.last().target_inhaul_speed_mpm, 1.0);
  EXPECT_FALSE(e.checkWatchdog(t + 20'000'000).has_value());  // 정확히 20 ms: 아직
  auto z = e.checkWatchdog(t + 20'500'000);
  ASSERT_TRUE(z.has_value());
  EXPECT_EQ(z->target_inhaul_speed_mpm, 0.0);
  EXPECT_EQ(z->correction_moment_z_knm, 0.0);
  EXPECT_EQ(z->safety_status_code, 2);
  EXPECT_TRUE(z->pose_lost);
  bool alarm = false;
  for (auto& a : e.takeAlerts()) alarm |= a.code == "ALARM_POSE_LOST";
  EXPECT_TRUE(alarm);
  t += 30'000'000;
  auto o = pose(0.5, 0, 0);  // 복귀: 0 에서 저크 제한 재출발
  ASSERT_TRUE(o.has_value());
  EXPECT_LT(o->target_inhaul_speed_mpm, 0.05);
  EXPECT_FALSE(o->pose_lost);
  EXPECT_EQ(e.counters().pose_timeouts, 1u);
}

TEST_F(EngineTest, UpstreamInterlockStops) {
  for (int k = 0; k < 300; ++k) pose(0.5, 0, 0);
  e.onUpstreamInterlock(t, true);
  auto o = pose(0.5, 0, 0);
  EXPECT_EQ(o->target_inhaul_speed_mpm, 0.0);
  EXPECT_EQ(o->safety_status_code, 2);
  EXPECT_TRUE(o->interlock);
  e.onUpstreamInterlock(t, false);
  EXPECT_EQ(pose(0.5, 0, 0)->safety_status_code, 0);
}

TEST_F(EngineTest, DangerInterlockSameCycle) {
  for (int k = 0; k < 300; ++k) pose(0.5, 0, 0);
  auto o = pose(0.5, 0.105, 0);
  EXPECT_EQ(o->safety_status_code, 2);
  EXPECT_EQ(o->target_inhaul_speed_mpm, 0.0);
  EXPECT_NE(o->correction_moment_z_knm, 0.0);  // 정지 중에도 복원 모멘트 (danger_zero_moment=false)
  EXPECT_LT(o->compute_time_us, 1000.0);
}

TEST_F(EngineTest, RejectsOutOfOrderAndNaN) {
  pose(0.5, 0, 0);
  PoseInput p = makePose(0.5, 0, 0, nsToSec(t));  // 중복 stamp
  EXPECT_FALSE(e.onPose(t + 1, p).has_value());
  p = makePose(std::nan(""), 0, 0, nsToSec(t + 10'000'000));
  EXPECT_FALSE(e.onPose(t + 10'000'000, p).has_value());
  EXPECT_EQ(e.counters().poses_rejected, 2u);
}

TEST_F(EngineTest, AlignedDwellAndRelease) {
  for (int k = 0; k < 49; ++k) EXPECT_FALSE(pose(2.398, 0.004, 0.1)->is_aligned);
  EXPECT_TRUE(pose(2.398, 0.004, 0.1)->is_aligned);  // 0.5 s dwell
  EXPECT_TRUE(pose(2.398, 0.012, 0.1)->is_aligned);  // 공차 10 mm 초과 but 15 mm 이내 → 유지
  EXPECT_FALSE(pose(2.398, 0.016, 0.1)->is_aligned);
}

TEST(Config, LoadsPackageYamlAndPartial) {
  TrajectoryConfig c;
  std::string err;
  ASSERT_TRUE(loadTrajectoryConfig(std::string(PIT_CONFIG_DIR) + "/dock_trajectory_profile.yaml",
                                   &c, &err))
      << err;
  EXPECT_EQ(c.dock.centerline.size(), 2u);
  EXPECT_TRUE(c.dock.has_target);
  EXPECT_DOUBLE_EQ(c.safety.y_danger_m, 0.100);
  EXPECT_DOUBLE_EQ(c.safety.pose_timeout_s, 0.020);
  TrajectoryAnalysisEngine e;
  EXPECT_TRUE(e.configure(c, &err)) << err;
  const std::string tmp = "/tmp/pit_partial.yaml";
  std::ofstream(tmp) << "profile:\n  v_max_mpm: 3.0\nsafety:\n  y_warn_m: 0.2\n";
  TrajectoryConfig p;
  ASSERT_TRUE(loadTrajectoryConfig(tmp, &p, &err));
  EXPECT_DOUBLE_EQ(p.profile.v_max_mpm, 3.0);
  EXPECT_DOUBLE_EQ(p.profile.a_max_mps2, ProfileConfig{}.a_max_mps2);
  EXPECT_FALSE(e.configure(p, &err));  // warn > danger 거부
  std::ofstream(tmp) << "dock:\n  centerline: [1, 2]\n";
  EXPECT_FALSE(loadTrajectoryConfig(tmp, &p, &err));
}

// ───────────── 폐루프 (테스트베드 합성) ─────────────
TEST(ClosedLoop, NormalInhaulAligns) {
  TrajectoryAnalysisEngine e;
  ASSERT_TRUE(e.configure(TrajectoryConfig{}));
  sim::TestbedSim s;
  sim::Scenario sc;
  sc.duration_s = 40;
  sc.y0 = 0.02;
  auto r = sim::runClosedLoop(e, s, sc);
  ASSERT_FALSE(r.samples.empty());
  EXPECT_TRUE(r.samples.back().out.is_aligned);
  EXPECT_LT(std::abs(r.samples.back().truth_x_remain), 0.005);
  EXPECT_EQ(r.counters.danger_events, 0u);
  EXPECT_EQ(r.counters.pose_timeouts, 0u);
}

TEST(ClosedLoop, LoadcellFaultAndPoseLoss) {
  TrajectoryAnalysisEngine e;
  ASSERT_TRUE(e.configure(TrajectoryConfig{}));
  sim::TestbedSim s;
  sim::Scenario sc;
  sc.duration_s = 35;
  sc.loadcell_faults = {{2, 10, 14, sim::LoadcellFault::kZero}};
  sc.pose_blackouts = {{30, 30.05}};
  auto r = sim::runClosedLoop(e, s, sc);
  bool pose_only = false, lost = false;
  for (auto& s2 : r.samples) {
    if (s2.t > 10.05 && s2.t < 14.0) pose_only |= s2.out.tension.mode == FeedbackMode::kPoseOnly;
    if (s2.from_watchdog) {
      lost = true;
      EXPECT_EQ(s2.out.target_inhaul_speed_mpm, 0.0);
    }
  }
  EXPECT_TRUE(pose_only);
  EXPECT_TRUE(lost);
  ASSERT_EQ(r.pose_lost_detect_ms.size(), 1u);
  EXPECT_LE(r.pose_lost_detect_ms[0], 2.0 + 1e-6);  // 워치독 2 ms 해상도
  EXPECT_TRUE(r.samples.back().out.is_aligned);
}
