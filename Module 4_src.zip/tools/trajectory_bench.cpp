// trajectory_bench — 설계서 8장 KPI 2~6 계측 + 테스트베드 시나리오 T1~T6 (합성 폐루프)
//   ./trajectory_bench [--duration 3600] [--report bench.md] [--csv-dir DIR] [--quick]
//   KPI 1(발행 주기)은 ROS 그래프 수준 → tools/alignment_kpi_monitor.py
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <numeric>
#include <random>
#include <sstream>

#include "pkg_inhaul_trajectory/sim_testbed.hpp"

using namespace pit;
using namespace pit::sim;

namespace {
double pct(std::vector<double> v, double p) {
  if (v.empty()) return 0.0;
  std::sort(v.begin(), v.end());
  const size_t i = std::min(v.size() - 1, static_cast<size_t>(p / 100.0 * (v.size() - 1) + 0.5));
  return v[i];
}
double maxAbs(const std::vector<double>& v) {
  double m = 0;
  for (double x : v) m = std::max(m, std::abs(x));
  return m;
}
double rms(const std::vector<double>& v) {
  if (v.empty()) return 0.0;
  double s = 0;
  for (double x : v) s += x * x;
  return std::sqrt(s / v.size());
}
const char* yesno(bool b) { return b ? "**충족**" : "**미충족**"; }

struct ScenarioSummary {
  std::string name, desc;
  double final_x_mm = 0, final_y_mm = 0, final_yaw_deg = 0;
  double max_y_mm = 0, max_yaw_deg = 0;
  double aligned_t = -1, recovery_t = -1;
  uint32_t danger = 0, hold = 0, faults = 0, lost = 0, upstream = 0;
  std::map<std::string, int> cause_count;
  int pose_only_samples = 0, samples = 0;
  double max_weight = 0;
  std::vector<std::string> alerts;
};

ScenarioSummary summarize(const std::string& name, const std::string& desc, const RunResult& r,
                          double recover_y = 0.010, double recover_yaw_deg = 0.3) {
  ScenarioSummary s;
  s.name = name;
  s.desc = desc;
  const auto& last = r.samples.back();
  s.final_x_mm = last.truth_x_remain * 1e3;
  s.final_y_mm = last.truth.y * 1e3;
  s.final_yaw_deg = last.truth.yaw * kRad2Deg;
  for (const auto& x : r.samples) {
    s.max_y_mm = std::max(s.max_y_mm, std::abs(x.truth.y) * 1e3);
    s.max_yaw_deg = std::max(s.max_yaw_deg, std::abs(x.truth.yaw) * kRad2Deg);
    if (s.aligned_t < 0 && x.out.is_aligned) s.aligned_t = x.t;
    if (s.recovery_t < 0 && std::abs(x.truth.y) < recover_y &&
        std::abs(x.truth.yaw) * kRad2Deg < recover_yaw_deg)
      s.recovery_t = x.t;
    if (!x.from_watchdog) {
      ++s.samples;
      s.cause_count[toString(x.out.tension.cause)]++;
      if (x.out.tension.mode == FeedbackMode::kPoseOnly) ++s.pose_only_samples;
      for (double w : x.out.tension.speed_weight) s.max_weight = std::max(s.max_weight, std::abs(w));
    }
  }
  s.danger = r.counters.danger_events;
  s.hold = r.counters.hold_events;
  s.faults = r.counters.loadcell_faults;
  s.lost = r.counters.pose_timeouts;
  s.upstream = r.counters.upstream_interlocks;
  for (const auto& a : r.alerts) {
    char b[256];
    std::snprintf(b, sizeof(b), "%.3f s `%s` %s", a.first, a.second.code.c_str(),
                  a.second.info.c_str());
    s.alerts.emplace_back(b);
  }
  return s;
}

void writeCsv(const std::string& path, const RunResult& r) {
  std::ofstream f(path);
  f << "t,x_true,y_true_mm,yaw_true_deg,x_remain_mm,y_error_mm,yaw_error_deg,v_cmd_mpm,v_ref_mpm,"
       "vx_true_mpm,mz_knm,fy_kn,level,hold,aligned,cause,mode,dT_bow,dT_stern,w1,w2,w3,w4,"
       "T1,T2,T3,T4\n";
  for (const auto& s : r.samples) {
    const auto& o = s.out;
    f << s.t << ',' << s.truth.x << ',' << s.truth.y * 1e3 << ',' << s.truth.yaw * kRad2Deg << ','
      << o.x_remain_m * 1e3 << ',' << o.y_error_m * 1e3 << ',' << o.yaw_error_deg << ','
      << o.target_inhaul_speed_mpm << ',' << o.v_ref_mpm << ',' << s.truth.vx * 60 << ','
      << o.correction_moment_z_knm << ',' << o.correction_force_y_kn << ','
      << int(o.safety_status_code) << ',' << o.hold_override << ',' << o.is_aligned << ','
      << toString(o.tension.cause) << ',' << int(o.tension.mode) << ','
      << o.delta_tension_bow_kn << ',' << o.delta_tension_stern_kn;
    for (double w : o.tension.speed_weight) f << ',' << w;
    for (double t : s.truth.tension) f << ',' << t;
    f << '\n';
  }
}
}  // namespace

int main(int argc, char** argv) {
  double duration = 3600.0;
  std::string report, csv_dir;
  bool quick = false;
  for (int i = 1; i < argc; ++i) {
    if (!std::strcmp(argv[i], "--duration") && i + 1 < argc) duration = std::atof(argv[++i]);
    else if (!std::strcmp(argv[i], "--report") && i + 1 < argc) report = argv[++i];
    else if (!std::strcmp(argv[i], "--csv-dir") && i + 1 < argc) csv_dir = argv[++i];
    else if (!std::strcmp(argv[i], "--quick")) quick = true;
  }
  if (quick) duration = std::min(duration, 120.0);

  TrajectoryConfig cfg;
  TrajectoryAnalysisEngine eng;
  std::string err;
  if (!eng.configure(cfg, &err)) {
    std::fprintf(stderr, "config: %s\n", err.c_str());
    return 1;
  }
  TestbedSim sim;
  std::ostringstream md;
  md << "# pkg_inhaul_trajectory 벤치 보고서\n\n";
  md << "합성 Physical Twin 테스트베드 폐루프 (선체 200 kg / 와이어 4본 2 kN/m / 윈치 τ 0.25 s / 포즈 100 Hz EKF 수준 잡음). "
        "물리 1 ms, 포즈·장력 100 Hz, 워치독 2 ms.\n\n";

  // ── 시나리오 ──
  std::vector<ScenarioSummary> sums;
  auto run = [&](Scenario sc, const std::string& desc, TrajectoryConfig c = TrajectoryConfig{}) {
    TrajectoryAnalysisEngine e;
    e.configure(c);
    RunResult r = runClosedLoop(e, sim, sc);
    if (!csv_dir.empty()) writeCsv(csv_dir + "/" + sc.name + ".csv", r);
    sums.push_back(summarize(sc.name, desc, r));
    return r;
  };

  const Scenario t1 = makeScenario("T1");
  const RunResult r1 = run(t1, "정상 인하울 (초기 +20 mm, +0.5°), 외란 없음");
  const Scenario t2a = makeScenario("T2a");
  run(t2a, "초기 편차 복원 +100 mm / +5° (설계서 5단계 기준)");
  run(makeScenario("T2b"), "초기 편차 복원 −100 mm / −5°");
  const Scenario t3 = makeScenario("T3a");
  run(t3, "정상 조류 60 N + 돌풍 200 N·40 N·m (12~15 s), 설계서대로 M_z 만 실행");
  TrajectoryConfig c3b;
  c3b.tension.force_y_applied = true;
  run(makeScenario("T3b"), "T3a + [제안] 횡력 지령 F_y 실행", c3b);
  run(makeScenario("T4a"), "W2(함수우) 권취 속도 +5 % 오차, 보정 가중치 미적용");
  const Scenario t4b = makeScenario("T4b");
  run(t4b, "T4a + 차등 속도 보정 가중치 적용 (윈치 연계 에뮬레이터)");
  const Scenario t5 = makeScenario("T5");
  const RunResult r5 = run(t5, "로드셀 단선(W3)·고착(W4)·스파이크(W1)·상한(W2), 포즈 50 ms/15 ms 결손, 장력 토픽 200 ms 결손, 모듈 3 인터록 펄스");
  const Scenario t6 = makeScenario("T6");
  const RunResult r6 = run(t6, "인터록 응답: 횡 돌풍 280 N (10~13 s) → 펜스 100 mm 침범");

  // ── KPI 2: 연산 지연 (장시간) ──
  std::vector<double> comp;
  double sim_time = 0;
  uint32_t seed = 11;
  const std::vector<Scenario> pool = {t1, t2a, t3, t4b, t5, t6};
  size_t idx = 0;
  while (sim_time < duration) {
    Scenario sc = pool[idx++ % pool.size()];
    sc.seed = seed++;
    TrajectoryAnalysisEngine e;
    e.configure(cfg);
    RunResult r = runClosedLoop(e, sim, sc);
    comp.insert(comp.end(), r.compute_us.begin(), r.compute_us.end());
    sim_time += sc.duration_s;
  }

  // ── KPI 3·4: 기하 정밀도 (임의 회전 도크, 무작위 자세) ──
  std::mt19937 rng(3);
  std::uniform_real_distribution<double> U(-1, 1);
  std::vector<double> ey64, eyaw64, ey32, eyaw32, ex64;
  for (int trial = 0; trial < 20; ++trial) {
    const double th = U(rng) * kPi;
    const Vec2 o(10 * U(rng), 10 * U(rng));
    const Vec2 u(std::cos(th), std::sin(th));
    const double L = 2.0 + 60.0 * std::abs(U(rng));  // 실함 길이 규모까지
    DockConfig dock;
    dock.centerline = {o, o + L * u};
    TrajectoryConfig c = cfg;
    c.dock = dock;
    SpatialDeviationEngine dev;
    dev.configure(c.dock, c.moment);
    for (int k = 0; k < 5000; ++k) {
      const double s = L * (0.5 + 0.5 * U(rng)), lat = 0.15 * U(rng), yaw = 6.0 * U(rng);
      const Vec2 p2 = o + s * u + lat * Vec2(-u.y(), u.x());
      PoseInput p;
      p.p = Vec3(p2.x(), p2.y(), 0.01 * U(rng));
      p.q = Quat(Eigen::AngleAxisd(th + yaw * kDeg2Rad, Vec3::UnitZ()) *
                 Eigen::AngleAxisd(1.0 * kDeg2Rad * U(rng), Vec3::UnitY()) *
                 Eigen::AngleAxisd(1.0 * kDeg2Rad * U(rng), Vec3::UnitX()));
      const auto d = dev.compute(p);
      ey64.push_back(d.y_error - lat);
      eyaw64.push_back(d.yaw_error * kRad2Deg - yaw);
      ex64.push_back(d.x_remain - (L - s));
      ey32.push_back(static_cast<float>(d.y_error) - lat);                       // msg float32
      eyaw32.push_back(static_cast<float>(d.yaw_error * kRad2Deg) - yaw);
    }
  }
  // 폐루프 T1 의 EKF 수준 잡음 포함 오차 (모듈 4 입력 정밀도에 종속)
  std::vector<double> ey_noisy, eyaw_noisy;
  for (const auto& s : r1.samples) {
    if (s.from_watchdog) continue;
    ey_noisy.push_back(s.out.y_error_m - s.truth.y);
    eyaw_noisy.push_back(s.out.yaw_error_deg - s.truth.yaw * kRad2Deg);
  }

  // ── KPI 5: 종단 0.5 m 감속 프로파일 추종 (T1) ──
  const double vmax = cfg.profile.v_max_mpm;
  std::vector<double> cmd_fs, act_fs, cmd_rel;
  for (const auto& s : r1.samples) {
    if (s.from_watchdog) continue;
    if (s.truth_x_remain > 0.5 || s.truth_x_remain < cfg.profile.stop_tolerance_m) continue;
    const double vref_meas = s.out.v_ref_mpm;
    const double vref_true =
        eng.profile().profile().referenceSpeed(s.truth_x_remain) * kMps2Mpm;
    const double vref_meas_creep = std::max(vref_meas, cfg.profile.v_creep_mpm);
    cmd_fs.push_back((s.out.target_inhaul_speed_mpm - vref_meas_creep) / vmax * 100.0);
    act_fs.push_back((s.truth.vx * kMps2Mpm - std::max(vref_true, cfg.profile.v_creep_mpm)) /
                     vmax * 100.0);
    if (vref_meas > 0.1 * vmax)
      cmd_rel.push_back((s.out.target_inhaul_speed_mpm - vref_meas) / vref_meas * 100.0);
  }

  // ── KPI 6: 인터록 응답 ──
  std::vector<double> il = r6.interlock_latency_ms;
  std::vector<double> lost = r5.pose_lost_detect_ms;
  // 판정 자체 지연 = 침범 포즈 수신 → 플래그 생성 (같은 콜백)
  // 상위 인터록 펄스 응답: T5 에서 5.0 s 이후 첫 포즈 출력의 속도 = 0 확인
  double upstream_resp_ms = -1;
  for (const auto& s : r5.samples)
    if (s.t >= 5.0 && s.out.upstream_interlock) {
      upstream_resp_ms = (s.t - 5.0) * 1e3;
      break;
    }

  // ── 보고서 ──
  char b[512];
  md << "## KPI 요약 (설계서 8장)\n\n| # | 항목 | 목표 | 결과 | 판정 |\n|---|---|---|---|---|\n";
  md << "| 1 | 궤적 분석 연산 주기 | ≥ 100 Hz, 드롭 0 % | 포즈 1건당 출력 1건 (이벤트 구동) — ROS 계측은 `alignment_kpi_monitor.py` | ROS 보고서 참조 |\n";
  std::snprintf(b, sizeof(b),
                "| 2 | 알고리즘 연산 지연 | ≤ 1.0 ms | p50 %.1f µs / p99 %.1f µs / p99.99 %.1f µs / max %.1f µs (%zu 사이클, %.0f s) | %s |\n",
                pct(comp, 50), pct(comp, 99), pct(comp, 99.99), pct(comp, 100), comp.size(),
                sim_time, yesno(pct(comp, 100) <= 1000.0));
  md << b;
  std::snprintf(b, sizeof(b),
                "| 3 | 횡편차 계산 정밀도 | ±1.0 mm | 기하 연산 max %.2e mm (float32 출력 %.2e mm), EKF 잡음 포함 RMSE %.3f / max %.3f mm | %s (연산), 입력 잡음은 모듈 3 정밀도 |\n",
                maxAbs(ey64) * 1e3, maxAbs(ey32) * 1e3, rms(ey_noisy) * 1e3,
                maxAbs(ey_noisy) * 1e3, yesno(maxAbs(ey32) * 1e3 <= 1.0 && maxAbs(ey_noisy) * 1e3 <= 1.0));
  md << b;
  std::snprintf(b, sizeof(b),
                "| 4 | 방위각 계산 정밀도 | ±0.05° | 기하 연산 max %.2e° (float32 %.2e°), 롤·피치 ±1° 포함, EKF 잡음 포함 RMSE %.4f / max %.4f° | %s |\n",
                maxAbs(eyaw64), maxAbs(eyaw32), rms(eyaw_noisy), maxAbs(eyaw_noisy),
                yesno(maxAbs(eyaw32) <= 0.05 && maxAbs(eyaw_noisy) <= 0.05));
  md << b;
  std::snprintf(b, sizeof(b),
                "| 5 | 종단 감속 프로파일 추종성 | ≤ 2.0 %% | 지령 vs 기준곡선: max %.3f %%FS (V_ref>10%% 구간 상대 max %.3f %%) / 선체 실속도 vs 기준곡선: max %.2f %%FS, RMS %.2f %%FS | %s (지령), 실속도는 윈치 응답 τ 의존 |\n",
                maxAbs(cmd_fs), maxAbs(cmd_rel), maxAbs(act_fs), rms(act_fs),
                yesno(maxAbs(cmd_fs) <= 2.0));
  md << b;
  std::snprintf(b, sizeof(b),
                "| 6 | 안전 인터록 응답 | ≤ 10 ms | 펜스 침범 포즈 수신 → 위험 플래그: %s ms (같은 주기). 포즈 상실: timeout 경과 후 %s ms 내 ALARM. 상위 인터록 → 속도 0: %.0f ms | %s |\n",
                il.empty() ? "-" : (std::to_string(maxAbs(il)).substr(0, 6)).c_str(),
                lost.empty() ? "-" : (std::to_string(maxAbs(lost)).substr(0, 5)).c_str(),
                upstream_resp_ms, yesno(!il.empty() && maxAbs(il) <= 10.0 && maxAbs(lost) <= 10.0));
  md << b;
  std::snprintf(b, sizeof(b), "\n종단 0.5 m 감속 시작 거리 = %.3f m (v_max %.1f m/min, a %.3f m/s², j %.3f m/s³).\n",
                eng.profile().profile().decelDistance(), vmax, cfg.profile.a_max_mps2,
                cfg.profile.j_max_mps3);
  md << b;

  md << "\n## 시나리오\n\n| 시나리오 | 조건 | 최종 X_rem / Y / Yaw (참값) | 최대 |Y| / |Yaw| | 복원(|Y|<10 mm·|Yaw|<0.3°) | 정렬 완료 | 위험/보류 | 장력 원인 분포 | 자세단독 % | 최대 가중치 |\n|---|---|---|---|---|---|---|---|---|---|\n";
  for (const auto& s : sums) {
    std::string causes;
    for (const auto& kv : s.cause_count) {
      if (!causes.empty()) causes += ", ";
      char cb[64];
      std::snprintf(cb, sizeof(cb), "%s %.0f%%", kv.first.c_str(), 100.0 * kv.second / s.samples);
      causes += cb;
    }
    std::snprintf(b, sizeof(b),
                  "| %s | %s | %.1f mm / %.1f mm / %.3f° | %.1f mm / %.2f° | %s | %s | %u / %u | %s | %.1f | %.3f |\n",
                  s.name.c_str(), s.desc.c_str(), s.final_x_mm, s.final_y_mm, s.final_yaw_deg,
                  s.max_y_mm, s.max_yaw_deg,
                  s.recovery_t < 0 ? "미복원" : (std::to_string(s.recovery_t).substr(0, 5) + " s").c_str(),
                  s.aligned_t < 0 ? "**미완료**" : (std::to_string(s.aligned_t).substr(0, 5) + " s").c_str(),
                  s.danger, s.hold, causes.c_str(), 100.0 * s.pose_only_samples / std::max(1, s.samples),
                  s.max_weight);
    md << b;
  }
  md << "\n## 경보 로그\n";
  for (const auto& s : sums) {
    md << "\n### " << s.name << " — " << s.desc << "\n\n";
    const size_t n = std::min<size_t>(s.alerts.size(), 40);
    for (size_t i = 0; i < n; ++i) md << "- " << s.alerts[i] << "\n";
    if (s.alerts.size() > n) md << "- … (" << s.alerts.size() - n << "건 생략)\n";
    if (s.alerts.empty()) md << "- (없음)\n";
  }
  const std::string out = md.str();
  std::fputs(out.c_str(), stdout);
  if (!report.empty()) std::ofstream(report) << out;
  return 0;
}
