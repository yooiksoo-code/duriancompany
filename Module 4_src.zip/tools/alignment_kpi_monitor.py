#!/usr/bin/env python3
"""ROS 그래프 수준 KPI 계측 — [모듈 4] /inhaul/alignment_status

  ros2 run pkg_inhaul_trajectory alignment_kpi_monitor.py --duration 60 [--report out.md] [--truth]

KPI 1  발행 주기 (Hz, 간격 최대, 100 Hz 기준 드롭률)
KPI 2  연산 지연 (진단 compute_time_us / callback_time_us)
KPI 3·4 (합성 시) /sim/ground_truth_pose 대비 횡편차·방위각 오차 — 같은 stamp 끼리 비교
KPI 6  위험/포즈상실 → /inhaul/safety_interlock 전이 응답
+ 경보(/hmi/trajectory_alerts) 로그, 안전 단계 분포, 정렬 완료 시각
"""
import argparse
import math
import statistics
import time

import rclpy
from inhaul_msgs.msg import AlignmentStatus, TrajectoryDiagnostics
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from std_msgs.msg import Bool, String


def pct(v, p):
    if not v:
        return float('nan')
    s = sorted(v)
    return s[min(len(s) - 1, int(round(p / 100.0 * (len(s) - 1))))]


def yaw_of(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))


class Monitor(Node):
    def __init__(self, truth):
        super().__init__('alignment_kpi_monitor')
        self.rx = []          # (수신 단조시각, stamp_ns, msg)
        self.diag = []
        self.alerts = []
        self.interlock = []   # (수신 시각, 값)
        self.truth = {}
        self.t0 = time.monotonic()
        self.create_subscription(AlignmentStatus, '/inhaul/alignment_status', self.on_status, 50)
        self.create_subscription(TrajectoryDiagnostics, '/inhaul/trajectory_diagnostics',
                                 self.on_diag, 50)
        self.create_subscription(String, '/hmi/trajectory_alerts', self.on_alert, 50)
        latched = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(Bool, '/inhaul/safety_interlock', self.on_interlock, latched)
        if truth:
            self.create_subscription(Odometry, '/sim/ground_truth_pose', self.on_truth, 50)

    def now(self):
        return time.monotonic() - self.t0

    def on_status(self, m):
        st = m.header.stamp.sec * 1_000_000_000 + m.header.stamp.nanosec
        self.rx.append((self.now(), st, m))

    def on_diag(self, d):
        self.diag.append((self.now(), d))

    def on_alert(self, s):
        self.alerts.append((self.now(), s.data))

    def on_interlock(self, b):
        self.interlock.append((self.now(), b.data))

    def on_truth(self, o):
        st = o.header.stamp.sec * 1_000_000_000 + o.header.stamp.nanosec
        self.truth[st] = (o.pose.pose.position.y, yaw_of(o.pose.pose.orientation))
        if len(self.truth) > 20000:
            for k in sorted(self.truth)[:5000]:
                del self.truth[k]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--duration', type=float, default=30.0)
    ap.add_argument('--report', default='')
    ap.add_argument('--truth', action='store_true', help='/sim/ground_truth_pose 대비 정밀도')
    ap.add_argument('--warmup', type=float, default=2.0)
    a, _ = ap.parse_known_args()
    rclpy.init()
    n = Monitor(a.truth)
    end = time.monotonic() + a.duration + a.warmup
    while time.monotonic() < end and rclpy.ok():
        rclpy.spin_once(n, timeout_sec=0.05)
    rx = [r for r in n.rx if r[0] >= a.warmup]
    lines = ['# alignment_kpi_monitor 보고서', '',
             f'계측 {a.duration:.0f} s (워밍업 {a.warmup:.0f} s 제외), 수신 {len(rx)} 건', '']
    if len(rx) > 2:
        span = rx[-1][0] - rx[0][0]
        iv = [(rx[i][0] - rx[i - 1][0]) * 1e3 for i in range(1, len(rx))]
        siv = [(rx[i][1] - rx[i - 1][1]) * 1e-6 for i in range(1, len(rx))]
        expected = span * 100.0
        drop = max(0.0, 1 - (len(rx) - 1) / expected) * 100 if expected > 0 else 0
        gaps = sum(1 for g in siv if g > 15.0)
        lines += ['| 항목 | 결과 |', '|---|---|',
                  f'| KPI 1 발행 주기 | {(len(rx) - 1) / span:.2f} Hz (100 Hz 기준 드롭 {drop:.2f} %) |',
                  f'| 수신 간격 | p50 {pct(iv, 50):.2f} / p99 {pct(iv, 99):.2f} / max {max(iv):.2f} ms |',
                  f'| stamp 간격 > 15 ms (포즈 결손 반영) | {gaps} 회, stamp 역순 {sum(1 for g in siv if g <= 0)} |']
    d = [x[1] for x in n.diag if x[0] >= a.warmup]
    if d:
        ct = [x.compute_time_us for x in d if not x.pose_lost]
        cb = [x.callback_time_us for x in d if not x.pose_lost]
        age = [x.pose_age_ms for x in d if not x.pose_lost]
        lines += [f'| KPI 2 엔진 연산 | p50 {pct(ct, 50):.1f} / p99 {pct(ct, 99):.1f} / max {max(ct):.1f} µs |',
                  f'| 콜백(수신→발행) | p50 {pct(cb, 50):.1f} / p99 {pct(cb, 99):.1f} / max {max(cb):.1f} µs |',
                  f'| 포즈 stamp→발행 | p50 {pct(age, 50):.2f} / p99 {pct(age, 99):.2f} / max {max(age):.2f} ms |']
        last = d[-1]
        lines += [f'| 카운터 | poses {last.poses}, 기각 {last.poses_rejected}, 포즈상실 {last.pose_timeouts}, '
                  f'위험 {last.danger_events}, 보류 {last.hold_events}, 로드셀이상 {last.loadcell_faults}, '
                  f'상위인터록 {last.upstream_interlocks} |']
    if a.truth and rx:
        ey, eyaw = [], []
        for _, st, m in rx:
            t = n.truth.get(st)
            if t is None:
                continue
            ey.append((m.y_error - t[0]) * 1e3)
            eyaw.append(m.yaw_error - math.degrees(t[1]))
        if ey:
            rms = math.sqrt(statistics.fmean([e * e for e in ey]))
            rmsy = math.sqrt(statistics.fmean([e * e for e in eyaw]))
            lines += [f'| KPI 3 횡편차 vs 참값 | RMSE {rms:.3f} / max {max(map(abs, ey)):.3f} mm ({len(ey)} 쌍) |',
                      f'| KPI 4 방위각 vs 참값 | RMSE {rmsy:.4f} / max {max(map(abs, eyaw)):.4f}° |']
    if rx:
        codes = [m.safety_status_code for _, _, m in rx]
        al = next((t for t, _, m in rx if m.is_aligned), None)
        lines += [f'| 안전 단계 분포 | 정상 {codes.count(0)}, 경고 {codes.count(1)}, 위험 {codes.count(2)} |',
                  f'| 정렬 완료 첫 수신 | {"-" if al is None else f"{al:.2f} s"} |']
    # KPI 6: 위험 상태 첫 출력 → 인터록 true 수신
    resp = []
    prev = 0
    for t, _, m in rx:
        if m.safety_status_code == 2 and prev != 2:
            hit = next((ti for ti, v in n.interlock if v and ti >= t - 0.05), None)
            if hit is not None:
                resp.append(max(0.0, (hit - t) * 1e3))
        prev = m.safety_status_code
    if resp:
        lines += [f'| KPI 6 위험 출력 → 인터록 토픽 | {len(resp)} 회, max {max(resp):.2f} ms (같은 콜백 발행, 모니터 수신 순서 기준) |']
    lines += ['', '## 경보', '']
    lines += [f'- {t:.3f} s `{s}`' for t, s in n.alerts] or ['- (없음)']
    out = '\n'.join(lines) + '\n'
    print(out)
    if a.report:
        with open(a.report, 'w') as f:
            f.write(out)
    n.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
