// trajectory_analysis_node — [모듈 4] INHAUL 궤적분석 ROS2 LifecycleNode (component)
//
//  구독  /sub_pose_filtered               nav_msgs/Odometry           (모듈 3, ≥100 Hz)  → 처리·발행 트리거
//        /winch_tension_raw               inhaul_msgs/WinchTensionArray (윈치 제어반, 100 Hz)
//        /sensor_fusion/safety_interlock  std_msgs/Bool (transient_local, 모듈 3)
//  발행  /inhaul/alignment_status         inhaul_msgs/AlignmentStatus  (포즈 수신마다, 포즈 상실 중 100 Hz 지령 0)
//        /inhaul/trajectory_diagnostics   inhaul_msgs/TrajectoryDiagnostics
//        /inhaul/safety_interlock         std_msgs/Bool (transient_local, 전이 시 + 10 Hz 하트비트)
//        /hmi/trajectory_alerts           std_msgs/String "코드|정보"
//  워치독 타이머 2 ms: 포즈 공백 > pose_timeout(20 ms) → ALARM_POSE_LOST, 지령 0.
#pragma once

#include <atomic>
#include <memory>
#include <string>

#include <inhaul_msgs/msg/alignment_status.hpp>
#include <inhaul_msgs/msg/trajectory_diagnostics.hpp>
#include <inhaul_msgs/msg/winch_tension_array.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <rclcpp_lifecycle/lifecycle_publisher.hpp>
#include <std_msgs/msg/bool.hpp>
#include <std_msgs/msg/string.hpp>

#include "pkg_inhaul_trajectory/trajectory_analysis_engine.hpp"

namespace pit {

class TrajectoryAnalysisNode : public rclcpp_lifecycle::LifecycleNode {
 public:
  using CallbackReturn = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn;
  explicit TrajectoryAnalysisNode(const rclcpp::NodeOptions& options = rclcpp::NodeOptions());
  ~TrajectoryAnalysisNode() override;

  CallbackReturn on_configure(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_activate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_deactivate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_cleanup(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_shutdown(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_error(const rclcpp_lifecycle::State&) override;

 private:
  void onPose(const nav_msgs::msg::Odometry::SharedPtr msg);
  void onTension(const inhaul_msgs::msg::WinchTensionArray::SharedPtr msg);
  void onUpstreamInterlock(const std_msgs::msg::Bool::SharedPtr msg);
  void onWatchdog();
  void onHeartbeat();
  void publish(const AlignmentOutput& o, const rclcpp::Time& stamp, int64_t cb_start_ns);
  void publishInterlock(bool active, bool force);
  void flushAlerts();
  static int64_t steadyNs();

  TrajectoryAnalysisEngine engine_;
  TrajectoryConfig cfg_;
  std::string config_file_;
  bool twist_in_child_ = true;
  bool active_ = false;
  bool frame_warned_ = false;
  int64_t last_tension_rx_ = 0;
  int64_t last_lost_pub_ = 0;
  double lost_publish_period_s_ = 0.01;
  int diag_every_n_ = 1;
  uint64_t out_count_ = 0;
  bool last_interlock_ = true;
  bool interlock_published_ = false;
  bool sd_watchdog_ = false;

  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr pose_sub_;
  rclcpp::Subscription<inhaul_msgs::msg::WinchTensionArray>::SharedPtr tension_sub_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr upstream_sub_;
  rclcpp_lifecycle::LifecyclePublisher<inhaul_msgs::msg::AlignmentStatus>::SharedPtr status_pub_;
  rclcpp_lifecycle::LifecyclePublisher<inhaul_msgs::msg::TrajectoryDiagnostics>::SharedPtr diag_pub_;
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::Bool>::SharedPtr interlock_pub_;
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::String>::SharedPtr alert_pub_;
  rclcpp::TimerBase::SharedPtr watchdog_timer_, heartbeat_timer_, autostart_timer_;
};

}  // namespace pit
