// pkg_inhaul_trajectory — [모듈 4] INHAUL 궤적분석 SW 모듈
// 공용 타입·단위·좌표 규약 (ROS 비의존)
//
// 좌표 규약
//  - 월드 = dock_world_frame (Z-up, 모듈 3 과 동일). 중심선은 XY 평면의 폴리라인.
//  - 중심선 접선 t = 인하울 진행 방향(시작점→종점), 법선 n = Z × t (진행방향 기준 좌측 = +).
//    → y_error 부호 "좌: +, 우: -" (설계서 5장).
//  - yaw: ZYX 오일러의 Z 회전, 반시계(+). yaw_error = wrap(ψ_sub − ψ_ref) ∈ (−π, π].
//  - 가상 모멘트 Mz: +Z(반시계, 선수 좌회전) 방향이 +. 단위 kN·m.
//  - 장력: kN. 속도: 내부 SI(m/s), 메시지 출력만 m/min.
//  - 시각: int64 ns. 수신시각(타임아웃 감시)은 steady clock, stamp 는 PTP 공통시계(모듈 3 출력 그대로).
#pragma once

#include <Eigen/Core>
#include <Eigen/Geometry>
#include <array>
#include <cmath>
#include <cstdint>
#include <string>

namespace pit {

using Vec2 = Eigen::Vector2d;
using Vec3 = Eigen::Vector3d;
using Quat = Eigen::Quaterniond;
using Mat3 = Eigen::Matrix3d;

constexpr double kPi = 3.14159265358979323846;
constexpr double kDeg2Rad = kPi / 180.0;
constexpr double kRad2Deg = 180.0 / kPi;
constexpr double kMps2Mpm = 60.0;   // m/s → m/min
constexpr int64_t kNsPerSec = 1'000'000'000LL;
constexpr int kNumWinch = 4;        // W1 함수좌, W2 함수우, W3 함미좌, W4 함미우

inline double nsToSec(int64_t ns) { return static_cast<double>(ns) * 1e-9; }
inline int64_t secToNs(double s) { return static_cast<int64_t>(std::llround(s * 1e9)); }

/// (−π, π] 로 정규화
inline double wrapPi(double a) {
  a = std::fmod(a + kPi, 2.0 * kPi);
  if (a <= 0.0) a += 2.0 * kPi;
  return a - kPi;
}

/// ZYX 오일러의 yaw (선수 축 벡터의 XY 투영 방위각과 같음)
inline double yawFromQuat(const Quat& q) {
  const Quat n = q.normalized();
  return std::atan2(2.0 * (n.w() * n.z() + n.x() * n.y()),
                    1.0 - 2.0 * (n.y() * n.y() + n.z() * n.z()));
}

/// /sub_pose_filtered (nav_msgs/Odometry) 의 필요한 부분
struct PoseInput {
  int64_t stamp_ns = 0;       // header.stamp (PTP)
  Vec3 p = Vec3::Zero();      // dock_world_frame 위치 [m]
  Quat q = Quat::Identity();  // R_W←B
  Vec3 v = Vec3::Zero();      // 선속도 [m/s]  (twist_frame 에 따라 선체/월드 좌표)
  Vec3 w = Vec3::Zero();      // 각속도 [rad/s]
  bool twist_valid = true;
  bool twist_in_child_frame = true;  // nav_msgs 규약 = child(선체) 좌표 (모듈 3 I3)
};

/// /winch_tension_raw (inhaul_msgs/WinchTensionArray)
struct TensionInput {
  int64_t stamp_ns = 0;
  std::array<double, kNumWinch> tension_kn{{0, 0, 0, 0}};
  std::array<uint8_t, kNumWinch> hw_status{{0, 0, 0, 0}};  // 0 = 정상 (제어반 보고)
};

enum class SafetyLevel : uint8_t { kNormal = 0, kWarning = 1, kDanger = 2 };

enum class FeedbackMode : uint8_t {
  kFull = 0,       // 자세 편차 + 장력 불균형
  kPoseOnly = 1,   // 로드셀 이상 → 비전/EKF 자세 편차 단독
};

enum class TensionCause : uint8_t {
  kUnknown = 0,          // 판정 불가(데이터 부족·POSE_ONLY)
  kBalanced = 1,         // 불감대 이내
  kExternalForce = 2,    // 외력(조류·바람)에 의한 선체 쏠림 — 와이어가 저항(음의 일)
  kWinchMismatch = 3,    // 윈치 권취 속도 오차 — 와이어가 선체를 끌어당김(양의 일)
};

enum class ChannelFault : uint8_t {
  kOk = 0,
  kInvalid = 1,     // NaN/Inf
  kOverrange = 2,   // 상한 초과
  kDropout = 3,     // 급격한 0 (단선)
  kSpike = 4,       // 샘플 간 급변 노이즈
  kFrozen = 5,      // 값 고착
  kHwStatus = 6,    // 제어반 상태코드 이상
  kStale = 7,       // 토픽 타임아웃
  kRecovering = 8,  // 정상값 복귀 후 재편입 대기
};

inline const char* toString(TensionCause c) {
  switch (c) {
    case TensionCause::kBalanced: return "BALANCED";
    case TensionCause::kExternalForce: return "EXTERNAL_FORCE";
    case TensionCause::kWinchMismatch: return "WINCH_MISMATCH";
    default: return "UNKNOWN";
  }
}

inline const char* toString(ChannelFault f) {
  switch (f) {
    case ChannelFault::kOk: return "OK";
    case ChannelFault::kInvalid: return "INVALID";
    case ChannelFault::kOverrange: return "OVERRANGE";
    case ChannelFault::kDropout: return "DROPOUT";
    case ChannelFault::kSpike: return "SPIKE";
    case ChannelFault::kFrozen: return "FROZEN";
    case ChannelFault::kHwStatus: return "HW_STATUS";
    case ChannelFault::kStale: return "STALE";
    case ChannelFault::kRecovering: return "RECOVERING";
  }
  return "?";
}

/// HMI 경보 (/hmi/trajectory_alerts, "코드|정보" — 모듈 3 /hmi/fusion_alerts 와 같은 형식)
struct Alert {
  std::string code;
  std::string info;
};

}  // namespace pit
