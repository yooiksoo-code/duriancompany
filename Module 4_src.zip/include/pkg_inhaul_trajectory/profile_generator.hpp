// [세부 3] S-Curve 속도 프로파일 및 가상 모멘트 생성기 (ProfileGenerator)
//
// 감속 기준곡선 V_ref(X_remain):
//   v_max 에서 저크 제한(j_max)·감속 제한(a_max) 3구간 정지 궤적(−j → −a 유지 → +j)을 시간영역으로 적분해
//   (잔여거리, 속도) 표를 만들고, 잔여거리로 보간. 이 곡선을 그대로 추종하면 가속도·저크가 한계 내.
//   V_target = min(v_max·scale, V_ref(X_remain)),  X_remain ≤ stop_tol → 0,  그 사이 최소 v_creep.
// 시간영역 저크 제한기 (2차): 출발·감속 오버라이드·복귀 등 목표의 불연속만 완화.
//   목표가 한계 내에서 매끄럽게 변하면(감속곡선 추종) 목표 미분을 앞먹임하여 지연 없이 추종.
// 가상 모멘트: M_z = sat(−(Kp,y·Yerr + Kd,y·Ẏerr + Kp,ψ·Yaw + Kd,ψ·Ẏaw), ±Mz_max)
// [제안] 횡력:  F_y = sat(−(Kp·Yerr + Ki·∫Yerr + Kd·Ẏerr), ±F_max)  (적분 와인드업 방지: 포화 시 적분 정지)
#pragma once

#include <vector>

#include "pkg_inhaul_trajectory/trajectory_config.hpp"

namespace pit {

class SCurveProfile {
 public:
  void build(const ProfileConfig& c);
  /// 감속 기준곡선 [m/s] (X_remain ≥ 감속거리 → v_max)
  double referenceSpeed(double x_remain) const;
  double decelDistance() const { return decel_dist_; }
  double vMax() const { return v_max_; }
  /// 기준곡선 위에서의 가속도 a(X) = −V·dV/dX [m/s²] (앞먹임·KPI 비교용)
  double referenceAccel(double x_remain) const;

 private:
  std::vector<double> d_;  // 잔여거리 (오름차순)
  std::vector<double> v_;
  double v_max_ = 0.0, decel_dist_ = 0.0;
};

class JerkLimitedTracker {
 public:
  void reset(double v = 0.0) { v_ = v; a_ = 0.0; have_prev_target_ = false; }
  double update(double target, double dt, double a_lim, double j_lim);
  double value() const { return v_; }
  double accel() const { return a_; }

 private:
  double v_ = 0.0, a_ = 0.0;
  double prev_target_ = 0.0;
  bool have_prev_target_ = false;
};

struct ProfileOutput {
  double v_ref = 0.0;      // 감속 기준곡선 V_ref(X_remain) [m/s]
  double v_target = 0.0;   // 배율·크리프·정지 반영 목표 [m/s]
  double v_cmd = 0.0;      // 저크 제한 후 지령 [m/s]
  double mz_cmd = 0.0;     // kN·m
  bool mz_saturated = false;
  double fy_cmd = 0.0;     // kN [제안]
};

class ProfileGenerator {
 public:
  void configure(const ProfileConfig& p, const MomentConfig& m);
  void reset();
  /// speed_scale ∈ [0,1] (안전 판정 결과), hard_stop: 즉시 0 (위험·포즈 상실·상위 인터록)
  ProfileOutput update(double dt, double x_remain, double y_err, double y_rate, double yaw_err,
                       double yaw_rate, double speed_scale, bool hard_stop, bool zero_moment);
  const SCurveProfile& profile() const { return prof_; }

 private:
  ProfileConfig pc_;
  MomentConfig mc_;
  SCurveProfile prof_;
  JerkLimitedTracker trk_;
  double fy_int_ = 0.0;    // ∫Yerr dt
};

}  // namespace pit
