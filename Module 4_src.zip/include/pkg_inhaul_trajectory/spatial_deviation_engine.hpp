// [세부 1] 공간 기하 편차 계산 엔진 (SpatialDeviationEngine)
//  도크 중심 안착 기준선 L_ref(폴리라인) 와 선체 기준점 P_sub, 방위각 ψ 비교.
//   X_remain = s_target − s(P_sub)      (중심선 호길이 기준. 직선·x축 정렬이면 X_target − x 와 동일)
//   Y_err    = (P_sub − P_ref(s))·n      (n = 진행방향 좌측 법선, 좌 +)
//   Yaw_err  = wrap(ψ_sub − ψ_ref(s))
//   Z_err    = z − z_ref
//  미분항: EKF twist 를 월드로 회전해 중심선 법선/Z 로 투영 (수치미분 잡음 없음).
#pragma once

#include <vector>

#include "pkg_inhaul_trajectory/trajectory_config.hpp"
#include "pkg_inhaul_trajectory/types.hpp"

namespace pit {

struct Projection {
  double s = 0.0;        // 시작점부터 호길이 [m] (시작 이전·종점 이후는 끝 구간 연장선 기준)
  double lateral = 0.0;  // 좌측 + [m]
  int segment = 0;
  Vec2 tangent = Vec2::UnitX();
  Vec2 normal = Vec2::UnitY();
  double heading = 0.0;  // ψ_ref [rad]
};

class DockCenterline {
 public:
  /// 점 2개 이상, 연속 중복점 없음. 실패 시 false + err.
  bool build(const std::vector<Vec2>& pts, std::string* err = nullptr);
  Projection project(const Vec2& p) const;
  double length() const { return cum_.empty() ? 0.0 : cum_.back(); }
  /// 중심선 위로 투영한 호길이 (목표점 지정용)
  double arcLengthOf(const Vec2& p) const { return project(p).s; }
  Vec2 pointAt(double s) const;
  size_t numSegments() const { return pts_.size() < 2 ? 0 : pts_.size() - 1; }

 private:
  std::vector<Vec2> pts_;
  std::vector<double> cum_;   // 각 점까지 누적 호길이
  std::vector<Vec2> tan_;     // 구간 단위 접선
};

struct DeviationState {
  double x_remain = 0.0;
  double y_error = 0.0;
  double yaw_error = 0.0;     // rad
  double z_error = 0.0;
  double y_error_rate = 0.0;  // m/s  (좌 + 방향으로 증가율)
  double yaw_error_rate = 0.0;// rad/s
  double along_speed = 0.0;   // 중심선 접선 방향 속도 [m/s]
  double s = 0.0;
  int segment = 0;
  double bow_lateral = 0.0;   // 선수 끝 횡변위 = Yerr + L_bow·sin(Yaw)
  double stern_lateral = 0.0; // 선미 끝 횡변위 = Yerr − L_stern·sin(Yaw)
  bool rate_valid = false;
};

class SpatialDeviationEngine {
 public:
  bool configure(const DockConfig& dock, const MomentConfig& moment, std::string* err = nullptr);
  void reset();
  DeviationState compute(const PoseInput& pose);
  const DockCenterline& centerline() const { return line_; }
  double targetArcLength() const { return s_target_; }

 private:
  DockCenterline line_;
  DockConfig dock_;
  MomentConfig mcfg_;
  double s_target_ = 0.0;
  // 수치미분 대체 경로 (use_twist=false 또는 twist 무효)
  bool have_prev_ = false;
  int64_t prev_stamp_ = 0;
  double prev_y_ = 0.0, prev_yaw_ = 0.0, f_ydot_ = 0.0, f_yawdot_ = 0.0;
};

}  // namespace pit
