// [세부 2] 4점 장력 불균형 분석기 (TensionImbalanceAnalyzer)
//   ΔT_bow = T_W1 − T_W2,  ΔT_stern = T_W3 − T_W4   (W1 함수좌, W2 함수우, W3 함미좌, W4 함미우)
//
// 채널 감시 (설계서 6장 2): NaN·상한초과·급격한 0(단선)·급변 스파이크·고착·HW 상태 → 해당 채널 배제,
//   하나라도 배제되면 FeedbackMode::kPoseOnly (비전/EKF 자세 편차 단독 피드백) 로 절체.
//   정상값 recover_s 연속 유지 후 재편입.
//
// 원인 판정 (설계서 4장 2) — 4점 와이어를 스프링(강성 k, 횡성분 g)으로 보면 체결점 횡변위 y_att 에서
//   길이가 맞는 와이어의 장력차는 ΔT_spring = −2·k·g·y_att (변위를 되돌리는 방향)
//   (자체 M_z·F_y 지령이 만든 장력차는 배분식 + 1차 지연 모델로 먼저 뺌 — command_compensation)
//   배분: ΔT_bow = (M + l_s·F)/(g(l_b+l_s)), ΔT_stern = (l_b·F − M)/(g(l_b+l_s))
//   ▸ 길이 불일치 장력 m = ΔT_res − ΔT_spring = ΔT_res + 2kg·y_att  (= k·(δ_좌 − δ_우), 권취량 차)
//   ▸ 외력: 선체가 밀려 변위 → ΔT_res ≈ ΔT_spring (와이어가 버팀), m ≈ 0          → EXTERNAL_FORCE
//   ▸ 권취 속도 오차: 한쪽을 더 감아 선체가 끌려간 평형 → ΔT_res ≈ 0, |m| ≈ |ΔT_spring| → WINCH_MISMATCH
//     (ΔT 만 보면 0 이라 놓침 — 설계 검토 R5)
//   판정: max(|ΔT_res|, |m|) < 불감대 → BALANCED, |m| > |ΔT_res| → WINCH_MISMATCH, 아니면 EXTERNAL_FORCE
//   k ≤ 0(미교정)이면 모델 없이 와이어 일률 P = F·ẏ + M·ψ̇ (운동 중) / 복원일 S = F·Yerr + M·Yaw (정지) 부호로 판정.
// 차등 속도 보정 가중치 (윈치 연계 모듈 전달용, 진단 토픽):
//   WINCH_MISMATCH 일 때만 w_좌 = clamp(−k_w·m/2/T_ref), w_우 = −w_좌 (더 감긴 쪽 감속)
//   EXTERNAL_FORCE 는 장력 균등화를 하지 않음 (외력에 버티는 와이어를 풀면 쏠림이 커짐) → 자세 PD 로 복원.
#pragma once

#include <array>
#include <vector>

#include "pkg_inhaul_trajectory/trajectory_config.hpp"
#include "pkg_inhaul_trajectory/types.hpp"

namespace pit {

struct TensionState {
  bool data_valid = false;                 // 수신 이력 있고 타임아웃 아님
  FeedbackMode mode = FeedbackMode::kPoseOnly;
  std::array<bool, kNumWinch> channel_valid{{false, false, false, false}};
  std::array<ChannelFault, kNumWinch> fault{{ChannelFault::kStale, ChannelFault::kStale,
                                             ChannelFault::kStale, ChannelFault::kStale}};
  std::array<double, kNumWinch> tension_kn{{0, 0, 0, 0}};  // 마지막 수신값
  bool bow_valid = false, stern_valid = false;
  double delta_bow_kn = 0.0;    // 원시 (유효 쌍만, 무효 = 0)
  double delta_stern_kn = 0.0;
  double residual_bow_kn = 0.0; // LPF + 지령 보상 후 (판정용)
  double residual_stern_kn = 0.0;
  double mismatch_bow_kn = 0.0;    // 길이 불일치 장력 m (모델 기반)
  double mismatch_stern_kn = 0.0;
  double wire_force_y_kn = 0.0;
  double wire_moment_z_knm = 0.0;
  double wire_power = 0.0;      // kN·m/s
  TensionCause cause = TensionCause::kUnknown;
  std::array<double, kNumWinch> speed_weight{{0, 0, 0, 0}};
  int64_t last_rx_ns = 0;
};

class TensionImbalanceAnalyzer {
 public:
  void configure(const TensionConfig& cfg, double tension_timeout_s);
  void reset();
  /// 장력 수신 (rx = 수신 steady 시각)
  void onTension(int64_t rx_ns, const TensionInput& in);
  /// 매 자세 주기 호출: 타임아웃 감시, 지령 보상 모델 전파, 원인 판정
  const TensionState& update(int64_t now_ns, double dt, double y_err, double yaw_err,
                             double y_rate, double yaw_rate, double prev_mz_cmd_knm,
                             double prev_fy_cmd_kn = 0.0);
  const TensionState& state() const { return st_; }
  std::vector<Alert> takeAlerts();
  uint32_t faultEvents() const { return fault_events_; }

 private:
  struct Channel {
    bool have_prev = false;
    double prev = 0.0;
    int64_t last_change = 0;   // 값이 마지막으로 바뀐 수신 시각
    int64_t good_since = -1;   // 이상 후 정상 연속 시작 시각
    ChannelFault latched = ChannelFault::kOk;
    double last_good = 0.0;    // 정상 판정된 마지막 값 (단선 판정 기준)
    ChannelFault reported = ChannelFault::kOk;  // 경보 중복 억제
    bool ever_valid = false;   // 최초 편입 전에는 복귀 경보를 내지 않음
  };
  ChannelFault check(int i, int64_t rx_ns, double v, uint8_t hw, bool others_active);

  TensionConfig c_;
  double timeout_s_ = 0.05;
  TensionState st_;
  std::array<Channel, kNumWinch> ch_;
  bool have_rx_ = false;
  bool filt_init_ = false;
  double f_bow_ = 0.0, f_stern_ = 0.0;   // LPF ΔT
  double cmd_dt_bow_ = 0.0, cmd_dt_stern_ = 0.0;  // 지령 유발 장력차 모델 (1차 지연)
  TensionCause candidate_ = TensionCause::kUnknown;
  double candidate_time_ = 0.0;
  FeedbackMode prev_mode_ = FeedbackMode::kPoseOnly;
  bool mode_reported_ = false;
  std::vector<Alert> alerts_;
  uint32_t fault_events_ = 0;
};

}  // namespace pit
