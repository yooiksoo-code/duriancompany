// 궤적분석 엔진: 세부 1~4 를 묶는 ROS 비의존 파이프라인 (노드·벤치·시험 공용)
//
//  onPose(/sub_pose_filtered) ─┬─ SpatialDeviationEngine → X_remain, Y_err, Yaw_err, Z_err, 율
//                              ├─ TensionImbalanceAnalyzer.update (최근 장력, 직전 M_z 지령 보상)
//                              ├─ SafetyBoundaryChecker → 단계·속도배율·HOLD
//                              ├─ ProfileGenerator → V_cmd(S-Curve, 저크제한), M_z,cmd(PD)
//                              └─ 정렬 완료 판정(공차 + dwell) → AlignmentOutput
//  checkWatchdog(now): 포즈 수신 공백 > pose_timeout → ALARM_POSE_LOST, 지령 0 출력
//  상위(모듈 3) 인터록 true → 속도 0 (모듈 3 은 DR_EXPIRED 중에도 Odometry 를 계속 발행하므로 필수)
#pragma once

#include <optional>
#include <vector>

#include "pkg_inhaul_trajectory/profile_generator.hpp"
#include "pkg_inhaul_trajectory/safety_boundary_checker.hpp"
#include "pkg_inhaul_trajectory/spatial_deviation_engine.hpp"
#include "pkg_inhaul_trajectory/tension_imbalance_analyzer.hpp"
#include "pkg_inhaul_trajectory/trajectory_config.hpp"

namespace pit {

/// inhaul_msgs/AlignmentStatus 와 1:1 (단위 변환 포함) + 진단용 부가 정보
struct AlignmentOutput {
  int64_t stamp_ns = 0;
  // 1. 기하학적 편차
  double x_remain_m = 0.0;
  double y_error_m = 0.0;
  double yaw_error_deg = 0.0;
  double z_error_m = 0.0;
  // 2. 장력 불균형 (무효 쌍 = 0, 유효성은 진단)
  double delta_tension_bow_kn = 0.0;
  double delta_tension_stern_kn = 0.0;
  // 3. 속도·복원 명령
  double target_inhaul_speed_mpm = 0.0;
  double correction_moment_z_knm = 0.0;
  // 4. 상태
  uint8_t safety_status_code = 0;   // 0 정상, 1 경고(감속), 2 위험(정지)
  bool is_aligned = false;

  // ── 진단 (inhaul_msgs/TrajectoryDiagnostics) ──
  bool pose_lost = false;
  bool upstream_interlock = false;
  bool interlock = false;           // 하류 속도 지령 0 요구 (위험·포즈상실·상위 인터록)
  bool hold_override = false;
  double speed_scale = 1.0;
  double v_ref_mpm = 0.0;           // 감속 기준곡선
  double v_target_mpm = 0.0;
  double y_error_rate_mps = 0.0;
  double yaw_error_rate_dps = 0.0;
  double along_speed_mps = 0.0;
  double s_along_m = 0.0;
  int segment = 0;
  double lateral_metric_m = 0.0;
  bool mz_saturated = false;
  double correction_force_y_kn = 0.0;  // [제안] 횡력 지령
  TensionState tension;
  double compute_time_us = 0.0;
};

struct EngineCounters {
  uint64_t poses = 0;
  uint64_t poses_rejected = 0;
  uint64_t tensions = 0;
  uint32_t pose_timeouts = 0;
  uint32_t danger_events = 0;
  uint32_t hold_events = 0;
  uint32_t loadcell_faults = 0;
  uint32_t upstream_interlocks = 0;
};

class TrajectoryAnalysisEngine {
 public:
  bool configure(const TrajectoryConfig& cfg, std::string* err = nullptr);
  void reset();

  void onTension(int64_t rx_ns, const TensionInput& in);
  void onUpstreamInterlock(int64_t rx_ns, bool active);
  /// 포즈 1건 처리 → 출력. 역순/중복 stamp·NaN 은 nullopt.
  std::optional<AlignmentOutput> onPose(int64_t rx_ns, const PoseInput& pose);
  /// 주기 감시 (노드: 2 ms 타이머). 포즈 상실 중이면 지령 0 출력을 돌려줌.
  std::optional<AlignmentOutput> checkWatchdog(int64_t now_ns);

  bool poseLost() const { return pose_lost_; }
  bool initialized() const { return have_pose_; }
  const AlignmentOutput& last() const { return last_; }
  EngineCounters counters() const;
  std::vector<Alert> takeAlerts();
  const TrajectoryConfig& config() const { return cfg_; }
  const SpatialDeviationEngine& deviation() const { return dev_; }
  const ProfileGenerator& profile() const { return prof_; }

 private:
  AlignmentOutput zeroOutput(int64_t stamp_ns) const;

  TrajectoryConfig cfg_;
  SpatialDeviationEngine dev_;
  TensionImbalanceAnalyzer ten_;
  SafetyBoundaryChecker safe_;
  ProfileGenerator prof_;

  bool have_pose_ = false;
  bool pose_lost_ = false;
  int64_t last_pose_rx_ = 0;
  int64_t last_pose_stamp_ = 0;
  bool upstream_ = false;
  double prev_mz_ = 0.0, prev_fy_ = 0.0;
  double aligned_timer_ = 0.0;
  bool aligned_ = false;
  bool nan_reported_ = false;
  bool was_interlock_ = false;
  bool was_hold_ = false;
  AlignmentOutput last_;
  EngineCounters cnt_;
  std::vector<Alert> alerts_;
};

/// YAML-CPP 로더 (config/dock_trajectory_profile.yaml). 없는 키는 기본값 유지.
bool loadTrajectoryConfig(const std::string& path, TrajectoryConfig* cfg, std::string* err);

}  // namespace pit
