// 모든 기본값의 단일 출처. config/dock_trajectory_profile.yaml 은 이 구조체를 덮어씁니다.
// ★ 표시는 테스트베드 합성 모델 기준 초기값 — 실장비 시험으로 교체해야 하는 값.
#pragma once

#include <string>
#include <vector>

#include "pkg_inhaul_trajectory/types.hpp"

namespace pit {

struct DockConfig {
  std::string frame_id = "dock_world_frame";
  /// 도크 중심 안착 기준선 L_ref: 시작점 → 종점 폴리라인 (x, y) [m]. 2점 = 직선.
  std::vector<Vec2> centerline{Vec2(0.0, 0.0), Vec2(2.4, 0.0)};
  /// 안착 목표 종점 (중심선 위로 투영). 미지정(empty) = 중심선 마지막 점.
  bool has_target = false;
  Vec2 target = Vec2(2.4, 0.0);
  double z_ref_m = 0.0;              // 목표 흘수/부력 기준 높이 (z_error = z − z_ref)
  double bow_length_m = 1.2;         // ★ 기준점 → 선수 끝 (안전 펜스 선단 검사용)
  double stern_length_m = 1.2;       // ★ 기준점 → 선미 끝
};

struct ToleranceConfig {
  double x_remain_m = 0.005;         // 안착 종점 허용 공차
  double y_error_m = 0.010;
  double yaw_error_deg = 0.30;
  double dwell_s = 0.5;              // 공차 내 연속 유지 시간 → is_aligned
  double release_factor = 1.5;       // 정렬 완료 해제 = 공차 × 이 값 초과
};

struct ProfileConfig {
  double v_max_mpm = 6.0;            // ★ 최대 인하울 속도 [m/min]
  double a_max_mps2 = 0.015;         // ★ 최대 감속도
  double j_max_mps3 = 0.008;         // ★ 최대 저크
  double v_creep_mpm = 0.3;          // 종점 직전 최소 접근 속도 (0 이면 비활성)
  double stop_tolerance_m = 0.002;   // X_remain ≤ 이 값 → 속도 지령 0
  // 시간영역 저크 제한기 (지령 불연속: 출발·감속 오버라이드·복귀). 프로파일 한계 × 배율.
  double limiter_accel_factor = 3.0;
  double limiter_jerk_factor = 3.0;
  double table_resolution_s = 0.002; // 감속 기준곡선 표 생성 시간 간격
};

struct SafetyConfig {
  // 설계서 4장 4): |Yerr| > 50 mm 감속 경고, > 100 mm 인터록
  double y_warn_m = 0.050;
  double y_danger_m = 0.100;
  double yaw_warn_deg = 2.5;         // ★ 설계서 미정 [결정 필요]
  double yaw_danger_deg = 5.0;       // ★ 설계서 미정 [결정 필요]
  double hysteresis_y_m = 0.005;     // 단계 해제 히스테리시스
  double hysteresis_yaw_deg = 0.25;
  double warn_min_speed_scale = 0.3; // 경고 구간 속도 배율: warn 에서 1.0 → danger 직전 이 값 (선형)
  bool check_extremities = false;    // true: 선수·선미 끝단 횡변위(Yerr ± L·sinψ)로도 펜스 판정 (권장안)
  bool danger_zero_moment = false;   // true: 위험 단계에서 복원 모멘트도 0 [결정 필요]
  double overshoot_m = 0.02;         // X_remain < −이 값 → 위험(종점 초과)

  // 설계서 6장 1) 급격한 편차 → 전진 보류 (Ramp-down Override)
  double override_y_rate_mps = 0.015;   // 편차가 커지는 방향 |dYerr/dt| 임계
  double override_yaw_rate_dps = 0.5;   // 편차가 커지는 방향 |dYaw/dt| 임계
  double override_min_y_m = 0.010;      // 이 편차 미만에서는 율이 커도 보류하지 않음 (중심선 통과 시 오작동 방지)
  double override_min_yaw_deg = 0.5;
  double override_hold_scale = 0.05;    // 보류 중 속도 배율 ("0 에 가깝게")
  double override_release_s = 1.0;      // 율 < 임계/2 (위험 아님) 연속 유지 → 해제

  // 설계서 6장 3) 위치 데이터 타임아웃
  double pose_timeout_s = 0.020;
  double tension_timeout_s = 0.050;     // 장력 토픽 전체 타임아웃 → POSE_ONLY
  bool honor_upstream_interlock = true; // 모듈 3 /sensor_fusion/safety_interlock true → 속도 0
};

struct MomentConfig {
  // M_z,cmd = −(Kp,y·Yerr + Kd,y·dYerr + Kp,ψ·Yaw + Kd,ψ·dYaw)  (부호: 편차 반대 방향 복원)
  double kp_y = 2.0;     // ★ kN·m / m
  double kd_y = 2.5;     // ★ kN·m / (m/s)
  double kp_yaw = 0.8;   // ★ kN·m / rad
  double kd_yaw = 0.45;  // ★ kN·m / (rad/s)
  double mz_max_knm = 0.6;          // ★ 포화
  // [제안] 횡력 지령 F_y,cmd = sat(−(Kp·Yerr + Ki·∫Yerr + Kd·dYerr), ±F_max)
  //   요 모멘트만으로는 정상(定常) 횡외력(조류)을 상쇄할 수 없어 추가. AlignmentStatus 에는 없고
  //   진단 토픽(correction_force_y)으로만 발행 — 윈치 연계 모듈 채택 여부 [결정 필요].
  double kp_fy = 6.0;    // ★ kN / m
  double ki_fy = 3.0;    // ★ kN / (m·s)
  double kd_fy = 2.0;    // ★ kN / (m/s)
  double fy_max_kn = 0.4;
  bool use_twist = true;            // 미분항 = EKF 속도(권장). false: 편차 수치미분 + LPF
  double derivative_lpf_tau_s = 0.05;  // use_twist=false 일 때
};

struct TensionConfig {
  double overrange_kn = 12.0;       // ★ 로드셀 정격 × 1.2
  double zero_kn = 0.02;            // 이 값 미만 = "0"
  double dropout_ref_kn = 0.20;     // 마지막 정상값이 이 이상인데 0 으로 떨어지면 단선
  double negative_kn = -0.5;        // 이 값 미만(물리적으로 불가) = INVALID
  double max_step_kn = 2.0;         // 샘플 간 변화 상한 (100 Hz 기준)
  double frozen_s = 1.0;            // 값 완전 고착 지속 (0 = 비활성)
  double recover_s = 1.0;           // 정상값 연속 유지 후 재편입
  double lpf_tau_s = 0.2;           // ΔT 판정용 저역통과
  double balance_deadband_kn = 0.03;
  // 와이어 기하 (원인 판정·지령 보상): 횡력 F_y = g·(ΔT_bow + ΔT_stern),
  //   모멘트 M_z = g·(l_bow·ΔT_bow − l_stern·ΔT_stern), g = 와이어 횡방향 성분(sinθ)
  double wire_lateral_gain = 0.5;   // ★ sin 30°
  double bow_lever_m = 1.2;         // ★ 함수 와이어 체결점 x
  double stern_lever_m = 1.2;       // ★ 함미 와이어 체결점 |x|
  // 와이어 등가 강성 (로드셀 포함). > 0 이면 모델 기반 원인 판정, ≤ 0 이면 일률/복원일 부호 판정.
  double wire_stiffness_kn_per_m = 2.0;  // ★ 테스트베드 교정 시험으로 산출
  double motion_v_th_mps = 0.002;   // (일률 판정) 운동 판정 임계
  double motion_r_th_dps = 0.05;
  double cause_persist_s = 0.3;     // 원인 전환 지속시간
  bool command_compensation = true; // 자체 M_z 지령이 만든 장력차를 원인 판정에서 제외
  double actuator_tau_s = 0.2;      // ★ 윈치 연계 모듈의 M_z → 장력차 응답 시정수
  bool force_y_applied = false;     // 윈치 연계 모듈이 [제안] F_y 지령도 실행하는지 (보상 모델 일치용)
  double weight_gain = 5.0;         // ★ 차등 속도 보정 가중치 w_좌 = −gain·m/2/T_ref (m = 길이 불일치 장력)
  double weight_ref_kn = 1.0;
  double weight_max = 0.2;
};

struct TrajectoryConfig {
  DockConfig dock;
  ToleranceConfig tolerance;
  ProfileConfig profile;
  SafetyConfig safety;
  MomentConfig moment;
  TensionConfig tension;
};

}  // namespace pit
