// Physical Twin 레일 테스트베드 합성 모델 (시험·벤치·합성 발행기 공용, ROS 비의존)
//
//  선체(축소모형) 평면 운동 + 4점 와이어(스프링) + 윈치 연계 모듈 [모듈 5] 에뮬레이터:
//    ẋ = v_x,  v̇_x = (V_cmd − v_x)/τ_w                      (윈치 권취 속도 루프)
//    ẏ = v_x·sinψ + v_s,  m·v̇_s = F_wire,y + F_ext − c_s·v_s
//    ψ̇ = r,              I·ṙ   = M_wire + M_ext − c_r·r
//    T_i = T0 + k·(−σ_i·g·y_i + δ_i) + (지령 장력차 배분),  σ = +1 좌(W1,W3) / −1 우(W2,W4)
//    y_bow = y + l_b·sinψ, y_stern = y − l_s·sinψ
//    δ̇_i = 권취 속도 오차(시나리오) + w_i·V_cmd (모듈 4 차등 속도 보정 가중치 적용 시)
//    (M_z, F_y) 지령 → 장력차 배분식을 1차 지연 τ_a 로 실현 (가상 모멘트의 물리 구현, F_y 는 [제안] 옵션)
//  센서: 포즈(EKF 출력 수준 잡음, 롤·피치 부유 운동 포함, 선체좌표 twist) 100 Hz, 로드셀 100 Hz.
//  모든 참값(truth*)은 같은 시각의 무잡음 상태.
#pragma once

#include <array>
#include <functional>
#include <limits>
#include <random>
#include <vector>

#include "pkg_inhaul_trajectory/trajectory_analysis_engine.hpp"
#include "pkg_inhaul_trajectory/types.hpp"

namespace pit::sim {

struct HullParams {
  double mass_kg = 200.0;
  double inertia_kgm2 = 150.0;
  double sway_damping = 885.0;    // N·s/m  (와이어 횡강성 2 kN/m 과 ζ≈0.7)
  double yaw_damping = 920.0;     // N·m·s/rad
  double wire_k_kn_per_m = 2.0;   // 와이어 1본 등가 강성
  double pretension_kn = 1.0;
  double g = 0.5;                 // 와이어 횡성분 sinθ
  double bow_lever = 1.2, stern_lever = 1.2;
  double winch_tau = 0.25;        // 권취 속도 루프 시정수
  double actuator_tau = 0.2;      // M_z → 장력차
  double roll_amp_deg = 0.4, pitch_amp_deg = 0.25, heave_amp_m = 0.002;  // 부유 미소운동
};

struct NoiseParams {
  double pos_xy = 0.15e-3, pos_z = 0.40e-3;    // m (모듈 3 위치 RMSE 수준)
  double yaw_deg = 0.003;
  double vel = 0.5e-3;                          // m/s
  double rate_dps = 0.02;
  double tension_kn = 0.005;
};

struct LoadcellFault {
  int ch = 0;           // 0..3
  double t0 = 0, t1 = 0;
  enum Kind { kZero, kSpike, kOverrange, kFrozen, kNaN } kind = kZero;
};

struct Scenario {
  std::string name = "T0";
  double duration_s = 60.0;
  double x0 = 0.0, y0 = 0.0, yaw0_deg = 0.0;
  // 외력: F_ext,y(t) [N], M_ext(t) [N·m]
  std::function<double(double)> f_ext = nullptr;
  std::function<double(double)> m_ext = nullptr;
  // 권취 속도 오차: winch i 가 V_cmd·(1+ratio) 로 감음 (t ≥ t0)
  std::array<double, kNumWinch> winch_speed_error{{0, 0, 0, 0}};
  double winch_error_t0 = 0.0;
  bool apply_speed_weights = false;   // 모듈 4 가중치를 에뮬레이터가 적용
  bool apply_lateral_force = false;   // [제안] F_y 지령을 에뮬레이터가 적용 (기본: 설계서대로 M_z 만)
  std::vector<LoadcellFault> loadcell_faults;
  std::vector<std::pair<double, double>> pose_blackouts;
  std::vector<std::pair<double, double>> tension_blackouts;
  bool upstream_interlock_pulse = false;  // 모듈 3 인터록 펄스 주입
  double upstream_t0 = 0, upstream_t1 = 0;
  bool noise = true;
  uint32_t seed = 7;
  double pose_rate_hz = 100.0, tension_rate_hz = 100.0;
  double pose_latency_s = 0.001;      // stamp → 수신
};

struct Truth {
  double t = 0, x = 0, y = 0, yaw = 0, vx = 0, vy_world = 0, r = 0, z = 0, roll = 0, pitch = 0;
  std::array<double, kNumWinch> tension{{0, 0, 0, 0}};
};

class TestbedSim {
 public:
  explicit TestbedSim(const HullParams& hp = {}, const NoiseParams& np = {}) : hp_(hp), np_(np) {}

  void reset(const Scenario& sc) {
    sc_ = sc;
    rng_.seed(sc.seed);
    t_ = 0.0;
    x_ = sc.x0; y_ = sc.y0; psi_ = sc.yaw0_deg * kDeg2Rad;
    vx_ = vs_ = r_ = 0.0;
    delta_.fill(0.0);
    ctrl_bow_ = ctrl_stern_ = 0.0;
    v_cmd_ = mz_cmd_ = fy_cmd_ = 0.0;
    weights_.fill(0.0);
    frozen_.fill(0.0);
    updateTension();
  }

  /// 제어 입력 (모듈 4 출력 → 모듈 5 에뮬레이터)
  void setCommand(double v_cmd_mps, double mz_knm, double fy_kn,
                  const std::array<double, kNumWinch>& w) {
    v_cmd_ = std::max(0.0, v_cmd_mps);
    mz_cmd_ = mz_knm;
    fy_cmd_ = sc_.apply_lateral_force ? fy_kn : 0.0;
    weights_ = w;
  }

  void step(double dt) {
    const HullParams& h = hp_;
    vx_ += (v_cmd_ - vx_) * dt / h.winch_tau;
    const double lever = h.bow_lever + h.stern_lever;
    // 모듈 5 배분: ΔT_bow = (M + l_s F)/(g(l_b+l_s)), ΔT_stern = (l_b F − M)/(g(l_b+l_s))
    ctrl_bow_ += ((mz_cmd_ + h.stern_lever * fy_cmd_) / (h.g * lever) - ctrl_bow_) * dt / h.actuator_tau;
    ctrl_stern_ += ((h.bow_lever * fy_cmd_ - mz_cmd_) / (h.g * lever) - ctrl_stern_) * dt / h.actuator_tau;
    for (int i = 0; i < kNumWinch; ++i) {
      double rate = 0.0;
      if (t_ >= sc_.winch_error_t0) rate += sc_.winch_speed_error[i] * vx_;
      if (sc_.apply_speed_weights) rate += weights_[i] * vx_;
      delta_[i] += rate * dt;
    }
    updateTension();
    const auto& T = tension_;
    const double fy = h.g * (T[0] - T[1] + T[2] - T[3]) * 1e3;                       // N
    const double mz = h.g * (h.bow_lever * (T[0] - T[1]) - h.stern_lever * (T[2] - T[3])) * 1e3;
    const double fext = sc_.f_ext ? sc_.f_ext(t_) : 0.0;
    const double mext = sc_.m_ext ? sc_.m_ext(t_) : 0.0;
    vs_ += (fy + fext - h.sway_damping * vs_) / h.mass_kg * dt;
    r_ += (mz + mext - h.yaw_damping * r_) / h.inertia_kgm2 * dt;
    x_ += vx_ * dt;
    y_ += (vx_ * std::sin(psi_) + vs_) * dt;
    psi_ += r_ * dt;
    t_ += dt;
  }

  Truth truth() const {
    Truth tr;
    tr.t = t_; tr.x = x_; tr.y = y_; tr.yaw = psi_; tr.vx = vx_;
    tr.vy_world = vx_ * std::sin(psi_) + vs_;
    tr.r = r_;
    tr.roll = hp_.roll_amp_deg * kDeg2Rad * std::sin(2 * kPi * 0.21 * t_);
    tr.pitch = hp_.pitch_amp_deg * kDeg2Rad * std::sin(2 * kPi * 0.13 * t_ + 0.7);
    tr.z = hp_.heave_amp_m * std::sin(2 * kPi * 0.17 * t_);
    tr.tension = tension_;
    return tr;
  }

  /// 기준선이 X 축(y=0)인 도크에서의 포즈 측정 (참값 + 잡음)
  PoseInput measurePose(bool with_noise) {
    const Truth tr = truth();
    std::normal_distribution<double> n(0.0, 1.0);
    const double k = with_noise ? 1.0 : 0.0;
    PoseInput p;
    p.stamp_ns = secToNs(t_);
    p.p = Vec3(tr.x + k * np_.pos_xy * n(rng_), tr.y + k * np_.pos_xy * n(rng_),
               tr.z + k * np_.pos_z * n(rng_));
    const double yaw = tr.yaw + k * np_.yaw_deg * kDeg2Rad * n(rng_);
    p.q = Quat(Eigen::AngleAxisd(yaw, Vec3::UnitZ()) * Eigen::AngleAxisd(tr.pitch, Vec3::UnitY()) *
               Eigen::AngleAxisd(tr.roll, Vec3::UnitX()));
    const Mat3 R = p.q.toRotationMatrix();
    // 모델 정의상 월드 속도 = (v_x, v_x·sinψ + v_s, 0) → 선체좌표로 회전 (nav_msgs twist 규약)
    const Vec3 vw(tr.vx, tr.vy_world, 0.0);
    p.v = R.transpose() * vw + k * np_.vel * Vec3(n(rng_), n(rng_), n(rng_));
    // 각속도: ψ̇ = r (롤·피치율은 작아 생략) → 선체좌표 ω = Rᵀ·[0,0,r] 은 ZYX 율 관계와 근사 일치
    const Vec3 ww(0.0, 0.0, tr.r);
    p.w = R.transpose() * ww + k * np_.rate_dps * kDeg2Rad * Vec3(n(rng_), n(rng_), n(rng_));
    p.twist_valid = true;
    p.twist_in_child_frame = true;
    return p;
  }

  TensionInput measureTension(bool with_noise) {
    std::normal_distribution<double> n(0.0, 1.0);
    TensionInput in;
    in.stamp_ns = secToNs(t_);
    for (int i = 0; i < kNumWinch; ++i)
      in.tension_kn[i] = tension_[i] + (with_noise ? np_.tension_kn * n(rng_) : 0.0);
    for (const auto& f : sc_.loadcell_faults) {
      if (t_ < f.t0 || t_ >= f.t1) continue;
      double& v = in.tension_kn[f.ch];
      switch (f.kind) {
        case LoadcellFault::kZero: v = 0.0; break;
        case LoadcellFault::kSpike: v += ((static_cast<int>(t_ * 100) % 2) ? 6.0 : -6.0); break;
        case LoadcellFault::kOverrange: v = 15.0; break;
        case LoadcellFault::kFrozen:
          if (frozen_[f.ch] == 0.0) frozen_[f.ch] = v;
          v = frozen_[f.ch];
          break;
        case LoadcellFault::kNaN: v = std::numeric_limits<double>::quiet_NaN(); break;
      }
    }
    return in;
  }

  double time() const { return t_; }
  const Scenario& scenario() const { return sc_; }
  const HullParams& hull() const { return hp_; }

 private:
  void updateTension() {
    const HullParams& h = hp_;
    const double yb = y_ + h.bow_lever * std::sin(psi_);
    const double ys = y_ - h.stern_lever * std::sin(psi_);
    const double sig[4] = {+1, -1, +1, -1};
    const double ya[4] = {yb, yb, ys, ys};
    const double ctrl[4] = {+0.5 * ctrl_bow_, -0.5 * ctrl_bow_, +0.5 * ctrl_stern_, -0.5 * ctrl_stern_};
    for (int i = 0; i < kNumWinch; ++i)
      tension_[i] = std::max(0.0, h.pretension_kn +
                                      h.wire_k_kn_per_m * (-sig[i] * h.g * ya[i] + delta_[i]) +
                                      ctrl[i]);
  }

  HullParams hp_;
  NoiseParams np_;
  Scenario sc_;
  std::mt19937 rng_{7};
  double t_ = 0, x_ = 0, y_ = 0, psi_ = 0, vx_ = 0, vs_ = 0, r_ = 0;
  std::array<double, kNumWinch> delta_{{0, 0, 0, 0}}, tension_{{0, 0, 0, 0}};
  std::array<double, kNumWinch> weights_{{0, 0, 0, 0}}, frozen_{{0, 0, 0, 0}};
  double ctrl_bow_ = 0, ctrl_stern_ = 0, v_cmd_ = 0, mz_cmd_ = 0, fy_cmd_ = 0;
};

/// 폐루프 실행 기록 1샘플 (포즈 주기)
struct Sample {
  double t = 0;
  Truth truth;
  AlignmentOutput out;
  bool from_watchdog = false;
  double truth_y_err = 0, truth_yaw_err = 0, truth_x_remain = 0;
};

struct RunResult {
  std::vector<Sample> samples;
  std::vector<std::pair<double, Alert>> alerts;
  std::vector<double> compute_us;
  EngineCounters counters;
  // 인터록 응답: (펜스 침범 포즈 수신 시각 → 인터록 출력 시각) [ms]
  std::vector<double> interlock_latency_ms;
  // 포즈 상실: (마지막 수신 + timeout → ALARM 시각) [ms]
  std::vector<double> pose_lost_detect_ms;
};

/// 테스트베드 표준 시나리오 (벤치·합성 발행기 공용). 알 수 없는 이름 → T1.
///  T1 정상 / T2a·T2b 초기 ±100 mm·±5° 복원 / T3a 조류+돌풍(M_z 만) / T3b T3a+[제안] F_y /
///  T4a W2 권취 +5 % / T4b T4a+보정 가중치 적용 / T5 센서·통신 결함 / T6 인터록(280 N 돌풍)
inline Scenario makeScenario(const std::string& name) {
  Scenario s;
  s.name = name;
  s.duration_s = 45;
  if (name == "T2a" || name == "T2b") {
    const double k = name == "T2a" ? 1.0 : -1.0;
    s.y0 = 0.10 * k;
    s.yaw0_deg = 5.0 * k;
  } else if (name == "T3a" || name == "T3b") {
    s.duration_s = 60;
    s.f_ext = [](double t) { return 60.0 + ((t >= 12 && t < 15) ? 140.0 : 0.0); };
    s.m_ext = [](double t) { return (t >= 12 && t < 15) ? 40.0 : 0.0; };
    s.apply_lateral_force = name == "T3b";
  } else if (name == "T4a" || name == "T4b") {
    s.winch_speed_error = {0, 0.05, 0, 0};
    s.winch_error_t0 = 3;
    s.apply_speed_weights = name == "T4b";
  } else if (name == "T5") {
    s.duration_s = 40;
    s.loadcell_faults = {{2, 10, 14, LoadcellFault::kZero},
                         {3, 16, 18, LoadcellFault::kFrozen},
                         {0, 20, 20.03, LoadcellFault::kSpike},
                         {1, 25, 26, LoadcellFault::kOverrange}};
    s.pose_blackouts = {{30, 30.05}, {33, 33.015}};
    s.tension_blackouts = {{35, 35.2}};
    s.upstream_interlock_pulse = true;
    s.upstream_t0 = 5;
    s.upstream_t1 = 5.5;
  } else if (name == "T6") {
    s.duration_s = 40;
    s.f_ext = [](double t) { return (t >= 10 && t < 13) ? 280.0 : 0.0; };
  } else {
    s.name = "T1";
    s.y0 = 0.02;
    s.yaw0_deg = 0.5;
  }
  return s;
}

inline bool inWindows(double t, const std::vector<std::pair<double, double>>& w) {
  for (const auto& p : w)
    if (t >= p.first && t < p.second) return true;
  return false;
}

/// 폐루프 실행: 물리 1 ms, 포즈·장력 주기 배달, 워치독 2 ms.
inline RunResult runClosedLoop(TrajectoryAnalysisEngine& eng, TestbedSim& sim,
                               const Scenario& sc, double watchdog_period_s = 0.002) {
  RunResult res;
  sim.reset(sc);
  eng.reset();
  const double dt = 0.001;
  const int pose_div = std::max(1, static_cast<int>(std::lround(1.0 / (sc.pose_rate_hz * dt))));
  const int ten_div = std::max(1, static_cast<int>(std::lround(1.0 / (sc.tension_rate_hz * dt))));
  const int wd_div = std::max(1, static_cast<int>(std::lround(watchdog_period_s / dt)));
  const int n = static_cast<int>(std::lround(sc.duration_s / dt));
  const double y_danger = eng.config().safety.y_danger_m;
  const double s_target = eng.deviation().targetArcLength();
  bool prev_breach = false;
  double breach_rx = -1;
  double last_pose_rx = -1;
  bool lost_reported = false;
  bool upstream = false;

  auto apply = [&](const AlignmentOutput& o) {
    sim.setCommand(o.target_inhaul_speed_mpm / kMps2Mpm, o.correction_moment_z_knm,
                   o.correction_force_y_kn, o.tension.speed_weight);
  };

  for (int k = 1; k <= n; ++k) {
    sim.step(dt);
    const double t = sim.time();
    const int64_t now_ns = secToNs(t);
    if (sc.upstream_interlock_pulse) {
      const bool u = t >= sc.upstream_t0 && t < sc.upstream_t1;
      if (u != upstream) eng.onUpstreamInterlock(now_ns, u);
      upstream = u;
    }
    if (k % ten_div == 3 % ten_div && !inWindows(t, sc.tension_blackouts))
      eng.onTension(now_ns, sim.measureTension(sc.noise));
    if (k % pose_div == 0 && !inWindows(t, sc.pose_blackouts)) {
      PoseInput p = sim.measurePose(sc.noise);
      const double rx = t + sc.pose_latency_s;  // 수신 시각 (stamp + 전송지연)
      auto o = eng.onPose(secToNs(rx), p);
      last_pose_rx = rx;
      lost_reported = false;
      if (o) {
        apply(*o);
        res.compute_us.push_back(o->compute_time_us);
        Sample s;
        s.t = t; s.truth = sim.truth(); s.out = *o;
        s.truth_y_err = s.truth.y;
        s.truth_yaw_err = s.truth.yaw;
        s.truth_x_remain = s_target - s.truth.x;
        res.samples.push_back(s);
        const bool breach = std::abs(s.truth.y) > y_danger;  // 참값 기준 침범
        if (breach && !prev_breach) breach_rx = rx;
        if (breach_rx >= 0 && o->interlock) {
          // 같은 주기에서 판정되면 지연 = 연산시간
          res.interlock_latency_ms.push_back((rx - breach_rx) * 1e3 + o->compute_time_us * 1e-3);
          breach_rx = -1;
        }
        prev_breach = breach;
      }
    }
    if (k % wd_div == 0) {
      auto z = eng.checkWatchdog(secToNs(t));
      if (z) {
        apply(*z);
        if (!lost_reported && last_pose_rx >= 0) {
          res.pose_lost_detect_ms.push_back(
              (t - (last_pose_rx + eng.config().safety.pose_timeout_s)) * 1e3);
          lost_reported = true;
        }
        Sample s;
        s.t = t; s.truth = sim.truth(); s.out = *z; s.from_watchdog = true;
        s.truth_y_err = s.truth.y; s.truth_yaw_err = s.truth.yaw;
        s.truth_x_remain = s_target - s.truth.x;
        res.samples.push_back(s);
      }
    }
    for (auto& a : eng.takeAlerts()) res.alerts.emplace_back(t, std::move(a));
  }
  res.counters = eng.counters();
  return res;
}

}  // namespace pit::sim
