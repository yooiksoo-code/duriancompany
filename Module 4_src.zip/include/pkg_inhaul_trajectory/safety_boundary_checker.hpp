// [세부 4] 안전 한계 판정기 (SafetyBoundaryChecker) + 급격한 편차 전진 보류 (설계서 6장 1)
//   가상 안전 펜스(Safety Corridor):
//     |e_y| > y_warn  → WARNING  (속도 배율 1.0 → warn_min_speed_scale 선형 감소)
//     |e_y| > y_danger→ DANGER   (속도 지령 0, 인터록 플래그)
//     e_y = |Yerr| (기본) 또는 max(|Yerr|, |선수 끝|, |선미 끝|) (check_extremities)
//     방위각도 같은 방식 (yaw_warn / yaw_danger), X_remain < −overshoot → DANGER
//   해제는 임계 − 히스테리시스 아래로 내려와야 함 (경계 채터링 방지).
//   Ramp-down Override: 편차가 "커지는 방향"으로 |ė| > 임계 → HOLD (속도 배율 hold_scale),
//     율 < 임계/2 (위험 단계 아님) 가 override_release_s 지속되면 해제 → 이후 경고 구간 속도 배율 적용.
#pragma once

#include <string>

#include "pkg_inhaul_trajectory/spatial_deviation_engine.hpp"
#include "pkg_inhaul_trajectory/trajectory_config.hpp"

namespace pit {

struct SafetyState {
  SafetyLevel level = SafetyLevel::kNormal;
  double speed_scale = 1.0;
  bool hold_override = false;
  bool danger = false;
  double lateral_metric = 0.0;   // 판정에 쓴 횡변위 [m]
  std::string reason;            // 마지막 판정 사유 (진단)
};

class SafetyBoundaryChecker {
 public:
  void configure(const SafetyConfig& cfg);
  void reset();
  const SafetyState& update(double dt, const DeviationState& d);
  const SafetyState& state() const { return st_; }
  uint32_t dangerEvents() const { return danger_events_; }
  uint32_t holdEvents() const { return hold_events_; }

 private:
  SafetyConfig c_;
  SafetyState st_;
  SafetyLevel y_level_ = SafetyLevel::kNormal, yaw_level_ = SafetyLevel::kNormal;
  bool overshoot_ = false;
  double release_timer_ = 0.0;
  uint32_t danger_events_ = 0, hold_events_ = 0;
};

}  // namespace pit
