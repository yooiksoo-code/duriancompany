"""[모듈 4] INHAUL 궤적분석 노드 실행.

  ros2 launch pkg_inhaul_trajectory trajectory_analysis.launch.py                  # 실운용 (모듈 3·윈치 브릿지 발행 중)
  ros2 launch pkg_inhaul_trajectory trajectory_analysis.launch.py sim:=true scenario:=T3a
  ros2 launch pkg_inhaul_trajectory trajectory_analysis.launch.py sim:=true scenario:=T3b force_y_applied:=true
  ros2 launch pkg_inhaul_trajectory trajectory_analysis.launch.py composed:=true   # 컨테이너 (라이프사이클 외부 전이)
"""
import os
import tempfile

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch_ros.actions import ComposableNodeContainer, Node
from launch_ros.descriptions import ComposableNode


def _setup(context):
    share = get_package_share_directory('pkg_inhaul_trajectory')
    cfg = context.launch_configurations['config_file'] or os.path.join(
        share, 'config', 'dock_trajectory_profile.yaml')
    sim = context.launch_configurations['sim'].lower() == 'true'
    composed = context.launch_configurations['composed'].lower() == 'true'
    if context.launch_configurations['force_y_applied'].lower() == 'true':
        # 설정 파일을 덮어쓰지 않고 임시 사본에 tension.force_y_applied 만 변경
        import yaml
        with open(cfg) as f:
            data = yaml.safe_load(f)
        data.setdefault('tension', {})['force_y_applied'] = True
        tmp = tempfile.NamedTemporaryFile('w', suffix='.yaml', delete=False)
        yaml.safe_dump(data, tmp, allow_unicode=True)
        tmp.close()
        cfg = tmp.name
    params = [{
        'config_file': cfg,
        'autostart': not composed,
        'watchdog_period_ms': float(context.launch_configurations['watchdog_period_ms']),
    }]
    actions = []
    if composed:
        actions.append(ComposableNodeContainer(
            name='inhaul_trajectory_container', namespace='', package='rclcpp_components',
            executable='component_container',
            composable_node_descriptions=[ComposableNode(
                package='pkg_inhaul_trajectory', plugin='pit::TrajectoryAnalysisNode',
                name='trajectory_analysis_node', parameters=params,
                extra_arguments=[{'use_intra_process_comms': True}])],
            output='screen'))
    else:
        actions.append(Node(package='pkg_inhaul_trajectory', executable='trajectory_analysis_node',
                            name='trajectory_analysis_node', parameters=params, output='screen'))
    if sim:
        actions.append(Node(
            package='pkg_inhaul_trajectory', executable='synthetic_inhaul_publisher',
            name='synthetic_inhaul_publisher', output='screen',
            parameters=[{'scenario': context.launch_configurations['scenario'],
                         'loop': context.launch_configurations['loop'].lower() == 'true',
                         'noise': True}]))
    return actions


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('config_file', default_value=''),
        DeclareLaunchArgument('sim', default_value='false'),
        DeclareLaunchArgument('scenario', default_value='T1'),
        DeclareLaunchArgument('loop', default_value='true'),
        DeclareLaunchArgument('composed', default_value='false'),
        DeclareLaunchArgument('force_y_applied', default_value='false'),
        DeclareLaunchArgument('watchdog_period_ms', default_value='2.0'),
        OpaqueFunction(function=_setup),
    ])
