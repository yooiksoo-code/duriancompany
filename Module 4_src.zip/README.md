# pkg_inhaul_trajectory — [모듈 4] INHAUL 궤적분석 SW 모듈

손원일급 잠수함 자동 INHAUL 시스템 구축을 위한 3D 위치 데이터 수집 및 분석 SW 개발
주식회사 두리안컴퍼니 · 연구책임자 박완선 · SW총괄 유익수
설계 근거: 연구노트 「SW 개발 설계계획서 — INHAUL 궤적분석 SW 모듈 (pkg_inhaul_trajectory)」(2026.10.26)

[모듈 3] `sensor_fusion_node` 의 융합 6DoF(`/sub_pose_filtered`, ≥100 Hz)와 윈치 제어반 4채널 로드셀(`/winch_tension_raw`)을 실시간 비교·분석해
도크 중심 안착선 대비 **잔여거리 X_remain · 횡편차 Y_err · 방위각 오차 Yaw_err**, **함수/함미 장력 불균형 ΔT** 를 산출하고,
**Jerk-Limited S-Curve 전진 속도 지령**과 **정렬 복원 가상 모멘트 M_z** 를 `/inhaul/alignment_status` (`inhaul_msgs/AlignmentStatus`) 로
[모듈 5] `winch_controller_node` 에 전달합니다. 안전 펜스 침범·포즈 상실·상위 인터록 시 속도 지령을 0 으로 내립니다.

---

## 1. 구성

```
inhaul_ws/src/
├── inhaul_msgs/                              # 0.4.0: AlignmentStatus / WinchTensionArray / TrajectoryDiagnostics 추가 (기존 변경 없음)
└── pkg_inhaul_trajectory/
    ├── include/pkg_inhaul_trajectory/
    │   ├── types.hpp                         # 좌표·부호·단위 규약 (y 좌+, yaw 반시계+, M_z 반시계+, kN, m/min 출력)
    │   ├── trajectory_config.hpp             # 모든 기본값의 단일 출처
    │   ├── spatial_deviation_engine.hpp      # [세부 1] SpatialDeviationEngine (폴리라인 중심선 투영)
    │   ├── tension_imbalance_analyzer.hpp    # [세부 2] TensionImbalanceAnalyzer (채널 감시·원인 판정·보정 가중치)
    │   ├── profile_generator.hpp             # [세부 3] ProfileGenerator (S-Curve 기준곡선·저크 제한기·PD 모멘트·[제안] F_y)
    │   ├── safety_boundary_checker.hpp       # [세부 4] SafetyBoundaryChecker (펜스·히스테리시스·Ramp-down Override)
    │   ├── trajectory_analysis_engine.hpp    # 파이프라인·정렬 판정·포즈 워치독·YAML 로더 (ROS 비의존)
    │   ├── sim_testbed.hpp                   # Physical Twin 합성 모델(선체+4점 와이어+윈치 에뮬레이터), 시나리오 T1~T6
    │   └── trajectory_analysis_node.hpp      # ROS2 LifecycleNode (component)
    ├── src/core/*.cpp, src/ros/{trajectory_analysis_node, synthetic_inhaul_publisher}.cpp
    ├── config/dock_trajectory_profile.yaml   # 도크 형상·공차·감속 프로파일·안전·게인·로드셀 DB (YAML-CPP)
    ├── launch/trajectory_analysis.launch.py  # 단독 / sim:=true scenario:=T1~T6 / composed:=true / force_y_applied:=true
    ├── systemd/inhaul-trajectory.service     # Type=notify, Restart=always, WatchdogSec=1s
    ├── tools/trajectory_bench.cpp            # 설계서 8장 KPI 2~6 + 시나리오 T1~T6 (3600 s)
    ├── tools/alignment_kpi_monitor.py        # ROS 그래프 수준 KPI 1~4·6 (합성 참값 대비)
    ├── test/test_inhaul_trajectory.cpp       # gtest 28건
    └── docs/test_reports/                    # 벤치 3600 s, ROS T1, ROS T5(결함주입) 보고서
```

## 2. 설계계획서 검토 결과

설계서를 모듈 3 산출물(출력 규약·인터록)과 대조하고 구현·폐루프 시험하면서 확인한 사항입니다.
**[반영]** 은 이번 구현에 반영, **[결정 필요]** 는 연구책임자 / 모듈 3·5 담당 확인이 필요한 것입니다.

### 2.1 수식·알고리즘

| # | 설계서 항목 | 검토 내용 | 조치 |
|---|---|---|---|
| R1 | 4장 3) M_z,cmd = K_p,y·Y_err + **K_d,y·Y_err** + K_p,ψ·Yaw + **K_d,ψ·Yaw** | 미분항에 미분 기호가 빠져 비례항과 같은 식이 됨 (편집 오류로 보임). 부호(복원 방향)·단위 미정 | **[반영]** M_z = sat(−(K_p,y·Y + K_d,y·Ẏ + K_p,ψ·ψ + K_d,ψ·ψ̇), ±M_max), kN·m, 반시계 +. 미분은 **EKF twist 를 중심선 법선으로 투영** (편차 수치미분 잡음 없음, `use_twist:false` 면 수치미분+LPF) |
| R2 | 4장 1) X_remain = X_target − x, Y_err = y − y_ref(x) | 도크 축이 dock_world_frame x 축과 평행할 때만 성립 | **[반영]** 중심선 폴리라인 투영(호길이 s, 좌측 법선 거리)으로 일반화. 직선·x축 정렬이면 설계서 식과 동일. 임의 회전 도크·실함 규모(≤62 m)에서 오차 1e-11 mm |
| R3 | 4장 1) Yaw_err = ψ_sub − ψ_ref | ±180° 부근 360° 점프. 롤·피치 부유 시 "선수 축 방위" 정의 필요 | **[반영]** wrap(−π, π], ψ = ZYX yaw(=선수축 XY 투영 방위), 롤·피치 ±1° 에서 오차 1e-13° |
| R4 | 4장 3) 정렬 복원 = 요 모멘트 단일 지령 | **요 모멘트만으로는 정상(定常) 횡외력(조류)을 상쇄할 수 없음**: T3a 조류 60 N 에서 30 mm 잔류 → 정렬 미완료, 돌풍 시 100.8 mm 까지 밀려 위험 1회 | **[반영·제안]** 횡력 지령 F_y = sat(−(K_p·Y + K_i·∫Y + K_d·Ẏ)) 를 계산해 진단 토픽 `correction_force_y_kn` 으로 발행. T3b(F_y 실행): 잔류 0.0 mm, 최대 18.5 mm, 36.3 s 정렬. **[결정 필요]** AlignmentStatus 에 필드 추가 및 모듈 5 배분 채택 |
| R5 | 4장 2) ΔT 로 외력/권취 속도 오차 판정 | **ΔT 만으로는 권취 속도 오차를 판정할 수 없음**: 와이어가 스프링처럼 동작해 W2 가 더 감기면 선체가 끌려가 W1=W2 로 평형 → ΔT≈0 인데 58 mm 편위 (T4a) | **[반영]** 와이어 모델 기반: 길이 불일치 장력 m = ΔT_res + 2kg·y_att. m ≈ 0 이면서 ΔT 큼 → 외력, \|m\| > \|ΔT\| → 권취 오차. 자체 M_z(·F_y) 지령이 만든 장력차는 배분식+1차 지연으로 먼저 제거. 가중치는 권취 오차일 때만(외력에 버티는 와이어를 풀지 않음). T4b 가중치 적용 시 58 → 7 mm. **[결정 필요]** 와이어 등가강성 k·횡성분 g 교정 시험 (k ≤ 0 이면 모델 없는 일률/복원일 부호 판정으로 동작) |
| R6 | 4장 4) 안전 펜스 = \|Y_err\| 50/100 mm | 기준점 횡편차만 봄 — 실함(약 65 m)에서 yaw 1° 는 선단 횡변위 약 0.57 m. 방위각 임계 미정 | **[반영]** `check_extremities` (선수·선미 끝 Y ± L·sinψ 도 판정, **권장 true**, 기본 false = 설계서). yaw 경고/위험 2.5°/5.0°, 해제 히스테리시스 5 mm·0.25°. **[결정 필요]** 방위 임계·선체 길이 |
| R7 | 4장 4) 100 mm 인터록 vs 7장 5단계 "횡편차 ±100 mm·방위 ±5° 복원" | 시험 초기 조건이 이미 인터록 경계 → 인터록 시 모멘트도 0 이면 복원 시험 자체가 불가 | **[반영]** 위험 단계 = 전진 지령 0 + **복원 모멘트 유지** (`danger_zero_moment: false`). T2a/T2b 1.95 s 내 복원 후 정상 인하울·정렬. **[결정 필요]** 상위 인터록 시 모듈 5 가 모멘트까지 차단하는지 |
| R8 | 6장 1) "급증" 시 전진 보류 | 급증 기준·해제 조건 미정. 첫 구현(해제 = NORMAL 복귀)은 **정상 조류로 경고 구간에 머무르면 영구 보류(크리프 고착)** 되는 결함을 T3a 에서 발견 | **[반영]** 편차가 **커지는 방향** \|Ẏ\| > 15 mm/s 또는 \|ψ̇\| > 0.5°/s (\|Y\| > 10 mm·\|ψ\| > 0.5° 일 때) → 속도 ×0.05, 율 < 임계/2 가 1 s 지속되면 해제(위험 단계 제외) → 이후 경고 배율. 복원 중인 빠른 움직임은 보류하지 않음 |
| R9 | 4장 3) V_cmd(X_remain) S-Curve | 거리 함수 정의만 있고 a·j 한계·시간영역 성질 미정 | **[반영]** v_max 에서 저크 제한 3구간 정지궤적을 해석적으로 적분해 (잔여거리, 속도) 표로 역변환 → 그대로 추종하면 a ≤ a_max, j ≤ j_max (시험). 출발·보류·복귀 불연속은 앞먹임 2차 저크 제한기(한계×3)로 완화 (매끄러운 기준곡선은 지연 없이 통과). 기본 v_max 6 m/min, a 0.015, j 0.008 → 감속 시작 0.427 m (KPI 5 "종단 0.5 m" 와 정합) ★ |
| R10 | 6장 2) 로드셀 "급격히 0 / 상한 초과 노이즈" | 단선 후 0 유지 시 복귀 판정, 고착·NaN·음수·HW 상태·토픽 단절 미정 | **[반영]** INVALID(NaN·< −0.5 kN)·OVERRANGE·SPIKE(>2 kN/샘플)·DROPOUT(마지막 정상값 ≥0.2 kN → 0, 0 유지 중 계속)·FROZEN·HW_STATUS·STALE(50 ms) → 채널 배제·POSE_ONLY 절체, 정상 1 s 유지 후 재편입. **고착 판정이 정적 하중(4채널 비트 동일)에서 오판**하는 결함을 시험에서 발견 → 다른 채널 2개 이상이 변하는 중일 때만 판정 |
| R11 | 6장 3) 20 ms(2주기) 미수신 → ALARM | 100 Hz 에서 **1프레임 누락 = 공백 20 ms + 지터** → 경계에서 오알람 가능. 감시 주기 미정 | **[반영]** 2 ms 워치독(검출 ≤ timeout + 2 ms), 상실 중 10 ms 마다 지령 0 발행, 복귀 시 0 에서 저크 제한 재출발. 설계서 값 20 ms 유지. **[결정 필요]** 25 ms(2.5주기) 권장 — 단일 프레임 누락 허용 |
| R12 | (미기재) 상위 결함 연계 | 모듈 3 은 DR_EXPIRED(비전 결손 2 s 초과) 중에도 Odometry 를 계속 발행 (모듈 3 R8) → 포즈 타임아웃만으로는 못 막음 | **[반영]** `/sensor_fusion/safety_interlock` (transient_local) 구독 → true 면 속도 0, 위험 코드 (`honor_upstream_interlock`) |

### 2.2 인터페이스·모듈 간 정합

| # | 항목 | 검토 내용 | 조치 |
|---|---|---|---|
| I1 | 장력 메시지 `custom_interfaces/msg/WinchTensionArray` | 프로젝트에 `custom_interfaces` 패키지 없음, 필드 미정 | **[반영]** `inhaul_msgs/WinchTensionArray` (tension[4] kN W1~W4, channel_status[4]) 로 일원화. **[결정 필요]** 윈치 제어반 브릿지 담당과 필드 확정 |
| I2 | ΔT 무효 쌍 표기 | AlignmentStatus 에 유효 플래그 없음 | **[반영]** 해당 쌍 0 + 진단 `channel_valid`/`channel_fault`. **[결정 필요]** NaN 표기가 모듈 5 에 안전한지 |
| I3 | 모듈 3 I4 (불규칙 출력 ~156 Hz) | 모듈 3 의 질의 | **답변**: 모듈 4 는 포즈마다 이벤트 구동, dt = stamp 차 → 불규칙 주기 수용. 단 KPI 1 "≥100 Hz" 는 모듈 3 출력률에 종속. 정확히 100 Hz 가 필요하면 모듈 3 `on_vision_update: false` |
| I4 | 차등 속도 보정 가중치·원인 판정·F_y | 설계서 4장 2) 에 "가중치 결정" 은 있으나 출력 메시지에 필드 없음 | **[반영]** `inhaul_msgs/TrajectoryDiagnostics` 신설 (가중치, 원인, F_y, 채널 상태, 시간). **[결정 필요]** 모듈 5 가 쓸 필드를 AlignmentStatus 로 옮길지 |
| I5 | 인터록·HMI 출력 | 설계서 "상위 인터록 트리거" 토픽 미정 | **[반영]** `/inhaul/safety_interlock` (Bool, transient_local, 전이 즉시 + 10 Hz, 미초기화·상실·위험·상위 시 true), `/hmi/trajectory_alerts` (`코드\|정보`, 모듈 3 과 같은 형식) |
| I6 | 포즈·장력 시간 정렬 | 미정 | 최근 장력 사용 (0~10 ms 차). 원인 판정은 LPF 0.2 s 라 영향 작음 |
| I7 | 좌표계 | 중심선 frame | `dock.frame_id` ≠ 포즈 frame_id 이면 기각(1회 경고). twist 는 nav_msgs 규약대로 선체 좌표 (모듈 3 I3) |

### 2.3 KPI 정의 검토

| # | KPI | 검토 내용 | 제안 |
|---|---|---|---|
| K1 | 3·4 횡편차 ±1 mm / 방위 ±0.05° | 모듈 4 연산 오차는 1e-11 mm / 1e-13° 로 0 — **실제 판정값은 입력(모듈 3) 정밀도가 지배** (EKF 수준 잡음에서 max 0.49~0.61 mm / 0.011°) | "모듈 1~4 체인 출력 vs 레일 참값" 으로 명시 |
| K2 | 5 감속 프로파일 일치율 ≤ 2 % | 기준(국소 상대 vs 풀스케일) 미정. 저속 끝단에서 상대오차는 의미 상실. **선체 실속도**는 윈치 속도 루프(τ 0.25 s 가정) 지연으로 4.95 %FS | %FS 정의 제안. 지령 기준 0.82 %FS 충족. 실속도 기준이면 모듈 5 앞먹임(또는 모듈 4 리드 보상) 필요 |
| K3 | 6 인터록 ≤ 10 ms | 펜스 판정은 같은 콜백(µs). **포즈 상실은 정의상 20 ms 무수신 후**에야 판정 | "판정 → 플래그" 시간으로 정의 (상실은 timeout + ≤ 2 ms) |
| K4 | 2 연산 ≤ 1 ms | 엔진 p99 0.4 µs. 공유 vCPU 에서 선점으로 max 0.17~0.8 ms (벤치) / 6 ms (ROS, 합성 발행기 1 kHz 타이머와 경합) | 목표 엣지PC(Preempt-RT, 전용 코어)에서 재측정 |

## 3. 처리 구조 (설계서 4장 구현)

```
/winch_tension_raw (W1~W4) ─▶ [세부 2] 채널 감시 (NaN·음수·상한·스파이크·단선·고착·HW·STALE) → 배제/재편입
                                   │                      │ 하나라도 배제 → POSE_ONLY
/sub_pose_filtered (Odometry) ─┐   ▼
  frame 검사, NaN·역순 기각    │  ΔT_bow = W1−W2, ΔT_stern = W3−W4 → LPF − (자체 M_z·F_y 지령 장력차)
                               │  m = ΔT_res + 2kg·y_att → BALANCED / EXTERNAL_FORCE / WINCH_MISMATCH → 보정 가중치
                               ▼
[세부 1] 중심선 투영 → X_remain, Y_err(좌+), Yaw_err(wrap), Z_err, Ẏ·ψ̇ (twist), 선수·선미 횡변위
   ▼
[세부 4] 펜스: |Y| 50/100 mm, |ψ| 2.5/5°, 종점 초과 20 mm (히스테리시스) + Ramp-down Override → 단계·속도 배율
   │        상위 인터록(/sensor_fusion/safety_interlock) → 위험
   ▼
[세부 3] V_target = min(v_max·배율, max(V_ref(X_remain), v_creep)) → 저크 제한기 → V_cmd (위험·상위 = 즉시 0)
         M_z = sat(−(Kp,y·Y + Kd,y·Ẏ + Kp,ψ·ψ + Kd,ψ·ψ̇)),  [제안] F_y = sat(−PID(Y))
   ▼
정렬 완료: |X|≤5 mm, |Y|≤10 mm, |ψ|≤0.3° 0.5 s 유지 → 래치 (×1.5 초과 시 해제)
   ▼
/inhaul/alignment_status · /inhaul/trajectory_diagnostics · /inhaul/safety_interlock · /hmi/trajectory_alerts
워치독 2 ms: 포즈 공백 > 20 ms → ALARM_POSE_LOST, 지령 0 (10 ms 주기 발행), 복귀 시 0 에서 재출발
```

## 4. 빌드

```bash
# 1) inhaul_msgs 에 메시지 3종 추가 (inhaul_msgs_additions/msg/*.msg → inhaul_ws/src/inhaul_msgs/msg/)
#    inhaul_msgs/CMakeLists.txt 의 rosidl_generate_interfaces 목록에 추가, package.xml 버전 0.4.0:
#      "msg/AlignmentStatus.msg" "msg/WinchTensionArray.msg" "msg/TrajectoryDiagnostics.msg"
#    (std_msgs 의존은 기존 FusionDiagnostics 와 같음)

# 2) 의존성 (Ubuntu 22.04 + ROS2 Humble)
sudo apt install ros-humble-rclcpp-components ros-humble-rclcpp-lifecycle ros-humble-rmw-cyclonedds-cpp \
                 libeigen3-dev libyaml-cpp-dev
cd inhaul_ws && colcon build --merge-install --packages-up-to pkg_inhaul_trajectory --cmake-args -DCMAKE_BUILD_TYPE=Release
colcon test --merge-install --packages-select pkg_inhaul_trajectory && colcon test-result --verbose

# ROS 없이 코어/시험/벤치만 (알고리즘 개발·CI)
cmake -S src/pkg_inhaul_trajectory -B build_core -DPIT_CORE_ONLY=ON && cmake --build build_core -j && ctest --test-dir build_core
./build_core/trajectory_bench --duration 3600 --report bench.md [--csv-dir out/]    # --quick: 2분 분량
```

## 5. 실행

```bash
# 합성 테스트베드 폐루프 (모듈 3·윈치 제어반·모듈 5 없이 노드 전체 검증)
ros2 launch pkg_inhaul_trajectory trajectory_analysis.launch.py sim:=true scenario:=T1 [loop:=false]
#   scenario: T1 정상 | T2a/T2b ±100 mm·±5° 복원 | T3a 조류+돌풍 | T3b T3a+F_y (force_y_applied:=true 함께) |
#             T4a W2 권취 +5 % | T4b T4a+가중치 적용 | T5 센서·통신 결함 | T6 280 N 돌풍 인터록
ros2 run pkg_inhaul_trajectory alignment_kpi_monitor.py --duration 45 --truth --report ros.md

# 실운용 (모듈 3 /sub_pose_filtered, 윈치 브릿지 /winch_tension_raw 발행 중)
ros2 launch pkg_inhaul_trajectory trajectory_analysis.launch.py [config_file:=/path/dock_trajectory_profile.yaml]
ros2 launch pkg_inhaul_trajectory trajectory_analysis.launch.py composed:=true      # 컨테이너 (라이프사이클 외부 전이)
ros2 lifecycle set /trajectory_analysis_node configure && ros2 lifecycle set /trajectory_analysis_node activate

ros2 topic echo /inhaul/alignment_status
ros2 topic echo /inhaul/trajectory_diagnostics   # 모드·원인·가중치·F_y·채널 상태·연산시간·카운터
ros2 topic echo /hmi/trajectory_alerts           # ERROR_SAFETY_INTERLOCK / ALARM_POSE_LOST / WARN_LOADCELL_FAULT ...
```

운영 배포: `systemd/inhaul-trajectory.service` (Type=notify, `Restart=always`, `RestartSec=100ms`, `WatchdogSec=1s`,
SCHED_FIFO 70, 모듈 1·2·3 과 다른 코어). sd_notify 는 libsystemd 없이 직접 구현 — 실행기가 멈추면 하트비트(10 Hz)가 끊겨 1 s 후 재기동됩니다.

## 6. 인터페이스

| 구분 | 토픽 / 파일 | 타입 | 비고 |
|---|---|---|---|
| 입력 | `/sub_pose_filtered` | `nav_msgs/Odometry` | best_effort depth 10 (reliable 발행자도 수신). frame_id ≠ `dock.frame_id` 기각. **수신마다 처리·발행** |
| 입력 | `/winch_tension_raw` | `inhaul_msgs/WinchTensionArray` (신규) | kN, [W1 함수좌, W2 함수우, W3 함미좌, W4 함미우], 50 ms 무수신 → POSE_ONLY |
| 입력 | `/sensor_fusion/safety_interlock` | `std_msgs/Bool` | transient_local (모듈 3). true → 속도 0 |
| 출력 | `/inhaul/alignment_status` | `inhaul_msgs/AlignmentStatus` (신규, 설계서 5장 그대로) | reliable. 포즈 상실 중에는 10 ms 마다 지령 0·코드 2 |
| 출력 | `/inhaul/trajectory_diagnostics` | `inhaul_msgs/TrajectoryDiagnostics` (신규) | 원인·가중치·[제안] F_y·채널 상태·연산/콜백 시간·카운터 (`diagnostics_every_n`) |
| 출력 | `/inhaul/safety_interlock` | `std_msgs/Bool` | transient_local, 전이 즉시 + 10 Hz. true = 미초기화·포즈상실·위험·상위 인터록 |
| 출력 | `/hmi/trajectory_alerts` | `std_msgs/String` | `코드\|정보`, 전이 시 1회 |
| 설정 | `config/dock_trajectory_profile.yaml` | YAML-CPP | ★ 표시 = 합성 테스트베드 기준 초기값 (게인·와이어 기하·강성·프로파일 한계) |

경보 코드: `ERROR_SAFETY_INTERLOCK`, `INFO_SAFETY_INTERLOCK_CLEARED`, `ALARM_POSE_LOST`, `INFO_POSE_RECOVERED`, `WARN_RAMPDOWN_OVERRIDE`,
`INFO_RAMPDOWN_RELEASED`, `WARN_UPSTREAM_INTERLOCK`, `INFO_UPSTREAM_INTERLOCK_CLEARED`, `WARN_LOADCELL_FAULT`, `INFO_LOADCELL_RECOVERED`,
`WARN_TENSION_TIMEOUT`, `WARN_FEEDBACK_POSE_ONLY`, `INFO_FEEDBACK_FULL`, `INFO_ALIGNED`, `WARN_ALIGNMENT_LOST`, `WARN_POSE_INVALID`.

## 7. 예외 처리 (설계서 6장)

| 요구 | 구현 | 검증 |
|---|---|---|
| 1) 급격한 편차 → 전진 보류 | 편차 증가 방향 율 임계 → 속도 ×0.05, 1 s 안정 후 해제 | `Safety.RampDownOverrideOnlyWhenGrowing`, T3a/T3b/T6, ROS T1 |
| 2) 로드셀 단선·이상 → ΔT 배제, 자세 단독 | 채널 7종 결함 + STALE, POSE_ONLY 절체, 1 s 후 재편입 | `TensionTest.*` 6건, T5 (벤치·ROS 동일 경보열) |
| 3) 포즈 20 ms 무수신 → ALARM_POSE_LOST, 지령 0 | 2 ms 워치독, 상실 중 10 ms 지령 0, 복귀 시 0 에서 재출발 | `EngineTest.PoseTimeoutZeroCommandAndRestart`, T5 50 ms·15 ms 결손 |
| (추가) 상위 인터록 | 모듈 3 인터록 → 속도 0 | `EngineTest.UpstreamInterlockStops`, T5 펄스 |
| (추가) 입력 이상 | NaN·비정상 쿼터니언·역순/중복 stamp·frame 불일치 기각 | `EngineTest.RejectsOutOfOrderAndNaN` |
| (추가) 자가 복구 | 프로세스 종료 → systemd 재기동, 실행기 정지 → watchdog, on_error → 종료코드 4 | composed 시험 중 실제 on_error → 종료코드 4 확인 (8.3-1) |

## 8. 시험 결과 (2026-11-23, 개발 컨테이너: 2 vCPU, 실시간 커널 아님, 합성 데이터)

합성 모델: 축소 선체 200 kg·150 kg·m², 4점 와이어 각 2 kN/m·예장력 1 kN·횡성분 0.5, 윈치 속도 루프 τ 0.25 s, M_z(·F_y) → 장력차 τ 0.2 s,
부유 롤 0.4°·피치 0.25°·히브 2 mm, 포즈 잡음 = 모듈 3 위치 RMSE 수준(0.15/0.15/0.40 mm, 0.003°, 속도 0.5 mm/s), 로드셀 5 N.

### 8.1 KPI (설계서 8장, `docs/test_reports/bench_3600s.md`)

| # | KPI | 목표 | 결과 | 판정 |
|---|---|---|---|---|
| 1 | 연산 주기 | ≥ 100 Hz, 드롭 0 % | ROS T1 **99.95 Hz** (46 s, 드롭 0.05 % = 합성 발행기 타이머 공백 2회), composed 100.00 Hz | 노드는 수신마다 발행 — 공백은 입력 측 (8.3) |
| 2 | 연산 지연 | ≤ 1.0 ms | 엔진 p50 **0.2 µs** / p99 0.4 µs / max 174 µs (361,909 사이클, 3620 s). ROS 콜백 p50 100 µs / p99 0.8 ms | 충족 (max 는 공유 vCPU 선점, K4) |
| 3 | 횡편차 정밀도 | ± 1.0 mm | 연산 오차 **1.0e-11 mm** (float32 출력 7.5e-6 mm), 입력 잡음 포함 RMSE 0.150 / max 0.49 mm (ROS 0.61 mm) | 충족 (K1) |
| 4 | 방위각 정밀도 | ± 0.05° | 연산 **8.9e-14°** (롤·피치 ±1° 포함), 입력 잡음 포함 RMSE 0.0030 / max 0.011° | 충족 |
| 5 | 종단 감속 추종 | ≤ 2.0 % | 지령 vs 기준곡선 max **0.82 %FS** / 선체 실속도 4.95 %FS (윈치 τ 지연) | 지령 기준 충족 (K2) |
| 6 | 인터록 응답 | ≤ 10 ms | 펜스 침범 → 위험 플래그 **같은 주기 (< 1 µs)**, ROS 인터록 토픽 수신 max 0.64 ms, 포즈 상실은 timeout 후 ≤ 1.0 ms | 충족 (K3) |

### 8.2 테스트베드 시나리오 (설계서 7장 5단계 Test 1~5 대응안, 합성 폐루프)

| 시나리오 | 조건 | 최종 X_rem / Y / Yaw (참값) | 최대 \|Y\| | 정렬 완료 | 위험/보류 | 장력 원인 |
|---|---|---|---|---|---|---|
| T1 | 정상 인하울, 초기 +20 mm/+0.5° | −0.6 mm / 0.0 mm / −0.005° | 20.0 mm | 31.5 s | 0 / 1 | BALANCED 97 % |
| T2a | 초기 **+100 mm / +5°** | −0.7 / 0.0 / −0.005° | 99.9 mm | 32.0 s (복원 1.95 s) | 0 / 1 | BALANCED 95 % |
| T2b | 초기 **−100 mm / −5°** | −0.7 / 0.0 / −0.005° | 99.9 mm | 32.0 s (복원 1.95 s) | 1 / 1 | BALANCED 95 % |
| T3a | 조류 60 N + 돌풍 200 N·40 N·m, **M_z 만** (설계서) | −0.9 / **30.0 mm** / −0.94° | 100.8 mm | **미완료** | 1 / 2 | **EXTERNAL_FORCE 98 %** |
| T3b | T3a + **[제안] F_y** | −0.5 / 0.0 / 0.000° | 18.5 mm | 36.3 s | 0 / 3 | BALANCED 90 % (F_y 가 상쇄) |
| T4a | W2 권취 +5 %, 가중치 미적용 | −0.8 / **−58.0 mm** / −0.37° | 58.0 mm | **미완료** | 0 / 0 | **WINCH_MISMATCH 85 %** (W1 +0.2, W2 −0.2) |
| T4b | T4a + 보정 가중치 적용 | −0.8 / −7.0 mm / −0.08° | 8.5 mm | 28.9 s | 0 / 0 | WINCH_MISMATCH 35 % |
| T5 | W3 단선·W4 고착·W1 스파이크·W2 상한, 포즈 50/15 ms·장력 200 ms 결손, 모듈 3 인터록 펄스 | −2.9 / 0.0 / 0.003° | 0.0 mm | 32.5 s | 0 / 0 | POSE_ONLY 30.6 % |
| T6 | 횡 돌풍 280 N (펜스 침범) | −0.6 / 0.0 / 0.001° | 145.3 mm | 36.5 s | 1 / 1 | EXTERNAL_FORCE (돌풍 중) |

T5 경보열 (벤치와 ROS 동일): `WARN_UPSTREAM_INTERLOCK` → `WARN_LOADCELL_FAULT W3 DROPOUT` → `WARN_FEEDBACK_POSE_ONLY` → `INFO_LOADCELL_RECOVERED` → … `W4 FROZEN` → `W1 INVALID(−5 kN 스파이크)` → `W2 OVERRANGE` → `ALARM_POSE_LOST`(30.0 s, 15 ms 결손 시에도 2프레임 누락으로 33.0 s) → `INFO_POSE_RECOVERED` → `WARN_TENSION_TIMEOUT` → 재편입.

### 8.3 ROS 노드 (RoboStack ROS2 Humble, CycloneDDS, `synthetic_inhaul_publisher`)

| 항목 | 결과 |
|---|---|
| colcon build (inhaul_msgs 스텁 + pkg_inhaul_trajectory) | 성공, 본 패키지 컴파일 경고 0 (`-Wall -Wextra -Wpedantic`) |
| colcon test | **29건** (gtest 28 + ctest 1) 통과 / 0 실패 |
| ROS T1 46 s (`ros_T1.md`) | 99.95 Hz, 엔진 p99 7.3 µs, 포즈 stamp→발행 p50 0.30 / p99 1.2 ms, Y RMSE 0.151 mm, 31.5 s 정렬 |
| ROS T5 41 s (`ros_T5_faults.md`) | 결함 경보열 벤치와 일치, 로드셀 이상 8건, 포즈상실 3회(마지막은 시나리오 종료), 32.5 s 정렬 |
| `composed:=true` + 외부 lifecycle | configure → activate 100 Hz → deactivate 0 Hz, `/inhaul/safety_interlock` 래치값 false → **true** (fail-safe) → activate 100 Hz |

개발 중 발견·반영한 사항:
1. **composed(intra-process) 에서 transient_local 구독이 activate 를 실패시킴** — 모듈 3 인터록 구독 생성 시 `intraprocess communication allowed only with volatile durability` → on_error → 종료코드 4 로 컨테이너가 내려감 (모듈 3 8.4-3 은 발행자, 이번은 구독자). 이 구독만 intra-process 비활성으로 수정.
2. **경고 구간 정체 시 영구 보류** (R8) — T3a 에서 재현, 해제 조건 수정.
3. **ΔT 만으로 권취 오차 미검출** (R5) — T4a 에서 재현, 모델 기반 판정으로 교체.
4. **제안 F_y 를 하류가 실행하지 않는데 보상 모델에서 빼면 원인을 반대로 판정** — `force_y_applied` 로 보상 모델을 실제 실행 지령과 일치.
5. **고착 판정 오판** (R10), 음수 스파이크가 단선으로 표시되던 판정 순서 수정.
6. 시작 시 STALE→정상 복귀 경보 4건 스팸 제거 (최초 편입은 경보 없음).

## 9. 한계 및 실장비 검증 필요 사항 (정직 고지)

- **모든 수치는 합성 모델 기준입니다.** 선체·와이어·윈치 모델은 축소 테스트베드를 가정한 1차 모델이며(와이어 선형 스프링, 윈치 1차 지연, 횡·요 독립 감쇠),
  실제 손원일급 규모·유체력·와이어 비선형(처짐)·윈치 데드밴드가 없습니다. 게인(★)은 이 모델로 정한 초기값이며 5단계 테스트베드에서 재조정해야 합니다.
- **장력 원인 판정은 와이어 등가강성 k·횡성분 g·체결점 레버암에 의존합니다.** 교정값이 30 % 이상 틀리면 외력/권취 오차 경계가 이동합니다. 교정 전에는 `wire_stiffness_kn_per_m: 0` (모델 없는 판정)도 가능하나 T4 유형(ΔT≈0 편위)은 못 잡습니다.
- 와이어가 실제로 **이완(slack)되어 장력 0** 이 되면 단선(DROPOUT)과 구분하지 못하고 채널을 배제합니다.
- 차등 속도 보정 가중치·F_y 의 실제 사용은 모듈 5 설계에 달려 있으며, 이번 검증은 단순 배분 에뮬레이터 기준입니다 (T3b·T4b).
- 정렬 판정 공차(5 mm / 10 mm / 0.3°)와 펜스 방위 임계(2.5°/5°)는 설계서 미정 항목을 임의로 정한 값입니다.
- 연산·지연 수치는 2 vCPU 컨테이너 결과입니다. ROS 실행에서 엔진 max 6 ms·콜백 max 7 ms 는 같은 코어의 1 kHz 합성 발행기와 경합한 선점이며, 목표 엣지PC(Preempt-RT, 전용 코어)에서 재측정이 필요합니다.
- 개발 빌드는 RoboStack(conda) 환경 한정 우회(`-include cstdint`, libyaml 링크 경고)를 썼습니다. 소스와 apt 기반 목표 환경과는 무관합니다.
- 실제 inhaul_ws(모듈 1~3) 와 함께 빌드·체인 시험은 하지 못했습니다 (작업 PC 폴더 미연결). `inhaul_msgs` 는 메시지 3종만 넣은 스텁으로 빌드했습니다.

## 10. 설계서 일정 대비 진행

| 단계 | 산출물 | 상태 |
|---|---|---|
| 1단계 (M1~M2) | 도크 궤적 파라미터 YAML, 기하 모델링 정의서 | `dock_trajectory_profile.yaml`, 폴리라인 중심선·좌표/부호 규약(types.hpp·본 문서 2·3장) 완료 |
| 2단계 (M3~M4) | trajectory_analysis_node 알파 | S-Curve 생성기, ΔT 분석기(모델 기반 원인 판정), LifecycleNode/component/systemd 완료 |
| 3단계 (M5~M6) | 안전 인터록 로직, 단위 기능 시험 결과서 | 펜스·Override·포즈 워치독·상위 인터록, gtest 28건, 벤치 보고서 완료 |
| 4단계 (M7~M9) | 100 Hz 연동, 연산 지연 프로파일 | 합성 ROS 폐루프·계측 도구 완료. **모듈 3 실출력·윈치 브릿지 연동, 목표 HW 측정 미착수** |
| 5단계 (M10~M12) | 테스트베드 Test 1~5 실증 | 시나리오 T1~T6 합성 정의·검증 완료, 실증 미착수 |
