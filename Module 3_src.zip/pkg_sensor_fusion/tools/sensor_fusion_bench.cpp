// sensor_fusion_bench — 설계서 8장 KPI 계측 (합성 레일 테스트베드)
//
//   ./sensor_fusion_bench [--s1-duration 3600] [--report bench.md] [--quick]
//
// KPI 1 갱신 주파수 ≥100 Hz / 드롭 0 %     → S1 (IMU 정규 출력 간격, 최대 간격)
// KPI 2 위치 RMSE ≤ 5 mm                   → S1, S1b, S4
// KPI 3 자세 RMSE ≤ 0.2°                   → S1, S1b, S4
// KPI 4 엔드투엔드 지연 < 10 ms             → S1 출력 방식 A/B/C 비교 (촬영 → 발행)
// KPI 5 예측+보정 1사이클 ≤ 1.5 ms          → S1 (비전 1회 = 보정 + 재전파, + 직전 예측 1회)
// KPI 6 2 s 결손 드리프트 ≤ 1.0 %           → S2, S2b, S7
// KPI 7 재수렴 ≤ 100 ms                    → S2 (±2σ 위치 경계가 결손 전 수준의 110 % 이내로 복귀)
// KPI 8 이상치 기각 100 % (발산 0건)        → S3 (크기별 기각률 곡선)
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>

#include "pkg_sensor_fusion/sim_runner.hpp"

using namespace psf;
using namespace psf::sim;

namespace {

struct Pct { double p50 = 0, p99 = 0, max = 0, mean = 0; };
Pct pct(std::vector<double> v) {
  Pct p;
  if (v.empty()) return p;
  std::sort(v.begin(), v.end());
  p.p50 = v[v.size() / 2];
  p.p99 = v[std::min(v.size() - 1, static_cast<size_t>(v.size() * 0.99))];
  p.max = v.back();
  double s = 0;
  for (double x : v) s += x;
  p.mean = s / v.size();
  return p;
}

struct Acc {
  Vec3 pos_sq = Vec3::Zero(), rot_sq = Vec3::Zero();
  double pos3_sq = 0, pos_max = 0, rot_max = 0, nees = 0;
  int n = 0, chi95 = 0;
  void add(const OutputSample& s) {
    pos_sq += s.e_pos.cwiseAbs2();
    rot_sq += s.e_rot.cwiseAbs2();
    pos3_sq += s.e_pos.squaredNorm();
    pos_max = std::max(pos_max, s.e_pos.norm());
    rot_max = std::max(rot_max, s.e_rot.cwiseAbs().maxCoeff());
    nees += s.nees;
    if (s.nees < 12.59) ++chi95;
    ++n;
  }
  Vec3 posRmse() const { return (pos_sq / std::max(n, 1)).cwiseSqrt(); }
  double pos3() const { return std::sqrt(pos3_sq / std::max(n, 1)); }
  Vec3 rotRmseDeg() const { return (rot_sq / std::max(n, 1)).cwiseSqrt() * 180 / M_PI; }
};

Acc accuracy(const ScenarioResult& R, double t_from, bool tracking_only = true) {
  Acc a;
  for (const auto& s : R.out) {
    if (s.t < t_from) continue;
    if (tracking_only && s.mode != FusionMode::TRACKING) continue;
    a.add(s);
  }
  return a;
}

int divergences(const ScenarioResult& R) {
  int d = 0;
  bool in_div = false;
  for (const auto& s : R.out) {
    const bool bad = s.valid && (s.e_pos.norm() > 0.05 || s.e_rot.norm() > 2.0 * M_PI / 180);
    if (bad && !in_div) ++d;
    in_div = bad;
  }
  return d;
}

FusionConfig baseConfig() {
  FusionConfig c;
  applyDefaultMount(c);
  c.imu = ImuSimParams{}.noise;
  return c;
}

std::string f(const char* fm, double a) { char b[64]; std::snprintf(b, sizeof b, fm, a); return b; }

struct DropStat { std::vector<double> ratio_pct, ratio_nom_pct, err_mm, dist_m, reconv_ms, reconv15_ms, reconv_abs_ms, reconv_err_ms; int expired = 0; };

DropStat dropoutStats(const ScenarioParams& sp, const ScenarioResult& R) {
  DropStat d;
  Trajectory tr(sp.traj);
  for (const auto& b : sp.vision_blackouts) {
    // 결손 직전 정상 σ, 결손 말 오차
    std::vector<double> sig;
    double e_end = -1;
    for (const auto& s : R.out) {
      if (s.t > b.t0 - 2.0 && s.t < b.t0 - 0.05 && s.mode == FusionMode::TRACKING) sig.push_back(s.sig_pos);
      if (s.t < b.t1) e_end = s.e_pos.norm();
    }
    double dist = 0;
    for (double t = b.t0; t < b.t1; t += 0.001) dist += (tr.pos(t + 0.001) - tr.pos(t)).norm();
    std::sort(sig.begin(), sig.end());
    const double sig0 = sig.empty() ? 0 : sig[sig.size() / 2];
    double t_conv = -1, t_conv15 = -1, t_conv_abs = -1, t_conv_err = -1;
    for (const auto& s : R.out) {
      if (s.t < b.t1) continue;
      if (t_conv < 0 && s.mode == FusionMode::TRACKING && s.sig_pos <= 1.1 * sig0) t_conv = s.t_pub - b.t1;
      if (t_conv15 < 0 && s.mode == FusionMode::TRACKING && s.sig_pos <= 1.5 * sig0) t_conv15 = s.t_pub - b.t1;
      if (t_conv_abs < 0 && s.mode == FusionMode::TRACKING && 2.0 * s.sig_pos <= 0.5e-3) t_conv_abs = s.t_pub - b.t1;
      if (t_conv_err < 0 && s.mode == FusionMode::TRACKING && s.e_pos.norm() <= 3.0 * sig0)
        t_conv_err = s.t_pub - b.t1;
      if (t_conv >= 0 && t_conv_err >= 0 && t_conv_abs >= 0 && t_conv15 >= 0) break;
    }
    d.err_mm.push_back(e_end * 1e3);
    d.dist_m.push_back(dist);
    d.ratio_pct.push_back(100.0 * e_end / std::max(dist, 1e-9));
    if (dist >= 0.4) d.ratio_nom_pct.push_back(100.0 * e_end / dist);  // 평균 0.2 m/s 이상 구간
    d.reconv_ms.push_back(t_conv * 1e3);
    d.reconv15_ms.push_back(t_conv15 * 1e3);
    d.reconv_abs_ms.push_back(t_conv_abs * 1e3);
    d.reconv_err_ms.push_back(t_conv_err * 1e3);
  }
  for (const auto& e : R.events) if (e.code == "ERROR_DR_TIMEOUT") ++d.expired;
  return d;
}

std::vector<Interval> periodicBlackouts(double first, double period, double len, double duration) {
  std::vector<Interval> v;
  for (double t = first; t + len + 3.0 < duration; t += period) v.push_back({t, t + len});
  return v;
}

}  // namespace

int main(int argc, char** argv) {
  double s1_dur = 600.0;
  std::string report = "sensor_fusion_bench.md";
  bool quick = false;
  for (int i = 1; i < argc; ++i) {
    if (!std::strcmp(argv[i], "--s1-duration") && i + 1 < argc) s1_dur = std::atof(argv[++i]);
    else if (!std::strcmp(argv[i], "--report") && i + 1 < argc) report = argv[++i];
    else if (!std::strcmp(argv[i], "--quick")) quick = true;
  }
  if (quick) s1_dur = std::min(s1_dur, 60.0);
  const double dscale = quick ? 0.25 : 1.0;

  std::ostringstream md;
  md << "# pkg_sensor_fusion KPI 벤치 보고서\n\n";
  md << "합성 레일 테스트베드 (2.5 m 왕복, 최고 0.3 m/s, heave/sway 수 mm, roll/pitch/yaw 0.3~0.5°). ";
  md << "IMU 레버암 (0.60, −0.15, −0.35) m · Z 90° 장착. 기본 IMU = 산업용 MEMS 급 "
        "(가속도 6e-4 m/s²/√Hz, 자이로 1e-4 rad/s/√Hz, 초기 바이어스 ~10 mg · ~0.1°/s). "
        "비전 σ 위치 0.15/0.15/0.40 mm, 회전 0.010/0.010/0.004° (모듈 2 S7 σ0.2 mm 조건 수준), 지연 3~7 ms.\n\n";

  std::map<std::string, std::string> kpi;
  FusionConfig c = baseConfig();

  // ------------------------------------------------------------------ S1
  std::printf("S1 normal %.0f s ...\n", s1_dur);
  ScenarioParams s1;
  s1.duration = s1_dur;
  FusionConfig cA = c; cA.output_rate_hz = 100.0; cA.output_on_vision_update = false;
  FusionConfig cD = c;  // 기본 설정 (100 Hz 정규 + 비전 갱신 직후 발행) = 방식 C
  const auto R1 = ScenarioRunner(s1, cD).run();
  const auto a1 = accuracy(R1, 5.0);
  // 출력 간격 (정규 출력, 초기화 이후)
  std::vector<double> gaps;
  double prev = -1;
  int n_reg = 0;
  for (const auto& s : R1.out) {
    if (prev >= 0) gaps.push_back((s.t - prev) * 1e3);
    prev = s.t;
    ++n_reg;
  }
  const auto g = pct(gaps);
  const double t_init = R1.out.empty() ? 0 : R1.out.front().t;
  const double rate = n_reg / (s1_dur - t_init);
  const double reg_rate = R1.regular_outputs / (s1_dur - t_init);
  const double expect = (s1_dur - t_init) * 100.0;
  const double drop_pct = 100.0 * std::max(0.0, expect - R1.regular_outputs) / expect;
  int gaps_over = 0;
  for (double x : gaps) if (x > 15.0) ++gaps_over;
  const auto cyc = pct(R1.cycle_us), imu = pct(R1.imu_us);

  // 출력 방식별 지연 (짧게)
  ScenarioParams s1l = s1; s1l.duration = 120.0 * dscale + 10;
  FusionConfig cB = c; cB.output_rate_hz = 0.0; cB.output_on_vision_update = false;
  FusionConfig cC = cD;
  const auto LA = ScenarioRunner(s1l, cA).run();
  const auto LB = ScenarioRunner(s1l, cB).run();
  const auto LC = ScenarioRunner(s1l, cC).run();
  const auto eA = pct(LA.e2e_ms), eB = pct(LB.e2e_ms), eC = pct(LC.e2e_ms);
  const auto fA = pct(LA.fusion_added_ms), fB = pct(LB.fusion_added_ms), fC = pct(LC.fusion_added_ms);
  const auto aB = accuracy(LB, 5.0), aC = accuracy(LC, 5.0);

  // ------------------------------------------------------------------ S1b: 30 Hz 비전 / 100 Hz IMU
  std::printf("S1b 30Hz vision / 100Hz IMU ...\n");
  ScenarioParams s1b;
  s1b.duration = 300.0 * dscale;
  s1b.vis.rate_hz = 30.0;
  s1b.imu.rate_hz = 100.0;
  const auto R1b = ScenarioRunner(s1b, cD).run();
  const auto a1b = accuracy(R1b, 5.0);
  int dr_false = 0;
  for (const auto& e : R1b.events) if (e.code == "WARN_VISION_DROPOUT") ++dr_false;
  // 설계서 원안 33 ms 결손 판정으로 같은 조건 실행
  FusionConfig c33 = cD; c33.dropout_timeout_s = 0.033;
  const auto R1b33 = ScenarioRunner(s1b, c33).run();
  int dr_false33 = 0;
  for (const auto& e : R1b33.events) if (e.code == "WARN_VISION_DROPOUT") ++dr_false33;

  // ------------------------------------------------------------------ S2: 2 s 결손 반복
  std::printf("S2 dropout 2 s x N ...\n");
  ScenarioParams s2;
  s2.duration = 400.0 * dscale + 20;
  s2.vision_blackouts = periodicBlackouts(10.0, 12.7, 2.0, s2.duration);
  const auto R2 = ScenarioRunner(s2, cD).run();
  const auto d2 = dropoutStats(s2, R2);

  ScenarioParams s2b = s2;
  s2b.vis.rate_hz = 30.0;
  s2b.imu.rate_hz = 100.0;
  const auto R2b = ScenarioRunner(s2b, cD).run();
  const auto d2b = dropoutStats(s2b, R2b);

  // S7: 소비자급 IMU (필터도 그 잡음으로 설정)
  std::printf("S7 consumer IMU ...\n");
  ScenarioParams s7 = s2;
  s7.imu.noise.acc_noise = 1.7e-3;
  s7.imu.noise.gyro_noise = 2.4e-4;
  s7.imu.noise.acc_bias_rw = 2e-4;
  s7.imu.noise.gyro_bias_rw = 2e-5;
  s7.imu.ba0 = Vec3(0.3, -0.25, 0.4);
  s7.imu.bg0 = Vec3(0.015, -0.01, 0.012);
  FusionConfig c7 = cD;
  c7.imu = s7.imu.noise;
  const auto R7 = ScenarioRunner(s7, c7).run();
  const auto d7 = dropoutStats(s7, R7);
  const auto a7 = accuracy(R7, 5.0);

  // ------------------------------------------------------------------ S3: 이상치
  std::printf("S3 outliers ...\n");
  struct OutRow { std::string name; int inj, rej, fp, inl, div; double pos_max; };
  std::vector<OutRow> orows;
  auto runOut = [&](const std::string& name, OutlierParams op) {
    ScenarioParams s3;
    s3.duration = 120.0 * dscale + 10;
    s3.outliers = op;
    s3.seed = 21;
    const auto R = ScenarioRunner(s3, cD).run();
    orows.push_back({name, R.outliers_injected, R.outliers_rejected, R.inliers_rejected, R.inliers,
                     divergences(R), accuracy(R, 5.0, false).pos_max});
  };
  runOut("반사상 5 mm 점프", {0.05, 0, false, 0.005, 0});
  runOut("Flip 5° 회전 점프", {0.05, 0, false, 0, 5.0 * M_PI / 180});
  runOut("반사상 20 mm + 2°", {0.05, 0, false, 0.02, 2.0 * M_PI / 180});
  for (double k : {3.0, 4.0, 5.0, 6.0, 8.0, 10.0}) runOut("한 축 " + f("%.0f", k) + "σ", {0.05, k, false, 0, 0});
  runOut("6축 모두 3σ", {0.05, 3.0, true, 0, 0});
  runOut("이상치 20 % 버스트, 6축 5σ", {0.20, 5.0, true, 0, 0});

  // ------------------------------------------------------------------ S4: 단일 태그 구간
  std::printf("S4 single tag ...\n");
  ScenarioParams s4;
  s4.duration = 120.0 * dscale + 10;
  for (double t = 8; t + 6 < s4.duration; t += 15) s4.single_tag.push_back({t, t + 6});
  const auto R4 = ScenarioRunner(s4, cD).run();
  Acc a4s, a4m;
  for (const auto& s : R4.out) {
    if (s.t < 5.0 || s.mode != FusionMode::TRACKING) continue;
    bool st = false;
    for (auto& iv : s4.single_tag) if (s.t >= iv.t0 && s.t < iv.t1) st = true;
    (st ? a4s : a4m).add(s);
  }

  // ------------------------------------------------------------------ S5: 지연 30~45 ms (재전파 vs 단순)
  std::printf("S5 latency ...\n");
  ScenarioParams s5;
  s5.duration = 120.0 * dscale + 10;
  s5.vis.latency_min_s = 0.030;
  s5.vis.latency_max_s = 0.045;
  const auto R5r = ScenarioRunner(s5, cD).run();
  FusionConfig cN = cD; cN.replay_enable = false;
  const auto R5n = ScenarioRunner(s5, cN).run();
  const auto a5r = accuracy(R5r, 5.0), a5n = accuracy(R5n, 5.0);

  // ------------------------------------------------------------------ S6: IMU 단절
  std::printf("S6 imu loss ...\n");
  auto imuRun = [&](double len) {
    ScenarioParams s6;
    s6.duration = 20.0;
    s6.imu_blackouts = {{10.0, 10.0 + len}};
    return ScenarioRunner(s6, cD).run();
  };
  const auto R6a = imuRun(0.080), R6b = imuRun(0.400);
  auto evList = [](const ScenarioResult& R) {
    std::string s;
    for (const auto& e : R.events)
      if (e.code != "INFO_FUSION_INITIALIZED" || toSec(e.stamp) > 2.0) s += e.code + " (" + f("%.3f", toSec(e.stamp)) + " s) → ";
    if (s.size() > 5) s.resize(s.size() - 5);
    return s;
  };
  auto afterAcc = [](const ScenarioResult& R) { return accuracy(R, 11.5); };

  // ------------------------------------------------------------------ S8: 공분산 과소보고
  std::printf("S8 cov mismatch ...\n");
  ScenarioParams s8;
  s8.duration = 120.0 * dscale + 10;
  s8.vis.cov_report_scale = 0.25;  // σ 를 절반으로 보고
  const auto R8 = ScenarioRunner(s8, cD).run();
  FusionConfig c8 = cD; c8.vision_cov_scale = 4.0;
  const auto R8c = ScenarioRunner(s8, c8).run();
  const auto a8 = accuracy(R8, 5.0), a8c = accuracy(R8c, 5.0);
  const double fr8 = 100.0 * R8.stats.vision_rejected_gate / std::max<double>(1, R8.stats.vision_received);
  const double fr8c = 100.0 * R8c.stats.vision_rejected_gate / std::max<double>(1, R8c.stats.vision_received);

  // ------------------------------------------------------------------ KPI 6 민감도 (비전 정밀도 × IMU 등급)
  std::printf("KPI6 sensitivity grid ...\n");
  struct VisLv { const char* name; Vec3 sp, sr; };
  const double D = M_PI / 180;
  const VisLv vis_lv[] = {
      {"모듈 2 S1 합성 수준 (0.007/0.008/0.032 mm, 0.006/0.003/0.0007°)", Vec3(0.007e-3, 0.008e-3, 0.032e-3), Vec3(0.0063 * D, 0.0027 * D, 0.0007 * D)},
      {"중간 (0.05/0.05/0.15 mm, 0.004/0.004/0.0015°)", Vec3(0.05e-3, 0.05e-3, 0.15e-3), Vec3(0.004 * D, 0.004 * D, 0.0015 * D)},
      {"기본 (0.15/0.15/0.40 mm, 0.010/0.010/0.004°)", Vec3(0.15e-3, 0.15e-3, 0.40e-3), Vec3(0.010 * D, 0.010 * D, 0.004 * D)}};
  struct ImuLv { const char* name; ImuSimParams p; };
  ImuSimParams tac; tac.noise = {1.5e-4, 1.0e-5, 1.0e-5, 2.0e-7}; tac.ba0 = Vec3(0.01, -0.01, 0.02); tac.bg0 = Vec3(1e-4, -1e-4, 5e-5);
  ImuSimParams ind;
  ImuSimParams con = s7.imu;
  ImuSimParams hi; hi.noise = {3.0e-4, 3.0e-5, 2.0e-5, 1.0e-6};
  const ImuLv imu_lv[] = {{"전술급", tac}, {"고급 MEMS", hi}, {"산업용 MEMS (기본)", ind}, {"소비자급 MEMS", con}};
  std::ostringstream grid_md;
  grid_md << "| 비전 정밀도 \\ IMU | 전술급 | 고급 MEMS | 산업용 (기본) | 소비자급 |\n|---|---|---|---|---|\n";
  for (const auto& vl : vis_lv) {
    grid_md << "| " << vl.name;
    for (const auto& il : imu_lv) {
      ScenarioParams sg;
      sg.duration = 200.0 * dscale + 20;
      sg.vision_blackouts = periodicBlackouts(10.0, 12.7, 2.0, sg.duration);
      sg.vis.sigma_pos = vl.sp;
      sg.vis.sigma_rot = vl.sr;
      sg.imu = il.p;
      sg.seed = 31;
      FusionConfig cg = cD;
      cg.imu = il.p.noise;
      const auto Rg = ScenarioRunner(sg, cg).run();
      const auto dg = pct(dropoutStats(sg, Rg).ratio_nom_pct);
      grid_md << " | " << f("%.2f", dg.p50) << " / " << f("%.2f", dg.max) << " %";
    }
    grid_md << " |\n";
  }

  // ================================================================== 보고서
  auto P = [](const Pct& p, const char* u = "") {
    char b[128];
    std::snprintf(b, sizeof b, "%.3f / %.3f / %.3f%s", p.p50, p.p99, p.max, u);
    return std::string(b);
  };
  const auto d2r = pct(d2.ratio_pct), d2e = pct(d2.err_mm), d2c = pct(d2.reconv_ms), d2ce = pct(d2.reconv_err_ms);
  const auto d2be = pct(d2b.err_mm), d2bc = pct(d2b.reconv_ms);
  const auto d7r = pct(d7.ratio_pct), d7e = pct(d7.err_mm);
  int out_div = 0;
  for (auto& r : orows) out_div += r.div;
  int big_inj = 0, big_rej = 0;
  for (int i = 0; i < 3; ++i) { big_inj += orows[i].inj; big_rej += orows[i].rej; }

  md << "## 1. KPI 요약\n\n| # | KPI | 목표 | 결과 | 판정 |\n|---|---|---|---|---|\n";
  md << "| 1 | 융합 갱신 주파수 | ≥100 Hz, 드롭 0 % | 정규 " << f("%.2f", reg_rate) << " Hz (+비전 직후 발행 포함 " << f("%.1f", rate)
     << " Hz), 정규 드롭 " << f("%.3f", drop_pct) << " %, 간격 max " << f("%.2f", g.max) << " ms (" << f("%.0f", s1_dur) << " s) | "
     << (reg_rate >= 99.9 && gaps_over == 0 ? "충족" : "미충족") << " |\n";
  md << "| 2 | 위치 RMSE (3D) | ≤ 5.0 mm | " << f("%.3f", a1.pos3() * 1e3) << " mm (max " << f("%.3f", a1.pos_max * 1e3)
     << ") / 30 Hz·100 Hz " << f("%.3f", a1b.pos3() * 1e3) << " mm | " << (a1.pos3() < 5e-3 && a1b.pos3() < 5e-3 ? "충족" : "미충족") << " |\n";
  const Vec3 rr = a1.rotRmseDeg(), rrb = a1b.rotRmseDeg();
  md << "| 3 | 자세 RMSE r/p/y | ≤ 0.2° | " << f("%.4f", rr.x()) << " / " << f("%.4f", rr.y()) << " / " << f("%.4f", rr.z())
     << "° (30/100 Hz: max축 " << f("%.4f", rrb.maxCoeff()) << "°) | " << (rr.maxCoeff() < 0.2 && rrb.maxCoeff() < 0.2 ? "충족" : "미충족") << " |\n";
  md << "| 4 | 엔드투엔드 지연 (촬영→발행) | < 10 ms | 기본(방식 C) p50 " << f("%.2f", eC.p50) << " / p99 " << f("%.2f", eC.p99)
     << " / max " << f("%.2f", eC.max) << " ms, 모듈 3 추가분 max " << f("%.3f", fC.max) << " ms (상류 지연 3~7 ms 모델) | "
     << (eC.max < 10 ? "충족 (상류 < 10 ms 조건)" : "미충족") << " |\n";
  md << "| 5 | 예측+보정 1사이클 | ≤ 1.5 ms | p50 " << f("%.1f", cyc.p50) << " / p99 " << f("%.1f", cyc.p99) << " / max "
     << f("%.1f", cyc.max) << " µs (max 는 공유 vCPU 선점) | " << (cyc.p99 < 1500 ? "충족 (p99 기준)" : "미충족") << " |\n";
  const auto d2n = pct(d2.ratio_nom_pct), d2bn = pct(d2b.ratio_nom_pct);
  md << "| 6 | 2 s 결손 드리프트 | ≤ 1.0 % | 이동 ≥ 0.4 m 구간 중앙 " << f("%.3f", d2n.p50) << " / 최대 " << f("%.3f", d2n.max)
     << " % (전 구간 최대 " << f("%.2f", d2r.max) << " %, 절대오차 최대 " << f("%.2f", d2e.max) << " mm), 30/100 Hz 최대 " << f("%.3f", d2bn.max) << " % | "
     << (d2n.max <= 1.0 && d2bn.max <= 1.0 ? "충족" : (d2n.p50 <= 1.0 ? "중앙값만 충족 — IMU 등급 의존 (민감도 표)" : "미충족")) << " |\n";
  const auto d2c15 = pct(d2.reconv15_ms), d2bc15 = pct(d2b.reconv15_ms);
  const auto d2ab = pct(d2.reconv_abs_ms), d2bab = pct(d2b.reconv_abs_ms), d2ee = pct(d2.reconv_err_ms), d2bee = pct(d2b.reconv_err_ms);
  md << "| 7 | 재수렴 시간 (±2σ) | ≤ 100 ms | 최대값 60/30 Hz — 2σ ≤ 0.5 mm: " << f("%.0f", d2ab.max) << " / " << f("%.0f", d2bab.max)
     << " ms, 오차 ≤ 결손 전 3σ: " << f("%.0f", d2ee.max) << " / " << f("%.0f", d2bee.max) << " ms, 2σ ≤ 결손 전 150 %: "
     << f("%.0f", d2c15.max) << " / " << f("%.0f", d2bc15.max) << " ms, 110 %: " << f("%.0f", d2c.max) << " / " << f("%.0f", d2bc.max) << " ms | "
     << "수렴 정의에 따라 다름 (README K2) |\n";
  md << "| 8 | 이상치 기각 / 발산 | 100 %, 0건 | 대형 점프 " << big_rej << "/" << big_inj << " 기각, 발산 " << out_div
     << "건 (3σ 한 축 점프는 2.3절) | " << (big_rej == big_inj && out_div == 0 ? "충족 (조건부)" : "미충족") << " |\n\n";

  md << "## 2. 시나리오별 상세\n\n";
  md << "### S1 정상 주행 (" << f("%.0f", s1_dur) << " s, 비전 60 Hz, IMU 200 Hz, 출력 기본값 C)\n\n";
  const Vec3 pr = a1.posRmse();
  md << "| 항목 | 값 |\n|---|---|\n";
  md << "| 위치 RMSE x/y/z | " << f("%.4f", pr.x() * 1e3) << " / " << f("%.4f", pr.y() * 1e3) << " / " << f("%.4f", pr.z() * 1e3) << " mm |\n";
  md << "| 위치 max | " << f("%.4f", a1.pos_max * 1e3) << " mm |\n";
  md << "| 자세 max (축별) | " << f("%.4f", a1.rot_max * 180 / M_PI) << "° |\n";
  md << "| 포즈 NEES 평균 (기대 6) / χ²₆ 95 % 이내 | " << f("%.2f", a1.nees / a1.n) << " / " << f("%.1f", 100.0 * a1.chi95 / a1.n) << " % |\n";
  md << "| 게이트 오기각 (정상 측정) | " << R1.inliers_rejected << " / " << R1.inliers << " |\n";
  md << "| 출력 간격 p50/p99/max | " << P(g, " ms") << " |\n";
  md << "| 예측 1회 (IMU) p50/p99/max | " << P(imu, " µs") << " |\n";
  md << "| 비전 1사이클 (보정+재전파+예측) p50/p99/max | " << P(cyc, " µs") << " |\n";
  md << "| 재전파 최대 스텝 | " << R1.stats.replay_steps_max << " |\n\n";

  md << "출력 방식별 지연 (120 s). e2e = 촬영 → 발행, 모듈 3 추가분 = 비전 도착 → 발행 (p50 / p99 / max)\n\n";
  md << "| 방식 | 출력률 | e2e [ms] | 모듈 3 추가분 [ms] | 위치 RMSE [mm] |\n|---|---|---|---|---|\n";
  md << "| A: IMU 샘플 솎음 100 Hz | " << f("%.1f", LA.out.size() / (s1l.duration - 0.5)) << " Hz | " << P(eA) << " | " << P(fA) << " | " << f("%.4f", accuracy(LA, 5.0).pos3() * 1e3) << " |\n";
  md << "| B: IMU 샘플마다 (200 Hz) | " << f("%.1f", LB.out.size() / (s1l.duration - 0.5)) << " Hz | " << P(eB) << " | " << P(fB) << " | " << f("%.4f", aB.pos3() * 1e3) << " |\n";
  md << "| **C: A + 비전 갱신 직후 발행 (기본값)** | " << f("%.1f", LC.out.size() / (s1l.duration - 0.5)) << " Hz (불규칙) | " << P(eC) << " | " << P(fC) << " | " << f("%.4f", aC.pos3() * 1e3) << " |\n\n";

  md << "### S1b 설계 최저 조건 (비전 30 Hz, IMU 100 Hz, " << f("%.0f", s1b.duration) << " s)\n\n";
  const Vec3 prb = a1b.posRmse();
  md << "위치 RMSE " << f("%.4f", prb.x() * 1e3) << " / " << f("%.4f", prb.y() * 1e3) << " / " << f("%.4f", prb.z() * 1e3)
     << " mm, max " << f("%.4f", a1b.pos_max * 1e3) << " mm, 자세 RMSE max축 " << f("%.4f", rrb.maxCoeff())
     << "°, NEES " << f("%.2f", a1b.nees / std::max(1, a1b.n)) << ".\n\n";
  md << "결손 오판정: dropout_timeout 50 ms → `WARN_VISION_DROPOUT` " << dr_false << "회, 설계서 원안 33 ms → "
     << dr_false33 << "회 (30 Hz 주기 33.3 ms + 지연 3~7 ms 이므로 매 프레임 사이 결손으로 판정됨).\n\n";

  auto dropTable = [&](const char* title, const DropStat& d) {
    const auto r = pct(d.ratio_pct), e = pct(d.err_mm), c2 = pct(d.reconv_ms), ce = pct(d.reconv_err_ms), di = pct(d.dist_m);
    const auto c15 = pct(d.reconv15_ms), cab = pct(d.reconv_abs_ms);
    md << title << "\n\n| 항목 | 중앙 | p99 | 최대 |\n|---|---|---|---|\n";
    const auto rn = pct(d.ratio_nom_pct);
    md << "| 드리프트 비율 [%] (전체 " << d.ratio_pct.size() << "회) | " << f("%.3f", r.p50) << " | " << f("%.3f", r.p99) << " | " << f("%.3f", r.max) << " |\n";
    md << "| 드리프트 비율 [%] (이동 ≥ 0.4 m, " << d.ratio_nom_pct.size() << "회) | " << f("%.3f", rn.p50) << " | " << f("%.3f", rn.p99) << " | " << f("%.3f", rn.max) << " |\n";
    md << "| 결손 종료 시 위치 오차 [mm] | " << f("%.3f", e.p50) << " | " << f("%.3f", e.p99) << " | " << f("%.3f", e.max) << " |\n";
    md << "| 결손 중 이동거리 [m] | " << f("%.3f", di.p50) << " | " << f("%.3f", di.p99) << " | " << f("%.3f", di.max) << " |\n";
    md << "| 재수렴 (2σ ≤ 150 % 결손 전) [ms] | " << f("%.1f", c15.p50) << " | " << f("%.1f", c15.p99) << " | " << f("%.1f", c15.max) << " |\n";
    md << "| 재수렴 (2σ ≤ 0.5 mm 절대) [ms] | " << f("%.1f", cab.p50) << " | " << f("%.1f", cab.p99) << " | " << f("%.1f", cab.max) << " |\n";
    md << "| 재수렴 (2σ ≤ 110 % 결손 전) [ms] | " << f("%.1f", c2.p50) << " | " << f("%.1f", c2.p99) << " | " << f("%.1f", c2.max) << " |\n";
    md << "| 재수렴 (오차 ≤ 3σ 결손 전) [ms] | " << f("%.1f", ce.p50) << " | " << f("%.1f", ce.p99) << " | " << f("%.1f", ce.max) << " |\n\n";
    md << "ERROR_DR_TIMEOUT " << d.expired << "회 / 결손 " << d.ratio_pct.size() << "회.\n\n";
  };
  dropTable("### S2 비전 2 s 차단 반복 (60 Hz / 200 Hz)", d2);
  dropTable("### S2b 비전 2 s 차단 반복 (30 Hz / 100 Hz)", d2b);
  dropTable("### S7 소비자급 MEMS IMU (잡음 ~3배, 바이어스 RW 10배, 초기 바이어스 ~40 mg·~0.8°/s)", d7);
  md << "IMU 등급 (가속도 잡음 m/s²/√Hz, 자이로 잡음 rad/s/√Hz): 전술급 1.5e-4 / 1e-5, 고급 MEMS 3e-4 / 3e-5, "
        "산업용 6e-4 / 1e-4, 소비자급 1.7e-3 / 2.4e-4. 필터 공정잡음은 각 IMU 값으로 설정.\n\n";
  md << "### KPI 6 민감도: 2 s 결손 드리프트 비율 중앙 / 최대, 이동 ≥ 0.4 m 구간 (" << f("%.0f", 200.0 * dscale + 20) << " s, 결손 "
     << periodicBlackouts(10.0, 12.7, 2.0, 200.0 * dscale + 20).size() << "회)\n\n" << grid_md.str() << "\n";
  md << "S7 정상 구간 위치 RMSE " << f("%.4f", a7.pos3() * 1e3) << " mm, 자세 RMSE max축 " << f("%.4f", a7.rotRmseDeg().maxCoeff()) << "°.\n\n";
  (void)d2ce; (void)d2be; (void)d7r; (void)d7e;

  md << "### S3 이상치 주입 (프레임당 5 %, 120 s, 크기 기준 σ = 모듈 2 보고 공분산)\n\n";
  md << "| 이상치 종류 | 주입 | 기각 | 기각률 | 정상측정 오기각 | 발산 | 위치 max [mm] |\n|---|---|---|---|---|---|---|\n";
  for (auto& r : orows)
    md << "| " << r.name << " | " << r.inj << " | " << r.rej << " | " << f("%.1f", 100.0 * r.rej / std::max(1, r.inj))
       << " % | " << r.fp << " / " << r.inl << " | " << r.div << " | " << f("%.3f", r.pos_max * 1e3) << " |\n";
  md << "\n";

  md << "### S4 단일 태그 구간 (6 s / 15 s, 보고 σ 위치×10·회전×5, 실제 오차는 보고보다 25 % 크고 5 % 확률 3σ 꼬리)\n\n";
  md << "| 구간 | 위치 RMSE [mm] | 위치 max [mm] | 자세 RMSE max축 [°] | NEES 평균 |\n|---|---|---|---|---|\n";
  md << "| 단일 태그 | " << f("%.3f", a4s.pos3() * 1e3) << " | " << f("%.3f", a4s.pos_max * 1e3) << " | " << f("%.4f", a4s.rotRmseDeg().maxCoeff())
     << " | " << f("%.2f", a4s.nees / std::max(1, a4s.n)) << " |\n";
  md << "| 다중 태그 | " << f("%.3f", a4m.pos3() * 1e3) << " | " << f("%.3f", a4m.pos_max * 1e3) << " | " << f("%.4f", a4m.rotRmseDeg().maxCoeff())
     << " | " << f("%.2f", a4m.nees / std::max(1, a4m.n)) << " |\n\n";
  md << "게이트 기각 " << R4.stats.vision_rejected_gate << " / " << R4.stats.vision_received << ", 재획득 " << R4.stats.relocks << "회.\n\n";

  md << "### S5 비전 지연 30~45 ms (시간 비동기 처리 비교)\n\n";
  md << "| 방식 | 위치 RMSE [mm] | 위치 max [mm] | NEES | 게이트 기각 |\n|---|---|---|---|---|\n";
  md << "| 상태이력 재전파 (본 구현) | " << f("%.4f", a5r.pos3() * 1e3) << " | " << f("%.3f", a5r.pos_max * 1e3) << " | " << f("%.2f", a5r.nees / std::max(1, a5r.n))
     << " | " << R5r.stats.vision_rejected_gate << " |\n";
  md << "| 도착 즉시 현재 상태에 적용 | " << f("%.4f", a5n.pos3() * 1e3) << " | " << f("%.3f", a5n.pos_max * 1e3) << " | " << f("%.2f", a5n.nees / std::max(1, a5n.n))
     << " | " << R5n.stats.vision_rejected_gate << " |\n\n";
  md << "재전파 최대 스텝 " << R5r.stats.replay_steps_max << ", 비전 1사이클 p99 " << f("%.1f", pct(R5r.cycle_us).p99) << " µs.\n\n";

  md << "### S6 IMU 단절\n\n| 단절 | 이벤트 | 복귀 후 위치 RMSE [mm] |\n|---|---|---|\n";
  md << "| 80 ms (선형보간 연결) | " << evList(R6a) << " | " << f("%.4f", afterAcc(R6a).pos3() * 1e3) << " |\n";
  md << "| 400 ms (재초기화, 바이어스 유지) | " << evList(R6b) << " | " << f("%.4f", afterAcc(R6b).pos3() * 1e3) << " |\n\n";

  md << "### S8 비전 공분산 과소보고 (σ 를 실제의 1/2 로 보고)\n\n";
  md << "| 설정 | 위치 RMSE [mm] | NEES | 게이트 기각률 |\n|---|---|---|---|\n";
  md << "| vision_cov_scale 1.0 | " << f("%.4f", a8.pos3() * 1e3) << " | " << f("%.2f", a8.nees / std::max(1, a8.n)) << " | " << f("%.2f", fr8) << " % |\n";
  md << "| vision_cov_scale 4.0 (보정) | " << f("%.4f", a8c.pos3() * 1e3) << " | " << f("%.2f", a8c.nees / std::max(1, a8c.n)) << " | " << f("%.2f", fr8c) << " % |\n\n";

  std::ofstream(report) << md.str();
  std::printf("%s", md.str().c_str());
  std::printf("\nreport → %s\n", report.c_str());
  return 0;
}
