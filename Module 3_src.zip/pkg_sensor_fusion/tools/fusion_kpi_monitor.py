#!/usr/bin/env python3
"""ROS 그래프 수준 KPI 계측 — /sub_pose_filtered 를 /sim/ground_truth(합성) 와 비교

  ros2 run pkg_sensor_fusion fusion_kpi_monitor.py --duration 30 [--report out.md]

계측: 발행률·간격(KPI 1), 위치/자세 오차(KPI 2·3, 합성 참값 필요), 수신 지연(now − stamp),
     진단 e2e 지연(KPI 4), 처리시간(KPI 5), HMI 경보 순서, 인터록 상태
"""
import argparse
import bisect
import math
import sys
import time

import numpy as np
import rclpy
from geometry_msgs.msg import PoseWithCovarianceStamped  # noqa: F401  (타입 등록용)
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from std_msgs.msg import Bool, String

try:
    from inhaul_msgs.msg import FusionDiagnostics
except ImportError:  # 진단 메시지 없이도 동작
    FusionDiagnostics = None


def stamp_s(h):
    return h.stamp.sec + h.stamp.nanosec * 1e-9


def quat_to_R(q):
    x, y, z, w = q.x, q.y, q.z, q.w
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def rot_log(R):
    c = max(-1.0, min(1.0, (np.trace(R) - 1) / 2))
    th = math.acos(c)
    if th < 1e-12:
        return np.zeros(3)
    return th / (2 * math.sin(th)) * np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])


class Monitor(Node):
    def __init__(self):
        super().__init__('fusion_kpi_monitor')
        self.out = []      # (stamp, recv, p, R)
        self.gt_t, self.gt = [], []
        self.diag = []
        self.alerts = []
        self.interlock = []
        self.create_subscription(Odometry, '/sub_pose_filtered', self.on_out, QoSProfile(depth=200))
        self.create_subscription(Odometry, '/sim/ground_truth', self.on_gt, QoSProfile(depth=500))
        self.create_subscription(String, '/hmi/fusion_alerts', self.on_alert, QoSProfile(depth=50))
        self.create_subscription(Bool, '/sensor_fusion/safety_interlock', self.on_il,
                                 QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                                            durability=DurabilityPolicy.TRANSIENT_LOCAL))
        if FusionDiagnostics is not None:
            self.create_subscription(FusionDiagnostics, '/sensor_fusion/diagnostics', self.on_diag, 20)

    def now_s(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_out(self, m):
        p = m.pose.pose.position
        self.out.append((stamp_s(m.header), self.now_s(), np.array([p.x, p.y, p.z]), quat_to_R(m.pose.pose.orientation)))

    def on_gt(self, m):
        p = m.pose.pose.position
        self.gt_t.append(stamp_s(m.header))
        self.gt.append((np.array([p.x, p.y, p.z]), quat_to_R(m.pose.pose.orientation)))

    def on_alert(self, m):
        self.alerts.append((self.now_s(), m.data))

    def on_il(self, m):
        if not self.interlock or self.interlock[-1][1] != m.data:
            self.interlock.append((self.now_s(), m.data))

    def on_diag(self, m):
        self.diag.append(m)

    def truth_at(self, t):
        i = bisect.bisect_left(self.gt_t, t)
        if i <= 0 or i >= len(self.gt_t):
            return None
        t0, t1 = self.gt_t[i - 1], self.gt_t[i]
        if t1 - t0 > 0.05:
            return None
        u = (t - t0) / (t1 - t0) if t1 > t0 else 0.0
        p = (1 - u) * self.gt[i - 1][0] + u * self.gt[i][0]
        R = self.gt[i - 1][1] if u < 0.5 else self.gt[i][1]
        return p, R


def pct(a, q):
    return float(np.percentile(a, q)) if len(a) else float('nan')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--duration', type=float, default=20.0)
    ap.add_argument('--warmup', type=float, default=2.0)
    ap.add_argument('--report', default='')
    a = ap.parse_args(rclpy.utilities.remove_ros_args(sys.argv)[1:])
    rclpy.init()
    n = Monitor()
    t_end = time.time() + a.warmup + a.duration
    while time.time() < t_end:
        rclpy.spin_once(n, timeout_sec=0.05)
    t_from = (n.out[0][0] + a.warmup) if n.out else 0
    out = [o for o in n.out if o[0] >= t_from]
    lines = ['# fusion_kpi_monitor 결과', '']
    if len(out) < 2:
        lines.append('출력 수신 없음')
    else:
        st = np.array([o[0] for o in out])
        rv = np.array([o[1] for o in out])
        gaps = np.diff(st) * 1e3
        span = st[-1] - st[0]
        lines += [f'- 수신 {len(out)}건 / {span:.1f} s → **{len(out) / span:.1f} Hz** (stamp 역순 {int((gaps <= 0).sum())}건)',
                  f'- stamp 간격 p50 / p99 / max: {pct(gaps, 50):.2f} / {pct(gaps, 99):.2f} / {gaps.max():.2f} ms, 15 ms 초과 {int((gaps > 15).sum())}건',
                  f'- 수신 지연 (now − stamp) p50 / p99 / max: {pct((rv - st) * 1e3, 50):.3f} / {pct((rv - st) * 1e3, 99):.3f} / {((rv - st) * 1e3).max():.3f} ms']
        ep, er = [], []
        for s, _, p, R in out:
            tr = n.truth_at(s)
            if tr is None:
                continue
            ep.append(np.linalg.norm(p - tr[0]))
            er.append(np.abs(rot_log(R @ tr[1].T)))
        if ep:
            ep = np.array(ep) * 1e3
            er = np.degrees(np.array(er))
            lines += [f'- 위치 오차 (참값 대비, {len(ep)}건) RMSE {math.sqrt((ep ** 2).mean()):.4f} mm, max {ep.max():.4f} mm',
                      f'- 자세 오차 RMSE r/p/y {math.sqrt((er[:, 0] ** 2).mean()):.4f} / {math.sqrt((er[:, 1] ** 2).mean()):.4f} / {math.sqrt((er[:, 2] ** 2).mean()):.4f}°, max {er.max():.4f}°']
        else:
            lines.append('- 참값 토픽 없음 (/sim/ground_truth) → 정밀도 생략')
    if n.diag:
        e2e = np.array([d.e2e_latency_ms for d in n.diag if d.e2e_latency_ms > 0])
        e2emax = np.array([d.e2e_latency_max_ms for d in n.diag if d.e2e_latency_max_ms > 0])
        vp = np.array([d.vision_proc_us for d in n.diag])
        d = n.diag[-1]
        lines += [f'- 진단: mode {d.mode_name}, valid {d.output_valid}, 비전 승인 {d.vision_accepted} / 수신 {d.vision_received}, '
                  f'게이트 기각 {d.vision_rejected_gate}, 재획득 {d.relocks}, IMU {d.imu_rate_hz:.1f} Hz '
                  f'(입력 stamp 공백 > 50 ms {d.imu_gaps}회), 출력 {d.output_rate_hz:.0f} Hz',
                  f'- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): {pct(e2emax, 50):.2f} / {e2emax.max() if len(e2emax) else float("nan"):.2f} ms (최근값 p50 {pct(e2e, 50):.2f})',
                  f'- 비전 처리 (보정+재전파) 최근값 p50 {pct(vp, 50):.1f} µs, 기동 후 최대 {d.max_vision_proc_us:.1f} µs',
                  f'- 바이어스 추정 acc [{d.acc_bias.x:.4f}, {d.acc_bias.y:.4f}, {d.acc_bias.z:.4f}] m/s², '
                  f'gyro [{d.gyro_bias.x:.5f}, {d.gyro_bias.y:.5f}, {d.gyro_bias.z:.5f}] rad/s']
    if n.alerts:
        lines.append('- HMI 경보: ' + ' → '.join(f'{m.split("|")[0]}' for _, m in n.alerts))
    if n.interlock:
        lines.append('- 인터록 전이: ' + ' → '.join(f'{"ON" if v else "OFF"}' for _, v in n.interlock))
    txt = '\n'.join(lines)
    print(txt)
    if a.report:
        with open(a.report, 'w') as f:
            f.write(txt + '\n')
    n.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
