#!/usr/bin/env python3
"""IMU 잡음 파라미터 산출 (설계서 7장 1단계: 바이어스 캘리브레이션) — 정지 상태 장시간 기록의 Allan 분산

  imu_allan_variance.py imu_static.csv [--rate 200] [--plot allan.png]
  imu_allan_variance.py --selftest

CSV: t[s], ax, ay, az [m/s^2], gx, gy, gz [rad/s] (헤더 1줄 허용). 2시간 이상 기록 권장.
rosbag 은 `ros2 topic echo --csv /sub_imu/data > imu.csv` 등으로 변환 후 열 순서를 맞춘다.

출력: sensor_fusion.yaml 의 imu.* 에 붙여넣을 값 (축 중 최댓값, 여유 계수 1.5 적용 권장)
  acc_noise   = 가속도 VRW  N_a  [m/s^2/√Hz]   (τ=1 s, 기울기 −1/2)
  gyro_noise  = 자이로 ARW  N_g  [rad/s/√Hz]
  acc_bias_rw = 가속도 RRW  K_a  [m/s^3/√Hz]   (기울기 +1/2 구간, 없으면 바이어스 불안정성에서 보수적 추정)
  gyro_bias_rw= 자이로 RRW  K_g  [rad/s^2/√Hz]
또한 정지 평균으로 초기 바이어스(자이로)와 중력 크기를 보고한다.
"""
import argparse
import math
import sys

import numpy as np


def allan(x, rate, n_tau=60):
    """overlapping Allan deviation. x: (N,) 각속도/가속도 샘플"""
    N = len(x)
    theta = np.cumsum(x) / rate
    m_max = N // 3
    ms = np.unique(np.logspace(0, math.log10(max(m_max, 2)), n_tau).astype(int))
    taus, devs = [], []
    for m in ms:
        if 2 * m >= N:
            break
        d = theta[2 * m:] - 2 * theta[m:-m] + theta[:-2 * m]
        tau = m / rate
        avar = (d ** 2).sum() / (2 * tau ** 2 * (N - 2 * m))
        taus.append(tau)
        devs.append(math.sqrt(avar))
    return np.array(taus), np.array(devs)


def fit_params(tau, dev):
    """N (−1/2), B (최소), K (+1/2) 추정"""
    lt, ld = np.log10(tau), np.log10(dev)
    slope = np.gradient(ld, lt)
    # N: 기울기 ≈ −0.5 인 구간의 σ√τ 중앙값 (τ=1 s 외삽)
    sel = np.abs(slope + 0.5) < 0.15
    N = float(np.median(dev[sel] * np.sqrt(tau[sel]))) if sel.any() else float(dev[0] * math.sqrt(tau[0]))
    i_min = int(np.argmin(dev))
    B = float(dev[i_min] / 0.664)
    # K: 기울기 ≈ +0.5 구간 σ·√(3/τ)
    selk = (np.abs(slope - 0.5) < 0.2) & (np.arange(len(tau)) > i_min)
    if selk.any():
        K = float(np.median(dev[selk] * np.sqrt(3.0 / tau[selk])))
        k_src = 'slope+1/2'
    else:
        # 기록이 짧아 +1/2 구간이 없으면 바이어스 불안정성이 τ_min 에서 랜덤워크로 도달한다고 보고 보수적으로
        K = float(dev[i_min] * math.sqrt(3.0 / tau[i_min]))
        k_src = 'from bias instability (record too short)'
    return N, B, K, k_src, float(tau[i_min])


def analyze(t, acc, gyr, rate=None, plot=None):
    if rate is None:
        rate = 1.0 / np.median(np.diff(t))
    res = {}
    for name, data in (('acc', acc), ('gyro', gyr)):
        res[name] = []
        for ax in range(3):
            tau, dev = allan(data[:, ax] - data[:, ax].mean(), rate)
            res[name].append(fit_params(tau, dev) + (tau, dev))
    out = {'rate': rate, 'gyro_mean': gyr.mean(axis=0), 'g_norm': float(np.linalg.norm(acc.mean(axis=0)))}
    for name in ('acc', 'gyro'):
        out[name + '_N'] = max(r[0] for r in res[name])
        out[name + '_B'] = max(r[1] for r in res[name])
        out[name + '_K'] = max(r[2] for r in res[name])
        out[name + '_K_src'] = res[name][0][3]
    if plot:
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            fig, axs = plt.subplots(1, 2, figsize=(11, 4))
            for k, name in enumerate(('acc', 'gyro')):
                for i, lab in enumerate('xyz'):
                    axs[k].loglog(res[name][i][5], res[name][i][6], label=lab)
                axs[k].set_title(name + (' [m/s²]' if name == 'acc' else ' [rad/s]'))
                axs[k].set_xlabel('τ [s]')
                axs[k].grid(True, which='both', alpha=.3)
                axs[k].legend()
            fig.tight_layout()
            fig.savefig(plot, dpi=110)
        except ImportError:
            print('matplotlib 없음 → 그래프 생략', file=sys.stderr)
    return out


def report(o, margin=1.5):
    print(f'# rate {o["rate"]:.1f} Hz, |g| {o["g_norm"]:.5f} m/s², 정지 자이로 평균(초기 바이어스) '
          f'[{o["gyro_mean"][0]:.6f}, {o["gyro_mean"][1]:.6f}, {o["gyro_mean"][2]:.6f}] rad/s')
    print(f'# acc : N={o["acc_N"]:.3e} m/s²/√Hz ({o["acc_N"] / 9.80665e-6:.1f} µg/√Hz), B={o["acc_B"]:.3e} m/s², K={o["acc_K"]:.3e} ({o["acc_K_src"]})')
    print(f'# gyro: N={o["gyro_N"]:.3e} rad/s/√Hz ({math.degrees(o["gyro_N"]) * 60:.3f} °/√h), '
          f'B={o["gyro_B"]:.3e} rad/s ({math.degrees(o["gyro_B"]) * 3600:.2f} °/h), K={o["gyro_K"]:.3e} ({o["gyro_K_src"]})')
    print(f'# sensor_fusion.yaml (여유 ×{margin})')
    print('imu:')
    print(f'  acc_noise: {o["acc_N"] * margin:.3e}')
    print(f'  gyro_noise: {o["gyro_N"] * margin:.3e}')
    print(f'  acc_bias_rw: {o["acc_K"] * margin:.3e}')
    print(f'  gyro_bias_rw: {o["gyro_K"] * margin:.3e}')


def selftest():
    rng = np.random.default_rng(0)
    rate, T = 200.0, 3 * 3600.0
    n = int(rate * T)
    Na, Ng, Ka, Kg = 6e-4, 1e-4, 1e-5, 3e-6
    acc = Na * math.sqrt(rate) * rng.standard_normal((n, 3)) + np.cumsum(Ka / math.sqrt(rate) * rng.standard_normal((n, 3)), axis=0)
    acc[:, 2] += 9.80665
    gyr = Ng * math.sqrt(rate) * rng.standard_normal((n, 3)) + np.cumsum(Kg / math.sqrt(rate) * rng.standard_normal((n, 3)), axis=0)
    t = np.arange(n) / rate
    o = analyze(t, acc, gyr, rate)
    ok = True
    for k, ref in (('acc_N', Na), ('gyro_N', Ng), ('acc_K', Ka), ('gyro_K', Kg)):
        err = abs(o[k] / ref - 1)
        tol = 0.15 if k.endswith('_N') else 0.6   # K 는 3 h 기록에서 통계 오차 큼
        print(f'{k}: est {o[k]:.3e} ref {ref:.3e} err {err * 100:.1f} % {"OK" if err < tol else "FAIL"}')
        ok &= err < tol
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('csv', nargs='?')
    ap.add_argument('--rate', type=float, default=None)
    ap.add_argument('--plot', default=None)
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    if not a.csv:
        ap.error('csv 경로 필요')
    d = np.genfromtxt(a.csv, delimiter=',', skip_header=0)
    d = d[~np.isnan(d).any(axis=1)]
    report(analyze(d[:, 0], d[:, 1:4], d[:, 4:7], a.rate, a.plot))


if __name__ == '__main__':
    main()
