# pkg_sensor_fusion — [모듈 3] EKF 센서융합 SW 모듈

손원일급 잠수함 자동 INHAUL 시스템 구축을 위한 3D 위치 데이터 수집 및 분석 SW 개발
주식회사 두리안컴퍼니 · 연구책임자 박완선 · SW총괄 유익수
설계 근거: 연구노트 「SW 개발 설계계획서 — EKF 센서융합 SW 모듈 (pkg_sensor_fusion)」(2026.10.23)

[모듈 2] `pose_estimation_node` 의 비전 6DoF(`/sub_pose_vision`, 30~60 Hz, 6×6 공분산)와 선체 6축 IMU(`/sub_imu/data`, ≥100 Hz)를
**오차상태 확장 칼만 필터(Error-State EKF)** 로 융합해 `dock_world_frame` 기준 `submarine_base_link` 의 위치·자세·속도를
`/sub_pose_filtered` (`nav_msgs/Odometry`, ≥100 Hz) 로 발행합니다. 비전 결손 시 최대 2 s IMU 추측항법으로 연속성을 유지하고,
IMU 유실·추측항법 시간 초과 시 HMI 경보와 속도 인터록을 냅니다. [모듈 1] 동적 ROI 와 [모듈 2] prior 도 이 토픽을 구독합니다.

---

## 1. 구성

```
inhaul_ws/src/
├── inhaul_msgs_patch/                    # inhaul_msgs 0.3.0: FusionDiagnostics.msg 추가 (기존 메시지 변경 없음)
└── pkg_sensor_fusion/
    ├── include/pkg_sensor_fusion/
    │   ├── types.hpp                     # SE(3)/SO(3), 시각(ns), 섭동·공분산 규약 (모듈 2 와 동일)
    │   ├── fusion_config.hpp             # 모든 기본값의 단일 출처
    │   ├── imu_prediction_engine.hpp     # [세부 1] IMUPredictionEngine (중점 적분, Φ, Q)
    │   ├── vision_update_engine.hpp      # [세부 2] VisionUpdateEngine (h(x), H, Joseph 갱신, χ² 게이트)
    │   ├── dropout_fallback_handler.hpp  # [세부 3] 결손 대응 상태기계 + HMI 이벤트
    │   ├── sensor_fusion_engine.hpp      # 상태이력 재전파·초기화·재획득·IMU 결함 처리 (ROS 비의존)
    │   ├── output_scheduler.hpp          # 발행 규칙 (노드·벤치 공용)
    │   ├── sim_world.hpp, sim_runner.hpp # 레일 궤적·IMU·비전 합성 + 시나리오 실행기 (시험·벤치·합성 발행기 공용)
    │   └── sensor_fusion_node.hpp        # ROS2 LifecycleNode (component)
    ├── src/core, src/ros (sensor_fusion_node, synthetic_sensor_publisher)
    ├── config/sensor_fusion.yaml
    ├── launch/sensor_fusion.launch.py    # 단독 / sim:=true (결손·이상치 주입) / composed:=true
    ├── systemd/sensor-fusion.service     # Type=notify, Restart=always, WatchdogSec=1s
    ├── tools/sensor_fusion_bench.cpp     # 설계서 8장 KPI 1~8 계측 (S1~S8 + 민감도)
    ├── tools/fusion_kpi_monitor.py       # ROS 그래프 수준 KPI 계측 (합성 참값 대비)
    ├── tools/imu_allan_variance.py       # 1단계 산출물: IMU 잡음·바이어스 파라미터 산출 (Allan 분산)
    ├── test/test_sensor_fusion.cpp       # gtest 23건
    └── docs/test_reports/                # 벤치(3600 s), ROS 300 s, ROS 결함주입 보고서
```

## 2. 설계계획서 검토 결과

설계서를 [모듈 2] 산출물(공분산 규약·출력 토픽)과 대조하고 구현·시험하면서 확인한 사항입니다.
**[반영]** 은 이번 구현에 반영, **[결정 필요]** 는 연구책임자 / 모듈 2·4·제어 담당 확인이 필요한 것입니다.

### 2.1 수식·알고리즘

| # | 설계서 항목 | 검토 내용 | 조치 |
|---|---|---|---|
| R1 | 4장 1) 예측 단계 수식 | 예측 단계 자리에 **보정 단계와 같은 칼만 이득·갱신 식**이 들어가 있음 (편집 오류로 보임). 예측식·공정잡음 모델이 정의되지 않음 | **[반영]** 중점(midpoint) 적분 명목상태 전파 + 오차상태 Φ ≈ I + AΔt + ½(AΔt)², 연속 잡음밀도 기반 Q (위치·속도 교차항 포함). Φ 는 수치미분과 대조 시험 (`Prediction.TransitionMatchesNumericalJacobian`) |
| R2 | 4장 1) 상태 x = [p, v, q, b_a, b_g] (16) | 쿼터니언 4성분에 직접 공분산을 두면 단위노름 제약 때문에 P 가 특이해지고 갱신 후 정규화가 일관성을 깨뜨림 | **[반영]** 명목상태는 설계서 그대로 16차원, 공분산은 15차원 오차상태 [δp, δv, δθ, δb_a, δb_g] (ESKF). 주입 후 리셋 야코비안 적용 |
| R3 | 4장 2) 관측 모델 h | h 미정의. 비전은 **선체 기준점**, IMU 는 **장착 위치**의 운동을 측정 — 레버암(설계 초기값 0.72 m)을 무시하면 roll 0.5° 에서 약 6 mm 오차. IMU 장착 외부파라미터 항목이 설계서에 없음 | **[반영]** 상태를 IMU 프레임으로 두고 h(x) = T_W→I·T_I→B, H = [I 0 −[R r]× 0 0; 0 0 I 0 0] (수치미분 대조 시험). `imu_extrinsics` 파라미터 신설. **[결정 필요]** IMU 장착 위치·자세 도면값 |
| R4 | 6장 2) tf2 버퍼 보간으로 시간 동기 | tf2 보간은 "과거 시각의 측정을 현재 상태에 적용"하는 문제를 해결하지 못함. 지연 30~45 ms 에서 도착 즉시 적용하면 위치 RMSE **6.5 mm**, NEES 7084, 비전 72 % 게이트 기각 (벤치 S5) | **[반영]** IMU 샘플마다 (상태, P) 스냅샷 보관 → 촬영 시각으로 되돌아가 IMU 보간으로 정확히 그 시각까지 적분 → 갱신 → 현재까지 재전파. 순서 뒤바뀐 측정도 재적용. 같은 조건 RMSE 0.15 mm, NEES 5.5 |
| R5 | 7장 1단계 바이어스 캘리브레이션 | 초기 정지 판정 기준 없음. **IMU 분산만으로는 등속 이동을 정지로 오판** — 개발 중 IMU 400 ms 단절 후 0.2 m/s 주행 중 재초기화에서 v = 0 으로 잘못 초기화 → 0.5 s 기각 후 재획득 발생 | **[반영]** 정지 = IMU 분산 작음 **그리고** 비전 차분 속도 < 15 mm/s. 정지면 b_g = 평균 자이로, b_a = 평균 가속도 − Rᵀ(−g) (비전 자세 사용). 이동 중이면 비전 차분 속도로 초기화. `imu_allan_variance.py` 로 잡음 파라미터 산출 |
| R6 | 4장 3) 결손 판정 Δt > 33 ms | 30 Hz 비전 주기가 33.3 ms 이므로 **매 프레임 사이가 결손으로 판정**됨: 300 s 에 5,398회 오전환 (S1b) | **[반영]** 기본 50 ms (30 Hz 주기 × 1.5). 50 ms 에서 300 s 동안 4회 (지연 지터). **[결정 필요]** 30 Hz 운용이 주라면 60 ms 권장 |
| R7 | 4장 3) "최대 2초" 기준 시점 | 마지막 프레임 간격·처리지연 때문에 2 s 차단에서도 비전 age 가 2.02 s 가 되어 시간초과로 판정됨 | **[반영]** 2 s 는 결손 판정 시점부터 계산 (비전 age 상한 = 50 ms + 2 s) |
| R8 | 4장 3) 2 s 초과 후 동작 | 미정의 | **[반영]** `DR_EXPIRED`: 출력은 계속 발행하되 진단 `output_valid=false`, `ERROR_DR_TIMEOUT`, 인터록 ON. 비전 복귀 시 자동 복구. **[결정 필요]** 출력 중단으로 바꿀지 (제어 모듈 정책) |
| R9 | 4장 2) Mahalanobis 기각 | 필터가 한 번 틀어지면(외부보정 갱신, 장시간 결손 후) 이후 정상 측정이 모두 기각되는 **영구 락아웃** | **[반영]** χ²₆ 99.9 % (22.46) 게이트 + 연속 기각 0.5 s 지속 & 최근 기각 측정 5개가 서로 일관(0.5 m/s, 15 °/s)이면 자세·위치 재설정 (`INFO_VISION_RELOCK`). 20 mm 영구 이동 주입 시험으로 확인. 모듈 2 R8 과 연계해 **게이트 책임은 모듈 3 으로 일원화** 권장 (모듈 2 Mahalanobis 게이트 off 유지) |
| R10 | 6장 1) IMU 50 ms 유실 | "드라이버 노드 레벨" 경보만 규정. 융합 노드의 동작(적분 불가 구간 처리, 복귀) 미정의 | **[반영]** 융합 노드가 수신 기준 50 ms 를 독립 감시 → `IMU_LOST`, `ERROR_IMU_DISCONNECT`, 출력 중단, 인터록 토픽 ON. 복귀 시 공백 ≤ 150 ms 면 선형보간으로 이어 적분, 초과 시 바이어스를 유지한 채 다음 비전으로 재초기화 |
| R11 | 3장 robot_localization 커스터마이징 | r_l `ekf_node` 는 RPY 상태, IMU 를 측정으로 취급(가속도를 제어입력으로 쓰지 않음), 가속도 바이어스 추정·레버암 미지원 → 2 s 추측항법 KPI 에 불리 | **[반영]** Eigen 고정크기 커스텀 ESKF (의존성 Eigen 만, 결정적 실행시간). r_l 기반 대조 설정은 만들지 않음 |

### 2.2 인터페이스·모듈 간 정합

| # | 항목 | 검토 내용 | 조치 |
|---|---|---|---|
| I1 | 비전 frame_id | 모듈 2 I3 (`dock` vs `dock_world_frame`) 미결 | **[반영]** `world_frame` 과 다른 frame 의 비전은 기각 + 1회 경고 |
| I2 | 공분산 회전 성분 규약 | 모듈 2 I7 [결정 필요] — 모듈 3 이 맞춰야 할 쪽 | **[반영]** 모듈 2 와 같은 월드 고정축 소회전 R = Exp(δθ)·R̂, 순서 [x,y,z,rx,ry,rz] 로 구현. 잔차·H·출력 공분산 모두 같은 정의 → **모듈 2 I7 은 이 규약으로 확정 제안** |
| I3 | `twist.twist` 좌표계 | 설계서 "선체 선형 속도". nav_msgs/Odometry 규약상 twist 는 `child_frame_id`(선체) 좌표 | **[반영]** 선체 좌표 선속도(레버암 ω×r 보정)·각속도. 월드 속도가 필요하면 pose 회전으로 변환 |
| I4 | 출력 주기 vs 지연 | "100 Hz" 와 "지연 < 10 ms" 가 충돌: 100 Hz 정주기만 쓰면 비전 반영까지 최대 10 ms 대기 (방식 A e2e max 13.9 ms) | **[반영]** 기본 = 100 Hz 정규 출력 + 비전 반영 직후 추가 발행 (stamp ≤ 최신 IMU + IMU 주기/2 로 단조 증가 보장, 약 156 Hz 불규칙). `output.on_vision_update: false` 면 정확히 100 Hz. **[결정 필요]** 모듈 4 궤적분석이 불규칙 주기를 받는지 |
| I5 | 진단·경보·인터록 인터페이스 | 설계서에 HMI 경고 플래그·속도 인터록 토픽 정의 없음 | **[반영]** `/sensor_fusion/diagnostics` (`inhaul_msgs/FusionDiagnostics`, 신규), `/hmi/fusion_alerts` (`코드\|정보`), `/sensor_fusion/safety_interlock` (`std_msgs/Bool`, latched, true = 속도 지령 0). **[결정 필요]** 제어 모듈의 인터록 수신 방식 |
| I6 | IMU 타임스탬프 | 비전은 PTP 촬영시각인데 IMU stamp 의 시계가 정의되지 않음 | **[반영]** 같은 PTP 공통시계 가정, 고정 오프셋 `imu.time_offset_s`. **[결정 필요]** IMU 기종·드라이버의 stamp 방식 (수신시각이면 지터가 생기며 온라인 시간오프셋 추정이 필요) |
| I7 | 출력 header.stamp | "실시간 최신 시각" | 정규 출력 = 최신 IMU 샘플 시각, 추가 출력 = 그 직후 외삽 시각 (같은 PTP 시계) |

### 2.3 KPI 정의 검토

| # | KPI | 검토 내용 | 제안 |
|---|---|---|---|
| K1 | 6. 2 s 드리프트 ≤ 1 % | 이동거리 대비 비율은 **저속·반환점에서 의미를 잃음**: 같은 오차 5.3 mm 가 0.1 m 이동 시 5 % 가 됨 (S2 전 구간 최대 5.06 %) | 평균 ≥ 0.2 m/s (2 s 동안 ≥ 0.4 m) 구간으로 판정하거나, 절대 오차 ≤ 5 mm (KPI 2 와 같은 한계) 병행 |
| K2 | 7. 재수렴 ±2σ ≤ 100 ms | "수렴"의 정의가 없음. 위치 σ 는 첫 프레임에서 2.6 → 0.29 mm 로 바로 떨어지지만, **속도 오차 재수렴이 정보량에 묶여** 결손 전 σ 의 110 % 이내로는 약 300 ms 걸림 (필터 문제가 아니라 비전 잡음·프레임률 한계) | 절대 기준 "2σ ≤ 0.5 mm" (KPI 2 의 1/10) 로 정의 → 최대 62 ms (60 Hz) / 91 ms (30 Hz) |
| K3 | 8. >3σ 이상치 100 % 기각 | **통계적으로 성립하지 않음**: 한 축 3σ 점프는 d² ≈ 9 + χ²₅ 로 정상 범위와 겹침 → χ²₆ 99.9 % 게이트에서 8 % 만 기각. 100 % 로 만들려면 게이트를 낮춰 정상 측정 오기각이 폭증. 기각되지 않은 3σ 점프의 영향은 σ 수준 (위치 max 0.47 mm), 발산 0 | "한 축 ≥ 8σ 또는 6축 동시 ≥ 3σ 이상치 기각 ≥ 99 %, 실이상치(반사·Flip) 100 %, 발산 0건" |
| K4 | 4. 엔드투엔드 < 10 ms | 촬영 → 발행에는 모듈 1 (목표 HW 평균 ≤ 4 ms) + 모듈 2 + DDS 가 포함. 모듈 3 추가분은 p99 2.2 ms | 상류 예산(모듈 1·2 ≤ 7.5 ms)을 함께 명시 |
| K5 | 6. 드리프트의 **IMU 등급 의존** | 2 s 추측항법 오차는 자이로 ARW(기울기 → 중력 누설)와 가속도 VRW 가 지배하고, 비전 정밀도 영향은 작음 (민감도 표) | **IMU 선정 요구사항 명시**: 자이로 ARW ≤ 0.1 °/√h (3e-5 rad/s/√Hz), 가속도 ≤ 30 µg/√Hz 급이면 최대 0.5 % 이하 |

## 3. 처리 구조 (설계서 4장 구현)

```
/sub_imu/data (Imu, ≥100 Hz)                         /sub_pose_vision (PoseWithCov, 30~60 Hz, PTP 촬영 stamp)
   │ 유효성: NaN·포화·역순/중복 stamp 기각                 │ frame_id·NaN·쿼터니언 노름 검사, 공분산 정리(×scale, PSD 절단, 하한 가산)
   ▼                                                   ▼
[세부 1] IMUPredictionEngine                         초기화 전 → 후보 누적 → 정지판정(IMU 분산 + 비전 속도) → 상태·P 초기화
   중점 적분: R⁺ = R·Exp((ω−b_g)Δt), v⁺ = v + (R_mid(a−b_a)+g)Δt                │
   P⁺ = Φ P Φᵀ + Q  →  (상태, P, IMU) 스냅샷 이력 (0.5 s 링버퍼, 동적할당 없음)     ▼
   │                                            t_v ≤ 최신 IMU: 스냅샷 k(t_k ≤ t_v) 로 되돌림 → t_v 까지 보간 적분
   │                                            t_v > 최신 IMU: 보류 (최대 30 ms, 만료 시 0차 외삽)
   │                                                   ▼
   │                                    [세부 2] VisionUpdateEngine: r = [p_m − p̂_B ; Log(R_m R̂_Bᵀ)]
   │                                       d² = rᵀS⁻¹r > 22.46 → 기각 (0.5 s 연속·일관 → 재획득)
   │                                       K = PHᵀS⁻¹, Joseph 갱신, 오차 주입·리셋 → 이후 IMU 로 현재까지 재전파
   ▼                                                   │
[세부 3] DropoutFallbackHandler: TRACKING ↔ DEAD_RECKONING(age>50 ms) → DR_EXPIRED(>2 s) / IMU_LOST(>50 ms)
   ▼
OutputScheduler: 100 Hz 정규 + 비전 반영 직후 → /sub_pose_filtered (Odometry, frame dock_world_frame, child submarine_base_link)
                 /sensor_fusion/diagnostics (10 Hz), /hmi/fusion_alerts (전이 시), /sensor_fusion/safety_interlock (latched)
```

### 좌표·데이터 계약
- 입력 비전 = 모듈 2 출력 그대로: T_W→B, 공분산 [x,y,z,rx,ry,rz], 회전 = 월드 고정축 소회전, stamp = 촬영 PTP 시각.
- IMU: 비력(중력 포함) [m/s²], 각속도 [rad/s], IMU 프레임. 장착 = `imu_extrinsics` (IMU 원점의 선체 좌표, R_B←I 의 ZYX rpy).
- 중력 `gravity` 기본 [0, 0, −9.80665] (dock_world_frame Z-up 가정).
- 출력 pose 공분산 = 위 비전 규약과 동일, twist 공분산 = 선체 좌표 [vx,vy,vz,wx,wy,wz].

## 4. 빌드

```bash
# 의존성 (Ubuntu 22.04 + ROS2 Humble)
sudo apt install ros-humble-rclcpp-components ros-humble-tf2-ros ros-humble-rmw-cyclonedds-cpp libeigen3-dev
# inhaul_msgs 0.3.0: inhaul_msgs_patch/README.md 대로 FusionDiagnostics.msg 추가
cd inhaul_ws && colcon build --merge-install --packages-up-to pkg_sensor_fusion --cmake-args -DCMAKE_BUILD_TYPE=Release
colcon test --merge-install --packages-select pkg_sensor_fusion && colcon test-result --verbose

# ROS 없이 코어/시험/벤치만 (알고리즘 개발·CI)
cmake -S src/pkg_sensor_fusion -B build_core -DPSF_CORE_ONLY=ON && cmake --build build_core -j && ctest --test-dir build_core
./build_core/sensor_fusion_bench --s1-duration 3600 --report bench.md     # --quick: 1분 내 요약
```

## 5. 실행

```bash
# 합성 IMU·비전과 함께 (모듈 2·IMU 없이 노드 전체 검증)
ros2 launch pkg_sensor_fusion sensor_fusion.launch.py sim:=true \
    [sim_vision_blackout_start:=14 sim_vision_blackout_duration:=2] [sim_imu_blackout_start:=12 sim_imu_blackout_duration:=0.08] \
    [sim_outlier_prob:=0.05] [sim_vision_rate:=30 sim_imu_rate:=100]
ros2 run pkg_sensor_fusion fusion_kpi_monitor.py --duration 30          # 참값 대비 오차·발행률·지연·경보

# 실운용 (모듈 2 /sub_pose_vision, IMU 드라이버 /sub_imu/data 발행 중)
ros2 launch pkg_sensor_fusion sensor_fusion.launch.py
ros2 launch pkg_sensor_fusion sensor_fusion.launch.py composed:=true     # 컨테이너 (라이프사이클 외부 전이)
ros2 lifecycle set /sensor_fusion_node configure && ros2 lifecycle set /sensor_fusion_node activate

ros2 topic echo /sensor_fusion/diagnostics   # mode, d², 바이어스, σ, e2e 지연, 처리시간, rpy_deg
ros2 topic echo /hmi/fusion_alerts           # WARN_VISION_DROPOUT / INFO_VISION_RECOVERED / ERROR_IMU_DISCONNECT ...

# IMU 잡음 파라미터 (1단계): 정지 상태 2 h 이상 기록 → CSV(t,ax,ay,az,gx,gy,gz)
ros2 run pkg_sensor_fusion imu_allan_variance.py imu_static.csv --plot allan.png   # yaml imu.* 값 출력
```

운영 배포: `systemd/sensor-fusion.service` (Type=notify, `Restart=always`, `RestartSec=100ms`, `WatchdogSec=1s`,
SCHED_FIFO 75, 모듈 1·2 와 다른 코어). watchdog 은 노드 실행기의 진단 타이머가 송출하므로 콜백이 멈추면 1 s 후 재기동됩니다.

## 6. 인터페이스

| 구분 | 토픽 / 파일 | 타입 | 비고 |
|---|---|---|---|
| 입력 | `/sub_imu/data` | `sensor_msgs/Imu` | best_effort, depth 50 (reliable 발행자도 수신). 자세·공분산 필드는 사용 안 함 |
| 입력 | `/sub_pose_vision` | `geometry_msgs/PoseWithCovarianceStamped` | reliable (모듈 2 QoS). frame_id ≠ world_frame 이면 기각 |
| 출력 | `/sub_pose_filtered` | `nav_msgs/Odometry` | frame `dock_world_frame`, child `submarine_base_link`, pose·twist 6×6 공분산 |
| 출력 | `/sensor_fusion/diagnostics` | `inhaul_msgs/FusionDiagnostics` (신규) | 10 Hz. mode, valid, interlock, 비전 age, d², 카운터, 처리시간, e2e 지연, 바이어스, σ, rpy |
| 출력 | `/hmi/fusion_alerts` | `std_msgs/String` | `코드\|정보`, 상태 전이 시 1회 |
| 출력 | `/sensor_fusion/safety_interlock` | `std_msgs/Bool` | transient_local. true = 속도 지령 0 (미초기화·IMU_LOST·DR_EXPIRED), 10 Hz 하트비트 |
| 출력(선택) | TF | `dock_world_frame → submarine_base_link` | `publish_tf: true` |
| 설정 | `config/sensor_fusion.yaml` | | ★ `imu_extrinsics`, `imu.*` 는 설계 초기값 — 도면·Allan 분산 결과로 교체 |

경보 코드: `INFO_FUSION_INITIALIZED`, `WARN_VISION_DROPOUT`, `INFO_VISION_RECOVERED`, `ERROR_DR_TIMEOUT`,
`ERROR_IMU_DISCONNECT`, `INFO_IMU_RECOVERED`, `WARN_FUSION_REINIT`, `INFO_VISION_RELOCK`.

## 7. 예외 처리 (설계서 4장 3), 6장)

| 요구 | 구현 | 검증 |
|---|---|---|
| 비전 결손 → IMU 추측항법 | 승인 비전 age > 50 ms → `DEAD_RECKONING` (출력 유지, `WARN_VISION_DROPOUT`), 결손 2 s 초과 → `DR_EXPIRED` (출력 유지·valid false·인터록), 복귀 시 `INFO_VISION_RECOVERED` | `Dropout.*` 2건, 벤치 S2(32회), ROS 2 s/3 s 차단 |
| 비말·반사 이상치 | χ²₆ 99.9 % 게이트, 0.5 s 연속·일관 기각 시 재획득 | `Outlier.*` 3건, 벤치 S3, ROS 5 % 주입 |
| IMU 50 ms 유실 | 수신 감시 → `IMU_LOST`·`ERROR_IMU_DISCONNECT`·출력 중단·인터록, ≤150 ms 보간 연결 / 초과 시 바이어스 유지 재초기화 | `ImuFault.*` 3건, 벤치 S6, ROS 80 ms / 400 ms |
| 비전-IMU 시간차 | 상태이력 재전파 (0.5 s), 보류·만료 외삽, 순서 뒤바뀜 재적용, 이력보다 오래된 측정 기각 | `TimeSkew.*` 3건, 벤치 S5 |
| 입력 이상 | NaN, 포화, 역순·중복 stamp, 비정상 공분산(PSD 절단), 공분산 미기재(기본값) | `Input.*` 2건 |
| 자가 복구 | 프로세스 종료 → systemd 재기동, 콜백 정지 → watchdog, on_error → 종료코드 4 | composed 모드 시험 중 실제 on_error → 종료코드 4 확인 (아래 8.4-3) |

## 8. 시험 결과 (2026-11-20, 개발 컨테이너: Xeon **2 vCPU**, 실시간 커널 아님, 합성 데이터)

시험 조건: 레일 2.5 m 왕복(최고 0.3 m/s) + 부유 미소운동, IMU 레버암 (0.60, −0.15, −0.35) m·Z 90° 장착,
**IMU = 산업용 MEMS 급 가정** (6e-4 m/s²/√Hz, 1e-4 rad/s/√Hz, 초기 바이어스 ~10 mg·~0.1°/s),
비전 σ 0.15/0.15/0.40 mm·0.010/0.010/0.004° (모듈 2 S7 σ0.2 mm 조건 수준), 상류 지연 3~7 ms.

### 8.1 KPI 벤치 (`docs/test_reports/bench_s1_3600s.md`)

| # | KPI | 목표 | 결과 | 판정 |
|---|---|---|---|---|
| 1 | 갱신 주파수 | ≥ 100 Hz, 드롭 0 % | 정규 100.00 Hz, 드롭 0 %, 간격 max 10.33 ms (**3600 s**) + 비전 직후 출력 포함 155.8 Hz | 충족 |
| 2 | 위치 RMSE | ≤ 5.0 mm | **0.140 mm** (max 0.53), 30 Hz/100 Hz 조건 0.181 mm | 충족 |
| 3 | 자세 RMSE | ≤ 0.2° | **0.0027 / 0.0027 / 0.0017°** (r/p/y) | 충족 |
| 4 | 엔드투엔드 지연 | < 10 ms | p50 5.41 / p99 6.98 / max 7.02 ms, **모듈 3 추가분 p99 2.2 ms** | 충족 (상류 ≤ 7 ms 가정, K4) |
| 5 | 예측+보정 1사이클 | ≤ 1.5 ms | p50 **15 µs** / p99 31 µs / max 2.6 ms | p99 충족, max 는 공유 vCPU 선점 (목표 HW 재측정) |
| 6 | 2 s 결손 드리프트 | ≤ 1.0 % | 이동 ≥ 0.4 m 구간 중앙 **0.73 %** / 최대 1.26 %, 절대 최대 5.3 mm | **중앙값만 충족** — IMU 등급 의존 (8.2) |
| 7 | 재수렴 | ≤ 100 ms | 2σ ≤ 0.5 mm 기준 최대 62 ms (30 Hz 91 ms) / 결손 전 σ 110 % 기준 296 ms | **정의 의존** (K2) |
| 8 | 이상치 기각 | 100 %, 발산 0 | 반사 5 mm·20 mm, Flip 5° **1173/1173 기각**, 6축 3σ 99.2 %, 한 축 3σ 8 %, 발산 0 | 실이상치 충족, ">3σ" 문구는 K3 |

시나리오 요약 (상세는 보고서):

| 시나리오 | 결과 |
|---|---|
| S1 3600 s 정상 | NEES 평균 **5.62** (기대 6), χ²₆ 95 % 이내 96.4 %, 정상 측정 오기각 75 / 215,969 (0.035 %), 재전파 최대 2 스텝 |
| S1b 비전 30 Hz / IMU 100 Hz | 위치 RMSE 0.074/0.074/0.148 mm, 결손 오판정 50 ms 기준 4회 vs 설계서 33 ms 기준 **5,398회** (R6) |
| S2 2 s 결손 ×32 | 결손 종료 오차 중앙 3.1 mm / 최대 5.3 mm, `ERROR_DR_TIMEOUT` 0회 |
| S4 단일 태그 구간 | 위치 RMSE 0.94 mm (max 2.3 mm), NEES 7.7 — 모듈 2 R4 의 낙관적 꼬리를 게이트가 흡수 (기각 2.2 %) |
| S5 지연 30~45 ms | 재전파 0.154 mm / NEES 5.5 vs 도착 즉시 적용 6.5 mm / NEES 7084 (R4) |
| S6 IMU 단절 80 / 400 ms | 보간 연결 / 바이어스 유지 재초기화 0.1 s 내 복귀, 복귀 후 RMSE 0.17 / 0.14 mm |
| S8 공분산 과소보고 (σ ½) | NEES 14.1, 게이트 기각 22 % → `vision.cov_scale: 4` 로 NEES 5.3, 기각 0.03 % (테스트베드 보정 절차의 근거) |

### 8.2 KPI 6 민감도 — 2 s 드리프트 비율 중앙 / 최대 (이동 ≥ 0.4 m, 17회)

| 비전 정밀도 \ IMU | 전술급 (1.5e-4 / 1e-5) | 고급 MEMS (3e-4 / 3e-5) | 산업용 MEMS (6e-4 / 1e-4, 기본) | 소비자급 (1.7e-3 / 2.4e-4) |
|---|---|---|---|---|
| 모듈 2 S1 합성 수준 | 0.09 / 0.19 % | 0.17 / 0.40 % | 0.42 / 0.91 % | 0.88 / 2.27 % |
| 중간 (0.05/0.15 mm, 0.004°) | 0.10 / 0.20 % | 0.19 / 0.39 % | 0.38 / 0.92 % | 0.89 / 2.38 % |
| 기본 (0.15/0.40 mm, 0.010°) | 0.16 / 0.25 % | 0.24 / 0.47 % | 0.46 / 0.99 % | 1.00 / 2.49 % |

(괄호: 가속도 m/s²/√Hz / 자이로 rad/s/√Hz). 행(비전)보다 열(IMU)의 영향이 압도적입니다. 2 s 오차의 분해:
자이로 ARW 1e-4 → 기울기 랜덤워크의 중력 누설 g·σ_g·t^2.5/√20 ≈ 1.2 mm/축, 가속도 VRW 6e-4 → σ_a·t^1.5/√3 ≈ 1.0 mm/축,
결손 직전 속도 불확실성 ~0.9 mm/s × 2 s ≈ 1.8 mm. **고급 MEMS 이상이면 모든 비전 조건에서 최대 0.5 % 이하**입니다.
(S2 단독 실행 최대 1.26 % 와 민감도 표 0.99 % 의 차이는 결손 횟수·난수 시드 차이입니다.)

### 8.3 ROS 노드 실행 (RoboStack ROS2 Humble, CycloneDDS, synthetic_sensor_publisher IMU 200 Hz / 비전 60 Hz)

| 항목 | 결과 |
|---|---|
| colcon build (inhaul_msgs 스텁, pkg_sensor_fusion) | 컴파일 경고 0 (`-Wall -Wextra -Wpedantic`) |
| colcon test | 24건 (gtest 23 + ctest 1) 통과 / 0 실패 |
| `fusion_kpi_monitor` **300 s** (`ros_kpi_monitor_300s.md`) | 155.5 Hz, stamp 역순 0, 위치 RMSE **0.139 mm** (max 0.43), 자세 RMSE 0.0027/0.0029/0.0018°, 수신지연 p50 0.84 / p99 3.2 ms, e2e p50 5.7 ms |
| 2 s 비전 차단 (30 s) | `WARN_VISION_DROPOUT` → `INFO_VISION_RECOVERED`, 결손 중 max 1.76 mm, 인터록 OFF 유지 |
| 3 s 비전 차단 | `WARN_VISION_DROPOUT` → `ERROR_DR_TIMEOUT` → `INFO_VISION_RECOVERED`, 인터록 OFF → ON → OFF |
| IMU 80 ms / 400 ms 단절 | `ERROR_IMU_DISCONNECT` → (`WARN_FUSION_REINIT`) → `INFO_IMU_RECOVERED`, 인터록 ON → OFF, 복귀 후 RMSE 0.14 mm |
| 이상치 5 % (5 mm) | 게이트 기각 66 / 1366, 위치 max 0.43 mm |
| 비전 30 Hz / IMU 100 Hz | 111.6 Hz, RMSE 0.19 mm |
| 라이프사이클 | active 153 Hz → deactivate 0 Hz → activate (재초기화 후) 정상 |
| `composed:=true` | 외부 configure/activate 후 133 Hz (3 s 창에 초기화 포함) |

### 8.4 개발 중 발견·반영한 사항
1. **설계서 예측식 자리의 갱신식 (R1)** — 예측 모델·Q 를 새로 정의하고 Φ 를 수치미분으로 검증.
2. **IMU 분산만의 정지 판정이 등속 주행을 정지로 오판 (R5)** — 400 ms IMU 단절 시나리오에서 재현(0.5 s 기각 후 재획득). 비전 변위 조건 추가 후 재획득 없이 0.1 s 내 복귀.
3. **intra-process 와 transient_local 비호환** — `composed:=true` 에서 latched 인터록 발행자 생성이 실패해 on_error → 종료코드 4 로 컨테이너가 내려감 (자가복구 경로는 설계대로 동작). 이 발행자만 intra-process 비활성으로 수정.
4. **비전 직후 발행이 정규 출력 stamp 를 앞질러 정규 출력이 0.8 % 누락** — 외삽 상한을 최신 IMU + 주기/2 로 제한해 드롭 0 %.
5. **IMU 없이 외삽 연쇄** — 보류 비전 만료 시 0차 외삽이 IMU 유실 중에도 계속 이어지는 결함을 시험으로 발견, 마지막 실측 IMU 기준 30 ms 이내로 제한.
6. **보류(PENDING) 측정의 결과 추적 누락** — 비전이 해당 시각의 IMU 보다 먼저 도착하면 보류 후 반영되는데, 이 결과가 벤치에 집계되지 않아 이상치 기각률이 낮게 나오던 계측 오류를 수정 (엔진 `takeVisionOutcomes()` 추가, 노드도 같은 경로로 비전 직후 발행).

## 9. 한계 및 실장비 검증 필요 사항 (정직 고지)

- **모든 정밀도 수치는 합성 데이터 기준입니다.** IMU 잡음은 백색+랜덤워크 모델이며 진동·온도 드리프트·눈금계수·축 비정렬이 없습니다.
  비전 오차는 가우시안이고 보고 공분산이 참이라고 가정했습니다 (S8 은 과소보고 영향만 확인). 5단계 레일 엔코더 비교로 확정해야 합니다.
- **IMU 기종이 정해지지 않았습니다.** `imu.*` 잡음 파라미터와 KPI 6 판정은 IMU 등급에 직접 좌우됩니다(8.2). 선정 후 `imu_allan_variance.py` 로 파라미터를 산출하십시오.
  눈금계수·축 비정렬 오차는 상태에 넣지 않았습니다 — 산업용 MEMS 의 0.1~0.3 % 눈금계수 오차는 0.07 m/s² 가속 구간에서 무시 가능하나, 실측 후 판단이 필요합니다.
- `imu_extrinsics`(레버암·장착 회전)는 **설계 초기값**입니다. 회전 오차 0.1° 는 가속 구간에서 약 0.1 mm/s² 바이어스처럼 작용하며 필터가 일부 흡수합니다. 온라인 외부파라미터 추정은 미구현입니다.
- **IMU–비전 시간 오프셋 온라인 추정은 미구현**입니다 (고정 `imu.time_offset_s`). IMU stamp 가 PTP 공통시계가 아니면 0.3 m/s × 오프셋만큼 위치 편향이 생깁니다.
- 지연·연산시간 KPI 는 2 vCPU 컨테이너 결과입니다. ROS 300 s 실행에서 **합성 발행기 타이머가 2회 50 ms 이상 멈춰**(입력 stamp 공백, 진단 `imu_gaps=2`) 실제로 `ERROR_IMU_DISCONNECT` 가 발생했고 e2e 최대가 68 ms 로 나왔습니다 — 융합 노드가 아닌 입력 측 정지를 정상 검출한 것이나, 목표 엣지PC(Preempt-RT, 전용 코어)에서 재측정이 필요합니다.
- DR_EXPIRED 중에도 Odometry 를 발행합니다 (진단 `output_valid=false`, 인터록 ON). Odometry 자체에는 유효 플래그가 없으므로 하류는 진단/인터록을 함께 봐야 합니다 (R8 결정 필요).
- 개발 빌드는 RoboStack(conda) 환경 한정 우회(`empy 3.3.4` 고정, gtest 용 `-include cstdint`)를 썼고, `inhaul_msgs` 는 FusionDiagnostics 만 담은 **스텁**으로 빌드했습니다. 실제 모듈 1·2 워크스페이스의 `inhaul_msgs` 와의 통합 빌드, 모듈 2 실출력과의 연동은 미시험입니다.

## 10. 설계서 일정 대비 진행

| 단계 | 산출물 | 상태 |
|---|---|---|
| 1단계 (M1~M2) | IMU 노드 패키지, 바이어스 캘리브레이션, EKF 설정 구조안 | 설정 구조(`sensor_fusion.yaml`), 정지 바이어스 초기 추정, Allan 분산 도구 완료. **IMU 드라이버는 기종 미정으로 미착수** |
| 2단계 (M3~M4) | 시간 동기 버퍼, 예측·갱신 루프, sensor_fusion_node 알파 | 상태이력 재전파, ESKF, LifecycleNode/component/systemd 완료 |
| 3단계 (M5~M6) | Dead-Reckoning 전환, Mahalanobis Gating, 단위시험 보고서 | 결손 상태기계, 게이트+재획득, gtest 23건, 벤치 보고서 완료 |
| 4단계 (M7~M9) | 실시간 커널 지연 < 10 ms 검증, 궤적분석 모듈 연동 | 지연 계측 도구(벤치·진단·모니터) 완료. **목표 HW 측정·모듈 4 연동 미착수** |
| 5단계 (M10~M12) | 테스트베드 실증, 성적서 | 미착수 |
