cmake_minimum_required(VERSION 3.16)
project(pkg_sensor_fusion VERSION 0.1.0 LANGUAGES CXX)

option(PSF_CORE_ONLY "ROS 없이 코어/시험/벤치만 빌드 (알고리즘 개발·CI)" OFF)
option(PSF_NATIVE_ARCH "-march=native (목표 엣지PC 에서만)" OFF)

if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
add_compile_options(-Wall -Wextra -Wpedantic)
if(PSF_NATIVE_ARCH)
  add_compile_options(-march=native)
endif()

find_package(Eigen3 3.3 REQUIRED NO_MODULE)

# ---------------------------------------------------------------- core (ROS 비의존)
add_library(psf_core STATIC
  src/core/imu_prediction_engine.cpp
  src/core/vision_update_engine.cpp
  src/core/dropout_fallback_handler.cpp
  src/core/sensor_fusion_engine.cpp)
target_include_directories(psf_core PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)
target_link_libraries(psf_core PUBLIC Eigen3::Eigen)

add_executable(sensor_fusion_bench tools/sensor_fusion_bench.cpp)
target_link_libraries(sensor_fusion_bench psf_core)

if(PSF_CORE_ONLY)
  enable_testing()
  find_package(GTest REQUIRED)
  add_executable(test_sensor_fusion test/test_sensor_fusion.cpp)
  target_link_libraries(test_sensor_fusion psf_core GTest::gtest_main)
  add_test(NAME test_sensor_fusion COMMAND test_sensor_fusion)
  return()
endif()

# ---------------------------------------------------------------- ROS 2
find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(rclcpp_lifecycle REQUIRED)
find_package(rclcpp_components REQUIRED)
find_package(lifecycle_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(sensor_msgs REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(tf2_ros REQUIRED)
find_package(inhaul_msgs REQUIRED)

set(ROS_DEPS rclcpp rclcpp_lifecycle rclcpp_components lifecycle_msgs geometry_msgs sensor_msgs
    nav_msgs std_msgs tf2_ros inhaul_msgs)

add_library(sensor_fusion_component SHARED src/ros/sensor_fusion_node.cpp)
target_link_libraries(sensor_fusion_component psf_core)
ament_target_dependencies(sensor_fusion_component ${ROS_DEPS})
rclcpp_components_register_node(sensor_fusion_component
  PLUGIN "psf::SensorFusionNode" EXECUTABLE sensor_fusion_node)

add_library(synthetic_sensor_component SHARED src/ros/synthetic_sensor_publisher.cpp)
target_link_libraries(synthetic_sensor_component psf_core)
ament_target_dependencies(synthetic_sensor_component ${ROS_DEPS})
rclcpp_components_register_node(synthetic_sensor_component
  PLUGIN "psf::SyntheticSensorPublisher" EXECUTABLE synthetic_sensor_publisher)

install(TARGETS psf_core sensor_fusion_component synthetic_sensor_component
  EXPORT export_${PROJECT_NAME}
  ARCHIVE DESTINATION lib LIBRARY DESTINATION lib RUNTIME DESTINATION bin)
install(TARGETS sensor_fusion_bench RUNTIME DESTINATION lib/${PROJECT_NAME})
install(DIRECTORY include/ DESTINATION include)
install(DIRECTORY config launch systemd DESTINATION share/${PROJECT_NAME})
install(PROGRAMS tools/fusion_kpi_monitor.py tools/imu_allan_variance.py DESTINATION lib/${PROJECT_NAME})

if(BUILD_TESTING)
  find_package(ament_cmake_gtest REQUIRED)
  ament_add_gtest(test_sensor_fusion test/test_sensor_fusion.cpp TIMEOUT 300)
  target_link_libraries(test_sensor_fusion psf_core)
endif()

ament_export_include_directories(include)
ament_export_targets(export_${PROJECT_NAME} HAS_LIBRARY_TARGET)
ament_export_dependencies(Eigen3)
ament_package()
