"""[모듈 3] sensor_fusion_node 실행

  ros2 launch pkg_sensor_fusion sensor_fusion.launch.py                 # 단독 (모듈 2 + IMU 드라이버 발행 중)
  ros2 launch pkg_sensor_fusion sensor_fusion.launch.py sim:=true       # 합성 IMU·비전 발행기와 함께
      sim_vision_blackout_start:=10.0 sim_vision_blackout_duration:=2.0 sim_imu_blackout_start:=-1 sim_outlier_prob:=0.0
  ros2 launch pkg_sensor_fusion sensor_fusion.launch.py composed:=true  # 컴포넌트 컨테이너 (라이프사이클은 외부 전이)
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import ComposableNodeContainer, LifecycleNode, Node
from launch_ros.descriptions import ComposableNode


def generate_launch_description():
    share = get_package_share_directory('pkg_sensor_fusion')
    params = os.path.join(share, 'config', 'sensor_fusion.yaml')
    sim = LaunchConfiguration('sim')
    composed = LaunchConfiguration('composed')
    args = [
        DeclareLaunchArgument('sim', default_value='false'),
        DeclareLaunchArgument('composed', default_value='false'),
        DeclareLaunchArgument('params', default_value=params),
        DeclareLaunchArgument('sim_vision_blackout_start', default_value='-1.0'),
        DeclareLaunchArgument('sim_vision_blackout_duration', default_value='2.0'),
        DeclareLaunchArgument('sim_vision_blackout_period', default_value='0.0'),
        DeclareLaunchArgument('sim_imu_blackout_start', default_value='-1.0'),
        DeclareLaunchArgument('sim_imu_blackout_duration', default_value='0.08'),
        DeclareLaunchArgument('sim_outlier_prob', default_value='0.0'),
        DeclareLaunchArgument('sim_vision_rate', default_value='60.0'),
        DeclareLaunchArgument('sim_imu_rate', default_value='200.0'),
        SetEnvironmentVariable('RMW_IMPLEMENTATION', 'rmw_cyclonedds_cpp'),
    ]
    p = LaunchConfiguration('params')
    sim_params = [p, {
        'vision_blackout_start': LaunchConfiguration('sim_vision_blackout_start'),
        'vision_blackout_duration': LaunchConfiguration('sim_vision_blackout_duration'),
        'vision_blackout_period': LaunchConfiguration('sim_vision_blackout_period'),
        'imu_blackout_start': LaunchConfiguration('sim_imu_blackout_start'),
        'imu_blackout_duration': LaunchConfiguration('sim_imu_blackout_duration'),
        'outlier_prob': LaunchConfiguration('sim_outlier_prob'),
        'vision_rate_hz': LaunchConfiguration('sim_vision_rate'),
        'imu_rate_hz': LaunchConfiguration('sim_imu_rate'),
    }]

    fusion = LifecycleNode(
        package='pkg_sensor_fusion', executable='sensor_fusion_node', name='sensor_fusion_node',
        namespace='', parameters=[p], output='screen', condition=UnlessCondition(composed))
    synth = Node(
        package='pkg_sensor_fusion', executable='synthetic_sensor_publisher',
        name='synthetic_sensor_publisher', parameters=sim_params, output='screen',
        condition=IfCondition(sim))
    container = ComposableNodeContainer(
        name='inhaul_fusion_container', namespace='', package='rclcpp_components',
        executable='component_container', output='screen', condition=IfCondition(composed),
        composable_node_descriptions=[
            ComposableNode(package='pkg_sensor_fusion', plugin='psf::SensorFusionNode',
                           name='sensor_fusion_node', parameters=[p, {'autostart': False}],
                           extra_arguments=[{'use_intra_process_comms': True}]),
        ])
    return LaunchDescription(args + [fusion, synth, container])
