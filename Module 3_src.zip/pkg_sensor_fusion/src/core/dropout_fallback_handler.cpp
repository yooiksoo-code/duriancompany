#include "pkg_sensor_fusion/dropout_fallback_handler.hpp"

#include <cstdio>

namespace psf {

namespace {
std::string fmt(const char* f, double a) {
  char b[96];
  std::snprintf(b, sizeof(b), f, a);
  return b;
}
}  // namespace

FusionMode DropoutFallbackHandler::update(TimeNs t, TimeNs last_vis, bool initialized, bool imu_lost,
                                          std::vector<FusionEvent>& ev) {
  FusionMode next;
  if (imu_lost) {
    next = FusionMode::IMU_LOST;
  } else if (!initialized) {
    next = FusionMode::UNINITIALIZED;
  } else {
    const double age = toSec(t - last_vis);
    if (age <= cfg_.dropout_timeout_s) next = FusionMode::TRACKING;
    else if (age <= cfg_.dropout_timeout_s + cfg_.max_dead_reckoning_s) next = FusionMode::DEAD_RECKONING;
    else next = FusionMode::DR_EXPIRED;
  }
  if (next == mode_) return mode_;

  const FusionMode prev = mode_;
  // 진입 이벤트
  switch (next) {
    case FusionMode::IMU_LOST:
      ev.push_back({t, "ERROR_IMU_DISCONNECT",
                    fmt("IMU no data > %.0f ms, speed interlock ON", cfg_.imu_timeout_s * 1e3)});
      break;
    case FusionMode::DEAD_RECKONING:
      dr_start_ = last_vis;
      if (prev != FusionMode::DR_EXPIRED)
        ev.push_back({t, "WARN_VISION_DROPOUT",
                      fmt("vision age > %.0f ms, IMU dead-reckoning", cfg_.dropout_timeout_s * 1e3)});
      break;
    case FusionMode::DR_EXPIRED:
      ev.push_back({t, "ERROR_DR_TIMEOUT",
                    fmt("dead-reckoning > %.1f s, output invalid, speed interlock ON",
                        cfg_.max_dead_reckoning_s)});
      break;
    case FusionMode::TRACKING:
      if (prev == FusionMode::DEAD_RECKONING || prev == FusionMode::DR_EXPIRED)
        ev.push_back({t, "INFO_VISION_RECOVERED", fmt("dead-reckoning %.3f s", toSec(t - dr_start_))});
      break;  // UNINITIALIZED → TRACKING 은 엔진이 INFO_FUSION_INITIALIZED 를 직접 낸다
    case FusionMode::UNINITIALIZED:
      break;
  }
  if (prev == FusionMode::IMU_LOST) ev.push_back({t, "INFO_IMU_RECOVERED", toString(next)});
  mode_ = next;
  return mode_;
}

}  // namespace psf
