#include "pkg_sensor_fusion/imu_prediction_engine.hpp"

namespace psf {

void ImuPredictionEngine::propagateNominal(NominalState& x, const Vec3& a, const Vec3& w,
                                           TimeNs t1) const {
  const double dt = toSec(t1 - x.t);
  if (dt <= 0) return;
  const Vec3 wc = w - x.bg;
  const Vec3 ac = a - x.ba;
  const Mat3 Rmid = x.R * expSO3(0.5 * dt * wc);
  const Vec3 aw = Rmid * ac + cfg_.gravity_w;
  x.p += x.v * dt + 0.5 * aw * dt * dt;
  x.v += aw * dt;
  x.R = x.R * expSO3(wc * dt);
  x.t = t1;
}

MatE ImuPredictionEngine::transition(const NominalState& x, const Vec3& a_mean, const Vec3& w_mean,
                                     double dt) const {
  const Vec3 wc = w_mean - x.bg;
  const Mat3 Rmid = x.R * expSO3(0.5 * dt * wc);
  const Vec3 aw_spec = Rmid * (a_mean - x.ba);
  MatE A = MatE::Zero();
  A.block<3, 3>(IP, IV).setIdentity();
  A.block<3, 3>(IV, ITH) = -skew(aw_spec);
  A.block<3, 3>(IV, IBA) = -Rmid;
  A.block<3, 3>(ITH, IBG) = -Rmid;
  const MatE Adt = A * dt;
  return MatE::Identity() + Adt + 0.5 * Adt * Adt;
}

void ImuPredictionEngine::propagate(NominalState& x, MatE& P, const Vec3& a0, const Vec3& w0,
                                    const Vec3& a1, const Vec3& w1, TimeNs t1) const {
  const double dt = toSec(t1 - x.t);
  if (dt <= 0) return;

  // --- 명목 상태 (중점 적분)
  const Vec3 wc = 0.5 * (w0 + w1) - x.bg;
  const Vec3 ac = 0.5 * (a0 + a1) - x.ba;
  const Mat3 Rmid = x.R * expSO3(0.5 * dt * wc);
  const Vec3 aw_spec = Rmid * ac;  // 월드 비력
  const Vec3 aw = aw_spec + cfg_.gravity_w;

  const MatE Phi = transition(x, 0.5 * (a0 + a1), 0.5 * (w0 + w1), dt);

  // --- 이산 공정잡음 (등방 잡음이므로 R 회전 불변)
  const double sa2 = cfg_.imu.acc_noise * cfg_.imu.acc_noise;
  const double sg2 = cfg_.imu.gyro_noise * cfg_.imu.gyro_noise;
  const double sba2 = cfg_.imu.acc_bias_rw * cfg_.imu.acc_bias_rw;
  const double sbg2 = cfg_.imu.gyro_bias_rw * cfg_.imu.gyro_bias_rw;
  const double dt2 = dt * dt, dt3 = dt2 * dt;
  MatE Q = MatE::Zero();
  const Mat3 I3 = Mat3::Identity();
  Q.block<3, 3>(IP, IP) = I3 * (sa2 * dt3 / 3.0);
  Q.block<3, 3>(IP, IV) = I3 * (sa2 * dt2 / 2.0);
  Q.block<3, 3>(IV, IP) = I3 * (sa2 * dt2 / 2.0);
  Q.block<3, 3>(IV, IV) = I3 * (sa2 * dt);
  Q.block<3, 3>(ITH, ITH) = I3 * (sg2 * dt);
  Q.block<3, 3>(IBA, IBA) = I3 * (sba2 * dt);
  Q.block<3, 3>(IBG, IBG) = I3 * (sbg2 * dt);

  P = Phi * P * Phi.transpose() + Q;
  P = 0.5 * (P + P.transpose());

  x.p += x.v * dt + 0.5 * aw * dt2;
  x.v += aw * dt;
  x.R = x.R * expSO3(wc * dt);
  // 수치 누적으로 직교성이 깨지지 않게 주기적으로 재정규화
  Quat q(x.R);
  x.R = q.normalized().toRotationMatrix();
  x.t = t1;
}

}  // namespace psf
