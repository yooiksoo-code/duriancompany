#include "pkg_sensor_fusion/vision_update_engine.hpp"

#include <Eigen/Cholesky>
#include <Eigen/Eigenvalues>

namespace psf {

namespace {
inline void imuToBody(const FusionConfig& c, Vec3& r_IB, Mat3& R_IB) {
  const Mat3 R_BI = c.q_body_imu.normalized().toRotationMatrix();
  R_IB = R_BI.transpose();
  r_IB = -(R_IB * c.t_body_imu);
}
}  // namespace

bool VisionUpdateEngine::conditionCovariance(const Mat6& in, Mat6& out, bool& floored) const {
  floored = false;
  if (!in.allFinite()) return false;
  Mat6 S = 0.5 * (in + in.transpose()) * cfg_.vision_cov_scale;
  if (S.diagonal().maxCoeff() <= 0.0) {
    // 공분산 미기재 → 기본값
    S.setZero();
    S.diagonal().head<3>().setConstant(cfg_.vision_default_sigma_pos * cfg_.vision_default_sigma_pos);
    S.diagonal().tail<3>().setConstant(cfg_.vision_default_sigma_rot * cfg_.vision_default_sigma_rot);
    floored = true;
  } else {
    Eigen::SelfAdjointEigenSolver<Mat6> es(S);
    if (es.info() != Eigen::Success) return false;
    Vec6 ev = es.eigenvalues();
    if (ev.minCoeff() < 0) {
      ev = ev.cwiseMax(0.0);
      S = es.eigenvectors() * ev.asDiagonal() * es.eigenvectors().transpose();
    }
  }
  // 하한: 가산형 (PSD 유지, 상관 구조 보존). 외부보정 계통오차 등 모델 밖 오차의 여유분
  const double fp = cfg_.vision_min_sigma_pos * cfg_.vision_min_sigma_pos;
  const double fr = cfg_.vision_min_sigma_rot * cfg_.vision_min_sigma_rot;
  for (int i = 0; i < 3; ++i) {
    if (fp > 0.1 * S(i, i)) floored = true;
    if (fr > 0.1 * S(3 + i, 3 + i)) floored = true;
    S(i, i) += fp;
    S(3 + i, 3 + i) += fr;
  }
  out = S;
  return true;
}

void VisionUpdateEngine::predictBody(const NominalState& x, Vec3& pB, Mat3& RB) const {
  Vec3 r_IB; Mat3 R_IB;
  imuToBody(cfg_, r_IB, R_IB);
  pB = x.p + x.R * r_IB;
  RB = x.R * R_IB;
}

Mat6E VisionUpdateEngine::bodyPoseJacobian(const NominalState& x) const {
  Vec3 r_IB; Mat3 R_IB;
  imuToBody(cfg_, r_IB, R_IB);
  Mat6E H = Mat6E::Zero();
  H.block<3, 3>(0, IP).setIdentity();
  H.block<3, 3>(0, ITH) = -skew(x.R * r_IB);
  H.block<3, 3>(3, ITH).setIdentity();
  return H;
}

void VisionUpdateEngine::inject(NominalState& x, MatE& P, const VecE& dx) {
  x.p += dx.segment<3>(IP);
  x.v += dx.segment<3>(IV);
  const Vec3 dth = dx.segment<3>(ITH);
  x.R = expSO3(dth) * x.R;
  x.R = Quat(x.R).normalized().toRotationMatrix();
  x.ba += dx.segment<3>(IBA);
  x.bg += dx.segment<3>(IBG);
  // ESKF 리셋 야코비안 (월드 고정축 오차): G_θ = I + ½[δθ]×
  MatE G = MatE::Identity();
  G.block<3, 3>(ITH, ITH) += 0.5 * skew(dth);
  P = G * P * G.transpose();
  P = 0.5 * (P + P.transpose());
}

UpdateInfo VisionUpdateEngine::update(NominalState& x, MatE& P, const VisionMeas& z,
                                      const Mat6& Rz, bool force) const {
  UpdateInfo info;
  Vec3 pB; Mat3 RB;
  predictBody(x, pB, RB);
  const Mat3 Rm = z.q.normalized().toRotationMatrix();
  Vec6 r;
  r.head<3>() = z.p - pB;
  r.tail<3>() = logSO3(Rm * RB.transpose());
  info.residual = r;

  const Mat6E H = bodyPoseJacobian(x);
  const Eigen::Matrix<double, kErr, 6> PHt = P * H.transpose();
  Mat6 S = H * PHt + Rz;
  S = 0.5 * (S + S.transpose());
  Eigen::LLT<Mat6> llt(S);
  if (llt.info() != Eigen::Success) return info;
  info.mahalanobis2 = r.dot(llt.solve(r));
  if (!force && cfg_.gate_enable && info.mahalanobis2 > cfg_.gate_chi2) return info;

  // K = P Hᵀ S⁻¹
  const Eigen::Matrix<double, kErr, 6> K = llt.solve(PHt.transpose()).transpose();
  const VecE dx = K * r;
  MatE IKH = MatE::Identity() - K * H;
  P = IKH * P * IKH.transpose() + K * Rz * K.transpose();
  inject(x, P, dx);
  info.accepted = true;
  return info;
}

}  // namespace psf
