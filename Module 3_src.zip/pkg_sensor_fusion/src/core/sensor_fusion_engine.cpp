#include "pkg_sensor_fusion/sensor_fusion_engine.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>

namespace psf {

namespace {
using Clock = std::chrono::steady_clock;
inline double usSince(Clock::time_point t0) {
  return std::chrono::duration<double, std::micro>(Clock::now() - t0).count();
}
std::string fmt3(const char* f, double a, double b, double c) {
  char buf[160];
  std::snprintf(buf, sizeof(buf), f, a, b, c);
  return buf;
}
}  // namespace

SensorFusionEngine::SensorFusionEngine(const FusionConfig& cfg)
    : cfg_(cfg), predictor_(cfg_), updater_(cfg_), dropout_(cfg_) {
  // 이력 용량: 최대 1 kHz IMU + 비전 합성 스냅샷 여유
  const size_t cap = static_cast<size_t>(cfg_.history_s * 1000.0) + 64;
  recs_.reserve(cap);
  pre_init_imu_.reserve(static_cast<size_t>(std::max(1.0, cfg_.init_static_window_s + 1.0) * 1000.0));
  pending_.reserve(16);
  applied_.reserve(64);
  rejected_.reserve(64);
  init_cands_.reserve(64);
  events_.reserve(32);
}

void SensorFusionEngine::reset() {
  recs_.clear();
  pre_init_imu_.clear();
  pending_.clear();
  applied_.clear();
  rejected_.clear();
  initialized_ = false;
  imu_lost_ = false;
  have_carry_bias_ = false;
  last_imu_stamp_ = last_real_imu_stamp_ = last_imu_arrival_ = last_vision_stamp_ = 0;
  reject_streak_start_ = 0;
  have_init_candidate_ = false;
  init_cands_.clear();
  first_candidate_stamp_ = 0;
  dropout_.reset();
  stats_ = FusionStats{};
  events_.clear();
}

bool SensorFusionEngine::validImu(const ImuSample& s) const {
  if (!s.acc.allFinite() || !s.gyro.allFinite()) return false;
  if (s.acc.norm() > cfg_.imu_acc_limit || s.gyro.norm() > cfg_.imu_gyro_limit) return false;
  if (last_imu_stamp_ != 0 && s.stamp <= last_imu_stamp_) return false;  // 중복·역순
  return true;
}

// ---------------------------------------------------------------------------
bool SensorFusionEngine::addImu(const ImuSample& s_in, TimeNs now) {
  const auto t0 = Clock::now();
  ImuSample s = s_in;
  s.stamp += fromSec(cfg_.imu_time_offset_s);
  ++stats_.imu_received;
  if (!validImu(s)) { ++stats_.imu_rejected; return false; }

  const TimeNs gap = last_real_imu_stamp_ ? s.stamp - last_real_imu_stamp_ : 0;
  if (last_imu_stamp_ && toSec(gap) > cfg_.imu_timeout_s) ++stats_.imu_gaps;
  if (gap > 0 && toSec(gap) < 0.1) imu_dt_avg_ = 0.99 * imu_dt_avg_ + 0.01 * toSec(gap);
  stats_.imu_rate_hz = imu_dt_avg_ > 0 ? 1.0 / imu_dt_avg_ : 0;
  last_imu_stamp_ = s.stamp;
  last_real_imu_stamp_ = s.stamp;
  last_imu_arrival_ = now;
  imu_lost_ = false;

  if (!initialized_) {
    pre_init_imu_.push_back(s);
    if (have_init_candidate_ && s.stamp >= init_candidate_.stamp) tryInitialize();
    updateMode();
    return initialized_;
  }

  if (toSec(gap) > cfg_.imu_max_bridge_gap_s) {
    // 적분 불가능한 공백 → 바이어스만 들고 재초기화 (다음 비전으로)
    const Rec& b = recs_.back();
    carry_ba_ = b.x.ba; carry_bg_ = b.x.bg;
    carry_Pba_ = b.P.block<3, 3>(IBA, IBA); carry_Pbg_ = b.P.block<3, 3>(IBG, IBG);
    have_carry_bias_ = true;
    initialized_ = false;
    recs_.clear();
    pending_.clear();
    pre_init_imu_.clear();
    init_cands_.clear();
    have_init_candidate_ = false;
    first_candidate_stamp_ = 0;
    pre_init_imu_.push_back(s);
    events_.push_back({s.stamp, "WARN_FUSION_REINIT",
                       fmt3("IMU gap %.0f ms > bridge %.0f ms, reinit on next vision (carry bias %.0f)",
                            toSec(gap) * 1e3, cfg_.imu_max_bridge_gap_s * 1e3, 1.0)});
    updateMode();
    return false;
  }
  if (toSec(gap) > cfg_.imu_timeout_s) ++stats_.imu_bridged;

  const Rec& last = recs_.back();
  Rec r;
  r.imu = s;
  r.x = last.x;
  r.P = last.P;
  predictor_.propagate(r.x, r.P, last.imu.acc, last.imu.gyro, s.acc, s.gyro, s.stamp);
  recs_.push_back(r);
  trimHistory();
  stats_.last_imu_proc_us = usSince(t0);
  stats_.max_imu_proc_us = std::max(stats_.max_imu_proc_us, stats_.last_imu_proc_us);

  processPending();
  updateMode();
  return true;
}

void SensorFusionEngine::trimHistory() {
  while (recs_.size() > 2 && toSec(recs_.back().x.t - recs_.front().x.t) > cfg_.history_s)
    recs_.pop_front();
}

void SensorFusionEngine::processPending() {
  while (!pending_.empty() && initialized_ && pending_.front().z.stamp <= recs_.back().x.t) {
    Pending p = pending_.front();
    pending_.pop_front();
    stats_.last_vision_result = applyAt(p.z, p.R, ApplyKind::UPDATE);
    outcome(p.z.stamp, stats_.last_vision_result);
  }
}

void SensorFusionEngine::forcePendingByExtrapolation(size_t) {
  // 가장 오래된 보류 측정: IMU 가 그 시각에 도달하지 못함 → 마지막 IMU 를 0차 유지로 외삽
  Pending p = pending_.front();
  pending_.pop_front();
  ++stats_.vision_pending_expired;
  const Rec& b = recs_.back();
  // IMU 유실 중이거나 마지막 실측 IMU 에서 너무 멀면 폐기 (IMU 없이 외삽을 이어가지 않음)
  if (imu_lost_ || toSec(p.z.stamp - last_real_imu_stamp_) > cfg_.output_max_extrapolation_s) {
    outcome(p.z.stamp, VisionResult::REJECT_STALE);
    return;
  }
  Rec r;
  r.imu = b.imu;
  r.imu.stamp = p.z.stamp;
  r.x = b.x;
  r.P = b.P;
  predictor_.propagate(r.x, r.P, b.imu.acc, b.imu.gyro, b.imu.acc, b.imu.gyro, p.z.stamp);
  recs_.push_back(r);
  // 이후 도착하는 이 시각 이전 IMU 는 역순으로 기각됨
  last_imu_stamp_ = std::max(last_imu_stamp_, p.z.stamp);
  stats_.last_vision_result = applyAt(p.z, p.R, ApplyKind::UPDATE);
  outcome(p.z.stamp, stats_.last_vision_result);
}

void SensorFusionEngine::tick(TimeNs now) {
  if (last_imu_arrival_ != 0 && !imu_lost_ && toSec(now - last_imu_arrival_) > cfg_.imu_timeout_s) {
    imu_lost_ = true;
  }
  while (initialized_ && !pending_.empty() &&
         toSec(now - pending_.front().arrival) > cfg_.vision_max_pending_s) {
    forcePendingByExtrapolation(0);
  }
  updateMode();
}

void SensorFusionEngine::updateMode() {
  const TimeNs t = (initialized_ && !recs_.empty()) ? recs_.back().x.t : last_imu_stamp_;
  dropout_.update(t, last_vision_stamp_, initialized_, imu_lost_, events_);
}

// ---------------------------------------------------------------------------
VisionResult SensorFusionEngine::addVision(const VisionMeas& z_in, TimeNs now) {
  const auto t0 = Clock::now();
  ++stats_.vision_received;
  VisionMeas z = z_in;
  Mat6 R;
  bool floored = false;
  const double qn = z.q.norm();
  VisionResult res;
  if (!z.p.allFinite() || !z.q.coeffs().allFinite() || qn < 0.9 || qn > 1.1 ||
      !updater_.conditionCovariance(z.cov, R, floored)) {
    ++stats_.vision_invalid;
    res = VisionResult::REJECT_INVALID;
  } else {
    z.q = normalized(z.q);
    if (!initialized_) {
      if (first_candidate_stamp_ == 0) first_candidate_stamp_ = z.stamp;
      if (!init_cands_.empty() && z.stamp <= init_cands_.back().stamp) init_cands_.clear();
      init_cands_.push_back(z);
      init_candidate_ = z;
      init_candidate_R_ = R;
      have_init_candidate_ = true;
      res = tryInitialize();
    } else if (z.stamp < recs_.front().x.t) {
      ++stats_.vision_stale;
      res = VisionResult::REJECT_STALE;
    } else if (z.stamp > recs_.back().x.t) {
      if (pending_.size() == pending_.capacity()) forcePendingByExtrapolation(0);
      pending_.push_back({z, R, now});
      res = VisionResult::PENDING;
    } else {
      res = applyAt(z, R, ApplyKind::UPDATE);
    }
  }
  updateMode();
  stats_.last_vision_result = res;
  if (res != VisionResult::PENDING) outcome(z.stamp, res);
  stats_.last_vision_proc_us = usSince(t0);
  stats_.max_vision_proc_us = std::max(stats_.max_vision_proc_us, stats_.last_vision_proc_us);
  return res;
}

void SensorFusionEngine::bodyFromImu(const VisionMeas& z, Vec3& pI, Mat3& RI) const {
  const Mat3 R_WB = z.q.toRotationMatrix();
  const Mat3 R_BI = cfg_.q_body_imu.normalized().toRotationMatrix();
  RI = R_WB * R_BI;
  pI = z.p + R_WB * cfg_.t_body_imu;
}

VisionResult SensorFusionEngine::tryInitialize() {
  const VisionMeas& z = init_candidate_;
  const Mat6& Rz = init_candidate_R_;
  if (pre_init_imu_.empty() || pre_init_imu_.back().stamp < z.stamp) return VisionResult::WAIT_INIT;
  // 정지 판정에 쓸 IMU 이력이 부족하면 최대 1 s 기다린다 (바이어스를 이어받는 재초기화는 대기 불필요,
  // 단 비전 차분 속도용 창은 확보)
  const double span = toSec(z.stamp - pre_init_imu_.front().stamp);
  const double vis_span = init_cands_.empty() ? 0.0 : toSec(z.stamp - init_cands_.front().stamp);
  const bool imu_ok = have_carry_bias_ || span >= cfg_.init_static_window_s;
  const bool vis_ok = vis_span >= cfg_.init_vel_window_s;
  if (!(imu_ok && vis_ok) && toSec(z.stamp - first_candidate_stamp_) < 1.0) return VisionResult::WAIT_INIT;

  // 비전 차분 속도 (창 안의 가장 오래된 후보 → 현재)
  bool have_vis_vel = false;
  Vec3 v_vis = Vec3::Zero();
  for (size_t i = 0; i < init_cands_.size(); ++i) {
    const double dt = toSec(z.stamp - init_cands_[i].stamp);
    if (dt <= cfg_.init_vel_window_s * 1.5 && dt >= 0.5 * cfg_.init_vel_window_s) {
      v_vis = (z.p - init_cands_[i].p) / dt;
      have_vis_vel = true;
      break;
    }
  }

  // z.stamp 를 감싸는 IMU 샘플
  size_t j = 0;
  while (j < pre_init_imu_.size() && pre_init_imu_[j].stamp < z.stamp) ++j;
  Vec3 a0, w0;
  if (j == 0) { a0 = pre_init_imu_[0].acc; w0 = pre_init_imu_[0].gyro; }
  else interpolateImu(pre_init_imu_[j - 1], pre_init_imu_[j], z.stamp, a0, w0);

  // 정지 판정 (초기 바이어스 추정)
  Vec3 ma = Vec3::Zero(), mg = Vec3::Zero();
  Vec3 sa = Vec3::Zero(), sg = Vec3::Zero();
  int n = 0;
  for (size_t i = 0; i < pre_init_imu_.size(); ++i) {
    const auto& s = pre_init_imu_[i];
    if (s.stamp > z.stamp || toSec(z.stamp - s.stamp) > cfg_.init_static_window_s) continue;
    ma += s.acc; mg += s.gyro;
    sa += s.acc.cwiseAbs2(); sg += s.gyro.cwiseAbs2();
    ++n;
  }
  bool is_static = false;
  if (n >= 10) {
    ma /= n; mg /= n;
    const Vec3 va = (sa / n - ma.cwiseAbs2()).cwiseMax(0.0);
    const Vec3 vg = (sg / n - mg.cwiseAbs2()).cwiseMax(0.0);
    is_static = std::sqrt(va.maxCoeff()) < cfg_.init_static_acc_std &&
                std::sqrt(vg.maxCoeff()) < cfg_.init_static_gyro_std;
  }
  // IMU 분산만으로는 등속 이동을 정지로 오판한다 → 비전 변위로 확인
  if (is_static && (!have_vis_vel || v_vis.norm() > cfg_.init_static_max_speed)) is_static = false;

  Rec r0;
  r0.imu.stamp = z.stamp;
  r0.imu.acc = a0;
  r0.imu.gyro = w0;
  NominalState& x = r0.x;
  x.t = z.stamp;
  bodyFromImu(z, x.p, x.R);
  MatE& P = r0.P;
  P.setZero();
  const double sth2 = Rz.block<3, 3>(3, 3).trace() / 3.0;
  P.block<3, 3>(IP, IP) = Rz.block<3, 3>(0, 0) + Mat3::Identity() * cfg_.t_body_imu.squaredNorm() * sth2;
  P.block<3, 3>(ITH, ITH) = Rz.block<3, 3>(3, 3);

  std::string how;
  if (is_static) {
    x.v.setZero();
    x.bg = mg;
    x.ba = ma - x.R.transpose() * (-cfg_.gravity_w);  // a_m = Rᵀ(a − g) + b_a, a = 0
    P.block<3, 3>(IV, IV) = Mat3::Identity() * std::pow(cfg_.init_sigma_vel_static, 2);
    P.block<3, 3>(IBA, IBA) = Mat3::Identity() * std::pow(cfg_.init_sigma_ba_static, 2);
    P.block<3, 3>(IBG, IBG) = Mat3::Identity() * std::pow(cfg_.init_sigma_bg_static, 2);
    how = "static";
  } else {
    double sv = cfg_.init_sigma_vel;
    x.v.setZero();
    if (have_vis_vel) {
      // 선체 기준점 속도 ≈ IMU 속도 (ω×r 항은 수 mm/s 이하) — σ 0.03 m/s 로 보수적으로
      x.v = v_vis;
      sv = 0.03;
    }
    P.block<3, 3>(IV, IV) = Mat3::Identity() * sv * sv;
    if (have_carry_bias_) {
      x.ba = carry_ba_; x.bg = carry_bg_;
      P.block<3, 3>(IBA, IBA) = carry_Pba_;
      P.block<3, 3>(IBG, IBG) = carry_Pbg_;
      how = "moving, carried bias";
    } else {
      P.block<3, 3>(IBA, IBA) = Mat3::Identity() * std::pow(cfg_.init_sigma_ba, 2);
      P.block<3, 3>(IBG, IBG) = Mat3::Identity() * std::pow(cfg_.init_sigma_bg, 2);
      how = "moving";
    }
  }

  recs_.clear();
  recs_.push_back(r0);
  for (size_t i = j; i < pre_init_imu_.size(); ++i) {
    const auto& s = pre_init_imu_[i];
    if (s.stamp <= recs_.back().x.t) continue;
    const Rec& last = recs_.back();
    Rec r;
    r.imu = s; r.x = last.x; r.P = last.P;
    predictor_.propagate(r.x, r.P, last.imu.acc, last.imu.gyro, s.acc, s.gyro, s.stamp);
    recs_.push_back(r);
  }
  trimHistory();
  pre_init_imu_.clear();
  pending_.clear();
  applied_.clear();
  applied_.push_back({z, Rz});
  rejected_.clear();
  reject_streak_start_ = 0;
  initialized_ = true;
  have_carry_bias_ = false;
  have_init_candidate_ = false;
  init_cands_.clear();
  first_candidate_stamp_ = 0;
  last_vision_stamp_ = z.stamp;
  stats_.last_vision_stamp_applied = z.stamp;
  ++stats_.inits;
  events_.push_back({z.stamp, "INFO_FUSION_INITIALIZED", how});
  return VisionResult::USED_FOR_INIT;
}

// ---------------------------------------------------------------------------
bool SensorFusionEngine::checkRelock(const VisionMeas& z) {
  if (reject_streak_start_ == 0 || toSec(z.stamp - reject_streak_start_) < cfg_.relock_timeout_s) return false;
  const int n = cfg_.relock_min_consistent;
  if (static_cast<int>(rejected_.size()) < n) return false;
  const size_t s0 = rejected_.size() - n;
  for (size_t i = s0 + 1; i < rejected_.size(); ++i) {
    const auto& a = rejected_[i - 1];
    const auto& b = rejected_[i];
    const double dt = toSec(b.stamp - a.stamp);
    if (dt <= 0) return false;
    const double sp = (b.p - a.p).norm() / dt;
    const double ang = logSO3((b.q * a.q.conjugate()).toRotationMatrix()).norm() / dt;
    // 고속 프레임에서 dt 가 작을 때 비전 잡음만으로 넘지 않게 1 mm·0.05° 여유
    if (sp > cfg_.relock_max_speed + 1e-3 / dt || ang > cfg_.relock_max_rate + 8.7e-4 / dt) return false;
  }
  return true;
}

VisionResult SensorFusionEngine::applyAt(const VisionMeas& z, const Mat6& Rz, ApplyKind kind) {
  // 비교 시험용: 지연 무시하고 현재 상태에 바로 적용
  if (!cfg_.replay_enable) {
    Rec& b = recs_.back();
    UpdateInfo info = updater_.update(b.x, b.P, z, Rz);
    stats_.last_mahalanobis2 = info.mahalanobis2;
    if (info.accepted) {
      ++stats_.vision_accepted;
      last_vision_stamp_ = std::max(last_vision_stamp_, z.stamp);
      stats_.last_vision_stamp_applied = z.stamp;
      return VisionResult::ACCEPTED;
    }
    ++stats_.vision_rejected_gate;
    return VisionResult::REJECT_MAHALANOBIS;
  }

  // 1) t_v 이하 마지막 스냅샷 k (이분 탐색)
  size_t lo = 0, hi = recs_.size() - 1;
  while (lo < hi) {
    const size_t mid = (lo + hi + 1) / 2;
    if (recs_[mid].x.t <= z.stamp) lo = mid; else hi = mid - 1;
  }
  const size_t k = lo;

  // 2) 이미 반영된 더 새로운 측정 (순서 뒤바뀜) → 재적용 목록
  Applied reapply[16];
  int nre = 0;
  while (!applied_.empty() && applied_.back().z.stamp > z.stamp && nre < 16) {
    reapply[nre++] = applied_.back();
    applied_.pop_back();
  }
  std::reverse(reapply, reapply + nre);

  NominalState x = recs_[k].x;
  MatE P = recs_[k].P;
  const size_t N = recs_.size();
  if (z.stamp > x.t && k + 1 < N) {
    Vec3 a, w;
    interpolateImu(recs_[k].imu, recs_[k + 1].imu, z.stamp, a, w);
    predictor_.propagate(x, P, recs_[k].imu.acc, recs_[k].imu.gyro, a, w, z.stamp);
  }

  // 3) 갱신
  VisionResult res;
  auto applyOne = [&](const VisionMeas& m, const Mat6& Rm, ApplyKind kd, bool primary) -> VisionResult {
    if (kd == ApplyKind::UPDATE) {
      UpdateInfo info = updater_.update(x, P, m, Rm);
      if (primary) stats_.last_mahalanobis2 = info.mahalanobis2;
      if (info.accepted) {
        ++stats_.vision_accepted;
        if (m.stamp >= last_vision_stamp_) {
          last_vision_stamp_ = m.stamp;
          stats_.last_vision_stamp_applied = m.stamp;
        }
        rejected_.clear();
        reject_streak_start_ = 0;
        applied_.push_back({m, Rm});
        return VisionResult::ACCEPTED;
      }
      ++stats_.vision_rejected_gate;
      if (!primary) return VisionResult::REJECT_MAHALANOBIS;
      if (reject_streak_start_ == 0) reject_streak_start_ = m.stamp;
      rejected_.push_back(m);
      if (!checkRelock(m)) return VisionResult::REJECT_MAHALANOBIS;
    }
    // 재획득: 연속 기각된 측정들이 서로 일관됨 → 필터가 틀렸다고 보고 자세·위치를 재설정
    const size_t nr = rejected_.size();
    Vec3 vB = x.v;
    if (nr >= 2) {
      const auto& a = rejected_[nr - static_cast<size_t>(std::min<int>(nr, cfg_.relock_min_consistent))];
      const auto& b = rejected_[nr - 1];
      const double dt = toSec(b.stamp - a.stamp);
      if (dt > 1e-3) vB = (b.p - a.p) / dt;
    }
    bodyFromImu(m, x.p, x.R);
    x.v = vB;
    P.block<9, kErr>(0, 0).setZero();
    P.block<kErr, 9>(0, 0).setZero();
    const double sth2 = Rm.block<3, 3>(3, 3).trace() / 3.0;
    P.block<3, 3>(IP, IP) = Rm.block<3, 3>(0, 0) + Mat3::Identity() * cfg_.t_body_imu.squaredNorm() * sth2;
    P.block<3, 3>(IV, IV) = Mat3::Identity() * 0.05 * 0.05;
    P.block<3, 3>(ITH, ITH) = Rm.block<3, 3>(3, 3);
    ++stats_.relocks;
    events_.push_back({m.stamp, "INFO_VISION_RELOCK",
                       fmt3("rejected %.2f s, %.0f consecutive, d2=%.1f",
                            toSec(m.stamp - reject_streak_start_), static_cast<double>(nr),
                            stats_.last_mahalanobis2)});
    last_vision_stamp_ = std::max(last_vision_stamp_, m.stamp);
    stats_.last_vision_stamp_applied = m.stamp;
    rejected_.clear();
    reject_streak_start_ = 0;
    applied_.clear();
    applied_.push_back({m, Rm});
    return VisionResult::RELOCK;
  };
  res = applyOne(z, Rz, kind, true);

  if (z.stamp == recs_[k].x.t) { recs_[k].x = x; recs_[k].P = P; }

  // 4) 재전파
  int ra = 0;
  for (size_t j = k + 1; j < N; ++j) {
    Rec& rj = recs_[j];
    const Rec& rp = recs_[j - 1];
    while (ra < nre && reapply[ra].z.stamp <= rj.x.t) {
      const TimeNs tm = reapply[ra].z.stamp;
      if (tm > x.t) {
        Vec3 a0, w0, a1, w1;
        interpolateImu(rp.imu, rj.imu, x.t, a0, w0);
        interpolateImu(rp.imu, rj.imu, tm, a1, w1);
        predictor_.propagate(x, P, a0, w0, a1, w1, tm);
      }
      applyOne(reapply[ra].z, reapply[ra].R, ApplyKind::UPDATE, false);
      ++ra;
    }
    if (rj.x.t > x.t) {
      Vec3 a0, w0;
      interpolateImu(rp.imu, rj.imu, x.t, a0, w0);
      predictor_.propagate(x, P, a0, w0, rj.imu.acc, rj.imu.gyro, rj.x.t);
    }
    rj.x = x;
    rj.P = P;
  }
  ++stats_.replays;
  stats_.replay_steps_max = std::max<uint64_t>(stats_.replay_steps_max, N - 1 - k);
  return res;
}

// ---------------------------------------------------------------------------
void SensorFusionEngine::fillOutput(const NominalState& x, const MatE& P, const ImuSample& imu,
                                    FusedOutput& o) const {
  Vec3 pB; Mat3 RB;
  updater_.predictBody(x, pB, RB);
  const Mat3 R_BI = cfg_.q_body_imu.normalized().toRotationMatrix();
  const Mat3 R_IB = R_BI.transpose();
  const Vec3 r_IB = -(R_IB * cfg_.t_body_imu);
  const Vec3 wI = imu.gyro - x.bg;
  o.stamp = x.t;
  o.p = pB;
  o.q = normalized(Quat(RB));
  o.w_body = R_BI * wI;
  const Vec3 vBw = x.v + x.R * wI.cross(r_IB);
  o.v_body = RB.transpose() * vBw;
  const Mat6E J = updater_.bodyPoseJacobian(x);
  o.pose_cov = J * P * J.transpose();
  o.twist_cov.setZero();
  o.twist_cov.block<3, 3>(0, 0) = RB.transpose() * P.block<3, 3>(IV, IV) * RB;
  const double sgd2 = cfg_.imu.gyro_noise * cfg_.imu.gyro_noise / std::max(imu_dt_avg_, 1e-4);
  o.twist_cov.block<3, 3>(3, 3) =
      R_BI * (P.block<3, 3>(IBG, IBG) + Mat3::Identity() * sgd2) * R_BI.transpose();
  o.mode = dropout_.mode();
  o.valid = o.mode == FusionMode::TRACKING || o.mode == FusionMode::DEAD_RECKONING;
  o.vision_age_s = toSec(x.t - last_vision_stamp_);
  o.ba = x.ba;
  o.bg = x.bg;
}

bool SensorFusionEngine::latestOutput(FusedOutput& out) const {
  if (!initialized_ || recs_.empty()) return false;
  const Rec& b = recs_.back();
  fillOutput(b.x, b.P, b.imu, out);
  return true;
}

bool SensorFusionEngine::predictOutput(TimeNs t, FusedOutput& out) const {
  if (!initialized_ || recs_.empty()) return false;
  const Rec& b = recs_.back();
  if (t <= b.x.t) { fillOutput(b.x, b.P, b.imu, out); return true; }
  if (toSec(t - b.x.t) > cfg_.output_max_extrapolation_s) return false;
  NominalState x = b.x;
  predictor_.propagateNominal(x, b.imu.acc, b.imu.gyro, t);
  fillOutput(x, b.P, b.imu, out);
  return true;
}

bool SensorFusionEngine::visionTriggeredOutput(TimeNs now, FusedOutput& out) const {
  if (!initialized_ || recs_.empty()) return false;
  const TimeNs cap = recs_.back().x.t + fromSec(0.5 * imu_dt_avg_);
  return predictOutput(std::max(recs_.back().x.t, std::min(now, cap)), out);
}

}  // namespace psf
