// synthetic_sensor_publisher — 모듈 2·IMU 없이 sensor_fusion_node 를 ROS 그래프 수준에서 검증하는 합성 발행기
//   /sub_imu/data (sensor_msgs/Imu)                    : imu_rate_hz, stamp = 샘플 시각
//   /sub_pose_vision (PoseWithCovarianceStamped)       : vision_rate_hz, stamp = 촬영 시각, 3~7 ms 뒤 발행
//   /sim/ground_truth (nav_msgs/Odometry, 선체 기준점)  : IMU 와 같은 stamp
// 결손·이상치 주입: vision_blackout_start/duration, imu_blackout_start/duration, outlier_prob
#include <deque>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_components/register_node_macro.hpp>
#include <sensor_msgs/msg/imu.hpp>

#include "pkg_sensor_fusion/sim_world.hpp"

namespace psf {

class SyntheticSensorPublisher : public rclcpp::Node {
 public:
  explicit SyntheticSensorPublisher(const rclcpp::NodeOptions& opt = rclcpp::NodeOptions())
      : rclcpp::Node("synthetic_sensor_publisher", opt) {
    world_ = declare_parameter("world_frame", "dock_world_frame");
    const double imu_rate = declare_parameter("imu_rate_hz", 200.0);
    const double vis_rate = declare_parameter("vision_rate_hz", 60.0);
    vis_blk_t0_ = declare_parameter("vision_blackout_start", -1.0);
    vis_blk_len_ = declare_parameter("vision_blackout_duration", 2.0);
    vis_blk_period_ = declare_parameter("vision_blackout_period", 0.0);  // >0 이면 반복
    imu_blk_t0_ = declare_parameter("imu_blackout_start", -1.0);
    imu_blk_len_ = declare_parameter("imu_blackout_duration", 0.08);
    outlier_prob_ = declare_parameter("outlier_prob", 0.0);
    outlier_jump_ = declare_parameter("outlier_jump_pos", 0.005);
    const auto tr = declare_parameter("imu_extrinsics.translation", std::vector<double>{0.6, -0.15, -0.35});
    const auto rpy = declare_parameter("imu_extrinsics.rpy_deg", std::vector<double>{0.0, 0.0, 90.0});
    const int seed = declare_parameter("seed", 1);
    mount_.t_body_imu = Vec3(tr[0], tr[1], tr[2]);
    mount_.q_body_imu = Quat(Eigen::AngleAxisd(rpy[2] * M_PI / 180, Vec3::UnitZ()) *
                             Eigen::AngleAxisd(rpy[1] * M_PI / 180, Vec3::UnitY()) *
                             Eigen::AngleAxisd(rpy[0] * M_PI / 180, Vec3::UnitX()));
    sim::ImuSimParams ip;
    ip.rate_hz = imu_rate;
    sim::VisionSimParams vp;
    vp.rate_hz = vis_rate;
    vp.latency_min_s = declare_parameter("vision_latency_min_s", vp.latency_min_s);
    vp.latency_max_s = declare_parameter("vision_latency_max_s", vp.latency_max_s);
    sim_ = std::make_unique<sim::SensorSim>(traj_, mount_, ip, vp, static_cast<uint64_t>(seed));

    pub_imu_ = create_publisher<sensor_msgs::msg::Imu>("/sub_imu/data", rclcpp::SensorDataQoS().keep_last(50));
    pub_vis_ = create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>("/sub_pose_vision", rclcpp::QoS(10).reliable());
    pub_gt_ = create_publisher<nav_msgs::msg::Odometry>("/sim/ground_truth", rclcpp::QoS(200).reliable());
    t0_ = now().nanoseconds();
    imu_timer_ = create_wall_timer(std::chrono::nanoseconds(static_cast<int64_t>(1e9 / imu_rate)), [this] { onImu(); });
    vis_timer_ = create_wall_timer(std::chrono::nanoseconds(static_cast<int64_t>(1e9 / vis_rate)), [this] { onVisCapture(); });
    out_timer_ = create_wall_timer(std::chrono::microseconds(500), [this] { onVisRelease(); });
    RCLCPP_INFO(get_logger(), "synthetic sensors: IMU %.0f Hz, vision %.0f Hz, lever [%.2f %.2f %.2f]", imu_rate,
                vis_rate, tr[0], tr[1], tr[2]);
  }

 private:
  double tsim() { return toSec(now().nanoseconds() - t0_); }
  bool inBlk(double t, double t0, double len, double period) const {
    if (t0 < 0) return false;
    if (t < t0) return false;
    const double u = period > 0 ? std::fmod(t - t0, period) : t - t0;
    return u < len;
  }

  void onImu() {
    const double t = tsim();
    if (t <= last_imu_t_) return;
    last_imu_t_ = t;
    ImuSample s = sim_->imu(t);
    if (inBlk(t, imu_blk_t0_, imu_blk_len_, 0)) return;
    sensor_msgs::msg::Imu m;
    m.header.stamp = rclcpp::Time(s.stamp + t0_, RCL_ROS_TIME);
    m.header.frame_id = "imu_link";
    m.linear_acceleration.x = s.acc.x(); m.linear_acceleration.y = s.acc.y(); m.linear_acceleration.z = s.acc.z();
    m.angular_velocity.x = s.gyro.x(); m.angular_velocity.y = s.gyro.y(); m.angular_velocity.z = s.gyro.z();
    m.orientation_covariance[0] = -1;  // 자세 미제공
    pub_imu_->publish(m);
    // 참값 (선체 기준점) — IMU 와 같은 시각
    const auto b = traj_.truth(toSec(s.stamp));
    nav_msgs::msg::Odometry g;
    g.header.stamp = m.header.stamp;
    g.header.frame_id = world_;
    g.child_frame_id = "submarine_base_link_truth";
    g.pose.pose.position.x = b.p.x(); g.pose.pose.position.y = b.p.y(); g.pose.pose.position.z = b.p.z();
    const Quat q(b.R);
    g.pose.pose.orientation.x = q.x(); g.pose.pose.orientation.y = q.y();
    g.pose.pose.orientation.z = q.z(); g.pose.pose.orientation.w = q.w();
    const Vec3 vb = b.R.transpose() * b.v;
    g.twist.twist.linear.x = vb.x(); g.twist.twist.linear.y = vb.y(); g.twist.twist.linear.z = vb.z();
    pub_gt_->publish(g);
  }

  void onVisCapture() {
    const double t = tsim();
    if (inBlk(t, vis_blk_t0_, vis_blk_len_, vis_blk_period_)) return;
    VisionMeas z = sim_->vision(t);
    if (outlier_prob_ > 0 && sim_->uniform() < outlier_prob_) z.p += outlier_jump_ * sim_->gauss3().normalized();
    geometry_msgs::msg::PoseWithCovarianceStamped m;
    m.header.stamp = rclcpp::Time(z.stamp + t0_, RCL_ROS_TIME);
    m.header.frame_id = world_;
    m.pose.pose.position.x = z.p.x(); m.pose.pose.position.y = z.p.y(); m.pose.pose.position.z = z.p.z();
    m.pose.pose.orientation.x = z.q.x(); m.pose.pose.orientation.y = z.q.y();
    m.pose.pose.orientation.z = z.q.z(); m.pose.pose.orientation.w = z.q.w();
    for (int r = 0; r < 6; ++r)
      for (int c = 0; c < 6; ++c) m.pose.covariance[r * 6 + c] = z.cov(r, c);
    queue_.push_back({now().nanoseconds() + fromSec(sim_->visionLatency()), m});
  }

  void onVisRelease() {
    const TimeNs n = now().nanoseconds();
    while (!queue_.empty() && queue_.front().first <= n) {
      pub_vis_->publish(queue_.front().second);
      queue_.pop_front();
    }
  }

  sim::Trajectory traj_;
  FusionConfig mount_;
  std::unique_ptr<sim::SensorSim> sim_;
  std::string world_;
  double vis_blk_t0_, vis_blk_len_, vis_blk_period_, imu_blk_t0_, imu_blk_len_, outlier_prob_, outlier_jump_;
  TimeNs t0_ = 0;
  double last_imu_t_ = -1;
  std::deque<std::pair<TimeNs, geometry_msgs::msg::PoseWithCovarianceStamped>> queue_;
  rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr pub_imu_;
  rclcpp::Publisher<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr pub_vis_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr pub_gt_;
  rclcpp::TimerBase::SharedPtr imu_timer_, vis_timer_, out_timer_;
};

}  // namespace psf

RCLCPP_COMPONENTS_REGISTER_NODE(psf::SyntheticSensorPublisher)
