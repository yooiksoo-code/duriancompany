#include "pkg_sensor_fusion/sensor_fusion_node.hpp"

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <lifecycle_msgs/msg/state.hpp>
#include <rclcpp_components/register_node_macro.hpp>

namespace psf {

namespace {

// systemd sd_notify (libsystemd 의존 없이)
void sdNotify(const char* msg) {
  const char* path = std::getenv("NOTIFY_SOCKET");
  if (!path || !*path) return;
  const int fd = ::socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (fd < 0) return;
  sockaddr_un addr{};
  addr.sun_family = AF_UNIX;
  const size_t len = std::strlen(path);
  if (len < sizeof(addr.sun_path)) {
    std::memcpy(addr.sun_path, path, len);
    if (path[0] == '@') addr.sun_path[0] = '\0';
    ::sendto(fd, msg, std::strlen(msg), MSG_NOSIGNAL, reinterpret_cast<sockaddr*>(&addr),
             static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + len));
  }
  ::close(fd);
}

Vec3 toVec3(const std::vector<double>& v, const Vec3& def) {
  return v.size() == 3 ? Vec3(v[0], v[1], v[2]) : def;
}

geometry_msgs::msg::Vector3 msgVec(const Vec3& v) {
  geometry_msgs::msg::Vector3 m;
  m.x = v.x(); m.y = v.y(); m.z = v.z();
  return m;
}

Vec3 rpyDeg(const Quat& q) {
  const Mat3 R = q.toRotationMatrix();
  const double pitch = std::asin(std::max(-1.0, std::min(1.0, -R(2, 0))));
  const double roll = std::atan2(R(2, 1), R(2, 2));
  const double yaw = std::atan2(R(1, 0), R(0, 0));
  return Vec3(roll, pitch, yaw) * 180.0 / M_PI;
}

}  // namespace

SensorFusionNode::SensorFusionNode(const rclcpp::NodeOptions& options)
    : rclcpp_lifecycle::LifecycleNode("sensor_fusion_node", options) {
  declareParameters();
  if (get_parameter("autostart").as_bool()) {
    autostart_timer_ = create_wall_timer(std::chrono::milliseconds(0), [this]() {
      autostart_timer_->cancel();
      if (configure().id() == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE) activate();
    });
  }
}

void SensorFusionNode::declareParameters() {
  const FusionConfig d;
  declare_parameter("autostart", true);
  declare_parameter("exit_on_error", true);
  declare_parameter("world_frame", "dock_world_frame");
  declare_parameter("child_frame", "submarine_base_link");
  declare_parameter("publish_tf", false);
  declare_parameter("topics.imu", "/sub_imu/data");
  declare_parameter("topics.vision", "/sub_pose_vision");
  declare_parameter("topics.output", "/sub_pose_filtered");
  declare_parameter("topics.diagnostics", "/sensor_fusion/diagnostics");
  declare_parameter("topics.alerts", "/hmi/fusion_alerts");
  declare_parameter("topics.interlock", "/sensor_fusion/safety_interlock");
  declare_parameter("qos.imu_reliable", false);
  declare_parameter("qos.imu_depth", 50);
  declare_parameter("qos.vision_reliable", true);
  declare_parameter("tick_rate_hz", 200.0);
  declare_parameter("diag_rate_hz", 10.0);

  declare_parameter("gravity", std::vector<double>{d.gravity_w.x(), d.gravity_w.y(), d.gravity_w.z()});
  declare_parameter("imu_extrinsics.translation", std::vector<double>{0.0, 0.0, 0.0});
  declare_parameter("imu_extrinsics.rpy_deg", std::vector<double>{0.0, 0.0, 0.0});
  declare_parameter("imu.acc_noise", d.imu.acc_noise);
  declare_parameter("imu.gyro_noise", d.imu.gyro_noise);
  declare_parameter("imu.acc_bias_rw", d.imu.acc_bias_rw);
  declare_parameter("imu.gyro_bias_rw", d.imu.gyro_bias_rw);
  declare_parameter("imu.timeout_s", d.imu_timeout_s);
  declare_parameter("imu.max_bridge_gap_s", d.imu_max_bridge_gap_s);
  declare_parameter("imu.acc_limit", d.imu_acc_limit);
  declare_parameter("imu.gyro_limit", d.imu_gyro_limit);
  declare_parameter("imu.time_offset_s", d.imu_time_offset_s);

  declare_parameter("vision.cov_scale", d.vision_cov_scale);
  declare_parameter("vision.min_sigma_pos", d.vision_min_sigma_pos);
  declare_parameter("vision.min_sigma_rot", d.vision_min_sigma_rot);
  declare_parameter("vision.default_sigma_pos", d.vision_default_sigma_pos);
  declare_parameter("vision.default_sigma_rot", d.vision_default_sigma_rot);
  declare_parameter("vision.max_pending_s", d.vision_max_pending_s);

  declare_parameter("gate.enable", d.gate_enable);
  declare_parameter("gate.chi2", d.gate_chi2);
  declare_parameter("gate.relock_timeout_s", d.relock_timeout_s);
  declare_parameter("gate.relock_min_consistent", d.relock_min_consistent);
  declare_parameter("gate.relock_max_speed", d.relock_max_speed);
  declare_parameter("gate.relock_max_rate", d.relock_max_rate);

  declare_parameter("dropout.timeout_s", d.dropout_timeout_s);
  declare_parameter("dropout.max_dead_reckoning_s", d.max_dead_reckoning_s);
  declare_parameter("history_s", d.history_s);
  declare_parameter("replay_enable", d.replay_enable);

  declare_parameter("init.static_window_s", d.init_static_window_s);
  declare_parameter("init.static_gyro_std", d.init_static_gyro_std);
  declare_parameter("init.static_acc_std", d.init_static_acc_std);
  declare_parameter("init.static_max_speed", d.init_static_max_speed);
  declare_parameter("init.vel_window_s", d.init_vel_window_s);
  declare_parameter("init.sigma_vel", d.init_sigma_vel);
  declare_parameter("init.sigma_ba", d.init_sigma_ba);
  declare_parameter("init.sigma_bg", d.init_sigma_bg);

  declare_parameter("output.rate_hz", d.output_rate_hz);
  declare_parameter("output.on_vision_update", d.output_on_vision_update);
  declare_parameter("output.max_extrapolation_s", d.output_max_extrapolation_s);
}

FusionConfig SensorFusionNode::readConfig() {
  FusionConfig c;
  auto D = [this](const char* n) { return get_parameter(n).as_double(); };
  c.gravity_w = toVec3(get_parameter("gravity").as_double_array(), c.gravity_w);
  c.t_body_imu = toVec3(get_parameter("imu_extrinsics.translation").as_double_array(), Vec3::Zero());
  const Vec3 rpy = toVec3(get_parameter("imu_extrinsics.rpy_deg").as_double_array(), Vec3::Zero()) * M_PI / 180.0;
  c.q_body_imu = Quat(Eigen::AngleAxisd(rpy.z(), Vec3::UnitZ()) * Eigen::AngleAxisd(rpy.y(), Vec3::UnitY()) *
                      Eigen::AngleAxisd(rpy.x(), Vec3::UnitX()));
  c.imu.acc_noise = D("imu.acc_noise");
  c.imu.gyro_noise = D("imu.gyro_noise");
  c.imu.acc_bias_rw = D("imu.acc_bias_rw");
  c.imu.gyro_bias_rw = D("imu.gyro_bias_rw");
  c.imu_timeout_s = D("imu.timeout_s");
  c.imu_max_bridge_gap_s = D("imu.max_bridge_gap_s");
  c.imu_acc_limit = D("imu.acc_limit");
  c.imu_gyro_limit = D("imu.gyro_limit");
  c.imu_time_offset_s = D("imu.time_offset_s");
  c.vision_cov_scale = D("vision.cov_scale");
  c.vision_min_sigma_pos = D("vision.min_sigma_pos");
  c.vision_min_sigma_rot = D("vision.min_sigma_rot");
  c.vision_default_sigma_pos = D("vision.default_sigma_pos");
  c.vision_default_sigma_rot = D("vision.default_sigma_rot");
  c.vision_max_pending_s = D("vision.max_pending_s");
  c.gate_enable = get_parameter("gate.enable").as_bool();
  c.gate_chi2 = D("gate.chi2");
  c.relock_timeout_s = D("gate.relock_timeout_s");
  c.relock_min_consistent = static_cast<int>(get_parameter("gate.relock_min_consistent").as_int());
  c.relock_max_speed = D("gate.relock_max_speed");
  c.relock_max_rate = D("gate.relock_max_rate");
  c.dropout_timeout_s = D("dropout.timeout_s");
  c.max_dead_reckoning_s = D("dropout.max_dead_reckoning_s");
  c.history_s = D("history_s");
  c.replay_enable = get_parameter("replay_enable").as_bool();
  c.init_static_window_s = D("init.static_window_s");
  c.init_static_gyro_std = D("init.static_gyro_std");
  c.init_static_acc_std = D("init.static_acc_std");
  c.init_static_max_speed = D("init.static_max_speed");
  c.init_vel_window_s = D("init.vel_window_s");
  c.init_sigma_vel = D("init.sigma_vel");
  c.init_sigma_ba = D("init.sigma_ba");
  c.init_sigma_bg = D("init.sigma_bg");
  c.output_rate_hz = D("output.rate_hz");
  c.output_on_vision_update = get_parameter("output.on_vision_update").as_bool();
  c.output_max_extrapolation_s = D("output.max_extrapolation_s");
  return c;
}

// ---------------------------------------------------------------------------- lifecycle
SensorFusionNode::CallbackReturn SensorFusionNode::on_configure(const rclcpp_lifecycle::State&) {
  try {
    cfg_ = readConfig();
  } catch (const std::exception& e) {
    RCLCPP_ERROR(get_logger(), "parameter error: %s", e.what());
    return CallbackReturn::FAILURE;
  }
  world_frame_ = get_parameter("world_frame").as_string();
  child_frame_ = get_parameter("child_frame").as_string();
  publish_tf_ = get_parameter("publish_tf").as_bool();
  exit_on_error_ = get_parameter("exit_on_error").as_bool();
  engine_ = std::make_unique<SensorFusionEngine>(cfg_);
  sched_ = std::make_unique<OutputScheduler>(cfg_);
  cbg_ = create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

  pub_odom_ = create_publisher<nav_msgs::msg::Odometry>(get_parameter("topics.output").as_string(),
                                                        rclcpp::QoS(10).reliable());
  pub_diag_ = create_publisher<inhaul_msgs::msg::FusionDiagnostics>(
      get_parameter("topics.diagnostics").as_string(), rclcpp::QoS(10).reliable());
  pub_alert_ = create_publisher<std_msgs::msg::String>(get_parameter("topics.alerts").as_string(),
                                                       rclcpp::QoS(50).reliable());
  // transient_local 은 intra-process 와 함께 쓸 수 없음 → 이 발행자만 intra-process 비활성 (composed 모드)
  rclcpp::PublisherOptions no_ipc;
  no_ipc.use_intra_process_comm = rclcpp::IntraProcessSetting::Disable;
  pub_interlock_ = create_publisher<std_msgs::msg::Bool>(get_parameter("topics.interlock").as_string(),
                                                         rclcpp::QoS(1).reliable().transient_local(), no_ipc);
  if (publish_tf_) tf_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
  RCLCPP_INFO(get_logger(),
              "configured: world=%s child=%s lever=[%.3f %.3f %.3f] out=%.0fHz on_vision=%d gate χ²=%.2f "
              "dropout=%.0fms max_dr=%.1fs",
              world_frame_.c_str(), child_frame_.c_str(), cfg_.t_body_imu.x(), cfg_.t_body_imu.y(),
              cfg_.t_body_imu.z(), cfg_.output_rate_hz, cfg_.output_on_vision_update, cfg_.gate_chi2,
              cfg_.dropout_timeout_s * 1e3, cfg_.max_dead_reckoning_s);
  return CallbackReturn::SUCCESS;
}

SensorFusionNode::CallbackReturn SensorFusionNode::on_activate(const rclcpp_lifecycle::State&) {
  engine_->reset();
  sched_->reset();
  pub_odom_->on_activate();
  pub_diag_->on_activate();
  pub_alert_->on_activate();
  pub_interlock_->on_activate();

  rclcpp::SubscriptionOptions so;
  so.callback_group = cbg_;
  rclcpp::QoS qi(static_cast<size_t>(get_parameter("qos.imu_depth").as_int()));
  if (get_parameter("qos.imu_reliable").as_bool()) qi.reliable(); else qi.best_effort();
  rclcpp::QoS qv(10);
  if (get_parameter("qos.vision_reliable").as_bool()) qv.reliable(); else qv.best_effort();
  sub_imu_ = create_subscription<sensor_msgs::msg::Imu>(
      get_parameter("topics.imu").as_string(), qi,
      [this](const sensor_msgs::msg::Imu::ConstSharedPtr m) { onImu(m); }, so);
  sub_vision_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
      get_parameter("topics.vision").as_string(), qv,
      [this](const geometry_msgs::msg::PoseWithCovarianceStamped::ConstSharedPtr m) { onVision(m); }, so);
  const auto tick_ns = std::chrono::nanoseconds(static_cast<int64_t>(1e9 / get_parameter("tick_rate_hz").as_double()));
  const auto diag_ns = std::chrono::nanoseconds(static_cast<int64_t>(1e9 / get_parameter("diag_rate_hz").as_double()));
  tick_timer_ = create_wall_timer(tick_ns, [this]() { onTick(); }, cbg_);
  diag_timer_ = create_wall_timer(diag_ns, [this]() { onDiagnostics(); }, cbg_);
  last_interlock_ = false;
  std_msgs::msg::Bool b;
  b.data = true;  // 초기화 전에는 인터록 (안전측)
  pub_interlock_->publish(b);
  sdNotify("READY=1");
  RCLCPP_INFO(get_logger(), "active");
  return CallbackReturn::SUCCESS;
}

SensorFusionNode::CallbackReturn SensorFusionNode::on_deactivate(const rclcpp_lifecycle::State&) {
  sub_imu_.reset();
  sub_vision_.reset();
  tick_timer_.reset();
  diag_timer_.reset();
  pub_odom_->on_deactivate();
  pub_diag_->on_deactivate();
  pub_alert_->on_deactivate();
  pub_interlock_->on_deactivate();
  return CallbackReturn::SUCCESS;
}

SensorFusionNode::CallbackReturn SensorFusionNode::on_cleanup(const rclcpp_lifecycle::State&) {
  pub_odom_.reset();
  pub_diag_.reset();
  pub_alert_.reset();
  pub_interlock_.reset();
  tf_.reset();
  engine_.reset();
  sched_.reset();
  return CallbackReturn::SUCCESS;
}

SensorFusionNode::CallbackReturn SensorFusionNode::on_shutdown(const rclcpp_lifecycle::State&) {
  sdNotify("STOPPING=1");
  return CallbackReturn::SUCCESS;
}

SensorFusionNode::CallbackReturn SensorFusionNode::on_error(const rclcpp_lifecycle::State&) {
  RCLCPP_FATAL(get_logger(), "lifecycle error");
  if (exit_on_error_) std::_Exit(4);  // systemd Restart=always 로 재기동 (모듈 1/2 와 동일)
  return CallbackReturn::FAILURE;
}

// ---------------------------------------------------------------------------- callbacks
void SensorFusionNode::onImu(const sensor_msgs::msg::Imu::ConstSharedPtr& m) {
  ImuSample s;
  s.stamp = rclcpp::Time(m->header.stamp).nanoseconds();
  if (s.stamp <= 0) return;
  s.acc = Vec3(m->linear_acceleration.x, m->linear_acceleration.y, m->linear_acceleration.z);
  s.gyro = Vec3(m->angular_velocity.x, m->angular_velocity.y, m->angular_velocity.z);
  const bool adv = engine_->addImu(s, nowNs());
  bool vis_applied = false;
  for (const auto& oc : engine_->takeVisionOutcomes())
    if (oc.result == VisionResult::ACCEPTED) vis_applied = true;
  FusedOutput o;
  bool regular = false;
  if (sched_->onImu(*engine_, adv, vis_applied, o, regular)) publishOutput(o);
  flushEvents();
}

void SensorFusionNode::onVision(const geometry_msgs::msg::PoseWithCovarianceStamped::ConstSharedPtr& m) {
  if (m->header.frame_id != world_frame_) {
    ++frame_mismatch_;
    if (world_frame_warned_ != m->header.frame_id) {
      world_frame_warned_ = m->header.frame_id;
      RCLCPP_WARN(get_logger(), "vision frame_id '%s' != world_frame '%s' → ignored (모듈 2 I3 참조)",
                  m->header.frame_id.c_str(), world_frame_.c_str());
    }
    return;
  }
  VisionMeas z;
  z.stamp = rclcpp::Time(m->header.stamp).nanoseconds();
  const auto& P = m->pose.pose.position;
  const auto& Q = m->pose.pose.orientation;
  z.p = Vec3(P.x, P.y, P.z);
  z.q = Quat(Q.w, Q.x, Q.y, Q.z);
  for (int r = 0; r < 6; ++r)
    for (int c = 0; c < 6; ++c) z.cov(r, c) = m->pose.covariance[r * 6 + c];
  const TimeNs now = nowNs();
  const VisionResult res = engine_->addVision(z, now);
  engine_->takeVisionOutcomes();
  FusedOutput o;
  if (sched_->onVision(*engine_, res, nowNs(), o)) publishOutput(o);
  flushEvents();
}

void SensorFusionNode::onTick() {
  engine_->tick(nowNs());
  for (const auto& oc : engine_->takeVisionOutcomes()) {
    if (oc.result == VisionResult::ACCEPTED) {  // 만료된 보류 비전이 외삽으로 반영됨
      FusedOutput o;
      if (sched_->onVision(*engine_, oc.result, nowNs(), o)) publishOutput(o);
    }
  }
  flushEvents();
  const bool il = engine_->interlock() || !engine_->initialized();
  if (il != last_interlock_) {
    std_msgs::msg::Bool b;
    b.data = il;
    pub_interlock_->publish(b);
    last_interlock_ = il;
  }
}

void SensorFusionNode::publishOutput(const FusedOutput& o) {
  nav_msgs::msg::Odometry od;
  od.header.stamp = rclcpp::Time(o.stamp, RCL_ROS_TIME);
  od.header.frame_id = world_frame_;
  od.child_frame_id = child_frame_;
  od.pose.pose.position.x = o.p.x();
  od.pose.pose.position.y = o.p.y();
  od.pose.pose.position.z = o.p.z();
  od.pose.pose.orientation.x = o.q.x();
  od.pose.pose.orientation.y = o.q.y();
  od.pose.pose.orientation.z = o.q.z();
  od.pose.pose.orientation.w = o.q.w();
  od.twist.twist.linear = msgVec(o.v_body);
  od.twist.twist.angular = msgVec(o.w_body);
  for (int r = 0; r < 6; ++r)
    for (int c = 0; c < 6; ++c) {
      od.pose.covariance[r * 6 + c] = o.pose_cov(r, c);
      od.twist.covariance[r * 6 + c] = o.twist_cov(r, c);
    }
  pub_odom_->publish(od);
  const TimeNs now = nowNs();
  pub_times_.push_back(now);
  while (!pub_times_.empty() && now - pub_times_.front() > 1000000000LL) pub_times_.pop_front();
  const TimeNs applied = engine_->stats().last_vision_stamp_applied;
  if (applied > last_applied_reported_) {
    e2e_last_ms_ = toSec(now - applied) * 1e3;
    e2e_win_max_ms_ = std::max(e2e_win_max_ms_, e2e_last_ms_);
    last_applied_reported_ = applied;
  }
  if (tf_) {
    geometry_msgs::msg::TransformStamped t;
    t.header = od.header;
    t.child_frame_id = child_frame_;
    t.transform.translation.x = o.p.x();
    t.transform.translation.y = o.p.y();
    t.transform.translation.z = o.p.z();
    t.transform.rotation = od.pose.pose.orientation;
    tf_->sendTransform(t);
  }
}

void SensorFusionNode::flushEvents() {
  for (const auto& e : engine_->takeEvents()) {
    std_msgs::msg::String s;
    s.data = e.code + "|" + e.info;
    pub_alert_->publish(s);
    if (e.code.rfind("ERROR", 0) == 0) RCLCPP_ERROR(get_logger(), "%s", s.data.c_str());
    else if (e.code.rfind("WARN", 0) == 0) RCLCPP_WARN(get_logger(), "%s", s.data.c_str());
    else RCLCPP_INFO(get_logger(), "%s", s.data.c_str());
  }
}

void SensorFusionNode::onDiagnostics() {
  sdNotify("WATCHDOG=1");  // 실행기(같은 콜백그룹)가 살아 있을 때만 송출됨
  const auto& st = engine_->stats();
  inhaul_msgs::msg::FusionDiagnostics d;
  d.header.stamp = now();
  d.header.frame_id = world_frame_;
  d.mode = static_cast<uint8_t>(engine_->mode());
  d.mode_name = toString(engine_->mode());
  d.interlock = engine_->interlock() || !engine_->initialized();
  d.last_vision_result = toString(st.last_vision_result);
  d.last_mahalanobis2 = st.last_mahalanobis2;
  d.imu_received = st.imu_received;
  d.imu_rejected = st.imu_rejected;
  d.imu_gaps = st.imu_gaps;
  d.vision_received = st.vision_received + frame_mismatch_;
  d.vision_accepted = st.vision_accepted;
  d.vision_rejected_gate = st.vision_rejected_gate;
  d.vision_stale = st.vision_stale;
  d.vision_invalid = st.vision_invalid + frame_mismatch_;
  d.relocks = st.relocks;
  d.inits = st.inits;
  d.imu_rate_hz = st.imu_rate_hz;
  d.output_rate_hz = static_cast<double>(pub_times_.size());
  d.imu_proc_us = st.last_imu_proc_us;
  d.vision_proc_us = st.last_vision_proc_us;
  d.max_vision_proc_us = st.max_vision_proc_us;
  d.e2e_latency_ms = e2e_last_ms_;
  d.e2e_latency_max_ms = e2e_win_max_ms_;
  e2e_win_max_ms_ = 0;
  FusedOutput o;
  if (engine_->latestOutput(o)) {
    d.output_valid = o.valid;
    d.vision_age_ms = o.vision_age_s * 1e3;
    d.acc_bias = msgVec(o.ba);
    d.gyro_bias = msgVec(o.bg);
    d.pos_sigma = msgVec(o.pose_cov.diagonal().head<3>().cwiseSqrt());
    d.rot_sigma_deg = msgVec(o.pose_cov.diagonal().tail<3>().cwiseSqrt() * 180.0 / M_PI);
    d.rpy_deg = msgVec(rpyDeg(o.q));
  }
  pub_diag_->publish(d);
  // 인터록 하트비트 (늦게 붙은 구독자, 상태 유지 확인)
  std_msgs::msg::Bool b;
  b.data = d.interlock;
  pub_interlock_->publish(b);
}

}  // namespace psf

RCLCPP_COMPONENTS_REGISTER_NODE(psf::SensorFusionNode)
