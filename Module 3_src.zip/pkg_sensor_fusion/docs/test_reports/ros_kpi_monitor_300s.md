# fusion_kpi_monitor 결과

- 수신 46646건 / 300.0 s → **155.5 Hz** (stamp 역순 0건)
- stamp 간격 p50 / p99 / max: 7.42 / 10.18 / 71.72 ms, 15 ms 초과 7건
- 수신 지연 (now − stamp) p50 / p99 / max: 0.835 / 3.232 / 60.658 ms
- 위치 오차 (참값 대비, 46643건) RMSE 0.1386 mm, max 0.4306 mm
- 자세 오차 RMSE r/p/y 0.0027 / 0.0029 / 0.0018°, max 0.0108°
- 진단: mode TRACKING, valid True, 비전 승인 18249 / 수신 18287, 게이트 기각 7, 재획득 0, IMU 200.0 Hz (입력 stamp 공백 > 50 ms 2회), 출력 160 Hz
- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): 7.20 / 68.35 ms (최근값 p50 5.66)
- 비전 처리 (보정+재전파) 최근값 p50 36.1 µs, 기동 후 최대 4897.5 µs
- 바이어스 추정 acc [0.0796, -0.0500, 0.1001] m/s², gyro [0.00142, -0.00097, 0.00084] rad/s
- HMI 경보: ERROR_IMU_DISCONNECT → WARN_VISION_DROPOUT → INFO_IMU_RECOVERED → INFO_VISION_RECOVERED → ERROR_IMU_DISCONNECT → INFO_IMU_RECOVERED → WARN_VISION_DROPOUT → INFO_VISION_RECOVERED
- 인터록 전이: OFF → ON → OFF
