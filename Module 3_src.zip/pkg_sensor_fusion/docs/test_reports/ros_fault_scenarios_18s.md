## dropout

- 수신 4518건 / 30.0 s → **150.6 Hz** (stamp 역순 0건)
- stamp 간격 p50 / p99 / max: 7.48 / 10.20 / 18.56 ms, 15 ms 초과 1건
- 수신 지연 (now − stamp) p50 / p99 / max: 0.870 / 2.793 / 15.914 ms
- 위치 오차 (참값 대비, 4518건) RMSE 0.2765 mm, max 1.7617 mm
- 자세 오차 RMSE r/p/y 0.0029 / 0.0029 / 0.0020°, max 0.0107°
- 진단: mode TRACKING, valid True, 비전 승인 1943 / 수신 1974, 게이트 기각 0, 재획득 0, IMU 199.7 Hz, 출력 160 Hz
- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): 7.21 / 17.63 ms (최근값 p50 5.65)
- 비전 처리 (보정+재전파) 최근값 p50 36.8 µs, 기동 후 최대 852.2 µs
- 바이어스 추정 acc [0.0800, -0.0501, 0.1001] m/s², gyro [0.00151, -0.00102, 0.00078] rad/s
- HMI 경보: WARN_VISION_DROPOUT → INFO_VISION_RECOVERED
- 인터록 전이: OFF
## imu80

- 수신 2796건 / 18.0 s → **155.4 Hz** (stamp 역순 0건)
- stamp 간격 p50 / p99 / max: 7.41 / 10.18 / 77.51 ms, 15 ms 초과 3건
- 수신 지연 (now − stamp) p50 / p99 / max: 0.849 / 2.854 / 32.225 ms
- 위치 오차 (참값 대비, 2794건) RMSE 0.1389 mm, max 0.4272 mm
- 자세 오차 RMSE r/p/y 0.0031 / 0.0028 / 0.0018°, max 0.0100°
- 진단: mode TRACKING, valid True, 비전 승인 1340 / 수신 1373, 게이트 기각 0, 재획득 0, IMU 199.6 Hz, 출력 161 Hz
- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): 7.19 / 34.07 ms (최근값 p50 5.82)
- 비전 처리 (보정+재전파) 최근값 p50 48.1 µs, 기동 후 최대 579.5 µs
- 바이어스 추정 acc [0.0800, -0.0501, 0.1001] m/s², gyro [0.00146, -0.00101, 0.00076] rad/s
- HMI 경보: ERROR_IMU_DISCONNECT → INFO_IMU_RECOVERED
- 인터록 전이: OFF → ON → OFF
## imu400

- 수신 2681건 / 18.0 s → **148.9 Hz** (stamp 역순 0건)
- stamp 간격 p50 / p99 / max: 7.47 / 10.18 / 522.46 ms, 15 ms 초과 1건
- 수신 지연 (now − stamp) p50 / p99 / max: 0.818 / 2.846 / 37.080 ms
- 위치 오차 (참값 대비, 2680건) RMSE 0.1361 mm, max 0.7505 mm
- 자세 오차 RMSE r/p/y 0.0027 / 0.0026 / 0.0017°, max 0.0109°
- 진단: mode TRACKING, valid True, 비전 승인 1316 / 수신 1379, 게이트 기각 1, 재획득 0, IMU 200.0 Hz, 출력 154 Hz
- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): 7.22 / 38.88 ms (최근값 p50 5.98)
- 비전 처리 (보정+재전파) 최근값 p50 49.4 µs, 기동 후 최대 2207.0 µs
- 바이어스 추정 acc [0.0800, -0.0502, 0.0999] m/s², gyro [0.00149, -0.00099, 0.00080] rad/s
- HMI 경보: ERROR_IMU_DISCONNECT → WARN_FUSION_REINIT → INFO_IMU_RECOVERED → INFO_FUSION_INITIALIZED
- 인터록 전이: OFF → ON → OFF
## drexp

- 수신 2642건 / 18.0 s → **146.8 Hz** (stamp 역순 0건)
- stamp 간격 p50 / p99 / max: 7.52 / 10.17 / 19.91 ms, 15 ms 초과 2건
- 수신 지연 (now − stamp) p50 / p99 / max: 0.889 / 2.727 / 13.112 ms
- 위치 오차 (참값 대비, 2642건) RMSE 0.9480 mm, max 5.6639 mm
- 자세 오차 RMSE r/p/y 0.0033 / 0.0033 / 0.0020°, max 0.0118°
- 진단: mode TRACKING, valid True, 비전 승인 1161 / 수신 1193, 게이트 기각 1, 재획득 0, IMU 200.0 Hz, 출력 160 Hz
- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): 7.25 / 19.95 ms (최근값 p50 5.97)
- 비전 처리 (보정+재전파) 최근값 p50 40.9 µs, 기동 후 최대 620.9 µs
- 바이어스 추정 acc [0.0800, -0.0502, 0.1001] m/s², gyro [0.00150, -0.00101, 0.00078] rad/s
- HMI 경보: WARN_VISION_DROPOUT → ERROR_DR_TIMEOUT → INFO_VISION_RECOVERED
- 인터록 전이: OFF → ON → OFF
## outlier

- 수신 2818건 / 18.0 s → **156.6 Hz** (stamp 역순 0건)
- stamp 간격 p50 / p99 / max: 7.36 / 10.18 / 18.48 ms, 15 ms 초과 2건
- 수신 지연 (now − stamp) p50 / p99 / max: 0.869 / 3.072 / 49.754 ms
- 위치 오차 (참값 대비, 2818건) RMSE 0.1629 mm, max 0.4300 mm
- 자세 오차 RMSE r/p/y 0.0031 / 0.0024 / 0.0019°, max 0.0102°
- 진단: mode TRACKING, valid True, 비전 승인 1269 / 수신 1366, 게이트 기각 66, 재획득 0, IMU 200.0 Hz, 출력 159 Hz
- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): 7.21 / 55.69 ms (최근값 p50 5.66)
- 비전 처리 (보정+재전파) 최근값 p50 48.2 µs, 기동 후 최대 2438.2 µs
- 바이어스 추정 acc [0.0797, -0.0500, 0.1004] m/s², gyro [0.00150, -0.00097, 0.00077] rad/s
- HMI 경보: ERROR_IMU_DISCONNECT → INFO_IMU_RECOVERED → WARN_VISION_DROPOUT → INFO_VISION_RECOVERED
- 인터록 전이: OFF → ON → OFF
## v30i100

- 수신 2009건 / 18.0 s → **111.6 Hz** (stamp 역순 0건)
- stamp 간격 p50 / p99 / max: 9.97 / 10.28 / 58.45 ms, 15 ms 초과 5건
- 수신 지연 (now − stamp) p50 / p99 / max: 0.874 / 2.214 / 11.536 ms
- 위치 오차 (참값 대비, 2008건) RMSE 0.1893 mm, max 0.4047 mm
- 자세 오차 RMSE r/p/y 0.0036 / 0.0031 / 0.0020°, max 0.0112°
- 진단: mode TRACKING, valid True, 비전 승인 669 / 수신 685, 게이트 기각 0, 재획득 0, IMU 100.0 Hz, 출력 114 Hz
- e2e 지연 (촬영 → 발행, 1 s 창 최대의 p50 / max): 10.23 / 17.93 ms (최근값 p50 5.69)
- 비전 처리 (보정+재전파) 최근값 p50 38.9 µs, 기동 후 최대 132.1 µs
- 바이어스 추정 acc [0.0801, -0.0499, 0.0999] m/s², gyro [0.00149, -0.00098, 0.00077] rad/s
- HMI 경보: ERROR_IMU_DISCONNECT → INFO_IMU_RECOVERED → INFO_VISION_RECOVERED
- 인터록 전이: OFF → ON → OFF
