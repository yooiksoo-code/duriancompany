// pkg_sensor_fusion 단위·시나리오 시험
#include <gtest/gtest.h>

#include <numeric>

#include "pkg_sensor_fusion/sim_runner.hpp"

using namespace psf;
using namespace psf::sim;

namespace {

FusionConfig baseConfig() {
  FusionConfig c;
  applyDefaultMount(c);
  c.imu = ImuSimParams{}.noise;
  return c;
}

struct Metrics {
  double pos_rmse = 0, pos_max = 0, rot_rmse_deg = 0, nees = 0, vel_rmse = 0;
  int n = 0;
};

Metrics metrics(const ScenarioResult& R, double t_from = 5.0,
                FusionMode only = FusionMode::TRACKING) {
  Metrics m;
  for (const auto& s : R.out) {
    if (s.t < t_from || s.mode != only) continue;
    m.pos_rmse += s.e_pos.squaredNorm();
    m.rot_rmse_deg += s.e_rot.squaredNorm();
    m.vel_rmse += s.e_vel.squaredNorm();
    m.nees += s.nees;
    m.pos_max = std::max(m.pos_max, s.e_pos.norm());
    ++m.n;
  }
  if (m.n) {
    m.pos_rmse = std::sqrt(m.pos_rmse / m.n);
    m.rot_rmse_deg = std::sqrt(m.rot_rmse_deg / m.n) * 180 / M_PI;
    m.vel_rmse = std::sqrt(m.vel_rmse / m.n);
    m.nees /= m.n;
  }
  return m;
}

bool hasEvent(const ScenarioResult& R, const std::string& code) {
  for (const auto& e : R.events) if (e.code == code) return true;
  return false;
}

NominalState randomState(std::mt19937_64& g) {
  std::normal_distribution<double> n(0, 1);
  NominalState x;
  x.p = Vec3(n(g), n(g), n(g));
  x.v = 0.3 * Vec3(n(g), n(g), n(g));
  x.R = expSO3(Vec3(n(g), n(g), n(g)));
  x.ba = 0.05 * Vec3(n(g), n(g), n(g));
  x.bg = 0.002 * Vec3(n(g), n(g), n(g));
  return x;
}

VecE ominus(const NominalState& a, const NominalState& b) {
  VecE d;
  d.segment<3>(IP) = a.p - b.p;
  d.segment<3>(IV) = a.v - b.v;
  d.segment<3>(ITH) = logSO3(a.R * b.R.transpose());
  d.segment<3>(IBA) = a.ba - b.ba;
  d.segment<3>(IBG) = a.bg - b.bg;
  return d;
}

void perturb(NominalState& x, const VecE& d) {
  x.p += d.segment<3>(IP);
  x.v += d.segment<3>(IV);
  x.R = expSO3(d.segment<3>(ITH)) * x.R;
  x.ba += d.segment<3>(IBA);
  x.bg += d.segment<3>(IBG);
}

// IMU 0~1 s + 비전 0.75~0.9 s (초기화 창 확보) 를 넣어 초기화
void initEngine(SensorFusionEngine& eng, SensorSim& sim) {
  for (int i = 0; i < 200; ++i) eng.addImu(sim.imu(i * 0.005), fromSec(i * 0.005));
  for (int k = 0; k <= 9; ++k) eng.addVision(sim.vision(0.75 + k / 60.0), fromSec(0.95));
}

}  // namespace

// ------------------------------------------------------------------ 수학 기본
TEST(Math, So3ExpLogRoundTrip) {
  std::mt19937_64 g(3);
  std::normal_distribution<double> n(0, 1);
  for (int i = 0; i < 200; ++i) {
    Vec3 w(n(g), n(g), n(g));
    w *= (i % 2 ? 1e-7 : 3.0 / std::max(1.0, w.norm()));
    EXPECT_LT((logSO3(expSO3(w)) - w).norm(), 1e-9);
  }
}

TEST(Prediction, TransitionMatchesNumericalJacobian) {
  FusionConfig c = baseConfig();
  ImuPredictionEngine pe(c);
  std::mt19937_64 g(7);
  for (int trial = 0; trial < 5; ++trial) {
    NominalState x = randomState(g);
    const Vec3 a(0.3, -0.2, 9.9), w(0.2, -0.1, 0.3);
    const double dt = 0.005;
    const MatE Phi = pe.transition(x, a, w, dt);
    NominalState x1 = x; x1.t = 0;
    pe.propagateNominal(x1, a, w, fromSec(dt));
    MatE Num;
    for (int i = 0; i < kErr; ++i) {
      VecE d = VecE::Zero();
      d(i) = 1e-6;
      NominalState xi = x; xi.t = 0;
      perturb(xi, d);
      pe.propagateNominal(xi, a, w, fromSec(dt));
      Num.col(i) = ominus(xi, x1) / 1e-6;
    }
    EXPECT_LT((Num - Phi).cwiseAbs().maxCoeff(), 2e-4) << "trial " << trial;
  }
}

TEST(Update, MeasurementJacobianWithLeverArm) {
  FusionConfig c = baseConfig();
  VisionUpdateEngine ve(c);
  std::mt19937_64 g(9);
  NominalState x = randomState(g);
  const Mat6E H = ve.bodyPoseJacobian(x);
  Vec3 p0; Mat3 R0;
  ve.predictBody(x, p0, R0);
  for (int i = 0; i < kErr; ++i) {
    VecE d = VecE::Zero();
    d(i) = 1e-7;
    NominalState xi = x;
    perturb(xi, d);
    Vec3 p1; Mat3 R1;
    ve.predictBody(xi, p1, R1);
    Vec6 num;
    num << (p1 - p0) / 1e-7, logSO3(R1 * R0.transpose()) / 1e-7;
    EXPECT_LT((num - H.col(i)).norm(), 1e-5) << "col " << i;
  }
}

TEST(Prediction, StationaryIsStationary) {
  FusionConfig c = baseConfig();
  c.imu = ImuNoiseParams{};
  ImuPredictionEngine pe(c);
  NominalState x;
  x.R = expSO3(Vec3(0.01, -0.02, 0.7));
  const Vec3 a = x.R.transpose() * (-c.gravity_w);
  MatE P = MatE::Identity() * 1e-6;
  for (int i = 1; i <= 200; ++i) pe.propagate(x, P, a, Vec3::Zero(), a, Vec3::Zero(), fromSec(i * 0.005));
  EXPECT_LT(x.p.norm(), 1e-9);
  EXPECT_LT(x.v.norm(), 1e-9);
  EXPECT_GT(P(IP, IP), 1e-6);  // 공분산은 증가
}

// ------------------------------------------------------------------ 초기화
TEST(Init, StaticBiasEstimation) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 3.0;
  sp.traj.static_only = true;
  ScenarioRunner r(sp, c);
  Trajectory tr(sp.traj);
  SensorSim sim(tr, c, sp.imu, sp.vis, 1);
  SensorFusionEngine eng(c);
  for (int i = 0; i < 200; ++i) eng.addImu(sim.imu(i * 0.005), fromSec(i * 0.005));
  for (int k = 0; k <= 9; ++k) eng.addVision(sim.vision(0.75 + k / 60.0), fromSec(0.99));
  eng.addImu(sim.imu(1.0), fromSec(1.0));
  ASSERT_TRUE(eng.initialized());
  EXPECT_LT(eng.state().v.norm(), 3e-3);  // 정지 초기화 (이후 비전 3프레임 반영)
  EXPECT_LT((eng.state().bg - sim.trueBg()).norm(), 2e-4);
  EXPECT_LT((eng.state().ba - sim.trueBa()).norm(), 5e-3);  // 비전 자세 오차 × g 수준
}

TEST(Init, WaitsForImuThenInitializes) {
  FusionConfig c = baseConfig();
  SensorFusionEngine eng(c);
  Trajectory tr;
  SensorSim sim(tr, c, {}, {}, 2);
  EXPECT_EQ(eng.addVision(sim.vision(0.0), fromSec(0.01)), VisionResult::WAIT_INIT);
  EXPECT_FALSE(eng.initialized());
  for (int i = 1; i < 300; ++i) eng.addImu(sim.imu(i * 0.005), fromSec(i * 0.005));
  EXPECT_FALSE(eng.initialized());  // 후보 비전보다 이전 IMU 가 없으면 (1 s 대기 후) 다음 비전에서
  eng.addVision(sim.vision(1.4), fromSec(1.41));
  EXPECT_TRUE(eng.initialized());
}

// ------------------------------------------------------------------ 정상 추적
TEST(Tracking, AccuracyAndConsistency) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 40.0;
  ScenarioRunner r(sp, c);
  const auto R = r.run();
  const auto m = metrics(R);
  EXPECT_LT(m.pos_rmse, 1.0e-3);       // KPI ±5 mm 대비 여유
  EXPECT_LT(m.rot_rmse_deg, 0.02);     // KPI ±0.2°
  EXPECT_GT(m.nees, 3.5);              // 6 DoF 기대값 6
  EXPECT_LT(m.nees, 8.5);
  EXPECT_LT(m.vel_rmse, 5e-3);
  EXPECT_EQ(R.stats.vision_rejected_gate, 0u + R.stats.vision_rejected_gate);  // 기록용
  EXPECT_LT(static_cast<double>(R.stats.vision_rejected_gate) / R.stats.vision_accepted, 0.01);
}

TEST(Tracking, BiasConvergesWhileMoving) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 30.0;
  sp.traj.t_start_motion = -10;  // 처음부터 움직임 → 정지 초기화 불가
  SensorFusionEngine eng(c);
  Trajectory tr(sp.traj);
  SensorSim sim(tr, c, sp.imu, sp.vis, 4);
  double tv = 0;
  for (double t = 0; t < sp.duration; t += 0.005) {
    eng.addImu(sim.imu(t), fromSec(t + 5e-4));
    if (t >= tv) { eng.addVision(sim.vision(t - 0.006), fromSec(t)); tv += 1.0 / 60; }
  }
  ASSERT_TRUE(eng.initialized());
  EXPECT_LT((eng.state().ba - sim.trueBa()).norm(), 5e-3);
  EXPECT_LT((eng.state().bg - sim.trueBg()).norm(), 1e-4);
}

// ------------------------------------------------------------------ 시간 비동기
TEST(TimeSkew, ReplayBeatsNaiveUnderLatency) {
  ScenarioParams sp;
  sp.duration = 30.0;
  sp.vis.latency_min_s = 0.030;
  sp.vis.latency_max_s = 0.045;
  FusionConfig c = baseConfig();
  const auto mr = metrics(ScenarioRunner(sp, c).run());
  c.replay_enable = false;
  const auto mn = metrics(ScenarioRunner(sp, c).run());
  EXPECT_LT(mr.pos_rmse, 1.0e-3);
  EXPECT_LT(mr.nees, 9.0);
  EXPECT_GT(mn.pos_rmse, 2.0 * mr.pos_rmse);  // 지연 무시 시 0.3 m/s × 40 ms ≈ 12 mm 편향
}

TEST(TimeSkew, OutOfOrderVisionEqualsInOrder) {
  FusionConfig c = baseConfig();
  Trajectory tr;
  auto runOrder = [&](bool swap) {
    SensorSim sim(tr, c, {}, {}, 11);
    SensorFusionEngine eng(c);
    std::vector<VisionMeas> vs;
    for (double t = 0; t < 3.0; t += 1.0 / 60) vs.push_back(sim.vision(t));
    SensorSim simi(tr, c, {}, {}, 12);
    size_t iv = 0;
    for (double t = 0; t < 3.0; t += 0.005) {
      eng.addImu(simi.imu(t), fromSec(t));
      while (iv + 1 < vs.size() && toSec(vs[iv + 1].stamp) + 0.012 <= t) {
        if (swap && iv > 120 && iv % 7 == 0) {
          eng.addVision(vs[iv + 1], fromSec(t));
          eng.addVision(vs[iv], fromSec(t));
        } else {
          eng.addVision(vs[iv], fromSec(t));
          eng.addVision(vs[iv + 1], fromSec(t));
        }
        iv += 2;
      }
    }
    return eng.state();
  };
  const NominalState a = runOrder(false), b = runOrder(true);
  EXPECT_LT((a.p - b.p).norm(), 1e-6);
  EXPECT_LT(logSO3(a.R * b.R.transpose()).norm(), 1e-7);
}

TEST(TimeSkew, PendingVisionAheadOfImu) {
  // IMU 수신이 비전보다 늦는 경우: 보류 후 IMU 도착 시 반영, 만료 시 외삽 반영
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 20.0;
  sp.imu.latency_s = 0.020;
  sp.vis.latency_min_s = 0.002;
  sp.vis.latency_max_s = 0.004;
  const auto R = ScenarioRunner(sp, c).run();
  const auto m = metrics(R);
  EXPECT_LT(m.pos_rmse, 1.0e-3);
  EXPECT_GT(R.stats.vision_accepted, 1000u);
}

// ------------------------------------------------------------------ 결손 대응
TEST(Dropout, TwoSecondDeadReckoning) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 26.0;
  sp.vision_blackouts = {{20.0, 22.0}};
  const auto R = ScenarioRunner(sp, c).run();
  EXPECT_TRUE(hasEvent(R, "WARN_VISION_DROPOUT"));
  EXPECT_TRUE(hasEvent(R, "INFO_VISION_RECOVERED"));
  EXPECT_FALSE(hasEvent(R, "ERROR_DR_TIMEOUT"));
  double e_end = 0;
  for (const auto& s : R.out) if (s.t < 22.0 && s.t > 21.9) e_end = s.e_pos.norm();
  Trajectory tr(sp.traj);
  double dist = 0;
  for (double t = 20.0; t < 22.0; t += 0.001) dist += (tr.pos(t + 0.001) - tr.pos(t)).norm();
  EXPECT_LT(e_end / dist, 0.01);  // KPI 6
  // 출력은 결손 중에도 끊기지 않음
  int n_dr = 0;
  for (const auto& s : R.out) if (s.t > 20.1 && s.t < 21.9) { EXPECT_TRUE(s.valid); ++n_dr; }
  EXPECT_GE(n_dr, 175);
}

TEST(Dropout, ExpiredSetsInvalidAndInterlock) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 16.0;
  sp.vision_blackouts = {{10.0, 13.0}};
  const auto R = ScenarioRunner(sp, c).run();
  EXPECT_TRUE(hasEvent(R, "ERROR_DR_TIMEOUT"));
  EXPECT_TRUE(hasEvent(R, "INFO_VISION_RECOVERED"));
  bool saw_invalid = false;
  for (const auto& s : R.out)
    if (s.t > 12.2 && s.t < 12.9) { EXPECT_FALSE(s.valid); saw_invalid = true; }
  EXPECT_TRUE(saw_invalid);
  const auto m = metrics(R, 13.5);
  EXPECT_LT(m.pos_rmse, 1.0e-3);  // 복귀 후 재수렴
}

// ------------------------------------------------------------------ 이상치
TEST(Outlier, LargeJumpsAllRejected) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 30.0;
  sp.outliers.prob = 0.05;
  sp.outliers.jump_pos = 0.005;  // 5 mm 반사상
  const auto R = ScenarioRunner(sp, c).run();
  EXPECT_GT(R.outliers_injected, 50);
  EXPECT_EQ(R.outliers_rejected, R.outliers_injected);
  EXPECT_LT(metrics(R).pos_max, 2e-3);
}

TEST(Outlier, FlipAmbiguityRejected) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 20.0;
  sp.outliers.prob = 0.05;
  sp.outliers.jump_rot = 5.0 * M_PI / 180;
  const auto R = ScenarioRunner(sp, c).run();
  EXPECT_EQ(R.outliers_rejected, R.outliers_injected);
}

TEST(Outlier, RelockAfterPersistentShift) {
  // 측정 기준이 영구적으로 20 mm 이동 (외부보정 갱신 등) → 0.5 s 기각 후 재획득
  FusionConfig c = baseConfig();
  Trajectory tr;
  SensorSim sim(tr, c, {}, {}, 5);
  SensorFusionEngine eng(c);
  double tv = 0;
  bool relock = false;
  for (double t = 0; t < 12.0; t += 0.005) {
    eng.addImu(sim.imu(t), fromSec(t));
    if (t >= tv) {
      VisionMeas z = sim.vision(t - 0.008);
      if (t > 8.0) z.p += Vec3(0.02, 0, 0);
      eng.addVision(z, fromSec(t));
      tv += 1.0 / 60;
    }
    for (auto& e : eng.takeEvents()) if (e.code == "INFO_VISION_RELOCK") relock = true;
  }
  EXPECT_TRUE(relock);
  Vec3 pB; Mat3 RB;
  VisionUpdateEngine(c).predictBody(eng.state(), pB, RB);
  EXPECT_LT((pB - (tr.pos(toSec(eng.stateTime())) + Vec3(0.02, 0, 0))).norm(), 1e-3);
  EXPECT_EQ(eng.mode(), FusionMode::TRACKING);
}

// ------------------------------------------------------------------ IMU 결함
TEST(ImuFault, ShortGapBridgedWithAlert) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 15.0;
  sp.imu_blackouts = {{8.0, 8.08}};
  const auto R = ScenarioRunner(sp, c).run();
  EXPECT_TRUE(hasEvent(R, "ERROR_IMU_DISCONNECT"));
  EXPECT_TRUE(hasEvent(R, "INFO_IMU_RECOVERED"));
  EXPECT_FALSE(hasEvent(R, "WARN_FUSION_REINIT"));
  EXPECT_EQ(R.stats.imu_bridged, 1u);
  EXPECT_LT(metrics(R, 9.0).pos_rmse, 1.0e-3);
}

TEST(ImuFault, LongGapReinitializesKeepingBias) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 15.0;
  sp.imu_blackouts = {{8.0, 8.4}};
  const auto R = ScenarioRunner(sp, c).run();
  EXPECT_TRUE(hasEvent(R, "ERROR_IMU_DISCONNECT"));
  EXPECT_TRUE(hasEvent(R, "WARN_FUSION_REINIT"));
  EXPECT_EQ(R.stats.inits, 2u);
  // 등속 주행 중 재초기화: IMU 분산이 작아도 정지로 오판하면 안 됨
  for (const auto& e : R.events) {
    if (e.code == "INFO_FUSION_INITIALIZED" && toSec(e.stamp) > 8.0) { EXPECT_NE(e.info, "static"); }
  }
  EXPECT_FALSE(hasEvent(R, "INFO_VISION_RELOCK"));
  EXPECT_LT(metrics(R, 9.0).pos_rmse, 1.0e-3);
}

TEST(ImuFault, TimeoutDetectedByTick) {
  FusionConfig c = baseConfig();
  SensorFusionEngine eng(c);
  Trajectory tr;
  SensorSim sim(tr, c, {}, {}, 6);
  initEngine(eng, sim);
  ASSERT_TRUE(eng.initialized());
  eng.tick(fromSec(0.995 + 0.040));
  EXPECT_FALSE(eng.interlock());
  eng.tick(fromSec(0.995 + 0.060));
  EXPECT_EQ(eng.mode(), FusionMode::IMU_LOST);
  EXPECT_TRUE(eng.interlock());
}

// ------------------------------------------------------------------ 입력 검증
TEST(Input, InvalidInputsRejected) {
  FusionConfig c = baseConfig();
  SensorFusionEngine eng(c);
  Trajectory tr;
  SensorSim sim(tr, c, {}, {}, 8);
  for (int i = 0; i < 200; ++i) eng.addImu(sim.imu(i * 0.005), fromSec(i * 0.005));
  ImuSample bad = sim.imu(1.0);
  bad.acc.x() = std::nan("");
  EXPECT_FALSE(eng.addImu(bad, fromSec(1.0)));
  ImuSample dup = sim.imu(0.995 - 0.005);
  EXPECT_FALSE(eng.addImu(dup, fromSec(1.0)));
  EXPECT_EQ(eng.stats().imu_rejected, 2u);

  VisionMeas z = sim.vision(0.9);
  z.p.y() = std::nan("");
  EXPECT_EQ(eng.addVision(z, fromSec(1.0)), VisionResult::REJECT_INVALID);
  VisionResult last = VisionResult::WAIT_INIT;
  for (int k = 0; k <= 9; ++k) {
    z = sim.vision(0.75 + k / 60.0);
    z.cov.setZero();  // 공분산 미기재 → 기본값 사용
    last = eng.addVision(z, fromSec(1.0));
  }
  EXPECT_NE(last, VisionResult::REJECT_INVALID);
  EXPECT_TRUE(eng.initialized());
  z = sim.vision(0.99);
  z.cov(0, 0) = -1.0;  // 비정상 → 고유값 절단 후 사용
  EXPECT_NE(eng.addVision(z, fromSec(1.0)), VisionResult::REJECT_INVALID);
}

TEST(Input, StaleVisionRejected) {
  FusionConfig c = baseConfig();
  SensorFusionEngine eng(c);
  Trajectory tr;
  SensorSim sim(tr, c, {}, {}, 10);
  initEngine(eng, sim);
  for (int i = 200; i < 600; ++i) eng.addImu(sim.imu(i * 0.005), fromSec(i * 0.005));
  EXPECT_EQ(eng.addVision(sim.vision(1.0), fromSec(3.0)), VisionResult::REJECT_STALE);
}

// ------------------------------------------------------------------ 단일 태그 구간
TEST(SingleTag, DegradedButBounded) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 30.0;
  sp.single_tag = {{10.0, 20.0}};
  const auto R = ScenarioRunner(sp, c).run();
  Metrics m;
  for (const auto& s : R.out) if (s.t > 10.5 && s.t < 20.0) m.pos_max = std::max(m.pos_max, s.e_pos.norm());
  EXPECT_LT(m.pos_max, 5e-3);
  EXPECT_LT(metrics(R, 21.0).pos_rmse, 1.0e-3);
}

// ------------------------------------------------------------------ 연산 시간 (KPI 5 ≤ 1.5 ms)
TEST(Timing, CycleWellBelowBudget) {
  FusionConfig c = baseConfig();
  ScenarioParams sp;
  sp.duration = 20.0;
  const auto R = ScenarioRunner(sp, c).run();
  std::vector<double> v = R.cycle_us;
  std::sort(v.begin(), v.end());
  const double p50 = v[v.size() / 2];
  EXPECT_LT(p50, 300.0);  // 개발 컨테이너 기준 (공유 vCPU) 여유값
}
