// 오프라인 시나리오 실행기 — 센서 이벤트를 "도착 시각" 순으로 엔진에 공급하고 참값과 비교한다.
// gtest 와 KPI 벤치(tools/sensor_fusion_bench.cpp)가 공유한다.
#pragma once

#include <algorithm>
#include <chrono>
#include <functional>
#include <map>
#include <Eigen/Cholesky>
#include <Eigen/Eigenvalues>
#include <vector>

#include "pkg_sensor_fusion/output_scheduler.hpp"
#include "pkg_sensor_fusion/sim_world.hpp"

namespace psf::sim {

struct Interval { double t0, t1; };

struct OutlierParams {
  double prob = 0.0;           // 프레임당 주입 확률
  double sigma_mult = 0.0;     // >0: k·σ 점프 (σ = 보고 공분산)
  bool all_axes = false;       // false: 임의 한 축, true: 6축 모두 k·σ (부호 무작위)
  double jump_pos = 0.0;       // 고정 크기 점프 [m] (반사상 등)
  double jump_rot = 0.0;       // [rad] (단일 태그 Flip 등)
};

struct ScenarioParams {
  double duration = 60.0;
  TrajectoryParams traj;
  ImuSimParams imu;
  VisionSimParams vis;
  std::vector<Interval> vision_blackouts;
  std::vector<Interval> imu_blackouts;
  std::vector<Interval> single_tag;    // 이 구간: 회전 σ×5, 위치 σ×10, 꼬리 낙관 (모듈 2 R4)
  OutlierParams outliers;
  double tick_period = 0.005;          // 노드 타이머 모사
  uint64_t seed = 1;
};

struct OutputSample {
  double t, t_pub;
  Vec3 e_pos;     // 추정 − 참값 (선체 기준점, world)
  Vec3 e_rot;     // Log(R_est R_trueᵀ) (world)
  Vec3 e_vel;     // body 프레임 선속도 오차
  double sig_pos; // 위치 1σ 최대 고유값 √
  double nees;    // 6DoF 포즈 NEES
  FusionMode mode;
  bool valid;
};

struct ScenarioResult {
  std::vector<OutputSample> out;
  std::vector<double> cycle_us;     // 비전 1회 (보정+재전파) + 직전 예측 1회
  std::vector<double> imu_us;
  std::vector<double> e2e_ms;       // 촬영 → 융합 출력 발행
  std::vector<double> fusion_added_ms;  // 비전 도착 → 융합 출력 발행
  std::vector<double> slow_latency_stamps;  // 추가분 > 3 ms 인 비전 stamp (진단용)
  std::vector<FusionEvent> events;
  int outliers_injected = 0, outliers_rejected = 0, inliers_rejected = 0, inliers = 0;
  FusionStats stats;
  double expected_outputs = 0;
  int regular_outputs = 0;
};

class ScenarioRunner {
 public:
  ScenarioRunner(const ScenarioParams& sp, const FusionConfig& cfg) : sp_(sp), cfg_(cfg) {}

  ScenarioResult run() {
    Trajectory tr(sp_.traj);
    SensorSim sim(tr, cfg_, sp_.imu, sp_.vis, sp_.seed);
    SensorFusionEngine eng(cfg_);
    ScenarioResult R;

    struct Ev { double arrival; int kind; double t; };  // kind 0 imu, 1 vision, 2 tick
    std::vector<Ev> evs;
    const double dti = 1.0 / sp_.imu.rate_hz, dtv = 1.0 / sp_.vis.rate_hz;
    for (double t = 0; t < sp_.duration; t += dti)
      if (!in(sp_.imu_blackouts, t)) evs.push_back({t + sp_.imu.latency_s, 0, t});
    for (double t = 0.5 * dtv; t < sp_.duration; t += dtv)
      if (!in(sp_.vision_blackouts, t)) evs.push_back({t + sim.visionLatency(), 1, t});
    for (double t = 0; t < sp_.duration; t += sp_.tick_period) evs.push_back({t, 2, t});
    std::stable_sort(evs.begin(), evs.end(), [](const Ev& a, const Ev& b) { return a.arrival < b.arrival; });

    OutputScheduler sched(cfg_);
    lat_wait_.clear();
    auto& lat_wait = lat_wait_;
    double imu_us_prev = 0;

    auto publish = [&](const FusedOutput& o, double t_pub) {
      record(tr, o, t_pub, R);
      const TimeNs applied = eng.stats().last_vision_stamp_applied;
      size_t w = 0;
      for (auto& p : lat_wait) {
        if (p.stamp <= applied) {
          R.e2e_ms.push_back((t_pub - toSec(p.stamp)) * 1e3);
          R.fusion_added_ms.push_back((t_pub - p.arrival) * 1e3);
          if ((t_pub - p.arrival) > 3e-3) R.slow_latency_stamps.push_back(toSec(p.stamp));
        } else {
          lat_wait[w++] = p;
        }
      }
      lat_wait.resize(w);
    };

    for (const Ev& e : evs) {
      const TimeNs now = fromSec(e.arrival);
      if (e.kind == 2) { eng.tick(now); for (auto& ev : eng.takeEvents()) R.events.push_back(ev); continue; }
      if (e.kind == 0) {
        const bool adv = eng.addImu(sim.imu(e.t), now);
        imu_us_prev = eng.stats().last_imu_proc_us;
        R.imu_us.push_back(imu_us_prev);
        // 이 IMU 로 보류 비전이 반영되었는지
        bool vis_applied = false;
        for (auto& oc : eng.takeVisionOutcomes()) {
          resolveOutcome(oc, R);
          if (oc.result == VisionResult::ACCEPTED) vis_applied = true;
        }
        FusedOutput o;
        bool regular = false;
        if (sched.onImu(eng, adv, vis_applied, o, regular)) {
          if (regular) ++R.regular_outputs;
          publish(o, e.arrival + imu_us_prev * 1e-6);
        }
      } else {
        VisionMeas z = sim.vision(e.t);
        bool single = in(sp_.single_tag, e.t);
        if (single) corruptSingleTag(sim, z);
        bool injected = false;
        if (sp_.outliers.prob > 0 && sim.uniform() < sp_.outliers.prob && eng.initialized()) {
          injectOutlier(sim, z);
          injected = true;
        }
        if (eng.initialized()) {
          injected_map_[z.stamp] = injected;
          if (injected) ++R.outliers_injected; else ++R.inliers;
        }
        const VisionResult res = eng.addVision(z, fromSec(e.arrival));
        const double vus = eng.stats().last_vision_proc_us;
        R.cycle_us.push_back(vus + imu_us_prev);
        if (res == VisionResult::ACCEPTED || res == VisionResult::PENDING)
          lat_wait.push_back({z.stamp, e.arrival});
        FusedOutput o;
        if (sched.onVision(eng, res, fromSec(e.arrival + vus * 1e-6), o)) publish(o, e.arrival + vus * 1e-6);
      }
      for (auto& ev : eng.takeEvents()) R.events.push_back(ev);
      for (auto& oc : eng.takeVisionOutcomes()) resolveOutcome(oc, R);
    }
    R.stats = eng.stats();
    R.expected_outputs = sp_.duration * (cfg_.output_rate_hz > 0 ? std::min(cfg_.output_rate_hz, sp_.imu.rate_hz) : sp_.imu.rate_hz);
    return R;
  }

 private:
  static bool in(const std::vector<Interval>& v, double t) {
    for (const auto& i : v) if (t >= i.t0 && t < i.t1) return true;
    return false;
  }

  void resolveOutcome(const VisionOutcome& oc, ScenarioResult& R) {
    if (oc.result != VisionResult::ACCEPTED) {  // 기각된 측정은 지연 계측 대상에서 제외
      size_t w = 0;
      for (auto& p : lat_wait_) if (p.stamp != oc.stamp) lat_wait_[w++] = p;
      lat_wait_.resize(w);
    }
    auto it = injected_map_.find(oc.stamp);
    if (it == injected_map_.end()) return;
    if (oc.result == VisionResult::REJECT_MAHALANOBIS) (it->second ? R.outliers_rejected : R.inliers_rejected)++;
    injected_map_.erase(it);
  }

  void record(const Trajectory& tr, const FusedOutput& o, double t_pub, ScenarioResult& R) {
    const double t = toSec(o.stamp);
    const BodyTruth b = tr.truth(t);
    OutputSample s;
    s.t = t;
    s.t_pub = t_pub;
    s.e_pos = o.p - b.p;
    s.e_rot = logSO3(o.q.toRotationMatrix() * b.R.transpose());
    s.e_vel = o.v_body - b.R.transpose() * b.v;
    Vec6 e;
    e << s.e_pos, s.e_rot;
    Eigen::SelfAdjointEigenSolver<Mat3> es(o.pose_cov.block<3, 3>(0, 0));
    s.sig_pos = std::sqrt(std::max(0.0, es.eigenvalues().maxCoeff()));
    s.nees = e.dot(o.pose_cov.ldlt().solve(e));
    s.mode = o.mode;
    s.valid = o.valid;
    R.out.push_back(s);
  }

  void corruptSingleTag(SensorSim& sim, VisionMeas& z) {
    // 단일 태그: 위치 σ ×10, 회전 σ ×5 보고. 실제 오차는 보고보다 25 % 크고 5 % 확률로 3σ 꼬리
    const auto& vp = sim.visionParams();
    const Vec3 sp = vp.sigma_pos * 10.0, sr = vp.sigma_rot * 5.0;
    double k = 1.25;
    if (sim.uniform() < 0.05) k = 3.0;
    z.p += k * sp.cwiseProduct(sim.gauss3());
    z.q = normalized(Quat(expSO3(k * sr.cwiseProduct(sim.gauss3())) * z.q.toRotationMatrix()));
    z.cov.diagonal().head<3>() = (sp.cwiseAbs2() + vp.sigma_pos.cwiseAbs2()) * vp.cov_report_scale;
    z.cov.diagonal().tail<3>() = (sr.cwiseAbs2() + vp.sigma_rot.cwiseAbs2()) * vp.cov_report_scale;
  }

  void injectOutlier(SensorSim& sim, VisionMeas& z) {
    const auto& o = sp_.outliers;
    if (o.sigma_mult > 0) {
      Vec6 d = Vec6::Zero();
      const Vec6 sig = z.cov.diagonal().cwiseSqrt();
      if (o.all_axes) {
        for (int i = 0; i < 6; ++i) d(i) = (sim.uniform() < 0.5 ? -1 : 1) * o.sigma_mult * sig(i);
      } else {
        const int ax = std::min(5, static_cast<int>(sim.uniform() * 6));
        d(ax) = (sim.uniform() < 0.5 ? -1 : 1) * o.sigma_mult * sig(ax);
      }
      z.p += d.head<3>();
      z.q = normalized(Quat(expSO3(d.tail<3>()) * z.q.toRotationMatrix()));
    }
    if (o.jump_pos > 0) z.p += o.jump_pos * sim.gauss3().normalized();
    if (o.jump_rot > 0)
      z.q = normalized(Quat(expSO3(o.jump_rot * sim.gauss3().normalized()) * z.q.toRotationMatrix()));
  }

  ScenarioParams sp_;
  FusionConfig cfg_;
  std::map<TimeNs, bool> injected_map_;
  struct PendingLat { TimeNs stamp; double arrival; };
  std::vector<PendingLat> lat_wait_;
};

}  // namespace psf::sim
