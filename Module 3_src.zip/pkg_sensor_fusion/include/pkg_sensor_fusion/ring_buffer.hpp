// 고정 용량 링 버퍼 — 실행 중 동적할당 없음 (용량은 configure 시 1회 할당)
#pragma once

#include <cassert>
#include <cstddef>
#include <vector>

namespace psf {

template <typename T>
class RingBuffer {
 public:
  void reserve(size_t cap) { buf_.assign(cap, T{}); head_ = 0; size_ = 0; }
  size_t capacity() const { return buf_.size(); }
  size_t size() const { return size_; }
  bool empty() const { return size_ == 0; }
  void clear() { head_ = 0; size_ = 0; }

  // 가득 차면 가장 오래된 원소를 덮어쓴다
  T& push_back(const T& v) {
    assert(!buf_.empty());
    if (size_ == buf_.size()) { head_ = (head_ + 1) % buf_.size(); --size_; }
    T& slot = buf_[(head_ + size_) % buf_.size()];
    slot = v;
    ++size_;
    return slot;
  }
  void pop_front() { if (size_) { head_ = (head_ + 1) % buf_.size(); --size_; } }
  void pop_back() { if (size_) --size_; }
  T& operator[](size_t i) { return buf_[(head_ + i) % buf_.size()]; }
  const T& operator[](size_t i) const { return buf_[(head_ + i) % buf_.size()]; }
  T& front() { return (*this)[0]; }
  const T& front() const { return (*this)[0]; }
  T& back() { return (*this)[size_ - 1]; }
  const T& back() const { return (*this)[size_ - 1]; }

 private:
  std::vector<T> buf_;
  size_t head_ = 0, size_ = 0;
};

}  // namespace psf
