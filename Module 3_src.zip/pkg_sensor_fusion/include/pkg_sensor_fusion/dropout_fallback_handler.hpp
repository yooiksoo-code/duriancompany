// [세부 3] Vision Dropout Fallback Handler — 운용 모드 상태기계와 HMI 이벤트
//
//   UNINITIALIZED ──첫 비전+IMU──▶ TRACKING ──비전 age > dropout_timeout──▶ DEAD_RECKONING
//        ▲                            ▲  └──────────── 비전 승인 ◀──────────────┘   │ DR > max_dr(2 s)
//        │ IMU 공백 > bridge          └──────────── 비전 승인 ◀── DR_EXPIRED ◀──────┘
//   IMU_LOST (IMU 수신 공백 > imu_timeout, 출력 중단·인터록)
//
// 추측항법 시간(2 s)은 결손 판정 시점(age > dropout_timeout)부터 센다 → 비전 age 상한 = timeout + max_dr.
// (2 s 차단 시험에서 차단 직전 프레임 간격·처리지연만큼 age 가 2 s 를 넘는 것을 오판하지 않기 위함)
// 비전 age 는 "마지막으로 *승인된* 비전의 촬영 시각" 부터 필터 상태 시각까지의 차이다.
// (게이트에서 기각된 측정은 비전이 없는 것과 같다)
#pragma once

#include <string>
#include <vector>

#include "pkg_sensor_fusion/fusion_config.hpp"

namespace psf {

struct FusionEvent {
  TimeNs stamp = 0;
  std::string code;   // WARN_VISION_DROPOUT, INFO_VISION_RECOVERED, ERROR_DR_TIMEOUT, ...
  std::string info;
};

class DropoutFallbackHandler {
 public:
  explicit DropoutFallbackHandler(const FusionConfig& cfg) : cfg_(cfg) {}

  void reset() { mode_ = FusionMode::UNINITIALIZED; dr_start_ = 0; }

  // 상태가 갱신될 때마다 호출. 전이 시 events 에 추가하고 현재 모드를 반환
  FusionMode update(TimeNs t_state, TimeNs last_vision_stamp, bool initialized, bool imu_lost,
                    std::vector<FusionEvent>& events);

  FusionMode mode() const { return mode_; }
  // 제어 인터록 (속도 지령 0 유도): IMU 유실 또는 추측항법 시간 초과
  bool interlock() const { return mode_ == FusionMode::IMU_LOST || mode_ == FusionMode::DR_EXPIRED; }
  TimeNs drStart() const { return dr_start_; }

 private:
  const FusionConfig& cfg_;
  FusionMode mode_ = FusionMode::UNINITIALIZED;
  TimeNs dr_start_ = 0;
};

}  // namespace psf
