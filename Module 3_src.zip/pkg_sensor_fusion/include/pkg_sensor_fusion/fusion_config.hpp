// 엔진 설정 — 기본값은 이 파일 한 곳에만 둔다 (ROS 파라미터 / YAML 은 이 값을 덮어씀)
#pragma once

#include "pkg_sensor_fusion/types.hpp"

namespace psf {

struct ImuNoiseParams {
  // 연속시간 잡음 밀도 (데이터시트/Allan 분산에서 읽음)
  // 기본값 = 산업용 MEMS 급 가정 (≈60 µg/√Hz, 0.34 °/√h). 실제 IMU 로 교체할 것
  double acc_noise = 6.0e-4;      // [m/s^2/√Hz]   (VRW)
  double gyro_noise = 1.0e-4;     // [rad/s/√Hz]   (ARW)
  double acc_bias_rw = 1.0e-5;    // [m/s^3/√Hz]   바이어스 랜덤워크
  double gyro_bias_rw = 3.0e-6;   // [rad/s^2/√Hz]
};

struct FusionConfig {
  // --- 좌표 / 장착
  Vec3 gravity_w{0.0, 0.0, -9.80665};   // dock_world_frame 기준 중력 (Z-up 가정)
  Vec3 t_body_imu = Vec3::Zero();       // IMU 원점의 선체 좌표 위치 (레버암) [m]
  Quat q_body_imu = Quat::Identity();   // R_B_I

  // --- IMU
  ImuNoiseParams imu;
  double imu_timeout_s = 0.050;         // 설계서 6장 1) 50 ms
  double imu_max_bridge_gap_s = 0.150;  // 이 이하 공백은 선형보간으로 적분, 초과 시 재초기화
  double imu_acc_limit = 16 * 9.80665;  // 포화/이상값 판정
  double imu_gyro_limit = 35.0;         // [rad/s]
  double imu_time_offset_s = 0.0;       // IMU stamp 보정 (t_true = t_imu + offset)

  // --- 비전
  double vision_cov_scale = 1.0;        // 모듈 2 공분산 배율 (테스트베드 보정)
  double vision_min_sigma_pos = 5.0e-5; // 공분산 하한 [m]  (계통오차 여유)
  double vision_min_sigma_rot = 5.0e-5; // [rad] (≈0.003°)
  double vision_default_sigma_pos = 1.0e-3;  // 공분산이 비어 있을 때
  double vision_default_sigma_rot = 1.0e-3;
  double vision_max_pending_s = 0.030;  // IMU 가 비전 시각에 도달할 때까지 최대 대기

  // --- 게이트 (설계서 4장 2)
  bool gate_enable = true;
  double gate_chi2 = 22.458;            // χ²(6) 99.9 %
  double relock_timeout_s = 0.5;        // 연속 기각이 이 시간 지속되면 재획득 검토
  int relock_min_consistent = 5;        // 재획득 판단에 쓰는 최근 기각 측정 수
  double relock_max_speed = 0.5;        // 기각 측정끼리 일관성 판정 [m/s]
  double relock_max_rate = 0.2618;      // [rad/s] (15°/s)

  // --- 결손 대응 (설계서 4장 3)
  double dropout_timeout_s = 0.050;     // 설계서 33 ms → 30 Hz 주기와 같아 오전환. 검토 R6 참조
  double max_dead_reckoning_s = 2.0;    // 안전 제한 시간

  // --- 지연 보상 (설계서 6장 2)
  double history_s = 0.5;               // 상태·IMU 이력 길이 (재전파 창)
  bool replay_enable = true;            // false: 도착 즉시 현재 상태에 적용 (비교 시험용)

  // --- 초기화
  double init_static_window_s = 0.5;
  double init_static_gyro_std = 0.01;   // [rad/s]
  double init_static_acc_std = 0.05;    // [m/s^2]
  double init_static_max_speed = 0.015; // 비전 변위로 본 정지 판정 [m/s] (IMU 만으로는 등속을 구분 못함, 비전 잡음 여유)
  double init_vel_window_s = 0.10;      // 비전 차분 속도 추정 창
  double init_sigma_vel = 0.5;          // 정지 아님 판정 시 [m/s]
  double init_sigma_ba = 0.2;           // [m/s^2]
  double init_sigma_bg = 0.01;          // [rad/s]
  double init_sigma_ba_static = 0.02;
  double init_sigma_bg_static = 3.0e-4;
  double init_sigma_vel_static = 1.0e-3;

  // --- 출력 (설계서 5장 ②)
  // 0 이면 IMU 샘플마다 발행 (200 Hz IMU → 200 Hz). >0 이면 그 주기 이상 간격으로 솎아냄
  double output_rate_hz = 100.0;
  // 비전 갱신 직후 현재 시각까지 외삽한 출력을 추가 발행 (지연 KPI 우선, 주기는 불규칙해짐) — 검토 I4
  bool output_on_vision_update = true;
  double output_max_extrapolation_s = 0.030;  // 외삽 상한
};

}  // namespace psf
