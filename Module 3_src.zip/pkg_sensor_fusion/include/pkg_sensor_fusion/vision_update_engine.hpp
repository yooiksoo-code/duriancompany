// [세부 2] VisionUpdateEngine — 비전 6DoF 관측 갱신 + Mahalanobis 게이트
//
// 관측 모델 (상태는 IMU 프레임, 측정은 선체 기준점 B):
//   h(x) = T_W_I · T_I_B :  p_B = p + R·r_IB ,  R_B = R·R_IB
// 잔차 (6):  r = [ p_meas − p̂_B ;  Log(R_meas · R̂_Bᵀ) ]   (월드 고정축 → 모듈 2 공분산과 같은 정의)
// 야코비안:  H = [ I 0 −[R̂ r_IB]× 0 0 ;  0 0 I 0 0 ]
//   K = P Hᵀ (H P Hᵀ + R)⁻¹ ,  P⁺ = (I−KH) P (I−KH)ᵀ + K R Kᵀ  (Joseph 형식)
//   d² = rᵀ S⁻¹ r  > χ²_6  이면 기각
#pragma once

#include "pkg_sensor_fusion/fusion_config.hpp"

namespace psf {

struct UpdateInfo {
  double mahalanobis2 = 0;  // d²
  Vec6 residual = Vec6::Zero();
  bool accepted = false;
  bool cov_floored = false;
};

class VisionUpdateEngine {
 public:
  explicit VisionUpdateEngine(const FusionConfig& cfg) : cfg_(cfg) {}

  // 측정 공분산 정리: 배율, 대칭화, 하한, 유효성. 사용 불가면 false
  bool conditionCovariance(const Mat6& in, Mat6& out, bool& floored) const;

  // 게이트를 거쳐 갱신. force=true 이면 게이트 무시 (재획득 직후 등)
  UpdateInfo update(NominalState& x, MatE& P, const VisionMeas& z, const Mat6& Rz,
                    bool force = false) const;

  // 선체 기준점 B 의 예측 포즈
  void predictBody(const NominalState& x, Vec3& pB, Mat3& RB) const;

  // [pB, θB] 에 대한 오차상태 야코비안 (출력 공분산에도 사용)
  Mat6E bodyPoseJacobian(const NominalState& x) const;

  // 오차 주입 + 공분산 리셋
  static void inject(NominalState& x, MatE& P, const VecE& dx);

 private:
  const FusionConfig& cfg_;
};

}  // namespace psf
