// pkg_sensor_fusion — [모듈 3] EKF 센서융합 SW 모듈
// 공용 타입 / SO(3) 유틸 / 규약
//
// 규약 (모듈 2 pkg_pose_estimation 과 동일하게 맞춤)
//  * 시각: int64 나노초 (PTP 공통 시계). 상대 시간 계산만 double 초로 변환한다.
//  * T_a_b : p_a = R_a_b · p_b + t_a_b  (설계서 T_{a→b} 표기와 동일 의미)
//  * 회전 섭동: 월드 고정축 소회전  R = Exp(δθ) · R̂   (모듈 2 공분산과 같은 정의)
//  * 6×6 포즈 공분산 순서: [x, y, z, rot_x, rot_y, rot_z]  (ROS REP 규약)
//  * 오차상태 순서(15): [δp(0..2), δv(3..5), δθ(6..8), δb_a(9..11), δb_g(12..14)]
#pragma once

#include <Eigen/Core>
#include <Eigen/Geometry>
#include <cmath>
#include <cstdint>
#include <string>

namespace psf {

using Vec3 = Eigen::Vector3d;
using Mat3 = Eigen::Matrix3d;
using Quat = Eigen::Quaterniond;
using Vec6 = Eigen::Matrix<double, 6, 1>;
using Mat6 = Eigen::Matrix<double, 6, 6>;
constexpr int kErr = 15;
using VecE = Eigen::Matrix<double, kErr, 1>;
using MatE = Eigen::Matrix<double, kErr, kErr>;
using Mat6E = Eigen::Matrix<double, 6, kErr>;

using TimeNs = int64_t;
constexpr double kNsToS = 1e-9;
inline double toSec(TimeNs dt) { return static_cast<double>(dt) * kNsToS; }
inline TimeNs fromSec(double s) { return static_cast<TimeNs>(std::llround(s * 1e9)); }

// 오차상태 인덱스
enum : int { IP = 0, IV = 3, ITH = 6, IBA = 9, IBG = 12 };

inline Mat3 skew(const Vec3& v) {
  Mat3 m;
  m << 0, -v.z(), v.y(), v.z(), 0, -v.x(), -v.y(), v.x(), 0;
  return m;
}

inline Mat3 expSO3(const Vec3& w) {
  const double th = w.norm();
  if (th < 1e-9) return Mat3::Identity() + skew(w);
  return Eigen::AngleAxisd(th, w / th).toRotationMatrix();
}

inline Vec3 logSO3(const Mat3& R) {
  Eigen::AngleAxisd aa(R);
  double th = aa.angle();
  Vec3 ax = aa.axis();
  if (th > M_PI) { th = 2 * M_PI - th; ax = -ax; }
  return ax * th;
}

inline Quat normalized(const Quat& q) {
  Quat r = q.normalized();
  if (r.w() < 0) r.coeffs() *= -1.0;
  return r;
}

// ---------------------------------------------------------------------------
// 센서 입력
struct ImuSample {
  TimeNs stamp = 0;     // 측정 시각 (PTP)
  Vec3 acc = Vec3::Zero();   // 비력 [m/s^2], IMU 프레임
  Vec3 gyro = Vec3::Zero();  // 각속도 [rad/s], IMU 프레임
};

struct VisionMeas {
  TimeNs stamp = 0;     // 촬영 시각 (모듈 2 가 입력 PTP stamp 를 그대로 전달)
  Vec3 p = Vec3::Zero();     // T_{W→B} 위치
  Quat q = Quat::Identity(); // T_{W→B} 회전
  Mat6 cov = Mat6::Zero();   // [x,y,z,rx,ry,rz], 월드 고정축 소회전
};

// 명목 상태 (IMU 프레임 기준): 설계서 x = [p, v, q, b_acc, b_gyro]
struct NominalState {
  TimeNs t = 0;
  Vec3 p = Vec3::Zero();   // p_W_I
  Vec3 v = Vec3::Zero();   // v_W_I
  Mat3 R = Mat3::Identity();  // R_W_I
  Vec3 ba = Vec3::Zero();
  Vec3 bg = Vec3::Zero();
};

// ---------------------------------------------------------------------------
enum class FusionMode : uint8_t {
  UNINITIALIZED = 0,
  TRACKING = 1,        // 비전 보정 정상
  DEAD_RECKONING = 2,  // 비전 결손, IMU 단독 (≤ max_dr)
  DR_EXPIRED = 3,      // 안전 제한 시간 초과 (출력은 유지하되 무효 플래그)
  IMU_LOST = 4,        // IMU 타임아웃 — 출력 중단, 인터록
};

inline const char* toString(FusionMode m) {
  switch (m) {
    case FusionMode::UNINITIALIZED: return "UNINITIALIZED";
    case FusionMode::TRACKING: return "TRACKING";
    case FusionMode::DEAD_RECKONING: return "DEAD_RECKONING";
    case FusionMode::DR_EXPIRED: return "DR_EXPIRED";
    case FusionMode::IMU_LOST: return "IMU_LOST";
  }
  return "?";
}

enum class VisionResult : uint8_t {
  ACCEPTED = 0,
  REJECT_MAHALANOBIS = 1,
  REJECT_STALE = 2,        // 이력 버퍼보다 오래됨
  REJECT_INVALID = 3,      // NaN, 비정상 공분산, frame 불일치
  USED_FOR_INIT = 4,
  PENDING = 5,             // IMU 가 아직 해당 시각에 도달하지 않음
  RELOCK = 6,              // 연속 기각 후 재획득(상태 재설정)
  WAIT_INIT = 7,           // 초기화 대기 (IMU 미수신 등)
};

inline const char* toString(VisionResult r) {
  switch (r) {
    case VisionResult::ACCEPTED: return "ACCEPTED";
    case VisionResult::REJECT_MAHALANOBIS: return "REJECT_MAHALANOBIS";
    case VisionResult::REJECT_STALE: return "REJECT_STALE";
    case VisionResult::REJECT_INVALID: return "REJECT_INVALID";
    case VisionResult::USED_FOR_INIT: return "USED_FOR_INIT";
    case VisionResult::PENDING: return "PENDING";
    case VisionResult::RELOCK: return "RELOCK";
    case VisionResult::WAIT_INIT: return "WAIT_INIT";
  }
  return "?";
}

// 출력 (선체 기준점 submarine_base_link)
struct FusedOutput {
  TimeNs stamp = 0;
  Vec3 p = Vec3::Zero();           // p_W_B
  Quat q = Quat::Identity();       // q_W_B
  Vec3 v_body = Vec3::Zero();      // 선속도, child(body) 프레임 (nav_msgs/Odometry 규약)
  Vec3 w_body = Vec3::Zero();      // 각속도, body 프레임
  Mat6 pose_cov = Mat6::Zero();    // [x,y,z,rx,ry,rz] (위치 world, 회전 world 고정축)
  Mat6 twist_cov = Mat6::Zero();   // [vx,vy,vz,wx,wy,wz] body 프레임
  FusionMode mode = FusionMode::UNINITIALIZED;
  bool valid = false;              // DR_EXPIRED / 미초기화이면 false
  double vision_age_s = 0;         // 마지막 승인 비전 stamp 이후 경과
  Vec3 ba = Vec3::Zero(), bg = Vec3::Zero();
};

}  // namespace psf
