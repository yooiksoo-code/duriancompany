// SensorFusionEngine — 예측(IMU) · 보정(비전) · 결손대응 · 지연보상을 묶은 ROS 비의존 엔진
//
// 시간 비동기(Time Skew) 처리 — 설계서 6장 2) 의 구현 방식:
//   tf2 버퍼 보간만으로는 "과거 시각의 측정을 현재 상태에 적용" 하는 문제가 남는다.
//   본 엔진은 IMU 샘플마다 (명목상태, P) 스냅샷을 이력 버퍼에 보관하고,
//   비전 측정이 도착하면 촬영 시각 t_v 의 스냅샷으로 되돌아가 (IMU 보간으로 정확히 t_v 까지 적분)
//   갱신한 뒤, 이후 IMU 샘플로 현재 시각까지 재전파한다 (state-history replay).
//   → 비전 지연(모듈 1+2 처리시간, DDS)이 커져도 필터가 일관성을 유지한다.
#pragma once

#include <vector>

#include "pkg_sensor_fusion/dropout_fallback_handler.hpp"
#include "pkg_sensor_fusion/imu_prediction_engine.hpp"
#include "pkg_sensor_fusion/ring_buffer.hpp"
#include "pkg_sensor_fusion/vision_update_engine.hpp"

namespace psf {

struct FusionStats {
  uint64_t imu_received = 0, imu_rejected = 0, imu_gaps = 0, imu_bridged = 0;
  uint64_t vision_received = 0, vision_accepted = 0, vision_rejected_gate = 0;
  uint64_t vision_stale = 0, vision_invalid = 0, vision_pending_expired = 0;
  uint64_t relocks = 0, inits = 0, replays = 0, replay_steps_max = 0;
  double last_imu_proc_us = 0;     // 예측 1회
  double last_vision_proc_us = 0;  // 보정 + 재전파
  double max_imu_proc_us = 0, max_vision_proc_us = 0;
  double last_mahalanobis2 = 0;
  VisionResult last_vision_result = VisionResult::WAIT_INIT;
  TimeNs last_vision_stamp_applied = 0;  // 마지막으로 반영(승인)된 비전 촬영 시각
  double imu_rate_hz = 0;
};

// 측정 1건의 최종 처리 결과 (보류되었던 측정은 나중에 확정됨)
struct VisionOutcome {
  TimeNs stamp = 0;
  VisionResult result = VisionResult::WAIT_INIT;
  double mahalanobis2 = 0;
};

class SensorFusionEngine {
 public:
  explicit SensorFusionEngine(const FusionConfig& cfg);

  void reset();
  const FusionConfig& config() const { return cfg_; }

  // now: 수신 시각 (같은 시계). 상태가 새 IMU 시각으로 전진했으면 true
  bool addImu(const ImuSample& s, TimeNs now);
  VisionResult addVision(const VisionMeas& z, TimeNs now);
  // 타이머 호출: IMU 타임아웃 감시, 보류 비전 만료 처리
  void tick(TimeNs now);

  bool initialized() const { return initialized_; }
  FusionMode mode() const { return dropout_.mode(); }
  bool interlock() const { return dropout_.interlock(); }

  // 최신 IMU 시각의 융합 출력
  bool latestOutput(FusedOutput& out) const;
  // t 까지 명목상태 외삽 (timer 출력 모드). t ≤ 최신 상태 시각이면 최신 출력
  bool predictOutput(TimeNs t, FusedOutput& out) const;
  // 비전 갱신 직후 추가 발행용 출력: stamp = min(now, 최신 IMU 시각 + IMU 주기/2)
  // → 다음 정규(IMU) 출력 stamp 보다 항상 앞서므로 stamp 단조증가가 깨지지 않는다
  bool visionTriggeredOutput(TimeNs now, FusedOutput& out) const;

  TimeNs stateTime() const { return recs_.empty() ? 0 : recs_.back().x.t; }
  TimeNs lastVisionStamp() const { return last_vision_stamp_; }
  const NominalState& state() const { return recs_.back().x; }
  const MatE& covariance() const { return recs_.back().P; }

  std::vector<FusionEvent> takeEvents() { std::vector<FusionEvent> e; e.swap(events_); return e; }
  // 확정된 비전 처리 결과 (PENDING 은 확정 시점에 나온다)
  std::vector<VisionOutcome> takeVisionOutcomes() {
    std::vector<VisionOutcome> o; o.swap(outcomes_); outcomes_.reserve(16); return o;
  }
  const FusionStats& stats() const { return stats_; }

 private:
  struct Rec {
    ImuSample imu;   // 이 시각의 IMU 측정 (보정된 stamp)
    NominalState x;  // imu.stamp 시각 상태
    MatE P = MatE::Zero();
  };
  struct Pending {
    VisionMeas z;
    Mat6 R = Mat6::Zero();
    TimeNs arrival;
  };
  enum class ApplyKind { UPDATE, RELOCK };

  bool validImu(const ImuSample& s) const;
  VisionResult tryInitialize();
  VisionResult applyAt(const VisionMeas& z, const Mat6& R, ApplyKind kind);
  void forcePendingByExtrapolation(size_t idx);
  void processPending();
  void updateMode();
  bool checkRelock(const VisionMeas& z);
  void bodyFromImu(const VisionMeas& z, Vec3& pI, Mat3& RI) const;
  void fillOutput(const NominalState& x, const MatE& P, const ImuSample& imu, FusedOutput& o) const;
  void trimHistory();

  FusionConfig cfg_;
  ImuPredictionEngine predictor_;
  VisionUpdateEngine updater_;
  DropoutFallbackHandler dropout_;

  RingBuffer<Rec> recs_;
  RingBuffer<ImuSample> pre_init_imu_;
  RingBuffer<Pending> pending_;
  struct Applied { VisionMeas z; Mat6 R = Mat6::Zero(); };
  RingBuffer<Applied> applied_;     // 순서 뒤바뀐 측정 재적용용
  RingBuffer<VisionMeas> rejected_; // 재획득 판단용

  bool initialized_ = false;
  bool imu_lost_ = false;
  bool have_carry_bias_ = false;
  Vec3 carry_ba_ = Vec3::Zero(), carry_bg_ = Vec3::Zero();
  Mat3 carry_Pba_ = Mat3::Identity(), carry_Pbg_ = Mat3::Identity();
  TimeNs last_imu_stamp_ = 0;       // 합성(외삽) 스냅샷 포함 — 역순 판정용
  TimeNs last_real_imu_stamp_ = 0;  // 실측 IMU
  TimeNs last_imu_arrival_ = 0;
  TimeNs last_vision_stamp_ = 0;
  TimeNs reject_streak_start_ = 0;
  bool have_init_candidate_ = false;
  VisionMeas init_candidate_;
  Mat6 init_candidate_R_ = Mat6::Identity();
  TimeNs first_candidate_stamp_ = 0;
  RingBuffer<VisionMeas> init_cands_;  // 초기화 후보 비전 이력 (속도 추정·정지 판정)
  double imu_dt_avg_ = 0.01;

  FusionStats stats_;
  std::vector<FusionEvent> events_;
  std::vector<VisionOutcome> outcomes_;
  void outcome(TimeNs st, VisionResult r) {
    if (outcomes_.size() < 256) outcomes_.push_back({st, r, stats_.last_mahalanobis2});
  }
};

}  // namespace psf
