// [세부 1] IMUPredictionEngine — 오차상태(Error-State) EKF 예측
//
// 명목 상태 x = [p, v, q, b_a, b_g] (설계서 상태벡터와 동일, 16차원)
// 공분산은 15차원 오차상태 δx = [δp, δv, δθ, δb_a, δb_g] 로 유지한다.
// (쿼터니언 4성분에 직접 공분산을 두면 단위노름 제약 때문에 P 가 특이해진다 → 검토 R2)
//
// 연속시간 오차 동역학 (월드 고정축 δθ, R = Exp(δθ)·R̂):
//   δṗ  = δv
//   δv̇  = −[R̂(a_m − b̂_a)]× δθ − R̂ δb_a − R̂ n_a
//   δθ̇  = −R̂ δb_g − R̂ n_g
//   δḃ_a = n_ba,  δḃ_g = n_bg
#pragma once

#include "pkg_sensor_fusion/fusion_config.hpp"

namespace psf {

class ImuPredictionEngine {
 public:
  explicit ImuPredictionEngine(const FusionConfig& cfg) : cfg_(cfg) {}

  // [x.t, t1] 구간을 IMU 측정 (a0,w0)@x.t → (a1,w1)@t1 (구간 내 선형) 로 적분한다.
  // 중점(midpoint) 적분, Φ ≈ I + AΔt + ½(AΔt)²
  void propagate(NominalState& x, MatE& P, const Vec3& a0, const Vec3& w0, const Vec3& a1,
                 const Vec3& w1, TimeNs t1) const;

  // 오차상태 전이행렬 Φ (구간 평균 IMU 값 기준) — propagate 내부와 같은 식, 시험에서 수치미분과 대조
  MatE transition(const NominalState& x, const Vec3& a_mean, const Vec3& w_mean, double dt) const;

  // 명목 상태만 (출력 외삽용)
  void propagateNominal(NominalState& x, const Vec3& a, const Vec3& w, TimeNs t1) const;

 private:
  const FusionConfig& cfg_;
};

// 두 IMU 샘플 사이 시각 t 의 선형보간
inline void interpolateImu(const ImuSample& s0, const ImuSample& s1, TimeNs t, Vec3& a, Vec3& w) {
  const TimeNs span = s1.stamp - s0.stamp;
  if (span <= 0) { a = s1.acc; w = s1.gyro; return; }
  double u = static_cast<double>(t - s0.stamp) / static_cast<double>(span);
  u = std::min(1.0, std::max(0.0, u));
  a = (1.0 - u) * s0.acc + u * s1.acc;
  w = (1.0 - u) * s0.gyro + u * s1.gyro;
}

}  // namespace psf
