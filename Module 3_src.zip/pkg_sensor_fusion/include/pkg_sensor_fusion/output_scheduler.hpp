// 출력 발행 규칙 — ROS 노드와 오프라인 벤치가 같은 규칙을 쓰도록 분리
//   정규 출력 : IMU 로 상태가 전진할 때, output_rate_hz 간격 이상이면 (0 이면 매 IMU)
//   비전 출력 : output_on_vision_update 이고 비전이 반영되었을 때 즉시 (지연 KPI)
//   stamp 는 항상 단조 증가
#pragma once

#include "pkg_sensor_fusion/sensor_fusion_engine.hpp"

namespace psf {

class OutputScheduler {
 public:
  explicit OutputScheduler(const FusionConfig& cfg)
      : min_dt_(cfg.output_rate_hz > 0 ? 0.75 / cfg.output_rate_hz : 0.0), on_vision_(cfg.output_on_vision_update) {}

  void reset() { last_reg_ = -1; last_stamp_ = 0; }

  // addImu 직후. vision_applied: 이 IMU 로 보류 비전이 반영되었는지
  bool onImu(const SensorFusionEngine& eng, bool advanced, bool vision_applied, FusedOutput& o, bool& regular) {
    regular = false;
    if (!advanced) return false;
    const double t = toSec(eng.stateTime());
    regular = last_reg_ < 0 || t - last_reg_ >= min_dt_ - 1e-6;
    if (!(regular || (on_vision_ && vision_applied))) return false;
    if (!eng.latestOutput(o) || o.stamp <= last_stamp_) { regular = false; return false; }
    if (regular) last_reg_ = t;
    last_stamp_ = o.stamp;
    return true;
  }

  // addVision 직후 (res == ACCEPTED 일 때만 발행)
  bool onVision(const SensorFusionEngine& eng, VisionResult res, TimeNs now, FusedOutput& o) {
    if (!on_vision_ || res != VisionResult::ACCEPTED) return false;
    if (!eng.visionTriggeredOutput(now, o) || o.stamp <= last_stamp_) return false;
    last_stamp_ = o.stamp;
    return true;
  }

 private:
  double min_dt_;
  bool on_vision_;
  double last_reg_ = -1;
  TimeNs last_stamp_ = 0;
};

}  // namespace psf
