// [모듈 3] sensor_fusion_node — ROS2 LifecycleNode (component)
//   입력 : /sub_imu/data (sensor_msgs/Imu, ≥100 Hz), /sub_pose_vision (PoseWithCovarianceStamped, 30~60 Hz)
//   출력 : /sub_pose_filtered (nav_msgs/Odometry), /sensor_fusion/diagnostics (inhaul_msgs/FusionDiagnostics)
//          /hmi/fusion_alerts (std_msgs/String "CODE|info"), /sensor_fusion/safety_interlock (std_msgs/Bool, latched)
#pragma once

#include <deque>
#include <memory>

#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <inhaul_msgs/msg/fusion_diagnostics.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <std_msgs/msg/bool.hpp>
#include <std_msgs/msg/string.hpp>
#include <tf2_ros/transform_broadcaster.h>

#include "pkg_sensor_fusion/output_scheduler.hpp"

namespace psf {

class SensorFusionNode : public rclcpp_lifecycle::LifecycleNode {
 public:
  using CallbackReturn = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn;
  explicit SensorFusionNode(const rclcpp::NodeOptions& options = rclcpp::NodeOptions());

  CallbackReturn on_configure(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_activate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_deactivate(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_cleanup(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_shutdown(const rclcpp_lifecycle::State&) override;
  CallbackReturn on_error(const rclcpp_lifecycle::State&) override;

 private:
  void declareParameters();
  FusionConfig readConfig();
  void onImu(const sensor_msgs::msg::Imu::ConstSharedPtr& msg);
  void onVision(const geometry_msgs::msg::PoseWithCovarianceStamped::ConstSharedPtr& msg);
  void onTick();
  void onDiagnostics();
  void publishOutput(const FusedOutput& o);
  void flushEvents();
  TimeNs nowNs() { return this->now().nanoseconds(); }

  FusionConfig cfg_;
  std::unique_ptr<SensorFusionEngine> engine_;
  std::unique_ptr<OutputScheduler> sched_;
  std::string world_frame_, child_frame_;
  bool publish_tf_ = false;
  bool exit_on_error_ = true;

  rclcpp::CallbackGroup::SharedPtr cbg_;
  rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr sub_imu_;
  rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr sub_vision_;
  rclcpp_lifecycle::LifecyclePublisher<nav_msgs::msg::Odometry>::SharedPtr pub_odom_;
  rclcpp_lifecycle::LifecyclePublisher<inhaul_msgs::msg::FusionDiagnostics>::SharedPtr pub_diag_;
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::String>::SharedPtr pub_alert_;
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::Bool>::SharedPtr pub_interlock_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_;
  rclcpp::TimerBase::SharedPtr tick_timer_, diag_timer_, autostart_timer_;

  // 진단 집계
  TimeNs last_applied_reported_ = 0;
  double e2e_last_ms_ = 0, e2e_win_max_ms_ = 0;
  std::deque<TimeNs> pub_times_;
  bool last_interlock_ = false;
  uint64_t frame_mismatch_ = 0;
  std::string world_frame_warned_;
};

}  // namespace psf
