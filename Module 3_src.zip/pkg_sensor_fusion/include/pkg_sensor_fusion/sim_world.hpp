// 합성 시험 환경: 레일 테스트베드 궤적 + 6축 IMU + 비전 6DoF (gtest · 벤치 · ROS 합성 발행기 공용)
//
// 궤적: 레일 2.5 m 왕복 (최고 0.3 m/s, 모듈 2 벤치 S1 과 같은 조건) + 부유 선체 미소운동
//       (heave/sway 수 mm, roll/pitch/yaw 0.3~0.5°)
// IMU : 레버암·장착회전 반영한 비력/각속도 + 백색잡음 + 바이어스 랜덤워크 + stamp 지터
// 비전: 월드축 위치잡음 + 월드 고정축 회전잡음, 촬영 stamp, 처리지연(모듈 1+2) 모사
#pragma once

#include <random>

#include "pkg_sensor_fusion/fusion_config.hpp"

namespace psf::sim {

struct TrajectoryParams {
  double rail_length = 2.5, v_max = 0.3;
  Vec3 origin{0.0, 0.0, 0.0};         // 선체 기준점 초기 위치 (dock_world_frame)
  double yaw0 = 0.0;
  double heave_amp = 0.004, heave_hz = 0.20;
  double sway_amp = 0.003, sway_hz = 0.13;
  double roll_amp = 0.5 * M_PI / 180, roll_hz = 0.25;
  double pitch_amp = 0.3 * M_PI / 180, pitch_hz = 0.17;
  double yaw_amp = 0.4 * M_PI / 180, yaw_hz = 0.08;
  double t_start_motion = 1.0;        // 처음 1 s 정지 (초기 바이어스 추정 시험)
  bool static_only = false;
};

struct BodyTruth {
  Vec3 p, v, a;   // 선체 기준점, world
  Mat3 R;         // R_W_B
  Vec3 w_w, alpha_w;  // 각속도/각가속도, world
};

class Trajectory {
 public:
  explicit Trajectory(const TrajectoryParams& p = {}) : P_(p) {}
  const TrajectoryParams& params() const { return P_; }

  Mat3 rot(double t) const {
    const double m = motionScale(t);
    const double r = m * P_.roll_amp * std::sin(2 * M_PI * P_.roll_hz * t);
    const double p = m * P_.pitch_amp * std::sin(2 * M_PI * P_.pitch_hz * t + 0.7);
    const double y = P_.yaw0 + m * P_.yaw_amp * std::sin(2 * M_PI * P_.yaw_hz * t + 1.3);
    return (Eigen::AngleAxisd(y, Vec3::UnitZ()) * Eigen::AngleAxisd(p, Vec3::UnitY()) *
            Eigen::AngleAxisd(r, Vec3::UnitX())).toRotationMatrix();
  }
  Vec3 pos(double t) const {
    const double L = P_.rail_length, W = 2 * P_.v_max / L;
    const double tm = std::max(0.0, t - P_.t_start_motion);
    const double m = motionScale(t);
    Vec3 p = P_.origin;
    if (!P_.static_only) p.x() += 0.5 * L * (1 - std::cos(W * tm));
    p.y() += m * P_.sway_amp * std::sin(2 * M_PI * P_.sway_hz * t);
    p.z() += m * P_.heave_amp * std::sin(2 * M_PI * P_.heave_hz * t + 0.4);
    return p;
  }
  BodyTruth truth(double t) const {
    BodyTruth b;
    const double h = 1e-3;
    b.p = pos(t);
    b.v = (pos(t + h) - pos(t - h)) / (2 * h);
    b.a = (pos(t + h) - 2 * b.p + pos(t - h)) / (h * h);
    b.R = rot(t);
    b.w_w = omega(t);
    b.alpha_w = (omega(t + h) - omega(t - h)) / (2 * h);
    return b;
  }

 private:
  // 정지 → 운동 전환을 매끄럽게 (가속도 불연속 방지)
  double motionScale(double t) const {
    if (P_.static_only) return 0.0;
    const double u = (t - P_.t_start_motion) / 2.0;
    if (u <= 0) return 0.0;
    if (u >= 1) return 1.0;
    return u * u * (3 - 2 * u);
  }
  Vec3 omega(double t) const {
    const double h = 1e-4;
    return logSO3(rot(t + h) * rot(t - h).transpose()) / (2 * h);
  }
  TrajectoryParams P_;
};

struct ImuSimParams {
  double rate_hz = 200.0;
  ImuNoiseParams noise;               // 실제 잡음 (필터 설정과 다르게 줄 수 있음)
  Vec3 ba0{0.08, -0.05, 0.10};        // 초기 가속도 바이어스 [m/s^2] (~10 mg)
  Vec3 bg0{1.5e-3, -1.0e-3, 0.8e-3};  // 초기 자이로 바이어스 [rad/s] (~0.1°/s)
  double stamp_jitter_s = 50e-6;      // 드라이버 stamp 지터
  double latency_s = 0.5e-3;          // 수신 지연
};

struct VisionSimParams {
  double rate_hz = 60.0;
  Vec3 sigma_pos{0.15e-3, 0.15e-3, 0.40e-3};            // [m]  (모듈 2 S7 σ0.2mm 조건 수준)
  Vec3 sigma_rot{0.010 * M_PI / 180, 0.010 * M_PI / 180, 0.004 * M_PI / 180};
  double cov_report_scale = 1.0;      // 모듈 2 가 보고하는 공분산 / 실제 공분산
  // 모듈 1 (목표HW KPI 평균 ≤4 ms) + 모듈 2 (p99 0.1 ms) + DDS. 개발 컨테이너 실측보다 목표HW 기준
  double latency_min_s = 0.003, latency_max_s = 0.007;
};

// 상태를 가진 센서 모델 (바이어스 랜덤워크)
class SensorSim {
 public:
  SensorSim(const Trajectory& tr, const FusionConfig& mount, const ImuSimParams& ip,
            const VisionSimParams& vp, uint64_t seed = 1)
      : tr_(tr), mount_(mount), ip_(ip), vp_(vp), rng_(seed), ba_(ip.ba0), bg_(ip.bg0) {}

  ImuSample imu(double t) {
    if (last_t_ >= 0) {
      const double dt = t - last_t_;
      ba_ += ip_.noise.acc_bias_rw * std::sqrt(dt) * gauss3();
      bg_ += ip_.noise.gyro_bias_rw * std::sqrt(dt) * gauss3();
    }
    last_t_ = t;
    const BodyTruth b = tr_.truth(t);
    const Mat3 R_BI = mount_.q_body_imu.normalized().toRotationMatrix();
    const Mat3 R_WI = b.R * R_BI;
    const Vec3 r_w = b.R * mount_.t_body_imu;
    const Vec3 a_I = b.a + b.alpha_w.cross(r_w) + b.w_w.cross(b.w_w.cross(r_w));
    const double sq = std::sqrt(ip_.rate_hz);
    ImuSample s;
    s.stamp = fromSec(t + ip_.stamp_jitter_s * n01_(rng_));
    s.acc = R_WI.transpose() * (a_I - mount_.gravity_w) + ba_ + ip_.noise.acc_noise * sq * gauss3();
    s.gyro = R_WI.transpose() * b.w_w + bg_ + ip_.noise.gyro_noise * sq * gauss3();
    return s;
  }

  VisionMeas vision(double t) {
    const BodyTruth b = tr_.truth(t);
    VisionMeas z;
    z.stamp = fromSec(t);
    z.p = b.p + vp_.sigma_pos.cwiseProduct(gauss3());
    z.q = normalized(Quat(expSO3(vp_.sigma_rot.cwiseProduct(gauss3())) * b.R));
    z.cov.setZero();
    z.cov.diagonal().head<3>() = vp_.sigma_pos.cwiseAbs2() * vp_.cov_report_scale;
    z.cov.diagonal().tail<3>() = vp_.sigma_rot.cwiseAbs2() * vp_.cov_report_scale;
    return z;
  }
  double visionLatency() {
    std::uniform_real_distribution<double> u(vp_.latency_min_s, vp_.latency_max_s);
    return u(rng_);
  }
  Vec3 gauss3() { return Vec3(n01_(rng_), n01_(rng_), n01_(rng_)); }
  double uniform() { return std::uniform_real_distribution<double>(0, 1)(rng_); }
  std::mt19937_64& rng() { return rng_; }
  const Vec3& trueBa() const { return ba_; }
  const Vec3& trueBg() const { return bg_; }
  const ImuSimParams& imuParams() const { return ip_; }
  const VisionSimParams& visionParams() const { return vp_; }

 private:
  const Trajectory& tr_;
  const FusionConfig& mount_;
  ImuSimParams ip_;
  VisionSimParams vp_;
  std::mt19937_64 rng_;
  std::normal_distribution<double> n01_{0.0, 1.0};
  Vec3 ba_, bg_;
  double last_t_ = -1;
};

// 기본 장착 (설계 초기값 — 실제 CAD 로 교체): IMU 가 선체 기준점에서 0.6 m 앞, 0.15 m 우, 0.35 m 아래, Z축 90° 회전
inline void applyDefaultMount(FusionConfig& c) {
  c.t_body_imu = Vec3(0.60, -0.15, -0.35);
  c.q_body_imu = Quat(Eigen::AngleAxisd(M_PI / 2, Vec3::UnitZ()));
}

}  // namespace psf::sim
