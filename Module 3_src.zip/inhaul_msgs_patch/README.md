# inhaul_msgs 0.3.0 패치 (모듈 3)

모듈 2 가 배포한 `inhaul_msgs` 0.2.0 에 `msg/FusionDiagnostics.msg` 하나만 추가합니다. 기존 메시지는 바뀌지 않습니다.

1. `msg/FusionDiagnostics.msg` 를 `inhaul_ws/src/inhaul_msgs/msg/` 에 복사
2. `inhaul_msgs/CMakeLists.txt` 의 `rosidl_generate_interfaces(...)` 목록에 `"msg/FusionDiagnostics.msg"` 추가
   (의존성 `std_msgs`, `geometry_msgs` 는 이미 있음 — 없으면 `DEPENDENCIES` 에 추가)
3. `package.xml` 버전을 0.3.0 으로 올리고 `colcon build --packages-select inhaul_msgs`
