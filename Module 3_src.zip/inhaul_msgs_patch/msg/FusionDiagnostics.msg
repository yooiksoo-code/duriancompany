# [모듈 3] sensor_fusion_node 진단 (inhaul_msgs 0.3.0 신규, 기존 메시지 변경 없음)
std_msgs/Header header            # stamp = 발행 시각, frame_id = dock_world_frame

uint8 MODE_UNINITIALIZED = 0
uint8 MODE_TRACKING = 1
uint8 MODE_DEAD_RECKONING = 2
uint8 MODE_DR_EXPIRED = 3
uint8 MODE_IMU_LOST = 4
uint8 mode
string mode_name
bool output_valid                 # TRACKING / DEAD_RECKONING 일 때 true
bool interlock                    # IMU_LOST / DR_EXPIRED → 속도 지령 0 유도

float64 vision_age_ms             # 마지막 승인 비전 촬영시각 → 필터 상태시각
string last_vision_result         # ACCEPTED, REJECT_MAHALANOBIS, PENDING, ...
float64 last_mahalanobis2         # 마지막 비전 혁신의 d² (χ²₆)

uint64 imu_received
uint64 imu_rejected
uint64 imu_gaps                   # 수신 간격 > imu_timeout
uint64 vision_received
uint64 vision_accepted
uint64 vision_rejected_gate
uint64 vision_stale
uint64 vision_invalid
uint64 relocks
uint64 inits
float64 imu_rate_hz
float64 output_rate_hz            # 최근 1 s 발행률

float64 imu_proc_us               # 예측 1회 (최근)
float64 vision_proc_us            # 보정 + 재전파 (최근)
float64 max_vision_proc_us        # 기동 후 최대
float64 e2e_latency_ms            # 최근 반영 비전의 촬영 → 융합 출력 발행 (PTP 공통시계 가정)
float64 e2e_latency_max_ms        # 최근 1 s 최대

geometry_msgs/Vector3 acc_bias    # [m/s^2]
geometry_msgs/Vector3 gyro_bias   # [rad/s]
geometry_msgs/Vector3 pos_sigma   # 1σ [m]
geometry_msgs/Vector3 rot_sigma_deg
geometry_msgs/Vector3 rpy_deg     # 융합 자세 roll/pitch/yaw (ZYX)
